/* DUPLICATOR-LITE (PHP BUILD MODE) MYSQL SCRIPT CREATED ON : 2017-12-29 18:19:03 */

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

SET FOREIGN_KEY_CHECKS = 0;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;

;


/* INSERT TABLE DATA: wp_weforms_entrymeta */
INSERT INTO `wp_weforms_entrymeta` VALUES("1", "1", "name", "Joe| | Blow");
INSERT INTO `wp_weforms_entrymeta` VALUES("2", "1", "email", "jblow@gmail.com");
INSERT INTO `wp_weforms_entrymeta` VALUES("3", "1", "message", "Hi!!!");
INSERT INTO `wp_weforms_entrymeta` VALUES("4", "2", "name", "Joe| | ");
INSERT INTO `wp_weforms_entrymeta` VALUES("5", "2", "email", "jblow@gmail.com");
INSERT INTO `wp_weforms_entrymeta` VALUES("6", "2", "message", "This is a test.");
INSERT INTO `wp_weforms_entrymeta` VALUES("7", "3", "name", "Edward| | Barber");
INSERT INTO `wp_weforms_entrymeta` VALUES("8", "3", "email", "barber.ed.5@gmail.com");
INSERT INTO `wp_weforms_entrymeta` VALUES("9", "3", "message", "This is a test...again.");
INSERT INTO `wp_weforms_entrymeta` VALUES("10", "4", "name", "Joe| | Blow");
INSERT INTO `wp_weforms_entrymeta` VALUES("11", "4", "email", "jblow@gmail.com");
INSERT INTO `wp_weforms_entrymeta` VALUES("12", "4", "message", "wdadawda");
INSERT INTO `wp_weforms_entrymeta` VALUES("13", "5", "name", "w| | d");
INSERT INTO `wp_weforms_entrymeta` VALUES("14", "5", "email", "jblow@gmail.com");
INSERT INTO `wp_weforms_entrymeta` VALUES("15", "5", "message", "awddaw");

/* INSERT TABLE DATA: wp_weforms_entries */
INSERT INTO `wp_weforms_entries` VALUES("1", "40", "1", "", "Google Chrome/Windows", "http://localhost:8000/?page_id=11", "publish", "2017-12-05 09:43:43");
INSERT INTO `wp_weforms_entries` VALUES("2", "40", "1", "", "Google Chrome/Windows", "http://localhost:8000/?page_id=11", "publish", "2017-12-05 09:44:56");
INSERT INTO `wp_weforms_entries` VALUES("3", "40", "1", "", "Google Chrome/Windows", "http://localhost:8000/?page_id=11", "publish", "2017-12-05 09:45:45");
INSERT INTO `wp_weforms_entries` VALUES("4", "40", "1", "", "Google Chrome/Windows", "http://localhost:8000/?page_id=11", "publish", "2017-12-19 19:15:03");
INSERT INTO `wp_weforms_entries` VALUES("5", "40", "1", "", "Mozilla Firefox/Windows", "http://localhost:8000/?page_id=11", "publish", "2017-12-29 13:14:04");

/* INSERT TABLE DATA: wp_users */
INSERT INTO `wp_users` VALUES("1", "edbarber", "$P$BA6uz9XRRaFBFVaSMEv2K9myqZ6GO11", "edbarber", "ebarber5969@conestogac.on.ca", "", "2017-12-04 23:06:32", "", "0", "edbarber");
INSERT INTO `wp_users` VALUES("2", "amrinder.kalsi13", "$P$BWnv1ihUQC.bLKyDb6ra7EA7ooToFj/", "amrinder-kalsi13", "amrinder.kalsi13@gmail.com", "", "2017-12-04 23:34:32", "1512430475:$P$B2Y.mRdda3wJlWXy0r5JLHB5bU/6ja.", "0", "amrinder.kalsi13");
INSERT INTO `wp_users` VALUES("3", "murzia4ka", "$P$BR94bq7htOCdEZ5uvcRJaLL5jfIN1J.", "murzia4ka", "murzia4ka@gmail.com", "", "2017-12-04 23:35:16", "1512430519:$P$BmbCM5rKKIqHGdB8/GtZlu/tcg89RO1", "0", "murzia4ka");
INSERT INTO `wp_users` VALUES("4", "iraidak", "$P$BR9qbmf8PAZkgtPzLdK4zb.v2AuWZp/", "iraidak", "iraidak@gmail.com", "", "2017-12-04 23:36:03", "1512430566:$P$Bo8cS104qm2aOS0pVlm654hOjkAujS1", "0", "iraidak");

/* INSERT TABLE DATA: wp_usermeta */
INSERT INTO `wp_usermeta` VALUES("1", "1", "nickname", "edbarber");
INSERT INTO `wp_usermeta` VALUES("2", "1", "first_name", "");
INSERT INTO `wp_usermeta` VALUES("3", "1", "last_name", "");
INSERT INTO `wp_usermeta` VALUES("4", "1", "description", "");
INSERT INTO `wp_usermeta` VALUES("5", "1", "rich_editing", "true");
INSERT INTO `wp_usermeta` VALUES("6", "1", "syntax_highlighting", "true");
INSERT INTO `wp_usermeta` VALUES("7", "1", "comment_shortcuts", "false");
INSERT INTO `wp_usermeta` VALUES("8", "1", "admin_color", "fresh");
INSERT INTO `wp_usermeta` VALUES("9", "1", "use_ssl", "0");
INSERT INTO `wp_usermeta` VALUES("10", "1", "show_admin_bar_front", "true");
INSERT INTO `wp_usermeta` VALUES("11", "1", "locale", "");
INSERT INTO `wp_usermeta` VALUES("12", "1", "wp_capabilities", "a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13", "1", "wp_user_level", "10");
INSERT INTO `wp_usermeta` VALUES("14", "1", "dismissed_wp_pointers", "");
INSERT INTO `wp_usermeta` VALUES("15", "1", "show_welcome_panel", "1");
INSERT INTO `wp_usermeta` VALUES("16", "1", "session_tokens", "a:3:{s:64:\"14c7d1b592fc252b118083271435d812fff99c7fc9c33b41fe492bfdb2a969de\";a:4:{s:10:\"expiration\";i:1514742256;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36\";s:5:\"login\";i:1514569456;}s:64:\"b8fdaa90b5a893578b8c3be79c5448c4e7a50e7e63cca2a667fb8dfeaee4cb03\";a:4:{s:10:\"expiration\";i:1514744025;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0\";s:5:\"login\";i:1514571225;}s:64:\"255577870596c408a35e9309025a8c604c3bb31d9cb49513af14ba7409ad1d07\";a:4:{s:10:\"expiration\";i:1514744302;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:129:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299\";s:5:\"login\";i:1514571502;}}");
INSERT INTO `wp_usermeta` VALUES("17", "1", "wp_user-settings", "editor=html&libraryContent=browse");
INSERT INTO `wp_usermeta` VALUES("18", "1", "wp_user-settings-time", "1512488185");
INSERT INTO `wp_usermeta` VALUES("19", "1", "wp_dashboard_quick_press_last_post_id", "202");
INSERT INTO `wp_usermeta` VALUES("20", "1", "community-events-location", "a:1:{s:2:\"ip\";s:2:\"::\";}");
INSERT INTO `wp_usermeta` VALUES("21", "1", "managenav-menuscolumnshidden", "a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("22", "1", "metaboxhidden_nav-menus", "a:2:{i:0;s:12:\"add-post_tag\";i:1;s:15:\"add-post_format\";}");
INSERT INTO `wp_usermeta` VALUES("23", "2", "nickname", "amrinder.kalsi13");
INSERT INTO `wp_usermeta` VALUES("24", "2", "first_name", "");
INSERT INTO `wp_usermeta` VALUES("25", "2", "last_name", "");
INSERT INTO `wp_usermeta` VALUES("26", "2", "description", "");
INSERT INTO `wp_usermeta` VALUES("27", "2", "rich_editing", "true");
INSERT INTO `wp_usermeta` VALUES("28", "2", "syntax_highlighting", "true");
INSERT INTO `wp_usermeta` VALUES("29", "2", "comment_shortcuts", "false");
INSERT INTO `wp_usermeta` VALUES("30", "2", "admin_color", "fresh");
INSERT INTO `wp_usermeta` VALUES("31", "2", "use_ssl", "0");
INSERT INTO `wp_usermeta` VALUES("32", "2", "show_admin_bar_front", "true");
INSERT INTO `wp_usermeta` VALUES("33", "2", "locale", "");
INSERT INTO `wp_usermeta` VALUES("34", "2", "wp_capabilities", "a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("35", "2", "wp_user_level", "10");
INSERT INTO `wp_usermeta` VALUES("36", "2", "dismissed_wp_pointers", "");
INSERT INTO `wp_usermeta` VALUES("37", "3", "nickname", "murzia4ka");
INSERT INTO `wp_usermeta` VALUES("38", "3", "first_name", "");
INSERT INTO `wp_usermeta` VALUES("39", "3", "last_name", "");
INSERT INTO `wp_usermeta` VALUES("40", "3", "description", "");
INSERT INTO `wp_usermeta` VALUES("41", "3", "rich_editing", "true");
INSERT INTO `wp_usermeta` VALUES("42", "3", "syntax_highlighting", "true");
INSERT INTO `wp_usermeta` VALUES("43", "3", "comment_shortcuts", "false");
INSERT INTO `wp_usermeta` VALUES("44", "3", "admin_color", "fresh");
INSERT INTO `wp_usermeta` VALUES("45", "3", "use_ssl", "0");
INSERT INTO `wp_usermeta` VALUES("46", "3", "show_admin_bar_front", "true");
INSERT INTO `wp_usermeta` VALUES("47", "3", "locale", "");
INSERT INTO `wp_usermeta` VALUES("48", "3", "wp_capabilities", "a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("49", "3", "wp_user_level", "10");
INSERT INTO `wp_usermeta` VALUES("50", "3", "dismissed_wp_pointers", "");
INSERT INTO `wp_usermeta` VALUES("51", "4", "nickname", "iraidak");
INSERT INTO `wp_usermeta` VALUES("52", "4", "first_name", "");
INSERT INTO `wp_usermeta` VALUES("53", "4", "last_name", "");
INSERT INTO `wp_usermeta` VALUES("54", "4", "description", "");
INSERT INTO `wp_usermeta` VALUES("55", "4", "rich_editing", "true");
INSERT INTO `wp_usermeta` VALUES("56", "4", "syntax_highlighting", "true");
INSERT INTO `wp_usermeta` VALUES("57", "4", "comment_shortcuts", "false");
INSERT INTO `wp_usermeta` VALUES("58", "4", "admin_color", "fresh");
INSERT INTO `wp_usermeta` VALUES("59", "4", "use_ssl", "0");
INSERT INTO `wp_usermeta` VALUES("60", "4", "show_admin_bar_front", "true");
INSERT INTO `wp_usermeta` VALUES("61", "4", "locale", "");
INSERT INTO `wp_usermeta` VALUES("62", "4", "wp_capabilities", "a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("63", "4", "wp_user_level", "10");
INSERT INTO `wp_usermeta` VALUES("64", "4", "dismissed_wp_pointers", "");
INSERT INTO `wp_usermeta` VALUES("65", "2", "account_status", "approved");
INSERT INTO `wp_usermeta` VALUES("66", "2", "role", "admin");
INSERT INTO `wp_usermeta` VALUES("67", "1", "account_status", "approved");
INSERT INTO `wp_usermeta` VALUES("68", "1", "role", "admin");
INSERT INTO `wp_usermeta` VALUES("69", "4", "account_status", "approved");
INSERT INTO `wp_usermeta` VALUES("70", "4", "role", "admin");
INSERT INTO `wp_usermeta` VALUES("71", "3", "account_status", "approved");
INSERT INTO `wp_usermeta` VALUES("72", "3", "role", "admin");
INSERT INTO `wp_usermeta` VALUES("73", "1", "um_user_profile_url_slug_user_login", "edbarber");
INSERT INTO `wp_usermeta` VALUES("74", "1", "um_account_secure_fields", "a:0:{}");
INSERT INTO `wp_usermeta` VALUES("75", "4", "um_user_profile_url_slug_user_login", "iraidak");
INSERT INTO `wp_usermeta` VALUES("76", "3", "um_user_profile_url_slug_user_login", "murzia4ka");
INSERT INTO `wp_usermeta` VALUES("77", "2", "um_user_profile_url_slug_user_login", "amrinder-kalsi13");
INSERT INTO `wp_usermeta` VALUES("128", "1", "_um_last_login", "1512469021");
INSERT INTO `wp_usermeta` VALUES("129", "1", "wppb_pms_cross_promo_dismiss_notification", "true");
INSERT INTO `wp_usermeta` VALUES("130", "1", "closedpostboxes_profile-builder_page_manage-fields", "a:0:{}");
INSERT INTO `wp_usermeta` VALUES("131", "1", "metaboxhidden_profile-builder_page_manage-fields", "a:0:{}");
INSERT INTO `wp_usermeta` VALUES("160", "4", "session_tokens", "a:1:{s:64:\"1bfceb930069a6749653b616483551c6faf14c1a87461fc42c07c91d3a1dee86\";a:4:{s:10:\"expiration\";i:1514061311;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36\";s:5:\"login\";i:1513888511;}}");
INSERT INTO `wp_usermeta` VALUES("161", "4", "wp_dashboard_quick_press_last_post_id", "91");
INSERT INTO `wp_usermeta` VALUES("162", "4", "community-events-location", "a:1:{s:2:\"ip\";s:2:\"::\";}");
INSERT INTO `wp_usermeta` VALUES("163", "4", "wppb_pms_cross_promo_dismiss_notification", "true");
INSERT INTO `wp_usermeta` VALUES("164", "4", "wp_user-settings", "editor=html&libraryContent=browse&align=left");
INSERT INTO `wp_usermeta` VALUES("165", "4", "wp_user-settings-time", "1513651270");
INSERT INTO `wp_usermeta` VALUES("167", "3", "wp_dashboard_quick_press_last_post_id", "191");
INSERT INTO `wp_usermeta` VALUES("168", "3", "community-events-location", "a:1:{s:2:\"ip\";s:2:\"::\";}");
INSERT INTO `wp_usermeta` VALUES("169", "3", "session_tokens", "a:1:{s:64:\"d818e3fcbf1b4bb0925a64741cb5f20cc7dd6dd087ec46328708ebc729ad1dad\";a:4:{s:10:\"expiration\";i:1514049372;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36\";s:5:\"login\";i:1513876572;}}");
INSERT INTO `wp_usermeta` VALUES("170", "3", "wp_user-settings", "editor=html");
INSERT INTO `wp_usermeta` VALUES("171", "3", "wp_user-settings-time", "1513878116");

/* INSERT TABLE DATA: wp_terms */
INSERT INTO `wp_terms` VALUES("1", "Uncategorised", "uncategorized", "0");
INSERT INTO `wp_terms` VALUES("2", "Main Menu", "main-menu", "0");

/* INSERT TABLE DATA: wp_term_taxonomy */
INSERT INTO `wp_term_taxonomy` VALUES("1", "1", "category", "", "0", "3");
INSERT INTO `wp_term_taxonomy` VALUES("2", "2", "nav_menu", "", "0", "8");

/* INSERT TABLE DATA: wp_term_relationships */
INSERT INTO `wp_term_relationships` VALUES("17", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("28", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("29", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("30", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("31", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("32", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("33", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("34", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("35", "2", "0");
INSERT INTO `wp_term_relationships` VALUES("55", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("57", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("59", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("61", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("63", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("65", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("67", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("136", "1", "0");
INSERT INTO `wp_term_relationships` VALUES("140", "1", "0");

/* INSERT TABLE DATA: wp_posts */
INSERT INTO `wp_posts` VALUES("6", "1", "2017-12-04 18:16:42", "2017-12-04 23:16:42", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=15\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=19\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=11\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "publish", "closed", "closed", "", "home", "", "", "2017-12-21 15:59:10", "2017-12-21 20:59:10", "", "0", "http://localhost:8000/?page_id=6", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("7", "1", "2017-12-04 18:16:42", "2017-12-04 23:16:42", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas a faucibus dui. Pellentesque ac lobortis dui, sit amet faucibus nunc. In semper sem sit amet nibh dapibus tempus. Phasellus efficitur gravida ante, a tincidunt nibh gravida vel. Integer facilisis risus a mattis sollicitudin. Praesent sed malesuada velit. Fusce commodo pretium porta. Praesent pretium, eros ut congue malesuada, urna orci cursus enim, vitae mollis turpis nisi ac nibh. Nullam auctor velit nec turpis interdum lacinia. Maecenas efficitur, ex nec vulputate iaculis, urna risus aliquet orci, vel bibendum enim ex a lacus. Nullam nec cursus nulla. Suspendisse potenti. Maecenas lacinia ex purus, ut laoreet sem fermentum vel.", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-04 18:16:42", "2017-12-04 23:16:42", "", "6", "http://localhost:8000/?p=7", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("8", "1", "2017-12-04 18:17:13", "2017-12-04 23:17:13", "Website description goes here.", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-04 18:17:13", "2017-12-04 23:17:13", "", "6", "http://localhost:8000/?p=8", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("9", "1", "2017-12-04 18:18:14", "2017-12-04 23:18:14", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1><br>

<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>

<h3 class=\"p1\" style=\"text-align: center;\">The Arabian Peninsula</h3>
<p class=\"p1\">Coffee cultivation and trade began on the Arabian Peninsula.  By the 15th century, coffee was being grown in the Yemeni district of Arabia and by the 16th century it was known in Persia, Egypt, Syria, and Turkey.</p>
<p class=\"p1\">Coffee was not only enjoyed in homes, but also in the many public coffee houses — called <em>qahveh khaneh</em> — which began to appear in cities across the Near East. The popularity of the coffee houses was unequaled and people frequented them for all kinds of social activity.</p>
<p class=\"p2\">Not only did the patrons drink coffee and engage in conversation, but they also listened to music, watched performers, played chess and kept current on the news.  Coffee houses quickly became such an important center for the exchange of information that they were often referred to as “Schools of the Wise.”</p>
<p class=\"p1\">With thousands of pilgrims visiting the holy city of Mecca each year from all over the world, knowledge of this “wine of Araby” began to spread.</p>

<h3 class=\"p1\" style=\"text-align: center;\">Coffee Comes to Europe</h3>
<p class=\"p1\">European travelers to the Near East brought back stories of an unusual dark black beverage. By the 17th century, coffee had made its way to Europe and was becoming popular across the continent.</p>
<p class=\"p2\">Some people reacted to this new beverage with suspicion or fear, calling it the “bitter invention of Satan.” The local clergy condemned coffee when it came to Venice in 1615. The controversy was so great that Pope Clement VIII was asked to intervene. He decided to taste the beverage for himself before making a decision, and found the drink so satisfying that he gave it papal approval.</p>
<p class=\"p2\">Despite such controversy, coffee houses were quickly becoming centers of social activity and communication in the major cities of England, Austria, France, Germany and Holland. In England “penny universities” sprang up, so called because for the price of a penny one could purchase a cup of coffee and engage in stimulating conversation.</p>
<p class=\"p2\">Coffee began to replace the common breakfast drink beverages of the time — beer and wine. Those who drank coffee instead of alcohol began the day alert and energized, and not surprisingly, the quality of their work was greatly improved. (We like to think of this a precursor to the modern office coffee service.)</p>
<p class=\"p2\">By the mid-17th century, there were over 300 coffee houses in London, many of which attracted like-minded patrons, including merchants, shippers, brokers and artists.</p>
<p class=\"p2\">Many businesses grew out of these specialized coffee houses. Lloyd\'s of London, for example, came into existence at the Edward Lloyd\'s Coffee House.</p>

<h3></h3>
<h3 style=\"text-align: center;\">The New World</h3>
<p class=\"p2\">In the mid-1600\'s, coffee was brought to New Amsterdam, later called New York by the British.</p>
<p class=\"p2\">Though coffee houses rapidly began to appear, tea continued to be the favored drink in the New World until 1773, when the colonists revolted against a heavy tax on tea imposed by King George III. The revolt, known as the Boston Tea Party, would forever change the American drinking preference to coffee.</p>

<blockquote class=\"p2\">\"Coffee - the favorite drink of the civilized world.\" - Thomas Jefferson</blockquote>
<h3 class=\"p2\" style=\"text-align: center;\">Plantations Around the World</h3>
<p class=\"p1\">As demand for the beverage continued to spread, there was fierce competition to cultivate coffee outside of Arabia.</p>
<p class=\"p2\">The Dutch finally got seedlings in the latter half of the 17th century. Their first attempts to plant them in India failed, but they were successful with their efforts in Batavia, on the island of Java in what is now Indonesia.</p>
<p class=\"p1\">The plants thrived and soon the Dutch had a productive and growing trade in coffee. They then expanded the cultivation of coffee trees to the islands of Sumatra and Celebes.</p>

<h3 class=\"p2\" style=\"text-align: center;\">Coming to the Americas</h3>
<p class=\"p1\">In 1714, the Mayor of Amsterdam presented a gift of a young coffee plant to King Louis XIV of France. The King ordered it to be planted in the Royal Botanical Garden in Paris. In 1723, a young naval officer, Gabriel de Clieu obtained a seedling from the King\'s plant. Despite a challenging voyage — complete with horrendous weather, a saboteur who tried to destroy the seedling, and a pirate attack — he managed to transport it safely to Martinique.</p>
<p class=\"p2\">Once planted, the seedling not only thrived, but it’s credited with the spread of over 18 million coffee trees on the island of Martinique in the next 50 years. Even more incredible is that this seedling was the parent of all coffee trees throughout the Caribbean, South and Central America.</p>
<p class=\"p2\">The famed Brazilian coffee owes its existence to Francisco de Mello Palheta, who was sent by the emperor to French Guiana to get coffee seedlings. The French were not willing to share, but the French Governor\'s wife, captivated by his good looks, gave him a large bouquet of flowers before he left— buried inside were enough coffee seeds to begin what is today a billion-dollar industry.</p>
<p class=\"p2\">Missionaries and travelers, traders and colonists continued to carry coffee seeds to new lands, and coffee trees were planted worldwide. Plantations were established in magnificent tropical forests and on rugged mountain highlands. Some crops flourished, while others were short-lived. New nations were established on coffee economies. Fortunes were made and lost. By the end of the 18th century, coffee had become one of the world\'s most profitable export crops. After crude oil, coffee is the most sought commodity in the world<span class=\"s1\">.</span></p>
&nbsp;

© National Coffee Association of U.S.A., Inc", "History", "", "publish", "closed", "closed", "", "history", "", "", "2017-12-18 19:46:09", "2017-12-19 00:46:09", "", "0", "http://localhost:8000/?page_id=9", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("10", "1", "2017-12-04 18:18:14", "2017-12-04 23:18:14", "History of coffee goes here.", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-04 18:18:14", "2017-12-04 23:18:14", "", "9", "http://localhost:8000/?p=10", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("11", "1", "2017-12-04 18:20:00", "2017-12-04 23:20:00", "[weforms id=\"40\"]

Change map to the location of Coffee Hall.
<iframe style=\"border: 0;\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16398.925008917766!2d-80.43201189453553!3d43.3990210903041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b8abcb983287b%3A0x3a4f69c14ee1cc80!2sWaterloo+Region+Museum!5e0!3m2!1sen!2sca!4v1512429559472\" width=\"600\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>", "Contact", "", "publish", "closed", "closed", "", "contact", "", "", "2017-12-05 09:14:00", "2017-12-05 14:14:00", "", "0", "http://localhost:8000/?page_id=11", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("12", "1", "2017-12-04 18:20:00", "2017-12-04 23:20:00", "Contact form goes here.

Change map to the location of Coffee Hall.
<iframe style=\"border: 0;\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16398.925008917766!2d-80.43201189453553!3d43.3990210903041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b8abcb983287b%3A0x3a4f69c14ee1cc80!2sWaterloo+Region+Museum!5e0!3m2!1sen!2sca!4v1512429559472\" width=\"600\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>", "Contact", "", "inherit", "closed", "closed", "", "11-revision-v1", "", "", "2017-12-04 18:20:00", "2017-12-04 23:20:00", "", "11", "http://localhost:8000/?p=12", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("13", "1", "2017-12-04 18:20:25", "2017-12-04 23:20:25", "", "Events", "", "publish", "closed", "closed", "", "events", "", "", "2017-12-07 13:59:09", "2017-12-07 18:59:09", "", "0", "http://localhost:8000/?page_id=13", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("14", "1", "2017-12-04 18:20:25", "2017-12-04 23:20:25", "Event calendar goes here.", "Events", "", "inherit", "closed", "closed", "", "13-revision-v1", "", "", "2017-12-04 18:20:25", "2017-12-04 23:20:25", "", "13", "http://localhost:8000/?p=14", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("15", "1", "2017-12-04 18:20:50", "2017-12-04 23:20:50", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i501/1712/ed/872c895081d4.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i528/1712/4e/735d72b33f8a.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s020.radikal.ru/i718/1712/ba/00862c951e0a.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Espresso</strong>
To make an espresso, shoot boiling water under high pressure through finely ground up coffee beans and then pour into a tiny mug. Sounds simple right? Well, it’s surprisingly difficult to master. Espressos are the purest coffee experience you can get, and while they’re not for everyone, it can be a truly singular drinking experience when you find a good brew.</td>
<td class=\"jewellery_desc\"><strong>Flat White</strong>
The most Aussie coffees available are the long black and the flat white – as both originated in Australia and New Zealand. For a flat white, the steamed milk from the bottom of the jug (which is usually not so frothy, but rather creamy) is poured over a shot of espresso. It is now popular among mums and dads at school fetes who are desperately trying to stay awake.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://i053.radikal.ru/1712/10/3ec08cfe8474.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s017.radikal.ru/i437/1712/41/ca147fb6b7c1.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Gibraltar</strong> 
The name gibraltar originated in San Francisco, California, where roasters – first Blue Bottle Coffee Company, later Ritual Coffee Roasters and others – started the cortado trend by serving the drink in Libbey Glass Company glassware by the same name</td>
<td class=\"jewellery_desc\"><strong>Mochachino</strong>
A ‘mocha’ is just a latte with added chocolate powder or syrup, as well as sometimes being topped with whipped cream. If anything, this is a good entry level coffee – living in the worlds between the childlike hot chocolate and the adult café latte.</td>
</tr>
</tbody>
</table>", "Catalog", "", "publish", "closed", "closed", "", "catalog", "", "", "2017-12-18 22:19:52", "2017-12-19 03:19:52", "", "0", "http://localhost:8000/?page_id=15", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("16", "1", "2017-12-04 18:20:50", "2017-12-04 23:20:50", "", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-04 18:20:50", "2017-12-04 23:20:50", "", "15", "http://localhost:8000/?p=16", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("17", "1", "2017-12-04 18:21:28", "2017-12-04 23:21:28", "<img class=\"alignleft wp-image-132\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg\" alt=\"001\" padding:1em />
<strong>DESCRIPTION</strong>
The focus of this class is the science behind brewing coffee, starting with the fundamental principles of extraction and ending in a deeper exploration into the application of these principles. In this session we also demonstrate a variety of popular brewing methods and equipment while examining their pros and cons.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.

At the end of this 2-hour lecture the floor is opened up for 30 minutes of questions and discussion, and yes, fresh brewed coffee is served at the start!
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 14 April 2018

10:00 AM – 12:00 PM EDT

CAD50

</div>", "Coffee Lecture: Alchemy of Brewing", "", "publish", "open", "open", "", "a-sample-coffee-catalog-item", "", "", "2017-12-18 21:04:01", "2017-12-19 02:04:01", "", "0", "http://localhost:8000/?p=17", "0", "post", "", "0");
INSERT INTO `wp_posts` VALUES("18", "1", "2017-12-04 18:21:28", "2017-12-04 23:21:28", "Here you would put a description and possibly and image.", "A Sample Coffee Catalog Item", "", "inherit", "closed", "closed", "", "17-revision-v1", "", "", "2017-12-04 18:21:28", "2017-12-04 23:21:28", "", "17", "http://localhost:8000/?p=18", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("19", "1", "2017-12-04 18:26:21", "2017-12-04 23:26:21", "
[generate-get-coffee-page]

", "Get Coffee", "", "publish", "closed", "closed", "", "get-coffee", "", "", "2017-12-18 22:23:47", "2017-12-19 03:23:47", "", "0", "http://localhost:8000/?page_id=19", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("20", "1", "2017-12-04 18:26:21", "2017-12-04 23:26:21", "This page has images of each coffee and a form associated with it that the user can edit (the form on a separate hidden page). This page must let the user edit an existing coffee by clicking on the corresponding image and editing the form.
The user can create a custom coffee on this page by selecting an appropriate image and editing the form. Once a coffee is customized or created, the user can place an order (saved in a database). The user can also cancel the order before placing an order.", "Get Coffee", "", "inherit", "closed", "closed", "", "19-revision-v1", "", "", "2017-12-04 18:26:21", "2017-12-04 23:26:21", "", "19", "http://localhost:8000/?p=20", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("22", "1", "2017-12-04 18:28:21", "2017-12-04 23:28:21", "Here the user is presented with a form that he/she can customize and save as an order to a database. Canceling  the order will also be an option", "Customize Coffee", "", "publish", "closed", "closed", "", "customize-coffee", "", "", "2017-12-04 18:28:21", "2017-12-04 23:28:21", "", "0", "http://localhost:8000/?page_id=22", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("23", "1", "2017-12-04 18:28:21", "2017-12-04 23:28:21", "Here the user is presented with a form that he/she can customize and save as an order to a database. Canceling  the order will also be an option", "Customize Coffee", "", "inherit", "closed", "closed", "", "22-revision-v1", "", "", "2017-12-04 18:28:21", "2017-12-04 23:28:21", "", "22", "http://localhost:8000/?p=23", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("24", "1", "2017-12-04 18:28:53", "2017-12-04 23:28:53", "[wppb-register]", "Registration", "", "publish", "closed", "closed", "", "registration", "", "", "2017-12-05 10:36:29", "2017-12-05 15:36:29", "", "0", "http://localhost:8000/?page_id=24", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("25", "1", "2017-12-04 18:28:53", "2017-12-04 23:28:53", "Here the user will be presented with a form that\'ll let them register as a new user.", "Registration", "", "inherit", "closed", "closed", "", "24-revision-v1", "", "", "2017-12-04 18:28:53", "2017-12-04 23:28:53", "", "24", "http://localhost:8000/?p=25", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("26", "1", "2017-12-04 18:29:16", "2017-12-04 23:29:16", "[wppb-login]", "Login/Logout", "", "publish", "closed", "closed", "", "login", "", "", "2017-12-05 10:57:09", "2017-12-05 15:57:09", "", "0", "http://localhost:8000/?page_id=26", "0", "page", "", "0");
INSERT INTO `wp_posts` VALUES("27", "1", "2017-12-04 18:29:16", "2017-12-04 23:29:16", "Here the user can log in to the website.", "Login", "", "inherit", "closed", "closed", "", "26-revision-v1", "", "", "2017-12-04 18:29:16", "2017-12-04 23:29:16", "", "26", "http://localhost:8000/?p=27", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("28", "1", "2017-12-04 18:29:59", "2017-12-04 23:29:59", " ", "", "", "publish", "closed", "closed", "", "28", "", "", "2017-12-04 18:30:49", "2017-12-04 23:30:49", "", "0", "http://localhost:8000/?p=28", "8", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("29", "1", "2017-12-04 18:30:00", "2017-12-04 23:30:00", " ", "", "", "publish", "closed", "closed", "", "29", "", "", "2017-12-04 18:30:49", "2017-12-04 23:30:49", "", "0", "http://localhost:8000/?p=29", "7", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("30", "1", "2017-12-04 18:30:01", "2017-12-04 23:30:01", " ", "", "", "publish", "closed", "closed", "", "30", "", "", "2017-12-04 18:30:49", "2017-12-04 23:30:49", "", "0", "http://localhost:8000/?p=30", "3", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("31", "1", "2017-12-04 18:30:02", "2017-12-04 23:30:02", " ", "", "", "publish", "closed", "closed", "", "31", "", "", "2017-12-04 18:30:50", "2017-12-04 23:30:50", "", "0", "http://localhost:8000/?p=31", "2", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("32", "1", "2017-12-04 18:30:03", "2017-12-04 23:30:03", " ", "", "", "publish", "closed", "closed", "", "32", "", "", "2017-12-04 18:30:50", "2017-12-04 23:30:50", "", "0", "http://localhost:8000/?p=32", "4", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("33", "1", "2017-12-04 18:30:03", "2017-12-04 23:30:03", " ", "", "", "publish", "closed", "closed", "", "33", "", "", "2017-12-04 18:30:50", "2017-12-04 23:30:50", "", "0", "http://localhost:8000/?p=33", "6", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("34", "1", "2017-12-04 18:30:04", "2017-12-04 23:30:04", " ", "", "", "publish", "closed", "closed", "", "34", "", "", "2017-12-04 18:30:51", "2017-12-04 23:30:51", "", "0", "http://localhost:8000/?p=34", "5", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("35", "1", "2017-12-04 18:30:04", "2017-12-04 23:30:04", " ", "", "", "publish", "closed", "closed", "", "35", "", "", "2017-12-04 18:30:51", "2017-12-04 23:30:51", "", "0", "http://localhost:8000/?p=35", "1", "nav_menu_item", "", "0");
INSERT INTO `wp_posts` VALUES("36", "1", "2017-12-04 18:30:49", "2017-12-04 23:30:49", "{
    \"nav_menu_item[28]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 26,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=26\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 8,
            \"status\": \"publish\",
            \"original_title\": \"Login\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[29]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 24,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=24\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 7,
            \"status\": \"publish\",
            \"original_title\": \"Registration\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[30]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 19,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=19\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 3,
            \"status\": \"publish\",
            \"original_title\": \"Get Coffee\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[31]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 15,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=15\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 2,
            \"status\": \"publish\",
            \"original_title\": \"Catalog\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[32]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 13,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=13\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 4,
            \"status\": \"publish\",
            \"original_title\": \"Events\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[33]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 11,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=11\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 6,
            \"status\": \"publish\",
            \"original_title\": \"Contact\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[34]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 9,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/?page_id=9\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 5,
            \"status\": \"publish\",
            \"original_title\": \"History\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    },
    \"nav_menu_item[35]\": {
        \"value\": {
            \"menu_item_parent\": 0,
            \"object_id\": 6,
            \"object\": \"page\",
            \"type\": \"post_type\",
            \"type_label\": \"Page\",
            \"url\": \"http://localhost:8000/\",
            \"title\": \"\",
            \"target\": \"\",
            \"attr_title\": \"\",
            \"description\": \"\",
            \"classes\": \"\",
            \"xfn\": \"\",
            \"nav_menu_term_id\": 2,
            \"position\": 1,
            \"status\": \"publish\",
            \"original_title\": \"Home\",
            \"_invalid\": false
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:30:49\"
    }
}", "", "", "trash", "closed", "closed", "", "315adfa9-3900-4caf-aa9d-c4ef7469f9ea", "", "", "2017-12-04 18:30:49", "2017-12-04 23:30:49", "", "0", "http://localhost:8000/?p=36", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("37", "1", "2017-12-04 18:31:12", "2017-12-04 23:31:12", "{
    \"sidebars_widgets[sidebar-1]\": {
        \"value\": [
            \"search-2\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:31:12\"
    }
}", "", "", "trash", "closed", "closed", "", "16a6dafb-415d-4f12-9f62-2dc71199c1f2", "", "", "2017-12-04 18:31:12", "2017-12-04 23:31:12", "", "0", "http://localhost:8000/?p=37", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("38", "1", "2017-12-04 18:31:24", "2017-12-04 23:31:24", "{
    \"blogdescription\": {
        \"value\": \"Tagline goes here\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:31:24\"
    }
}", "", "", "trash", "closed", "closed", "", "e5771c69-6123-42aa-84c6-e7e5303cb2b1", "", "", "2017-12-04 18:31:24", "2017-12-04 23:31:24", "", "0", "http://localhost:8000/?p=38", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("39", "1", "2017-12-04 18:31:36", "2017-12-04 23:31:36", "{
    \"blogdescription\": {
        \"value\": \"Tagline goes here\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2017-12-04 23:31:36\"
    }
}", "", "", "trash", "closed", "closed", "", "5d2d2554-d2cc-4c61-9c46-e45cec922828", "", "", "2017-12-04 18:31:36", "2017-12-04 23:31:36", "", "0", "http://localhost:8000/?p=39", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("40", "1", "2017-12-05 09:07:08", "2017-12-05 14:07:08", "", "Contact Form", "", "publish", "closed", "closed", "", "contact-form", "", "", "2017-12-05 09:09:56", "2017-12-05 14:09:56", "", "0", "http://localhost:8000/?p=40", "0", "wpuf_contact_form", "", "0");
INSERT INTO `wp_posts` VALUES("44", "1", "2017-12-05 09:09:56", "2017-12-05 14:09:56", "a:19:{s:8:\"template\";s:10:\"name_field\";s:4:\"name\";s:4:\"name\";s:5:\"label\";s:4:\"Name\";s:8:\"required\";s:3:\"yes\";s:5:\"width\";s:5:\"large\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";i:40;s:4:\"help\";s:0:\"\";s:7:\"is_meta\";s:3:\"yes\";s:9:\"wpuf_cond\";a:5:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_field\";a:0:{}s:13:\"cond_operator\";a:1:{i:0;s:1:\"=\";}s:11:\"cond_option\";a:1:{i:0;s:10:\"- select -\";}s:10:\"cond_logic\";s:3:\"all\";}s:6:\"format\";s:10:\"first-last\";s:10:\"first_name\";a:3:{s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:3:\"sub\";s:5:\"First\";}s:11:\"middle_name\";a:3:{s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:3:\"sub\";s:6:\"Middle\";}s:9:\"last_name\";a:3:{s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:3:\"sub\";s:4:\"Last\";}s:6:\"inline\";s:3:\"yes\";s:9:\"hide_subs\";b:0;s:7:\"dynamic\";a:2:{s:6:\"status\";b:0;s:10:\"param_name\";s:0:\"\";}}", "", "", "publish", "closed", "closed", "", "44", "", "", "2017-12-05 09:09:56", "2017-12-05 14:09:56", "", "40", "http://localhost:8000/?p=44", "0", "wpuf_input", "", "0");
INSERT INTO `wp_posts` VALUES("45", "1", "2017-12-05 09:09:56", "2017-12-05 14:09:56", "a:13:{s:8:\"template\";s:13:\"email_address\";s:4:\"name\";s:5:\"email\";s:5:\"label\";s:13:\"Email Address\";s:8:\"required\";s:3:\"yes\";s:5:\"width\";s:5:\"large\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";i:40;s:4:\"help\";s:0:\"\";s:7:\"is_meta\";s:3:\"yes\";s:9:\"wpuf_cond\";a:5:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_field\";a:0:{}s:13:\"cond_operator\";a:1:{i:0;s:1:\"=\";}s:11:\"cond_option\";a:1:{i:0;s:10:\"- select -\";}s:10:\"cond_logic\";s:3:\"all\";}s:9:\"duplicate\";s:0:\"\";}", "", "", "publish", "closed", "closed", "", "45", "", "", "2017-12-05 09:09:56", "2017-12-05 14:09:56", "", "40", "http://localhost:8000/?p=45", "1", "wpuf_input", "", "0");
INSERT INTO `wp_posts` VALUES("46", "1", "2017-12-05 09:09:57", "2017-12-05 14:09:57", "a:16:{s:8:\"template\";s:14:\"textarea_field\";s:4:\"name\";s:7:\"message\";s:5:\"label\";s:7:\"Message\";s:8:\"required\";s:3:\"yes\";s:5:\"width\";s:5:\"large\";s:3:\"css\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"default\";s:0:\"\";s:4:\"size\";i:40;s:4:\"help\";s:0:\"\";s:7:\"is_meta\";s:3:\"yes\";s:9:\"wpuf_cond\";a:5:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_field\";a:0:{}s:13:\"cond_operator\";a:1:{i:0;s:1:\"=\";}s:11:\"cond_option\";a:1:{i:0;s:10:\"- select -\";}s:10:\"cond_logic\";s:3:\"all\";}s:16:\"word_restriction\";s:0:\"\";s:4:\"rows\";i:5;s:4:\"cols\";i:25;s:4:\"rich\";s:2:\"no\";}", "", "", "publish", "closed", "closed", "", "46", "", "", "2017-12-05 09:09:57", "2017-12-05 14:09:57", "", "40", "http://localhost:8000/?p=46", "2", "wpuf_input", "", "0");
INSERT INTO `wp_posts` VALUES("47", "1", "2017-12-05 09:13:59", "2017-12-05 14:13:59", "[weforms id=\"40\"]

Change map to the location of Coffee Hall.
<iframe style=\"border: 0;\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16398.925008917766!2d-80.43201189453553!3d43.3990210903041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b8abcb983287b%3A0x3a4f69c14ee1cc80!2sWaterloo+Region+Museum!5e0!3m2!1sen!2sca!4v1512429559472\" width=\"600\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>", "Contact", "", "inherit", "closed", "closed", "", "11-autosave-v1", "", "", "2017-12-05 09:13:59", "2017-12-05 14:13:59", "", "11", "http://localhost:8000/?p=47", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("48", "1", "2017-12-05 09:14:00", "2017-12-05 14:14:00", "[weforms id=\"40\"]

Change map to the location of Coffee Hall.
<iframe style=\"border: 0;\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16398.925008917766!2d-80.43201189453553!3d43.3990210903041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b8abcb983287b%3A0x3a4f69c14ee1cc80!2sWaterloo+Region+Museum!5e0!3m2!1sen!2sca!4v1512429559472\" width=\"600\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>", "Contact", "", "inherit", "closed", "closed", "", "11-revision-v1", "", "", "2017-12-05 09:14:00", "2017-12-05 14:14:00", "", "11", "http://localhost:8000/?p=48", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("54", "1", "2017-12-05 09:30:54", "2017-12-05 14:30:54", "", "Members", "", "trash", "closed", "closed", "", "members__trashed", "", "", "2017-12-05 10:13:49", "2017-12-05 15:13:49", "", "0", "http://localhost:8000/?um_directory=members", "0", "um_directory", "", "0");
INSERT INTO `wp_posts` VALUES("69", "1", "2017-12-05 09:31:12", "2017-12-05 14:31:12", "", "Admin", "", "publish", "closed", "closed", "", "admin", "", "", "2017-12-05 09:31:12", "2017-12-05 14:31:12", "", "0", "http://localhost:8000/?um_role=admin", "0", "um_role", "", "0");
INSERT INTO `wp_posts` VALUES("70", "1", "2017-12-05 09:31:16", "2017-12-05 14:31:16", "", "Member", "", "publish", "closed", "closed", "", "member", "", "", "2017-12-05 09:31:16", "2017-12-05 14:31:16", "", "0", "http://localhost:8000/?um_role=member", "0", "um_role", "", "0");
INSERT INTO `wp_posts` VALUES("71", "1", "2017-12-05 09:39:31", "2017-12-05 14:39:31", "", "Registration", "", "publish", "closed", "closed", "", "registration", "", "", "2017-12-05 09:53:59", "2017-12-05 14:53:59", "", "0", "http://localhost:8000/?post_type=um_form&#038;p=71", "0", "um_form", "", "0");
INSERT INTO `wp_posts` VALUES("73", "1", "2017-12-05 09:51:31", "2017-12-05 14:51:31", "[ultimatemember form_id=71]", "Registration", "", "inherit", "closed", "closed", "", "24-revision-v1", "", "", "2017-12-05 09:51:31", "2017-12-05 14:51:31", "", "24", "http://localhost:8000/?p=73", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("74", "1", "2017-12-05 10:08:42", "2017-12-05 15:08:42", "", "Login", "", "publish", "closed", "closed", "", "login", "", "", "2017-12-05 10:25:27", "2017-12-05 15:25:27", "", "0", "http://localhost:8000/?post_type=um_form&#038;p=74", "0", "um_form", "", "0");
INSERT INTO `wp_posts` VALUES("75", "1", "2017-12-05 10:09:52", "2017-12-05 15:09:52", "[ultimatemember form_id=74]", "Login", "", "inherit", "closed", "closed", "", "26-revision-v1", "", "", "2017-12-05 10:09:52", "2017-12-05 15:09:52", "", "26", "http://localhost:8000/?p=75", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("76", "1", "2017-12-05 10:32:31", "2017-12-05 15:32:31", "Login form goes here.", "Login", "", "inherit", "closed", "closed", "", "26-revision-v1", "", "", "2017-12-05 10:32:31", "2017-12-05 15:32:31", "", "26", "http://localhost:8000/?p=76", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("77", "1", "2017-12-05 10:32:50", "2017-12-05 15:32:50", "Registration form goes here.", "Registration", "", "inherit", "closed", "closed", "", "24-revision-v1", "", "", "2017-12-05 10:32:50", "2017-12-05 15:32:50", "", "24", "http://localhost:8000/?p=77", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("78", "1", "2017-12-05 10:36:29", "2017-12-05 15:36:29", "[wppb-register]", "Registration", "", "inherit", "closed", "closed", "", "24-revision-v1", "", "", "2017-12-05 10:36:29", "2017-12-05 15:36:29", "", "24", "http://localhost:8000/?p=78", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("79", "1", "2017-12-05 10:36:57", "2017-12-05 15:36:57", "[wppb-login]", "Login", "", "inherit", "closed", "closed", "", "26-autosave-v1", "", "", "2017-12-05 10:36:57", "2017-12-05 15:36:57", "", "26", "http://localhost:8000/?p=79", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("80", "1", "2017-12-05 10:37:04", "2017-12-05 15:37:04", "[wppb-login]", "Login", "", "inherit", "closed", "closed", "", "26-revision-v1", "", "", "2017-12-05 10:37:04", "2017-12-05 15:37:04", "", "26", "http://localhost:8000/?p=80", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("81", "1", "2017-12-05 10:57:09", "2017-12-05 15:57:09", "[wppb-login]", "Login/Logout", "", "inherit", "closed", "closed", "", "26-revision-v1", "", "", "2017-12-05 10:57:09", "2017-12-05 15:57:09", "", "26", "http://localhost:8000/?p=81", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("84", "1", "2017-12-07 13:58:52", "2017-12-07 18:58:52", "Here you would put a description and possibly an image of an event. Make sure to set the correct date too!", "A Sample Event", "", "inherit", "closed", "closed", "", "17-revision-v1", "", "", "2017-12-07 13:58:52", "2017-12-07 18:58:52", "", "17", "http://localhost:8000/?p=84", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("85", "1", "2017-12-07 13:59:09", "2017-12-07 18:59:09", "", "Events", "", "inherit", "closed", "closed", "", "13-revision-v1", "", "", "2017-12-07 13:59:09", "2017-12-07 18:59:09", "", "13", "http://localhost:8000/?p=85", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("86", "1", "2017-12-07 13:59:57", "2017-12-07 18:59:57", "Here you would put your coffee catalog that would have an image and description associated with it.", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-07 13:59:57", "2017-12-07 18:59:57", "", "15", "http://localhost:8000/?p=86", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("89", "1", "2017-12-11 19:54:52", "2017-12-12 00:54:52", "This page has images of each coffee and a form associated with it that the user can edit (the form on a separate hidden page). This page must let the user edit an existing coffee by clicking on the corresponding image and editing the form.
The user can create a custom coffee on this page by selecting an appropriate image and editing the form. Once a coffee is customized or created, the user can place an order (saved in a database). The user can also cancel the order before placing an order.

[generate-get-coffee-page]
<br>
[generate-customize-coffee-page]", "Get Coffee", "", "inherit", "closed", "closed", "", "19-revision-v1", "", "", "2017-12-11 19:54:52", "2017-12-12 00:54:52", "", "19", "http://localhost:8000/?p=89", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("90", "1", "2017-12-12 23:54:12", "2017-12-13 04:54:12", "This page has images of each coffee and a form associated with it that the user can edit (the form on a separate hidden page). This page must let the user edit an existing coffee by clicking on the corresponding image and editing the form.
The user can create a custom coffee on this page by selecting an appropriate image and editing the form. Once a coffee is customized or created, the user can place an order (saved in a database). The user can also cancel the order before placing an order.
<br>
[generate-get-coffee-page]

", "Get Coffee", "", "inherit", "closed", "closed", "", "19-revision-v1", "", "", "2017-12-12 23:54:12", "2017-12-13 04:54:12", "", "19", "http://localhost:8000/?p=90", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("92", "4", "2017-12-18 15:10:41", "2017-12-18 20:10:41", "", "header2", "", "inherit", "open", "closed", "", "header2", "", "", "2017-12-18 15:10:41", "2017-12-18 20:10:41", "", "0", "http://localhost:8000/wp-content/uploads/2017/12/header2.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("93", "4", "2017-12-18 15:10:42", "2017-12-18 20:10:42", "", "icon", "", "inherit", "open", "closed", "", "icon", "", "", "2017-12-18 15:10:42", "2017-12-18 20:10:42", "", "0", "http://localhost:8000/wp-content/uploads/2017/12/icon.png", "0", "attachment", "image/png", "0");
INSERT INTO `wp_posts` VALUES("94", "4", "2017-12-18 15:10:44", "2017-12-18 20:10:44", "", "list-of-different-types-of-coffee_23-2147573277", "", "inherit", "open", "closed", "", "list-of-different-types-of-coffee_23-2147573277", "", "", "2017-12-18 15:10:44", "2017-12-18 20:10:44", "", "0", "http://localhost:8000/wp-content/uploads/2017/12/list-of-different-types-of-coffee_23-2147573277.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("95", "4", "2017-12-18 15:10:45", "2017-12-18 20:10:45", "", "palkortum01", "", "inherit", "open", "closed", "", "palkortum01", "", "", "2017-12-18 15:10:45", "2017-12-18 20:10:45", "", "0", "http://localhost:8000/wp-content/uploads/2017/12/palkortum01.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("96", "4", "2017-12-18 15:10:47", "2017-12-18 20:10:47", "", "palkortum20", "", "inherit", "open", "closed", "", "palkortum20", "", "", "2017-12-18 15:10:47", "2017-12-18 20:10:47", "", "0", "http://localhost:8000/wp-content/uploads/2017/12/palkortum20.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("97", "4", "2017-12-18 15:11:03", "2017-12-18 20:11:03", "{
    \"masonic_child::header_image\": {
        \"value\": \"http://localhost:8000/wp-content/uploads/2017/12/header2.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:11:03\"
    },
    \"masonic_child::header_image_data\": {
        \"value\": {
            \"url\": \"http://localhost:8000/wp-content/uploads/2017/12/header2.jpg\",
            \"thumbnail_url\": \"http://localhost:8000/wp-content/uploads/2017/12/header2.jpg\",
            \"timestamp\": 1513627855747,
            \"attachment_id\": 92,
            \"width\": 1350,
            \"height\": 500
        },
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:11:03\"
    }
}", "", "", "trash", "closed", "closed", "", "606d86a7-c1e0-4539-ae20-8896e57aa397", "", "", "2017-12-18 15:11:03", "2017-12-18 20:11:03", "", "0", "http://localhost:8000/?p=97", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("98", "4", "2017-12-18 15:11:26", "2017-12-18 20:11:26", "{
    \"site_icon\": {
        \"value\": 93,
        \"type\": \"option\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:11:26\"
    }
}", "", "", "trash", "closed", "closed", "", "9ecd0142-ecd5-44b9-a09e-d07f7df41e31", "", "", "2017-12-18 15:11:26", "2017-12-18 20:11:26", "", "0", "http://localhost:8000/?p=98", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("99", "4", "2017-12-18 15:11:41", "2017-12-18 20:11:41", "{
    \"masonic_child::custom_logo\": {
        \"value\": 93,
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:11:41\"
    }
}", "", "", "trash", "closed", "closed", "", "31305964-f40d-4559-9774-c86d9b39fd03", "", "", "2017-12-18 15:11:41", "2017-12-18 20:11:41", "", "0", "http://localhost:8000/?p=99", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("100", "4", "2017-12-18 15:14:25", "2017-12-18 20:14:25", "{
    \"masonic_child::masonic_primary_color\": {
        \"value\": \"#893b00\",
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:13:23\"
    },
    \"masonic_child::header_textcolor\": {
        \"value\": \"#dd9933\",
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:14:23\"
    },
    \"masonic_child::masonic_link_color\": {
        \"value\": \"#6a6a6a\",
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-18 20:14:23\"
    }
}", "", "", "trash", "closed", "closed", "", "56748dd1-54fa-455c-b87e-89a3c4f2880b", "", "", "2017-12-18 15:14:25", "2017-12-18 20:14:25", "", "0", "http://localhost:8000/?p=100", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("101", "4", "2017-12-18 19:45:33", "2017-12-19 00:45:33", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1>
<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>

<h3 class=\"p1\" style=\"text-align: center;\">The Arabian Peninsula</h3>
<p class=\"p1\">Coffee cultivation and trade began on the Arabian Peninsula.  By the 15th century, coffee was being grown in the Yemeni district of Arabia and by the 16th century it was known in Persia, Egypt, Syria, and Turkey.</p>
<p class=\"p1\">Coffee was not only enjoyed in homes, but also in the many public coffee houses — called <em>qahveh khaneh</em> — which began to appear in cities across the Near East. The popularity of the coffee houses was unequaled and people frequented them for all kinds of social activity.</p>
<p class=\"p2\">Not only did the patrons drink coffee and engage in conversation, but they also listened to music, watched performers, played chess and kept current on the news.  Coffee houses quickly became such an important center for the exchange of information that they were often referred to as “Schools of the Wise.”</p>
<p class=\"p1\">With thousands of pilgrims visiting the holy city of Mecca each year from all over the world, knowledge of this “wine of Araby” began to spread.</p>

<h3 class=\"p1\" style=\"text-align: center;\">Coffee Comes to Europe</h3>
<p class=\"p1\">European travelers to the Near East brought back stories of an unusual dark black beverage. By the 17th century, coffee had made its way to Europe and was becoming popular across the continent.</p>
<p class=\"p2\">Some people reacted to this new beverage with suspicion or fear, calling it the “bitter invention of Satan.” The local clergy condemned coffee when it came to Venice in 1615. The controversy was so great that Pope Clement VIII was asked to intervene. He decided to taste the beverage for himself before making a decision, and found the drink so satisfying that he gave it papal approval.</p>
<p class=\"p2\">Despite such controversy, coffee houses were quickly becoming centers of social activity and communication in the major cities of England, Austria, France, Germany and Holland. In England “penny universities” sprang up, so called because for the price of a penny one could purchase a cup of coffee and engage in stimulating conversation.</p>
<p class=\"p2\">Coffee began to replace the common breakfast drink beverages of the time — beer and wine. Those who drank coffee instead of alcohol began the day alert and energized, and not surprisingly, the quality of their work was greatly improved. (We like to think of this a precursor to the modern office coffee service.)</p>
<p class=\"p2\">By the mid-17th century, there were over 300 coffee houses in London, many of which attracted like-minded patrons, including merchants, shippers, brokers and artists.</p>
<p class=\"p2\">Many businesses grew out of these specialized coffee houses. Lloyd\'s of London, for example, came into existence at the Edward Lloyd\'s Coffee House.</p>

<h3></h3>
<h3 style=\"text-align: center;\">The New World</h3>
<p class=\"p2\">In the mid-1600\'s, coffee was brought to New Amsterdam, later called New York by the British.</p>
<p class=\"p2\">Though coffee houses rapidly began to appear, tea continued to be the favored drink in the New World until 1773, when the colonists revolted against a heavy tax on tea imposed by King George III. The revolt, known as the Boston Tea Party, would forever change the American drinking preference to coffee.</p>

<blockquote class=\"p2\">\"Coffee - the favorite drink of the civilized world.\" - Thomas Jefferson</blockquote>
<h3 class=\"p2\" style=\"text-align: center;\">Plantations Around the World</h3>
<p class=\"p1\">As demand for the beverage continued to spread, there was fierce competition to cultivate coffee outside of Arabia.</p>
<p class=\"p2\">The Dutch finally got seedlings in the latter half of the 17th century. Their first attempts to plant them in India failed, but they were successful with their efforts in Batavia, on the island of Java in what is now Indonesia.</p>
<p class=\"p1\">The plants thrived and soon the Dutch had a productive and growing trade in coffee. They then expanded the cultivation of coffee trees to the islands of Sumatra and Celebes.</p>

<h3 class=\"p2\" style=\"text-align: center;\">Coming to the Americas</h3>
<p class=\"p1\">In 1714, the Mayor of Amsterdam presented a gift of a young coffee plant to King Louis XIV of France. The King ordered it to be planted in the Royal Botanical Garden in Paris. In 1723, a young naval officer, Gabriel de Clieu obtained a seedling from the King\'s plant. Despite a challenging voyage — complete with horrendous weather, a saboteur who tried to destroy the seedling, and a pirate attack — he managed to transport it safely to Martinique.</p>
<p class=\"p2\">Once planted, the seedling not only thrived, but it’s credited with the spread of over 18 million coffee trees on the island of Martinique in the next 50 years. Even more incredible is that this seedling was the parent of all coffee trees throughout the Caribbean, South and Central America.</p>
<p class=\"p2\">The famed Brazilian coffee owes its existence to Francisco de Mello Palheta, who was sent by the emperor to French Guiana to get coffee seedlings. The French were not willing to share, but the French Governor\'s wife, captivated by his good looks, gave him a large bouquet of flowers before he left— buried inside were enough coffee seeds to begin what is today a billion-dollar industry.</p>
<p class=\"p2\">Missionaries and travelers, traders and colonists continued to carry coffee seeds to new lands, and coffee trees were planted worldwide. Plantations were established in magnificent tropical forests and on rugged mountain highlands. Some crops flourished, while others were short-lived. New nations were established on coffee economies. Fortunes were made and lost. By the end of the 18th century, coffee had become one of the world\'s most profitable export crops. After crude oil, coffee is the most sought commodity in the world<span class=\"s1\">.</span></p>
&nbsp;

© National Coffee Association of U.S.A., Inc", "History", "", "inherit", "closed", "closed", "", "9-autosave-v1", "", "", "2017-12-18 19:45:33", "2017-12-19 00:45:33", "", "9", "http://localhost:8000/?p=101", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("102", "4", "2017-12-18 19:35:27", "2017-12-19 00:35:27", "<h1 class=\"title style-scope ytd-video-primary-info-renderer\" style=\"text-align: center;\">Coffee Production Process</h1>
<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-18 19:35:27", "2017-12-19 00:35:27", "", "9", "http://localhost:8000/?p=102", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("103", "4", "2017-12-18 19:37:36", "2017-12-19 00:37:36", "", "800px-John_Frederick_Lewis_004", "The Coffee Bearer by John Frederick Lewis (1857).
(Ottoman quarters in Cairo, Egypt)", "inherit", "open", "closed", "", "800px-john_frederick_lewis_004", "", "", "2017-12-18 19:38:22", "2017-12-19 00:38:22", "", "9", "http://localhost:8000/wp-content/uploads/2017/12/800px-John_Frederick_Lewis_004.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("104", "4", "2017-12-18 19:39:39", "2017-12-19 00:39:39", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1>
<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>


[caption id=\"attachment_103\" align=\"alignleft\" width=\"174\"]<img class=\" wp-image-103\" src=\"http://localhost:8000/wp-content/uploads/2017/12/800px-John_Frederick_Lewis_004.jpg\" alt=\"Coffee\" width=\"174\" height=\"278\" /> The Coffee Bearer by <a href=\"https://en.wikipedia.org/wiki/John_Frederick_Lewis\">John Frederick Lewis</a> (1857).<br />(Ottoman quarters in Cairo, Egypt)[/caption]

&nbsp;", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-18 19:39:39", "2017-12-19 00:39:39", "", "9", "http://localhost:8000/?p=104", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("105", "4", "2017-12-18 19:41:32", "2017-12-19 00:41:32", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1>
<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>


[caption id=\"attachment_103\" align=\"alignleft\" width=\"174\"]<img class=\" wp-image-103\" src=\"http://localhost:8000/wp-content/uploads/2017/12/800px-John_Frederick_Lewis_004.jpg\" alt=\"Coffee\" width=\"174\" height=\"278\" /> The Coffee Bearer by <a href=\"https://en.wikipedia.org/wiki/John_Frederick_Lewis\">John Frederick Lewis</a> (1857).<br />(Ottoman quarters in Cairo, Egypt)[/caption]
<h3 class=\"p1\">The Arabian Peninsula</h3>
<p class=\"p1\">Coffee cultivation and trade began on the Arabian Peninsula.  By the 15th century, coffee was being grown in the Yemeni district of Arabia and by the 16th century it was known in Persia, Egypt, Syria, and Turkey.</p>
<p class=\"p1\">Coffee was not only enjoyed in homes, but also in the many public coffee houses — called <em>qahveh khaneh</em> — which began to appear in cities across the Near East. The popularity of the coffee houses was unequaled and people frequented them for all kinds of social activity.</p>
<p class=\"p2\">Not only did the patrons drink coffee and engage in conversation, but they also listened to music, watched performers, played chess and kept current on the news.  Coffee houses quickly became such an important center for the exchange of information that they were often referred to as “Schools of the Wise.”</p>
<p class=\"p1\">With thousands of pilgrims visiting the holy city of Mecca each year from all over the world, knowledge of this “wine of Araby” began to spread.</p>
&nbsp;

© National Coffee Association of U.S.A., Inc", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-18 19:41:32", "2017-12-19 00:41:32", "", "9", "http://localhost:8000/?p=105", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("106", "4", "2017-12-18 19:42:51", "2017-12-19 00:42:51", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1>
<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>


[caption id=\"attachment_103\" align=\"alignright\" width=\"174\"]<img class=\" wp-image-103\" src=\"http://localhost:8000/wp-content/uploads/2017/12/800px-John_Frederick_Lewis_004.jpg\" alt=\"Coffee\" width=\"174\" height=\"278\" /> The Coffee Bearer by <a href=\"https://en.wikipedia.org/wiki/John_Frederick_Lewis\">John Frederick Lewis</a> (1857).<br />(Ottoman quarters in Cairo, Egypt)[/caption]
<h3 class=\"p1\">The Arabian Peninsula</h3>
<p class=\"p1\">Coffee cultivation and trade began on the Arabian Peninsula.  By the 15th century, coffee was being grown in the Yemeni district of Arabia and by the 16th century it was known in Persia, Egypt, Syria, and Turkey.</p>
<p class=\"p1\">Coffee was not only enjoyed in homes, but also in the many public coffee houses — called <em>qahveh khaneh</em> — which began to appear in cities across the Near East. The popularity of the coffee houses was unequaled and people frequented them for all kinds of social activity.</p>
<p class=\"p2\">Not only did the patrons drink coffee and engage in conversation, but they also listened to music, watched performers, played chess and kept current on the news.  Coffee houses quickly became such an important center for the exchange of information that they were often referred to as “Schools of the Wise.”</p>
<p class=\"p1\">With thousands of pilgrims visiting the holy city of Mecca each year from all over the world, knowledge of this “wine of Araby” began to spread.</p>
&nbsp;

© National Coffee Association of U.S.A., Inc", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-18 19:42:51", "2017-12-19 00:42:51", "", "9", "http://localhost:8000/?p=106", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("107", "4", "2017-12-18 19:45:27", "2017-12-19 00:45:27", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1>
<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>

<h3 class=\"p1\" style=\"text-align: center;\">The Arabian Peninsula</h3>
<p class=\"p1\">Coffee cultivation and trade began on the Arabian Peninsula.  By the 15th century, coffee was being grown in the Yemeni district of Arabia and by the 16th century it was known in Persia, Egypt, Syria, and Turkey.</p>
<p class=\"p1\">Coffee was not only enjoyed in homes, but also in the many public coffee houses — called <em>qahveh khaneh</em> — which began to appear in cities across the Near East. The popularity of the coffee houses was unequaled and people frequented them for all kinds of social activity.</p>
<p class=\"p2\">Not only did the patrons drink coffee and engage in conversation, but they also listened to music, watched performers, played chess and kept current on the news.  Coffee houses quickly became such an important center for the exchange of information that they were often referred to as “Schools of the Wise.”</p>
<p class=\"p1\">With thousands of pilgrims visiting the holy city of Mecca each year from all over the world, knowledge of this “wine of Araby” began to spread.</p>

<h3 class=\"p1\" style=\"text-align: center;\">Coffee Comes to Europe</h3>
<p class=\"p1\">European travelers to the Near East brought back stories of an unusual dark black beverage. By the 17th century, coffee had made its way to Europe and was becoming popular across the continent.</p>
<p class=\"p2\">Some people reacted to this new beverage with suspicion or fear, calling it the “bitter invention of Satan.” The local clergy condemned coffee when it came to Venice in 1615. The controversy was so great that Pope Clement VIII was asked to intervene. He decided to taste the beverage for himself before making a decision, and found the drink so satisfying that he gave it papal approval.</p>
<p class=\"p2\">Despite such controversy, coffee houses were quickly becoming centers of social activity and communication in the major cities of England, Austria, France, Germany and Holland. In England “penny universities” sprang up, so called because for the price of a penny one could purchase a cup of coffee and engage in stimulating conversation.</p>
<p class=\"p2\">Coffee began to replace the common breakfast drink beverages of the time — beer and wine. Those who drank coffee instead of alcohol began the day alert and energized, and not surprisingly, the quality of their work was greatly improved. (We like to think of this a precursor to the modern office coffee service.)</p>
<p class=\"p2\">By the mid-17th century, there were over 300 coffee houses in London, many of which attracted like-minded patrons, including merchants, shippers, brokers and artists.</p>
<p class=\"p2\">Many businesses grew out of these specialized coffee houses. Lloyd\'s of London, for example, came into existence at the Edward Lloyd\'s Coffee House.</p>

<h3></h3>
<h3 style=\"text-align: center;\">The New World</h3>
<p class=\"p2\">In the mid-1600\'s, coffee was brought to New Amsterdam, later called New York by the British.</p>
<p class=\"p2\">Though coffee houses rapidly began to appear, tea continued to be the favored drink in the New World until 1773, when the colonists revolted against a heavy tax on tea imposed by King George III. The revolt, known as the Boston Tea Party, would forever change the American drinking preference to coffee.</p>

<blockquote class=\"p2\">\"Coffee - the favorite drink of the civilized world.\" - Thomas Jefferson</blockquote>
<h3 class=\"p2\" style=\"text-align: center;\">Plantations Around the World</h3>
<p class=\"p1\">As demand for the beverage continued to spread, there was fierce competition to cultivate coffee outside of Arabia.</p>
<p class=\"p2\">The Dutch finally got seedlings in the latter half of the 17th century. Their first attempts to plant them in India failed, but they were successful with their efforts in Batavia, on the island of Java in what is now Indonesia.</p>
<p class=\"p1\">The plants thrived and soon the Dutch had a productive and growing trade in coffee. They then expanded the cultivation of coffee trees to the islands of Sumatra and Celebes.</p>

<h3 class=\"p2\" style=\"text-align: center;\">Coming to the Americas</h3>
<p class=\"p1\">In 1714, the Mayor of Amsterdam presented a gift of a young coffee plant to King Louis XIV of France. The King ordered it to be planted in the Royal Botanical Garden in Paris. In 1723, a young naval officer, Gabriel de Clieu obtained a seedling from the King\'s plant. Despite a challenging voyage — complete with horrendous weather, a saboteur who tried to destroy the seedling, and a pirate attack — he managed to transport it safely to Martinique.</p>
<p class=\"p2\">Once planted, the seedling not only thrived, but it’s credited with the spread of over 18 million coffee trees on the island of Martinique in the next 50 years. Even more incredible is that this seedling was the parent of all coffee trees throughout the Caribbean, South and Central America.</p>
<p class=\"p2\">The famed Brazilian coffee owes its existence to Francisco de Mello Palheta, who was sent by the emperor to French Guiana to get coffee seedlings. The French were not willing to share, but the French Governor\'s wife, captivated by his good looks, gave him a large bouquet of flowers before he left— buried inside were enough coffee seeds to begin what is today a billion-dollar industry.</p>
<p class=\"p2\">Missionaries and travelers, traders and colonists continued to carry coffee seeds to new lands, and coffee trees were planted worldwide. Plantations were established in magnificent tropical forests and on rugged mountain highlands. Some crops flourished, while others were short-lived. New nations were established on coffee economies. Fortunes were made and lost. By the end of the 18th century, coffee had become one of the world\'s most profitable export crops. After crude oil, coffee is the most sought commodity in the world<span class=\"s1\">.</span></p>
&nbsp;

© National Coffee Association of U.S.A., Inc", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-18 19:45:27", "2017-12-19 00:45:27", "", "9", "http://localhost:8000/?p=107", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("108", "4", "2017-12-18 19:46:09", "2017-12-19 00:46:09", "<h1 class=\"p1\" style=\"text-align: center;\">The History of Coffee</h1><br>

<p style=\"text-align: center;\"><iframe src=\"https://www.youtube.com/embed/SvBj4O44Fnw\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>

<h4 style=\"text-align: center;\">No one knows exactly how or when coffee was discovered, though there are many legends about its origin.</h4>
<p class=\"p1\">Coffee grown worldwide can trace its heritage back centuries to the ancient coffee forests on the Ethiopian plateau. There, legend says the goat herder Kaldi first discovered the potential of these beloved beans.</p>
<p class=\"p1\">The story goes that that Kaldi discovered coffee after he noticed that after eating the berries from a certain tree, his goats became so energetic that they did not want to sleep at night<span class=\"s1\">.</span></p>
<p class=\"p1\">Kaldi reported his findings to the abbot of the local monastery, who made a drink with the berries and found that it kept him alert through the long hours of evening prayer. The abbot shared his discovery with the other monks at the monastery, and knowledge of the energizing berries began to spread.</p>
<p class=\"p1\">As word moved east and coffee reached the Arabian peninsula, it began a journey which would bring these beans across the globe.</p>

<h3 class=\"p1\" style=\"text-align: center;\">The Arabian Peninsula</h3>
<p class=\"p1\">Coffee cultivation and trade began on the Arabian Peninsula.  By the 15th century, coffee was being grown in the Yemeni district of Arabia and by the 16th century it was known in Persia, Egypt, Syria, and Turkey.</p>
<p class=\"p1\">Coffee was not only enjoyed in homes, but also in the many public coffee houses — called <em>qahveh khaneh</em> — which began to appear in cities across the Near East. The popularity of the coffee houses was unequaled and people frequented them for all kinds of social activity.</p>
<p class=\"p2\">Not only did the patrons drink coffee and engage in conversation, but they also listened to music, watched performers, played chess and kept current on the news.  Coffee houses quickly became such an important center for the exchange of information that they were often referred to as “Schools of the Wise.”</p>
<p class=\"p1\">With thousands of pilgrims visiting the holy city of Mecca each year from all over the world, knowledge of this “wine of Araby” began to spread.</p>

<h3 class=\"p1\" style=\"text-align: center;\">Coffee Comes to Europe</h3>
<p class=\"p1\">European travelers to the Near East brought back stories of an unusual dark black beverage. By the 17th century, coffee had made its way to Europe and was becoming popular across the continent.</p>
<p class=\"p2\">Some people reacted to this new beverage with suspicion or fear, calling it the “bitter invention of Satan.” The local clergy condemned coffee when it came to Venice in 1615. The controversy was so great that Pope Clement VIII was asked to intervene. He decided to taste the beverage for himself before making a decision, and found the drink so satisfying that he gave it papal approval.</p>
<p class=\"p2\">Despite such controversy, coffee houses were quickly becoming centers of social activity and communication in the major cities of England, Austria, France, Germany and Holland. In England “penny universities” sprang up, so called because for the price of a penny one could purchase a cup of coffee and engage in stimulating conversation.</p>
<p class=\"p2\">Coffee began to replace the common breakfast drink beverages of the time — beer and wine. Those who drank coffee instead of alcohol began the day alert and energized, and not surprisingly, the quality of their work was greatly improved. (We like to think of this a precursor to the modern office coffee service.)</p>
<p class=\"p2\">By the mid-17th century, there were over 300 coffee houses in London, many of which attracted like-minded patrons, including merchants, shippers, brokers and artists.</p>
<p class=\"p2\">Many businesses grew out of these specialized coffee houses. Lloyd\'s of London, for example, came into existence at the Edward Lloyd\'s Coffee House.</p>

<h3></h3>
<h3 style=\"text-align: center;\">The New World</h3>
<p class=\"p2\">In the mid-1600\'s, coffee was brought to New Amsterdam, later called New York by the British.</p>
<p class=\"p2\">Though coffee houses rapidly began to appear, tea continued to be the favored drink in the New World until 1773, when the colonists revolted against a heavy tax on tea imposed by King George III. The revolt, known as the Boston Tea Party, would forever change the American drinking preference to coffee.</p>

<blockquote class=\"p2\">\"Coffee - the favorite drink of the civilized world.\" - Thomas Jefferson</blockquote>
<h3 class=\"p2\" style=\"text-align: center;\">Plantations Around the World</h3>
<p class=\"p1\">As demand for the beverage continued to spread, there was fierce competition to cultivate coffee outside of Arabia.</p>
<p class=\"p2\">The Dutch finally got seedlings in the latter half of the 17th century. Their first attempts to plant them in India failed, but they were successful with their efforts in Batavia, on the island of Java in what is now Indonesia.</p>
<p class=\"p1\">The plants thrived and soon the Dutch had a productive and growing trade in coffee. They then expanded the cultivation of coffee trees to the islands of Sumatra and Celebes.</p>

<h3 class=\"p2\" style=\"text-align: center;\">Coming to the Americas</h3>
<p class=\"p1\">In 1714, the Mayor of Amsterdam presented a gift of a young coffee plant to King Louis XIV of France. The King ordered it to be planted in the Royal Botanical Garden in Paris. In 1723, a young naval officer, Gabriel de Clieu obtained a seedling from the King\'s plant. Despite a challenging voyage — complete with horrendous weather, a saboteur who tried to destroy the seedling, and a pirate attack — he managed to transport it safely to Martinique.</p>
<p class=\"p2\">Once planted, the seedling not only thrived, but it’s credited with the spread of over 18 million coffee trees on the island of Martinique in the next 50 years. Even more incredible is that this seedling was the parent of all coffee trees throughout the Caribbean, South and Central America.</p>
<p class=\"p2\">The famed Brazilian coffee owes its existence to Francisco de Mello Palheta, who was sent by the emperor to French Guiana to get coffee seedlings. The French were not willing to share, but the French Governor\'s wife, captivated by his good looks, gave him a large bouquet of flowers before he left— buried inside were enough coffee seeds to begin what is today a billion-dollar industry.</p>
<p class=\"p2\">Missionaries and travelers, traders and colonists continued to carry coffee seeds to new lands, and coffee trees were planted worldwide. Plantations were established in magnificent tropical forests and on rugged mountain highlands. Some crops flourished, while others were short-lived. New nations were established on coffee economies. Fortunes were made and lost. By the end of the 18th century, coffee had become one of the world\'s most profitable export crops. After crude oil, coffee is the most sought commodity in the world<span class=\"s1\">.</span></p>
&nbsp;

© National Coffee Association of U.S.A., Inc", "History", "", "inherit", "closed", "closed", "", "9-revision-v1", "", "", "2017-12-18 19:46:09", "2017-12-19 00:46:09", "", "9", "http://localhost:8000/?p=108", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("109", "4", "2017-12-18 19:47:15", "2017-12-19 00:47:15", "{
    \"masonic_child::background_image\": {
        \"value\": \"http://localhost:8000/wp-content/uploads/2017/12/palkortum20.jpg\",
        \"type\": \"theme_mod\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 00:47:15\"
    }
}", "", "", "trash", "closed", "closed", "", "270c79b9-26f8-43a1-8144-e0b16f3054a9", "", "", "2017-12-18 19:47:15", "2017-12-19 00:47:15", "", "0", "http://localhost:8000/?p=109", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("111", "4", "2017-12-18 19:57:15", "2017-12-19 00:57:15", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a href=\"[url=http://radikal.ru][img]http://s018.radikal.ru/i518/1712/f9/dd9be1559d3c.png[/img][/url]\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/100a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/102b.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/102b.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 19:57:15", "2017-12-19 00:57:15", "", "15", "http://localhost:8000/?p=111", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("112", "4", "2017-12-18 19:59:19", "2017-12-19 00:59:19", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a href=\"http://s018.radikal.ru/i518/1712/f9/dd9be1559d3c.png\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/100a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/102b.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/102b.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 19:59:19", "2017-12-19 00:59:19", "", "15", "http://localhost:8000/?p=112", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("113", "4", "2017-12-18 20:02:32", "2017-12-19 01:02:32", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/102b.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/102b.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:02:32", "2017-12-19 01:02:32", "", "15", "http://localhost:8000/?p=113", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("114", "4", "2017-12-18 20:03:14", "2017-12-19 01:03:14", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=200/>
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/102b.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/102b.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:03:14", "2017-12-19 01:03:14", "", "15", "http://localhost:8000/?p=114", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("115", "4", "2017-12-18 20:06:23", "2017-12-19 01:06:23", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=200/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=200/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:06:23", "2017-12-19 01:06:23", "", "15", "http://localhost:8000/?p=115", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("116", "4", "2017-12-18 20:07:06", "2017-12-19 01:07:06", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=200/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=200/> 
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=200/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:07:06", "2017-12-19 01:07:06", "", "15", "http://localhost:8000/?p=116", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("117", "4", "2017-12-18 20:07:39", "2017-12-19 01:07:39", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:07:39", "2017-12-19 01:07:39", "", "15", "http://localhost:8000/?p=117", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("118", "4", "2017-12-18 20:09:12", "2017-12-19 01:09:12", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"\"http://s017.radikal.ru/i407/1712/d1/8065d64cf7e5.png\"\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:09:12", "2017-12-19 01:09:12", "", "15", "http://localhost:8000/?p=118", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("119", "4", "2017-12-18 20:09:43", "2017-12-19 01:09:43", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:09:43", "2017-12-19 01:09:43", "", "15", "http://localhost:8000/?p=119", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("120", "4", "2017-12-18 20:12:06", "2017-12-19 01:12:06", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Affogatos aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\">Caffè Americano-                                                                                                                   
You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:12:06", "2017-12-19 01:12:06", "", "15", "http://localhost:8000/?p=120", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("121", "4", "2017-12-18 20:13:10", "2017-12-19 01:13:10", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Affogatos aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\">Caffè Americano-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war. </td>                                                                                                              
</tr>
<tr>
<td class=\"jewellery\"><a href=\"images/JW/105a.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/105a.jpg\" alt=\"001\" />
</a></td>
<td class=\"jewellery\"><a href=\"images/JW/107.jpg\" target=\"_blank\" rel=\"noopener\">
<img src=\"images/JW/107.jpg\" alt=\"002\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
<td class=\"jewellery_desc\">Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:13:10", "2017-12-19 01:13:10", "", "15", "http://localhost:8000/?p=121", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("122", "4", "2017-12-18 20:16:58", "2017-12-19 01:16:58", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Affogatos aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\">Caffè Americano-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war. </td>                                                                                                              
</tr>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"\"http://s017.radikal.ru/i407/1712/d1/8065d64cf7e5.png\"\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=150/> 
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Cappuccino
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\">A cortado- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>

</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:16:58", "2017-12-19 01:16:58", "", "15", "http://localhost:8000/?p=122", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("123", "4", "2017-12-18 20:19:45", "2017-12-19 01:19:45", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i643/1712/66/948d7dc47e8a.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Affogatos aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\">Caffè Americano-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war. </td>                                                                                                              
</tr>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"\"http://s017.radikal.ru/i407/1712/d1/8065d64cf7e5.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=150/> 
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Cappuccino
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\">A cortado- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>

</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:19:45", "2017-12-19 01:19:45", "", "15", "http://localhost:8000/?p=123", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("124", "4", "2017-12-18 20:20:35", "2017-12-19 01:20:35", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Affogatos aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\">Caffè Americano-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war. </td>                                                                                                              
</tr>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"\"http://s017.radikal.ru/i407/1712/d1/8065d64cf7e5.png\" width=150/>
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=150/> 
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Cappuccino
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\">A cortado- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>

</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:20:35", "2017-12-19 01:20:35", "", "15", "http://localhost:8000/?p=124", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("125", "4", "2017-12-18 20:21:43", "2017-12-19 01:21:43", "&nbsp;
<table>
<tbody>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=150/> 
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=150/> 
</a></td>

</tr>
<tr>
<td class=\"jewellery_desc\">Affogatos aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\">Caffè Americano-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war. </td>                                                                                                              
</tr>
<tr>
<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=150/> 
</a></td>

<td class=\"jewellery\">
<a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=150/> 
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Cappuccino
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\">A cortado- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>

</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:21:43", "2017-12-19 01:21:43", "", "15", "http://localhost:8000/?p=125", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("126", "4", "2017-12-18 20:23:37", "2017-12-19 01:23:37", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 01:23:37\"
    }
}", "", "", "trash", "closed", "closed", "", "5b697e53-a622-417d-be57-17a50bec43e5", "", "", "2017-12-18 20:23:37", "2017-12-19 01:23:37", "", "0", "http://localhost:8000/?p=126", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("127", "4", "2017-12-18 20:23:37", "2017-12-19 01:23:37", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:150px;
		height:auto;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{
    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: bisque;
}

.jewellery_desc_home{
	  font-size: 80%;
    align-content: center;
    padding-left: 2%;
		color:brown;
	
}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "publish", "closed", "closed", "", "masonic_child", "", "", "2017-12-18 22:22:44", "2017-12-19 03:22:44", "", "0", "http://localhost:8000/?p=127", "0", "custom_css", "", "0");
INSERT INTO `wp_posts` VALUES("128", "4", "2017-12-18 20:23:37", "2017-12-19 01:23:37", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 20:23:37", "2017-12-19 01:23:37", "", "127", "http://localhost:8000/?p=128", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("129", "4", "2017-12-18 20:36:28", "2017-12-19 01:36:28", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:36:28", "2017-12-19 01:36:28", "", "15", "http://localhost:8000/?p=129", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("130", "4", "2017-12-18 20:41:08", "2017-12-19 01:41:08", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i528/1712/4e/735d72b33f8a.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s020.radikal.ru/i718/1712/ba/00862c951e0a.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Espresso
To make an espresso, shoot boiling water under high pressure through finely ground up coffee beans and then pour into a tiny mug. Sounds simple right? Well, it’s surprisingly difficult to master. Espressos are the purest coffee experience you can get, and while they’re not for everyone, it can be a truly singular drinking experience when you find a good brew.</td>
<td class=\"jewellery_desc\">Flat White
The most Aussie coffees available are the long black and the flat white – as both originated in Australia and New Zealand. For a flat white, the steamed milk from the bottom of the jug (which is usually not so frothy, but rather creamy) is poured over a shot of espresso. It is now popular among mums and dads at school fetes who are desperately trying to stay awake.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\" \" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:41:08", "2017-12-19 01:41:08", "", "15", "http://localhost:8000/?p=130", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("131", "4", "2017-12-18 20:43:39", "2017-12-19 01:43:39", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i528/1712/4e/735d72b33f8a.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s020.radikal.ru/i718/1712/ba/00862c951e0a.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Espresso
To make an espresso, shoot boiling water under high pressure through finely ground up coffee beans and then pour into a tiny mug. Sounds simple right? Well, it’s surprisingly difficult to master. Espressos are the purest coffee experience you can get, and while they’re not for everyone, it can be a truly singular drinking experience when you find a good brew.</td>
<td class=\"jewellery_desc\">Flat White
The most Aussie coffees available are the long black and the flat white – as both originated in Australia and New Zealand. For a flat white, the steamed milk from the bottom of the jug (which is usually not so frothy, but rather creamy) is poured over a shot of espresso. It is now popular among mums and dads at school fetes who are desperately trying to stay awake.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://i053.radikal.ru/1712/10/3ec08cfe8474.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s017.radikal.ru/i437/1712/41/ca147fb6b7c1.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\">Gibraltar 
The name gibraltar originated in San Francisco, California, where roasters – first Blue Bottle Coffee Company, later Ritual Coffee Roasters and others – started the cortado trend by serving the drink in Libbey Glass Company glassware by the same name</td>
<td class=\"jewellery_desc\">Mochachino
A ‘mocha’ is just a latte with added chocolate powder or syrup, as well as sometimes being topped with whipped cream. If anything, this is a good entry level coffee – living in the worlds between the childlike hot chocolate and the adult café latte.</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 20:43:39", "2017-12-19 01:43:39", "", "15", "http://localhost:8000/?p=131", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("132", "4", "2017-12-18 20:47:31", "2017-12-19 01:47:31", "", "https_cdn.evbuc.comimages385990791020846340631original", "", "inherit", "open", "closed", "", "https_cdn-evbuc-comimages385990791020846340631original", "", "", "2017-12-18 20:47:31", "2017-12-19 01:47:31", "", "17", "http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("133", "4", "2017-12-18 20:51:17", "2017-12-19 01:51:17", "<img class=\"alignleft wp-image-132\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg\" alt=\"001\" padding:1em />
<strong>DESCRIPTION</strong>
The focus of this class is the science behind brewing coffee, starting with the fundamental principles of extraction and ending in a deeper exploration into the application of these principles. In this session we also demonstrate a variety of popular brewing methods and equipment while examining their pros and cons.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.

At the end of this 2-hour lecture the floor is opened up for 30 minutes of questions and discussion, and yes, fresh brewed coffee is served at the start!
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 14 April 2018

10:00 AM – 12:00 PM EDT

&amp;50

</div>", "Coffee Lecture: Alchemy of Brewing", "", "inherit", "closed", "closed", "", "17-autosave-v1", "", "", "2017-12-18 20:51:17", "2017-12-19 01:51:17", "", "17", "http://localhost:8000/?p=133", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("134", "4", "2017-12-18 20:49:34", "2017-12-19 01:49:34", "<img class=\"alignleft  wp-image-132\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"332\" height=\"166\" />
<strong>DESCRIPTION</strong>
The focus of this class is the science behind brewing coffee, starting with the fundamental principles of extraction and ending in a deeper exploration into the application of these principles. In this session we also demonstrate a variety of popular brewing methods and equipment while examining their pros and cons.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.

At the end of this 2-hour lecture the floor is opened up for 30 minutes of questions and discussion, and yes, fresh brewed coffee is served at the start!
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 14 April 2018

10:00 AM – 12:00 PM EDT

&amp;50

</div>", "Coffee Lecture: Alchemy of Brewing", "", "inherit", "closed", "closed", "", "17-revision-v1", "", "", "2017-12-18 20:49:34", "2017-12-19 01:49:34", "", "17", "http://localhost:8000/?p=134", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("135", "4", "2017-12-18 20:51:05", "2017-12-19 01:51:05", "<img class=\"alignleft wp-image-132\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg\" alt=\"001\" padding:1em />
<strong>DESCRIPTION</strong>
The focus of this class is the science behind brewing coffee, starting with the fundamental principles of extraction and ending in a deeper exploration into the application of these principles. In this session we also demonstrate a variety of popular brewing methods and equipment while examining their pros and cons.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.

At the end of this 2-hour lecture the floor is opened up for 30 minutes of questions and discussion, and yes, fresh brewed coffee is served at the start!
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 14 April 2018

10:00 AM – 12:00 PM EDT

&amp;50

</div>", "Coffee Lecture: Alchemy of Brewing", "", "inherit", "closed", "closed", "", "17-revision-v1", "", "", "2017-12-18 20:51:05", "2017-12-19 01:51:05", "", "17", "http://localhost:8000/?p=135", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("136", "4", "2017-12-18 20:53:57", "2017-12-19 01:53:57", "<img class=\"alignleft size-full wp-image-137\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"800\" height=\"400\" />
<strong>DESCRIPTION</strong>
This class is akin to a wine tasting, but for coffee! We start by explaining how a coffee’s value and grade is determined, and what takes place inside typical coffee cupping rooms. Then we brew, taste and analyze three different fresh-roasted coffees, making notes on each one, learning to chart their acidity, body and complexity, as well as how to differentiate amoung the three main growing regions.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 5 May 2018

10:00 AM – 12:00 PM EDT
CAD50

</div>", "Coffee Lecture: Cupping & Tasting", "", "publish", "open", "open", "", "coffee-lecture-cupping-tasting", "", "", "2017-12-18 21:03:19", "2017-12-19 02:03:19", "", "0", "http://localhost:8000/?p=136", "0", "post", "", "0");
INSERT INTO `wp_posts` VALUES("137", "4", "2017-12-18 20:52:53", "2017-12-19 01:52:53", "", "https_cdn.evbuc.comimages385991881020846340631original", "", "inherit", "open", "closed", "", "https_cdn-evbuc-comimages385991881020846340631original", "", "", "2017-12-18 20:52:53", "2017-12-19 01:52:53", "", "136", "http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("138", "4", "2017-12-18 20:53:57", "2017-12-19 01:53:57", "<img class=\"alignleft size-full wp-image-137\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"800\" height=\"400\" />
<strong>DESCRIPTION</strong>
This class is akin to a wine tasting, but for coffee! We start by explaining how a coffee’s value and grade is determined, and what takes place inside typical coffee cupping rooms. Then we brew, taste and analyze three different fresh-roasted coffees, making notes on each one, learning to chart their acidity, body and complexity, as well as how to differentiate amoung the three main growing regions.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 5 May 2018

10:00 AM – 12:00 PM EDT
$50

</div>", "Coffee Lecture: Cupping & Tasting", "", "inherit", "closed", "closed", "", "136-revision-v1", "", "", "2017-12-18 20:53:57", "2017-12-19 01:53:57", "", "136", "http://localhost:8000/?p=138", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("139", "4", "2017-12-18 20:54:13", "2017-12-19 01:54:13", "<img class=\"alignleft size-full wp-image-137\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"800\" height=\"400\" />
<strong>DESCRIPTION</strong>
This class is akin to a wine tasting, but for coffee! We start by explaining how a coffee’s value and grade is determined, and what takes place inside typical coffee cupping rooms. Then we brew, taste and analyze three different fresh-roasted coffees, making notes on each one, learning to chart their acidity, body and complexity, as well as how to differentiate amoung the three main growing regions.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 5 May 2018

10:00 AM – 12:00 PM EDT
$50

</div>", "Coffee Lecture: Cupping & Tasting", "", "inherit", "closed", "closed", "", "136-autosave-v1", "", "", "2017-12-18 20:54:13", "2017-12-19 01:54:13", "", "136", "http://localhost:8000/?p=139", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("140", "4", "2017-12-18 20:56:06", "2017-12-19 01:56:06", "<img class=\"alignleft wp-image-141\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"534\" height=\"267\" />
<strong>DESCRIPTION</strong>
Our discovery of the naturally sweet taste of fresh-roasted coffee is the foundation of this class, which covers the science, history, and technology behind coffee roasting. In this session we also demonstrate a variety of methods for roasting coffee at home.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 17 March 2018

9:00 AM – 12:00 PM EDT
CAD50

</div>", "Coffee Lecture: Art of Roasting", "", "publish", "open", "open", "", "coffee-lecture-art-of-roasting", "", "", "2017-12-18 21:02:42", "2017-12-19 02:02:42", "", "0", "http://localhost:8000/?p=140", "0", "post", "", "0");
INSERT INTO `wp_posts` VALUES("141", "4", "2017-12-18 20:55:28", "2017-12-19 01:55:28", "", "https_cdn.evbuc.comimages385989661020846340631original", "", "inherit", "open", "closed", "", "https_cdn-evbuc-comimages385989661020846340631original", "", "", "2017-12-18 20:55:28", "2017-12-19 01:55:28", "", "140", "http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("142", "4", "2017-12-18 20:56:06", "2017-12-19 01:56:06", "<img class=\"alignleft  wp-image-141\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"534\" height=\"267\" />
<strong>DESCRIPTION</strong>
Our discovery of the naturally sweet taste of fresh-roasted coffee is the foundation of this class, which covers the science, history, and technology behind coffee roasting. In this session we also demonstrate a variety of methods for roasting coffee at home.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.", "Coffee Lecture: Art of Roasting", "", "inherit", "closed", "closed", "", "140-revision-v1", "", "", "2017-12-18 20:56:06", "2017-12-19 01:56:06", "", "140", "http://localhost:8000/?p=142", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("143", "4", "2017-12-18 20:56:40", "2017-12-19 01:56:40", "<img class=\"alignleft wp-image-141\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"534\" height=\"267\" />
<strong>DESCRIPTION</strong>
Our discovery of the naturally sweet taste of fresh-roasted coffee is the foundation of this class, which covers the science, history, and technology behind coffee roasting. In this session we also demonstrate a variety of methods for roasting coffee at home.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 17 March 2018

9:00 AM – 12:00 PM EDT
$50

</div>", "Coffee Lecture: Art of Roasting", "", "inherit", "closed", "closed", "", "140-revision-v1", "", "", "2017-12-18 20:56:40", "2017-12-19 01:56:40", "", "140", "http://localhost:8000/?p=143", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("144", "4", "2017-12-18 20:58:23", "2017-12-19 01:58:23", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 01:58:23\"
    }
}", "", "", "trash", "closed", "closed", "", "66641c8d-6a09-43c8-af95-790a90c4048c", "", "", "2017-12-18 20:58:23", "2017-12-19 01:58:23", "", "0", "http://localhost:8000/?p=144", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("145", "4", "2017-12-18 20:58:24", "2017-12-19 01:58:24", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 20:58:24", "2017-12-19 01:58:24", "", "127", "http://localhost:8000/?p=145", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("146", "4", "2017-12-18 20:59:15", "2017-12-19 01:59:15", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n\\tborder: 2px solid brown;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 01:59:15\"
    }
}", "", "", "trash", "closed", "closed", "", "2bb2affb-65f1-46dd-995a-f1d020915c06", "", "", "2017-12-18 20:59:15", "2017-12-19 01:59:15", "", "0", "http://localhost:8000/?p=146", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("147", "4", "2017-12-18 20:59:15", "2017-12-19 01:59:15", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
	border: 2px solid brown;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 20:59:15", "2017-12-19 01:59:15", "", "127", "http://localhost:8000/?p=147", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("148", "4", "2017-12-18 20:59:31", "2017-12-19 01:59:31", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 01:59:31\"
    }
}", "", "", "trash", "closed", "closed", "", "91ed3e62-1ab9-43ec-82f5-406cb8d9267c", "", "", "2017-12-18 20:59:31", "2017-12-19 01:59:31", "", "0", "http://localhost:8000/?p=148", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("149", "4", "2017-12-18 20:59:31", "2017-12-19 01:59:31", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 20:59:31", "2017-12-19 01:59:31", "", "127", "http://localhost:8000/?p=149", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("150", "4", "2017-12-18 21:02:42", "2017-12-19 02:02:42", "<img class=\"alignleft wp-image-141\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"534\" height=\"267\" />
<strong>DESCRIPTION</strong>
Our discovery of the naturally sweet taste of fresh-roasted coffee is the foundation of this class, which covers the science, history, and technology behind coffee roasting. In this session we also demonstrate a variety of methods for roasting coffee at home.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 17 March 2018

9:00 AM – 12:00 PM EDT
CAD50

</div>", "Coffee Lecture: Art of Roasting", "", "inherit", "closed", "closed", "", "140-revision-v1", "", "", "2017-12-18 21:02:42", "2017-12-19 02:02:42", "", "140", "http://localhost:8000/?p=150", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("151", "4", "2017-12-18 21:03:19", "2017-12-19 02:03:19", "<img class=\"alignleft size-full wp-image-137\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg\" alt=\"\" width=\"800\" height=\"400\" />
<strong>DESCRIPTION</strong>
This class is akin to a wine tasting, but for coffee! We start by explaining how a coffee’s value and grade is determined, and what takes place inside typical coffee cupping rooms. Then we brew, taste and analyze three different fresh-roasted coffees, making notes on each one, learning to chart their acidity, body and complexity, as well as how to differentiate amoung the three main growing regions.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 5 May 2018

10:00 AM – 12:00 PM EDT
CAD50

</div>", "Coffee Lecture: Cupping & Tasting", "", "inherit", "closed", "closed", "", "136-revision-v1", "", "", "2017-12-18 21:03:19", "2017-12-19 02:03:19", "", "136", "http://localhost:8000/?p=151", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("153", "4", "2017-12-18 21:04:01", "2017-12-19 02:04:01", "<img class=\"alignleft wp-image-132\" src=\"http://localhost:8000/wp-content/uploads/2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg\" alt=\"001\" padding:1em />
<strong>DESCRIPTION</strong>
The focus of this class is the science behind brewing coffee, starting with the fundamental principles of extraction and ending in a deeper exploration into the application of these principles. In this session we also demonstrate a variety of popular brewing methods and equipment while examining their pros and cons.

This coffee lecture is led by Merchants of Green Coffee\'s CEO and aims to be a source of unbiased information learned throughout the company\'s 20+ year history of sourcing and marketing certified green coffees while helping to pioneer innovative off-grid coffee production programs, and educate consumers about coffee quality.

In no way a sales pitch, this lecture is full of little-known coffee information that\'s chosen with discretion and delivered in a way that is uniquely raw and witty. This class has been evolving for more than 10 years and is attended by many different people of varying coffee knowledge; from everyday coffee drinkers, to people who work in coffee or are interested in entering the industry, writers, professors, foodies, curious consumers and so on.

At the end of this 2-hour lecture the floor is opened up for 30 minutes of questions and discussion, and yes, fresh brewed coffee is served at the start!
<h3 class=\"label-primary l-mar-bot-2\" data-automation=\"listing-info-language\">DATE AND TIME</h3>
<div class=\"event-details__data\">

Sat, 14 April 2018

10:00 AM – 12:00 PM EDT

CAD50

</div>", "Coffee Lecture: Alchemy of Brewing", "", "inherit", "closed", "closed", "", "17-revision-v1", "", "", "2017-12-18 21:04:01", "2017-12-19 02:04:01", "", "17", "http://localhost:8000/?p=153", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("154", "4", "2017-12-21 15:59:17", "2017-12-21 20:59:17", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=15\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=19\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=11\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-autosave-v1", "", "", "2017-12-21 15:59:17", "2017-12-21 20:59:17", "", "6", "http://localhost:8000/?p=154", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("155", "4", "2017-12-18 21:09:38", "2017-12-19 02:09:38", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\">
<strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:09:38", "2017-12-19 02:09:38", "", "6", "http://localhost:8000/?p=155", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("156", "4", "2017-12-18 21:10:04", "2017-12-19 02:10:04", "", "535620b33317274", "", "inherit", "open", "closed", "", "535620b33317274", "", "", "2017-12-18 21:10:04", "2017-12-19 02:10:04", "", "6", "http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg", "0", "attachment", "image/jpeg", "0");
INSERT INTO `wp_posts` VALUES("157", "4", "2017-12-18 21:10:35", "2017-12-19 02:10:35", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:10:35", "2017-12-19 02:10:35", "", "6", "http://localhost:8000/?p=157", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("158", "4", "2017-12-18 21:13:46", "2017-12-19 02:13:46", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
                                <a target=\"_blank\" href=\"images/JW/100a.jpg\">
                                    <img src=\"images/JW/100a.jpg\" alt=\"001\">
                                </a>
                            </td>
                            <td class=\"jewellery\">
                                <a target=\"_blank\" href=\"images/JW/102b.jpg\">
                                    <img src=\"images/JW/102b.jpg\" alt=\"002\">
                                </a>
                            </td>
                            <td class=\"jewellery\">
                                <a target=\"_blank\" href=\"images/JW/100a.jpg\">
                                    <img src=\"images/JW/100a.jpg\" alt=\"001\">
                                </a>
                            </td>
                            <td class=\"jewellery\">
                                <a target=\"_blank\" href=\"images/JW/102b.jpg\">
                                    <img src=\"images/JW/102b.jpg\" alt=\"002\">
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</p>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Set consists of earrings, ring and brooch Swarovski crystals, antique brass color metal findings</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:13:46", "2017-12-19 02:13:46", "", "6", "http://localhost:8000/?p=158", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("159", "4", "2017-12-18 21:22:53", "2017-12-19 02:22:53", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:22:53", "2017-12-19 02:22:53", "", "6", "http://localhost:8000/?p=159", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("160", "4", "2017-12-18 21:24:22", "2017-12-19 02:24:22", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" width=100 /></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" width=100/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" width=100/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" width=100/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:24:22", "2017-12-19 02:24:22", "", "6", "http://localhost:8000/?p=160", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("161", "4", "2017-12-18 21:26:30", "2017-12-19 02:26:30", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" width=100 /></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" width=100/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" width=100/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" width=100/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:26:30", "2017-12-19 02:26:30", "", "6", "http://localhost:8000/?p=161", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("162", "4", "2017-12-18 21:26:57", "2017-12-19 02:26:57", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" width=400 /></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" width=100/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" width=100/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" width=100/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:26:57", "2017-12-19 02:26:57", "", "6", "http://localhost:8000/?p=162", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("163", "4", "2017-12-18 21:27:43", "2017-12-19 02:27:43", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\"/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\"/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\"/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\"/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:27:43", "2017-12-19 02:27:43", "", "6", "http://localhost:8000/?p=163", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("164", "4", "2017-12-18 21:29:26", "2017-12-19 02:29:26", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 02:29:26\"
    }
}", "", "", "trash", "closed", "closed", "", "9d47075e-5acd-4dd1-af14-e32cb0e9328a", "", "", "2017-12-18 21:29:26", "2017-12-19 02:29:26", "", "0", "http://localhost:8000/?p=164", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("165", "4", "2017-12-18 21:29:27", "2017-12-19 02:29:27", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 21:29:27", "2017-12-19 02:29:27", "", "127", "http://localhost:8000/?p=165", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("166", "4", "2017-12-18 21:30:15", "2017-12-19 02:30:15", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" width=200/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" width=200/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" width=200/></a>
                            </td>
                            <td class=\"jewellery\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" width=200/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:30:15", "2017-12-19 02:30:15", "", "6", "http://localhost:8000/?p=166", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("167", "4", "2017-12-18 21:32:37", "2017-12-19 02:32:37", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_home img{\\n\\t  width:80%;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 02:32:37\"
    }
}", "", "", "trash", "closed", "closed", "", "d8282859-4f15-47aa-a1b9-100a46723ca1", "", "", "2017-12-18 21:32:37", "2017-12-19 02:32:37", "", "0", "http://localhost:8000/?p=167", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("168", "4", "2017-12-18 21:32:38", "2017-12-19 02:32:38", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:80%;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 21:32:38", "2017-12-19 02:32:38", "", "127", "http://localhost:8000/?p=168", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("169", "4", "2017-12-18 21:32:43", "2017-12-19 02:32:43", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery_home\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\"/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:32:43", "2017-12-19 02:32:43", "", "6", "http://localhost:8000/?p=169", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("170", "4", "2017-12-18 21:33:26", "2017-12-19 02:33:26", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_home img{\\n\\t  width:50%;\\n\\t\\theight:auto;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 02:33:26\"
    }
}", "", "", "trash", "closed", "closed", "", "1eaf55fb-dacb-42f5-a9ff-3c9c71f7f6a9", "", "", "2017-12-18 21:33:26", "2017-12-19 02:33:26", "", "0", "http://localhost:8000/?p=170", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("171", "4", "2017-12-18 21:33:27", "2017-12-19 02:33:27", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:50%;
		height:auto;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 21:33:27", "2017-12-19 02:33:27", "", "127", "http://localhost:8000/?p=171", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("172", "4", "2017-12-18 21:34:08", "2017-12-19 02:34:08", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_home img{\\n\\t  width:150px;\\n\\t\\theight:auto;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n\\n.jewellery_desc{\\n\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 02:34:08\"
    }
}", "", "", "trash", "closed", "closed", "", "f857ad4a-75b1-4ab9-8bb7-5a84249073f7", "", "", "2017-12-18 21:34:08", "2017-12-19 02:34:08", "", "0", "http://localhost:8000/?p=172", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("173", "4", "2017-12-18 21:34:09", "2017-12-19 02:34:09", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:150px;
		height:auto;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{

    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 21:34:09", "2017-12-19 02:34:09", "", "127", "http://localhost:8000/?p=173", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("174", "4", "2017-12-18 21:35:17", "2017-12-19 02:35:17", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_home img{\\n\\t  width:150px;\\n\\t\\theight:auto;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n\\n.jewellery_desc{\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;\\n}\\n\\n.jewellery_desc_home{\\n\\t  font-size: 80%;\\n    align-content: center;\\n    padding-left: 2%;\\n\\t\\tbackground-color: #f9caae;\\n}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 02:35:17\"
    }
}", "", "", "trash", "closed", "closed", "", "7d63832b-c246-4d2b-b53e-4e1cc7b0f5b0", "", "", "2017-12-18 21:35:17", "2017-12-19 02:35:17", "", "0", "http://localhost:8000/?p=174", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("175", "4", "2017-12-18 21:34:46", "2017-12-19 02:34:46", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery_home\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"http://radikal.ru\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\"/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc_home\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc_home\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc_home\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc_home\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:34:46", "2017-12-19 02:34:46", "", "6", "http://localhost:8000/?p=175", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("176", "4", "2017-12-18 21:35:18", "2017-12-19 02:35:18", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:150px;
		height:auto;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{
    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;
}

.jewellery_desc_home{
	  font-size: 80%;
    align-content: center;
    padding-left: 2%;
		background-color: #f9caae;
}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 21:35:18", "2017-12-19 02:35:18", "", "127", "http://localhost:8000/?p=176", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("177", "4", "2017-12-18 21:36:33", "2017-12-19 02:36:33", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_home img{\\n\\t  width:150px;\\n\\t\\theight:auto;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n\\n.jewellery_desc{\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: #f9caae;\\n}\\n\\n.jewellery_desc_home{\\n\\t  font-size: 80%;\\n    align-content: center;\\n    padding-left: 2%;\\n\\t\\tcolor:brown;\\n\\t\\n}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 02:36:33\"
    }
}", "", "", "trash", "closed", "closed", "", "afc7f298-9d68-4e77-a3a8-10facefb104c", "", "", "2017-12-18 21:36:33", "2017-12-19 02:36:33", "", "0", "http://localhost:8000/?p=177", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("178", "4", "2017-12-18 21:36:33", "2017-12-19 02:36:33", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:150px;
		height:auto;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{
    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: #f9caae;
}

.jewellery_desc_home{
	  font-size: 80%;
    align-content: center;
    padding-left: 2%;
		color:brown;
	
}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 21:36:33", "2017-12-19 02:36:33", "", "127", "http://localhost:8000/?p=178", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("179", "4", "2017-12-18 21:37:28", "2017-12-19 02:37:28", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery_home\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\"/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc_home\">
                                <p>Click here to see more events!</p>
                            </td>
                            <td class=\"jewellery_desc_home\">
                                <p>Click here to see more recepies!</p>
                            </td>
                              <td class=\"jewellery_desc_home\">
                                <p>Click here to place the order!</p>
                            </td>
                            <td class=\"jewellery_desc_home\">
                                <p>Contact us!</p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:37:28", "2017-12-19 02:37:28", "", "6", "http://localhost:8000/?p=179", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("180", "4", "2017-12-18 21:37:57", "2017-12-19 02:37:57", "<h2 style=\"text-align: center;\">Welcome to Coffee Hall</h2>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
 <table>
                        <tr>
                            <td class=\"jewellery_home\">
  <a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\"/></a>
                            </td>
                            <td class=\"jewellery_home\">
<a target=\"_blank\" href=\"#\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\"/></a>
                            </td>
                        </tr>
                        <tr>
                            <td class=\"jewellery_desc_home\">
                                <p><strong>Click here to see more events!</strong></p>
                            </td>
                            <td class=\"jewellery_desc_home\">
                                <p><strong>Click here to see more recepies!</strong></p>
                            </td>
                              <td class=\"jewellery_desc_home\">
                                <p><strong>Click here to place the order!</strong></p>
                            </td>
                            <td class=\"jewellery_desc_home\">
                                <p><strong>Contact us!</strong></p>
                            </td>
                        </tr>
                       
                    </table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:37:57", "2017-12-19 02:37:57", "", "6", "http://localhost:8000/?p=180", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("181", "4", "2017-12-18 21:40:39", "2017-12-19 02:40:39", "<h1 style=\"text-align: center;\">Welcome to Coffee Hall</h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:40:39", "2017-12-19 02:40:39", "", "6", "http://localhost:8000/?p=181", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("182", "4", "2017-12-18 21:41:14", "2017-12-19 02:41:14", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-18 21:41:14", "2017-12-19 02:41:14", "", "6", "http://localhost:8000/?p=182", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("183", "4", "2017-12-18 22:18:18", "2017-12-19 03:18:18", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i528/1712/4e/735d72b33f8a.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s020.radikal.ru/i718/1712/ba/00862c951e0a.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Espresso</strong>
To make an espresso, shoot boiling water under high pressure through finely ground up coffee beans and then pour into a tiny mug. Sounds simple right? Well, it’s surprisingly difficult to master. Espressos are the purest coffee experience you can get, and while they’re not for everyone, it can be a truly singular drinking experience when you find a good brew.</td>
<td class=\"jewellery_desc\"><strong>Flat White</strong>
The most Aussie coffees available are the long black and the flat white – as both originated in Australia and New Zealand. For a flat white, the steamed milk from the bottom of the jug (which is usually not so frothy, but rather creamy) is poured over a shot of espresso. It is now popular among mums and dads at school fetes who are desperately trying to stay awake.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://i053.radikal.ru/1712/10/3ec08cfe8474.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s017.radikal.ru/i437/1712/41/ca147fb6b7c1.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Gibraltar</strong> 
The name gibraltar originated in San Francisco, California, where roasters – first Blue Bottle Coffee Company, later Ritual Coffee Roasters and others – started the cortado trend by serving the drink in Libbey Glass Company glassware by the same name</td>
<td class=\"jewellery_desc\"><strong>Mochachino</strong>
A ‘mocha’ is just a latte with added chocolate powder or syrup, as well as sometimes being topped with whipped cream. If anything, this is a good entry level coffee – living in the worlds between the childlike hot chocolate and the adult café latte.</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 22:18:18", "2017-12-19 03:18:18", "", "15", "http://localhost:8000/?p=183", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("185", "4", "2017-12-18 22:19:52", "2017-12-19 03:19:52", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i501/1712/ed/872c895081d4.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i528/1712/4e/735d72b33f8a.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s020.radikal.ru/i718/1712/ba/00862c951e0a.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Espresso</strong>
To make an espresso, shoot boiling water under high pressure through finely ground up coffee beans and then pour into a tiny mug. Sounds simple right? Well, it’s surprisingly difficult to master. Espressos are the purest coffee experience you can get, and while they’re not for everyone, it can be a truly singular drinking experience when you find a good brew.</td>
<td class=\"jewellery_desc\"><strong>Flat White</strong>
The most Aussie coffees available are the long black and the flat white – as both originated in Australia and New Zealand. For a flat white, the steamed milk from the bottom of the jug (which is usually not so frothy, but rather creamy) is poured over a shot of espresso. It is now popular among mums and dads at school fetes who are desperately trying to stay awake.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://i053.radikal.ru/1712/10/3ec08cfe8474.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s017.radikal.ru/i437/1712/41/ca147fb6b7c1.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Gibraltar</strong> 
The name gibraltar originated in San Francisco, California, where roasters – first Blue Bottle Coffee Company, later Ritual Coffee Roasters and others – started the cortado trend by serving the drink in Libbey Glass Company glassware by the same name</td>
<td class=\"jewellery_desc\"><strong>Mochachino</strong>
A ‘mocha’ is just a latte with added chocolate powder or syrup, as well as sometimes being topped with whipped cream. If anything, this is a good entry level coffee – living in the worlds between the childlike hot chocolate and the adult café latte.</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-revision-v1", "", "", "2017-12-18 22:19:52", "2017-12-19 03:19:52", "", "15", "http://localhost:8000/?p=185", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("186", "4", "2017-12-18 22:22:44", "2017-12-19 03:22:44", "{
    \"custom_css[masonic_child]\": {
        \"value\": \".jewellery {\\n    border: 1px solid black;\\n}\\n\\n.jewellery img{\\n    width:80%;\\n    min-width: 200px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n.jewellery_home img{\\n\\t  width:150px;\\n\\t\\theight:auto;\\n    min-width: 100px;\\n    max-width: 40%;\\n    padding-bottom: .5em;\\n    padding-top: .5em;\\n    display: block;\\n    margin: auto;\\n}\\n\\n\\n.jewellery_desc{\\n    font-size: 80%;\\n    align-content: center;\\n    border: 1px solid black;\\n    padding-left: 2%;\\n\\tbackground-color: bisque;\\n}\\n\\n.jewellery_desc_home{\\n\\t  font-size: 80%;\\n    align-content: center;\\n    padding-left: 2%;\\n\\t\\tcolor:brown;\\n\\t\\n}\\n\\n.alignleft{\\n\\tfloat:left;\\n\\tpadding:1em;\\n}\",
        \"type\": \"custom_css\",
        \"user_id\": 4,
        \"date_modified_gmt\": \"2017-12-19 03:22:44\"
    }
}", "", "", "trash", "closed", "closed", "", "16acd817-5fd3-4542-93f8-5d35ea93781d", "", "", "2017-12-18 22:22:44", "2017-12-19 03:22:44", "", "0", "http://localhost:8000/?p=186", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("187", "4", "2017-12-18 22:22:44", "2017-12-19 03:22:44", ".jewellery {
    border: 1px solid black;
}

.jewellery img{
    width:80%;
    min-width: 200px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}

.jewellery_home img{
	  width:150px;
		height:auto;
    min-width: 100px;
    max-width: 40%;
    padding-bottom: .5em;
    padding-top: .5em;
    display: block;
    margin: auto;
}


.jewellery_desc{
    font-size: 80%;
    align-content: center;
    border: 1px solid black;
    padding-left: 2%;
	background-color: bisque;
}

.jewellery_desc_home{
	  font-size: 80%;
    align-content: center;
    padding-left: 2%;
		color:brown;
	
}

.alignleft{
	float:left;
	padding:1em;
}", "masonic_child", "", "inherit", "closed", "closed", "", "127-revision-v1", "", "", "2017-12-18 22:22:44", "2017-12-19 03:22:44", "", "127", "http://localhost:8000/?p=187", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("188", "4", "2017-12-18 22:23:47", "2017-12-19 03:23:47", "
[generate-get-coffee-page]

", "Get Coffee", "", "inherit", "closed", "closed", "", "19-revision-v1", "", "", "2017-12-18 22:23:47", "2017-12-19 03:23:47", "", "19", "http://localhost:8000/?p=188", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("192", "3", "2017-12-21 12:42:20", "2017-12-21 17:42:20", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-21 12:42:20", "2017-12-21 17:42:20", "", "6", "http://localhost:8000/?p=192", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("194", "3", "2017-12-21 12:43:40", "2017-12-21 17:43:40", "<h2 style=\"text-align: center;\"><strong>Sorts of Coffee</strong></h2>
<table>
<tbody>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s16.radikal.ru/i190/1712/e4/a19ce0800927.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s03.radikal.ru/i176/1712/04/6003b94308cc.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Affogatos</strong> aren’t a coffee at all really, as they’re a shot of espresso poured over a desert (usually ice cream). That doesn’t make them any less delicious though.</td>
<td class=\"jewellery_desc\"><strong>Caffè Americano</strong>-You can make this type of coffee quite simply by adding hot water to a shot of espresso coffee. It has been said that American soldiers during the Second World War would make this type of coffee to make their beverages last longer. It was then (apparently) adopted by American baristas after the war.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i501/1712/ed/872c895081d4.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s019.radikal.ru/i618/1712/7c/7c1f0d4045b8.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Cappuccino</strong>
Possibly the most popular type of coffee in the world, a cappuccino consists of three layers (kind of like a cake). The first is a shot of espresso, then a shot of steamed milk, and finally the barista adds a layer of frothed, foamy milk. This final layer can also be topped with chocolate shavings or powder. Traditionally, Italians would consume this type of coffee at breakfast.</td>
<td class=\"jewellery_desc\"><strong>A cortado</strong>- is a Spanish-origin general term for a beverage consisting of either coffee or espresso mixed with a roughly equal amount of warm milk to reduce the acidity.[1][2] On American specialty coffee menus, the milk in a cortado is usually dense rather than frothy or foamy</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s018.radikal.ru/i528/1712/4e/735d72b33f8a.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s020.radikal.ru/i718/1712/ba/00862c951e0a.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Espresso</strong>
To make an espresso, shoot boiling water under high pressure through finely ground up coffee beans and then pour into a tiny mug. Sounds simple right? Well, it’s surprisingly difficult to master. Espressos are the purest coffee experience you can get, and while they’re not for everyone, it can be a truly singular drinking experience when you find a good brew.</td>
<td class=\"jewellery_desc\"><strong>Flat White</strong>
The most Aussie coffees available are the long black and the flat white – as both originated in Australia and New Zealand. For a flat white, the steamed milk from the bottom of the jug (which is usually not so frothy, but rather creamy) is poured over a shot of espresso. It is now popular among mums and dads at school fetes who are desperately trying to stay awake.</td>
</tr>
<tr>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://i053.radikal.ru/1712/10/3ec08cfe8474.png\" width=\"150/\" />
</a></td>
<td class=\"jewellery\"><a target=\"_blank\" rel=\"noopener\">
<img src=\"http://s017.radikal.ru/i437/1712/41/ca147fb6b7c1.png\" width=\"150/\" />
</a></td>
</tr>
<tr>
<td class=\"jewellery_desc\"><strong>Gibraltar</strong> 
The name gibraltar originated in San Francisco, California, where roasters – first Blue Bottle Coffee Company, later Ritual Coffee Roasters and others – started the cortado trend by serving the drink in Libbey Glass Company glassware by the same name</td>
<td class=\"jewellery_desc\"><strong>Mochachino</strong>
A ‘mocha’ is just a latte with added chocolate powder or syrup, as well as sometimes being topped with whipped cream. If anything, this is a good entry level coffee – living in the worlds between the childlike hot chocolate and the adult café latte.</td>
</tr>
</tbody>
</table>", "Catalog", "", "inherit", "closed", "closed", "", "15-autosave-v1", "", "", "2017-12-21 12:43:40", "2017-12-21 17:43:40", "", "15", "http://localhost:8000/?p=194", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("195", "3", "2017-12-21 12:44:11", "2017-12-21 17:44:11", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=15&preview_id=15&preview_nonce=a97062a05f&_thumbnail_id=-1&preview=true\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-21 12:44:11", "2017-12-21 17:44:11", "", "6", "http://localhost:8000/?p=195", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("196", "3", "2017-12-21 12:45:20", "2017-12-21 17:45:20", "[generate-get-coffee-page]

", "Get Coffee", "", "inherit", "closed", "closed", "", "19-autosave-v1", "", "", "2017-12-21 12:45:20", "2017-12-21 17:45:20", "", "19", "http://localhost:8000/?p=196", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("197", "3", "2017-12-21 12:45:44", "2017-12-21 17:45:44", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=15&preview_id=15&preview_nonce=a97062a05f&_thumbnail_id=-1&preview=true\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=19&preview_id=19&preview_nonce=31d04dc847&_thumbnail_id=-1&preview=true\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"#\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-21 12:45:44", "2017-12-21 17:45:44", "", "6", "http://localhost:8000/?p=197", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("198", "3", "2017-12-21 12:46:26", "2017-12-21 17:46:26", "[weforms id=\"40\"]

Change map to the location of Coffee Hall.
<iframe style=\"border: 0;\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d16398.925008917766!2d-80.43201189453553!3d43.3990210903041!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x882b8abcb983287b%3A0x3a4f69c14ee1cc80!2sWaterloo+Region+Museum!5e0!3m2!1sen!2sca!4v1512429559472\" width=\"600\" height=\"450\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe>", "Contact", "", "inherit", "closed", "closed", "", "11-autosave-v1", "", "", "2017-12-21 12:46:26", "2017-12-21 17:46:26", "", "11", "http://localhost:8000/?p=198", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("199", "3", "2017-12-21 12:46:52", "2017-12-21 17:46:52", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=15&preview_id=15&preview_nonce=a97062a05f&_thumbnail_id=-1&preview=true\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=19&preview_id=19&preview_nonce=31d04dc847&_thumbnail_id=-1&preview=true\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=11&preview_id=11&preview_nonce=daba344b8e&_thumbnail_id=-1&preview=true\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-21 12:46:52", "2017-12-21 17:46:52", "", "6", "http://localhost:8000/?p=199", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("200", "3", "2017-12-21 12:48:05", "2017-12-21 17:48:05", "{
    \"blogdescription\": {
        \"value\": \"Find unique coffee!\",
        \"type\": \"option\",
        \"user_id\": 3,
        \"date_modified_gmt\": \"2017-12-21 17:48:05\"
    }
}", "", "", "trash", "closed", "closed", "", "e996e55f-b9c1-468c-a77f-7ae4ede30b86", "", "", "2017-12-21 12:48:05", "2017-12-21 17:48:05", "", "0", "http://localhost:8000/?p=200", "0", "customize_changeset", "", "0");
INSERT INTO `wp_posts` VALUES("201", "4", "2017-12-21 15:59:10", "2017-12-21 20:59:10", "<h1 style=\"text-align: center;\"><strong>Welcome to Coffee Hall</strong></h1>
<p style=\"text-align: center;\"><strong>Coffee Hall is a small but fierce shop that roasts seasonal coffees people love.</strong>
<strong> All of our coffees are Direct Trade, transparently sourced,</strong>
<strong> and roasted in small batches.</strong>
<strong> We also offer tiger training to cafes and cubs alike at our workshop in Kitchener-Waterloo or at your cafe.</strong></p>
<img class=\"size-full wp-image-156 aligncenter\" src=\"http://localhost:8000/wp-content/uploads/2017/12/535620b33317274.jpg\" alt=\"\" width=\"617\" height=\"260\" />
<table>
<tbody>
<tr>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=13\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i503/1712/35/e570a4c3616a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=15\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i513/1712/84/11661962f368.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=19\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s020.radikal.ru/i722/1712/a1/16efa793339a.png\" /></a></td>
<td class=\"jewellery_home\"><a href=\"index.php/?page_id=11\" target=\"_blank\" rel=\"noopener\"><img src=\"http://s018.radikal.ru/i526/1712/e6/f8a0d8ab32d2.png\" /></a></td>
</tr>
<tr>
<td class=\"jewellery_desc_home\"><strong>Click here to see more events!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to see more recepies!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Click here to place the order!</strong></td>
<td class=\"jewellery_desc_home\"><strong>Contact us!</strong></td>
</tr>
</tbody>
</table>", "Home", "", "inherit", "closed", "closed", "", "6-revision-v1", "", "", "2017-12-21 15:59:10", "2017-12-21 20:59:10", "", "6", "http://localhost:8000/?p=201", "0", "revision", "", "0");
INSERT INTO `wp_posts` VALUES("202", "1", "2017-12-29 12:44:24", "0000-00-00 00:00:00", "", "Auto Draft", "", "auto-draft", "open", "open", "", "", "", "", "2017-12-29 12:44:24", "0000-00-00 00:00:00", "", "0", "http://localhost:8000/?p=202", "0", "post", "", "0");
INSERT INTO `wp_posts` VALUES("203", "1", "2017-12-29 13:11:19", "0000-00-00 00:00:00", "", "Auto Draft", "", "auto-draft", "open", "open", "", "", "", "", "2017-12-29 13:11:19", "0000-00-00 00:00:00", "", "0", "http://localhost:8000/?p=203", "0", "post", "", "0");

/* INSERT TABLE DATA: wp_postmeta */
INSERT INTO `wp_postmeta` VALUES("14", "6", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("15", "6", "_edit_lock", "1513889999:4");
INSERT INTO `wp_postmeta` VALUES("16", "9", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("17", "9", "_edit_lock", "1513644247:4");
INSERT INTO `wp_postmeta` VALUES("18", "11", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("19", "11", "_edit_lock", "1513878470:3");
INSERT INTO `wp_postmeta` VALUES("20", "13", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("21", "13", "_edit_lock", "1512673011:1");
INSERT INTO `wp_postmeta` VALUES("22", "15", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("23", "15", "_edit_lock", "1513878126:3");
INSERT INTO `wp_postmeta` VALUES("24", "17", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("25", "17", "_edit_lock", "1513649095:4");
INSERT INTO `wp_postmeta` VALUES("34", "19", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("35", "19", "_edit_lock", "1513878216:3");
INSERT INTO `wp_postmeta` VALUES("36", "22", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("37", "22", "_edit_lock", "1513629949:4");
INSERT INTO `wp_postmeta` VALUES("38", "24", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("39", "24", "_edit_lock", "1513087858:1");
INSERT INTO `wp_postmeta` VALUES("40", "26", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("41", "26", "_edit_lock", "1512489288:1");
INSERT INTO `wp_postmeta` VALUES("42", "28", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("43", "28", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("44", "28", "_menu_item_object_id", "26");
INSERT INTO `wp_postmeta` VALUES("45", "28", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("46", "28", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("47", "28", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("48", "28", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("49", "28", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("51", "29", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("52", "29", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("53", "29", "_menu_item_object_id", "24");
INSERT INTO `wp_postmeta` VALUES("54", "29", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("55", "29", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("56", "29", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("57", "29", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("58", "29", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("60", "30", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("61", "30", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("62", "30", "_menu_item_object_id", "19");
INSERT INTO `wp_postmeta` VALUES("63", "30", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("64", "30", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("65", "30", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("66", "30", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("67", "30", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("69", "31", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("70", "31", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("71", "31", "_menu_item_object_id", "15");
INSERT INTO `wp_postmeta` VALUES("72", "31", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("73", "31", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("74", "31", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("75", "31", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("76", "31", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("78", "32", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("79", "32", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("80", "32", "_menu_item_object_id", "13");
INSERT INTO `wp_postmeta` VALUES("81", "32", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("82", "32", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("83", "32", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("84", "32", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("85", "32", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("87", "33", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("88", "33", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("89", "33", "_menu_item_object_id", "11");
INSERT INTO `wp_postmeta` VALUES("90", "33", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("91", "33", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("92", "33", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("93", "33", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("94", "33", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("96", "34", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("97", "34", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("98", "34", "_menu_item_object_id", "9");
INSERT INTO `wp_postmeta` VALUES("99", "34", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("100", "34", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("101", "34", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("102", "34", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("103", "34", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("105", "35", "_menu_item_type", "post_type");
INSERT INTO `wp_postmeta` VALUES("106", "35", "_menu_item_menu_item_parent", "0");
INSERT INTO `wp_postmeta` VALUES("107", "35", "_menu_item_object_id", "6");
INSERT INTO `wp_postmeta` VALUES("108", "35", "_menu_item_object", "page");
INSERT INTO `wp_postmeta` VALUES("109", "35", "_menu_item_target", "");
INSERT INTO `wp_postmeta` VALUES("110", "35", "_menu_item_classes", "a:1:{i:0;s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("111", "35", "_menu_item_xfn", "");
INSERT INTO `wp_postmeta` VALUES("112", "35", "_menu_item_url", "");
INSERT INTO `wp_postmeta` VALUES("114", "36", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("115", "36", "_wp_trash_meta_time", "1512430251");
INSERT INTO `wp_postmeta` VALUES("116", "37", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("117", "37", "_wp_trash_meta_time", "1512430272");
INSERT INTO `wp_postmeta` VALUES("118", "38", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("119", "38", "_wp_trash_meta_time", "1512430284");
INSERT INTO `wp_postmeta` VALUES("120", "39", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("121", "39", "_wp_trash_meta_time", "1512430296");
INSERT INTO `wp_postmeta` VALUES("122", "40", "wpuf_form_settings", "a:41:{s:11:\"redirect_to\";s:4:\"same\";s:7:\"message\";s:64:\"Thanks for contacting us! We will get in touch with you shortly.\";s:7:\"page_id\";s:0:\"\";s:3:\"url\";s:0:\"\";s:11:\"submit_text\";s:7:\"Submit \";s:13:\"schedule_form\";s:5:\"false\";s:14:\"schedule_start\";s:0:\"\";s:12:\"schedule_end\";s:0:\"\";s:18:\"sc_pending_message\";s:39:\"Form submission hasn\'t been started yet\";s:18:\"sc_expired_message\";s:30:\"Form submission is now closed.\";s:13:\"require_login\";s:5:\"false\";s:17:\"req_login_message\";s:36:\"You need to login to submit a query.\";s:13:\"limit_entries\";s:5:\"false\";s:12:\"limit_number\";s:3:\"100\";s:13:\"limit_message\";s:57:\"Sorry, we have reached the maximum number of submissions.\";s:14:\"label_position\";s:5:\"above\";s:16:\"enable_multistep\";b:0;s:26:\"multistep_progressbar_type\";s:11:\"progressive\";s:21:\"payment_paypal_images\";s:68:\"https://www.paypalobjects.com/webstatic/mktg/logo/AM_mc_vs_dc_ae.jpg\";s:20:\"payment_paypal_label\";s:6:\"PayPal\";s:20:\"payment_stripe_label\";s:11:\"Credit Card\";s:21:\"payment_stripe_images\";a:4:{i:0;s:4:\"visa\";i:1;s:10:\"mastercard\";i:2;s:4:\"amex\";i:3;s:8:\"discover\";}s:25:\"payment_stripe_deactivate\";s:0:\"\";s:11:\"stripe_mode\";s:4:\"live\";s:14:\"stripe_page_id\";s:0:\"\";s:20:\"stripe_override_keys\";s:0:\"\";s:12:\"stripe_email\";s:0:\"\";s:10:\"stripe_key\";s:0:\"\";s:17:\"stripe_secret_key\";s:0:\"\";s:15:\"stripe_key_test\";s:0:\"\";s:22:\"stripe_secret_key_test\";s:0:\"\";s:20:\"stripe_prefill_email\";s:0:\"\";s:23:\"stripe_user_email_field\";s:0:\"\";s:25:\"payment_paypal_deactivate\";s:0:\"\";s:11:\"paypal_mode\";s:4:\"live\";s:11:\"paypal_type\";s:5:\"_cart\";s:15:\"paypal_override\";s:0:\"\";s:12:\"paypal_email\";s:0:\"\";s:14:\"paypal_page_id\";s:0:\"\";s:20:\"paypal_prefill_email\";s:0:\"\";s:23:\"paypal_user_email_field\";s:0:\"\";}");
INSERT INTO `wp_postmeta` VALUES("123", "40", "notifications", "a:1:{i:0;a:14:{s:6:\"active\";s:4:\"true\";s:4:\"type\";s:5:\"email\";s:5:\"smsTo\";s:0:\"\";s:7:\"smsText\";s:45:\"[{form_name}] New Form Submission #{entry_id}\";s:4:\"name\";s:18:\"Admin Notification\";s:7:\"subject\";s:45:\"[{form_name}] New Form Submission #{entry_id}\";s:2:\"to\";s:13:\"{admin_email}\";s:7:\"replyTo\";s:13:\"{field:email}\";s:7:\"message\";s:19:\"<p>{all_fields}</p>\";s:8:\"fromName\";s:11:\"{site_name}\";s:11:\"fromAddress\";s:13:\"{admin_email}\";s:2:\"cc\";s:0:\"\";s:3:\"bcc\";s:0:\"\";s:12:\"weforms_cond\";a:3:{s:16:\"condition_status\";s:2:\"no\";s:10:\"cond_logic\";s:3:\"any\";s:10:\"conditions\";a:1:{i:0;a:3:{s:4:\"name\";s:0:\"\";s:8:\"operator\";s:1:\"=\";s:6:\"option\";s:0:\"\";}}}}}");
INSERT INTO `wp_postmeta` VALUES("124", "40", "integrations", "a:1:{s:5:\"slack\";O:8:\"stdClass\":2:{s:7:\"enabled\";b:0;s:3:\"url\";s:0:\"\";}}");
INSERT INTO `wp_postmeta` VALUES("143", "54", "_um_template", "members");
INSERT INTO `wp_postmeta` VALUES("144", "54", "_um_mode", "directory");
INSERT INTO `wp_postmeta` VALUES("145", "54", "_um_has_profile_photo", "0");
INSERT INTO `wp_postmeta` VALUES("146", "54", "_um_has_cover_photo", "0");
INSERT INTO `wp_postmeta` VALUES("147", "54", "_um_show_social", "0");
INSERT INTO `wp_postmeta` VALUES("148", "54", "_um_show_userinfo", "0");
INSERT INTO `wp_postmeta` VALUES("149", "54", "_um_show_tagline", "0");
INSERT INTO `wp_postmeta` VALUES("150", "54", "_um_search", "0");
INSERT INTO `wp_postmeta` VALUES("151", "54", "_um_userinfo_animate", "1");
INSERT INTO `wp_postmeta` VALUES("152", "54", "_um_sortby", "user_registered_desc");
INSERT INTO `wp_postmeta` VALUES("153", "54", "_um_profile_photo", "1");
INSERT INTO `wp_postmeta` VALUES("154", "54", "_um_cover_photos", "1");
INSERT INTO `wp_postmeta` VALUES("155", "54", "_um_show_name", "1");
INSERT INTO `wp_postmeta` VALUES("156", "54", "_um_directory_header", "{total_users} Members");
INSERT INTO `wp_postmeta` VALUES("157", "54", "_um_directory_header_single", "{total_users} Member");
INSERT INTO `wp_postmeta` VALUES("158", "54", "_um_directory_no_users", "We are sorry. We cannot find any users who match your search criteria.");
INSERT INTO `wp_postmeta` VALUES("159", "54", "_um_profiles_per_page", "12");
INSERT INTO `wp_postmeta` VALUES("160", "54", "_um_profiles_per_page_mobile", "6");
INSERT INTO `wp_postmeta` VALUES("161", "54", "_um_core", "members");
INSERT INTO `wp_postmeta` VALUES("183", "69", "_um_core", "admin");
INSERT INTO `wp_postmeta` VALUES("184", "69", "_um_can_access_wpadmin", "1");
INSERT INTO `wp_postmeta` VALUES("185", "69", "_um_can_not_see_adminbar", "0");
INSERT INTO `wp_postmeta` VALUES("186", "69", "_um_can_edit_everyone", "1");
INSERT INTO `wp_postmeta` VALUES("187", "69", "_um_can_delete_everyone", "1");
INSERT INTO `wp_postmeta` VALUES("188", "69", "_um_can_edit_profile", "1");
INSERT INTO `wp_postmeta` VALUES("189", "69", "_um_can_delete_profile", "1");
INSERT INTO `wp_postmeta` VALUES("190", "69", "_um_can_view_all", "1");
INSERT INTO `wp_postmeta` VALUES("191", "69", "_um_can_make_private_profile", "1");
INSERT INTO `wp_postmeta` VALUES("192", "69", "_um_can_access_private_profile", "1");
INSERT INTO `wp_postmeta` VALUES("193", "69", "_um_default_homepage", "1");
INSERT INTO `wp_postmeta` VALUES("194", "69", "_um_status", "approved");
INSERT INTO `wp_postmeta` VALUES("195", "69", "_um_auto_approve_act", "redirect_profile");
INSERT INTO `wp_postmeta` VALUES("196", "69", "_um_after_login", "redirect_admin");
INSERT INTO `wp_postmeta` VALUES("197", "69", "_um_after_logout", "redirect_home");
INSERT INTO `wp_postmeta` VALUES("198", "70", "_um_core", "member");
INSERT INTO `wp_postmeta` VALUES("199", "70", "_um_can_access_wpadmin", "0");
INSERT INTO `wp_postmeta` VALUES("200", "70", "_um_can_not_see_adminbar", "1");
INSERT INTO `wp_postmeta` VALUES("201", "70", "_um_can_edit_everyone", "0");
INSERT INTO `wp_postmeta` VALUES("202", "70", "_um_can_delete_everyone", "0");
INSERT INTO `wp_postmeta` VALUES("203", "70", "_um_can_edit_profile", "1");
INSERT INTO `wp_postmeta` VALUES("204", "70", "_um_can_delete_profile", "1");
INSERT INTO `wp_postmeta` VALUES("205", "70", "_um_can_view_all", "1");
INSERT INTO `wp_postmeta` VALUES("206", "70", "_um_can_make_private_profile", "0");
INSERT INTO `wp_postmeta` VALUES("207", "70", "_um_can_access_private_profile", "0");
INSERT INTO `wp_postmeta` VALUES("208", "70", "_um_default_homepage", "1");
INSERT INTO `wp_postmeta` VALUES("209", "70", "_um_status", "approved");
INSERT INTO `wp_postmeta` VALUES("210", "70", "_um_auto_approve_act", "redirect_profile");
INSERT INTO `wp_postmeta` VALUES("211", "70", "_um_after_login", "redirect_profile");
INSERT INTO `wp_postmeta` VALUES("212", "70", "_um_after_logout", "redirect_home");
INSERT INTO `wp_postmeta` VALUES("214", "71", "_um_custom_fields", "a:4:{s:10:\"user_login\";a:17:{s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:4:\"type\";s:4:\"text\";s:7:\"metakey\";s:10:\"user_login\";s:8:\"position\";s:1:\"1\";s:5:\"title\";s:8:\"Username\";s:9:\"min_chars\";s:1:\"3\";s:10:\"visibility\";s:3:\"all\";s:5:\"label\";s:8:\"Username\";s:6:\"public\";s:1:\"1\";s:8:\"validate\";s:15:\"unique_username\";s:9:\"max_chars\";s:2:\"24\";s:8:\"required\";s:1:\"1\";s:8:\"editable\";s:1:\"1\";s:17:\"conditional_value\";s:1:\"0\";s:8:\"in_group\";s:0:\"\";}s:10:\"user_email\";a:15:{s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:4:\"type\";s:4:\"text\";s:7:\"metakey\";s:10:\"user_email\";s:8:\"position\";s:1:\"2\";s:5:\"title\";s:14:\"E-mail Address\";s:10:\"visibility\";s:3:\"all\";s:5:\"label\";s:14:\"E-mail Address\";s:6:\"public\";s:1:\"1\";s:8:\"validate\";s:12:\"unique_email\";s:8:\"required\";s:1:\"1\";s:8:\"editable\";s:1:\"1\";s:17:\"conditional_value\";s:1:\"0\";s:8:\"in_group\";s:0:\"\";}s:13:\"user_password\";a:18:{s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:4:\"type\";s:8:\"password\";s:7:\"metakey\";s:13:\"user_password\";s:8:\"position\";s:1:\"3\";s:5:\"title\";s:8:\"Password\";s:9:\"min_chars\";s:1:\"8\";s:9:\"max_chars\";s:2:\"30\";s:10:\"visibility\";s:3:\"all\";s:5:\"label\";s:8:\"Password\";s:6:\"public\";s:1:\"1\";s:15:\"force_good_pass\";s:1:\"1\";s:18:\"force_confirm_pass\";s:1:\"1\";s:8:\"required\";s:1:\"1\";s:8:\"editable\";s:1:\"1\";s:17:\"conditional_value\";s:1:\"0\";s:8:\"in_group\";s:0:\"\";}s:9:\"_um_row_1\";a:5:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";s:6:\"origin\";s:9:\"_um_row_1\";}}");
INSERT INTO `wp_postmeta` VALUES("215", "71", "_edit_lock", "1512487210:1");
INSERT INTO `wp_postmeta` VALUES("216", "71", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("217", "71", "_um_register_use_globals", "1");
INSERT INTO `wp_postmeta` VALUES("218", "71", "_um_register_role", "0");
INSERT INTO `wp_postmeta` VALUES("219", "71", "_um_register_template", "register");
INSERT INTO `wp_postmeta` VALUES("220", "71", "_um_register_max_width", "450px");
INSERT INTO `wp_postmeta` VALUES("221", "71", "_um_register_align", "center");
INSERT INTO `wp_postmeta` VALUES("222", "71", "_um_register_icons", "label");
INSERT INTO `wp_postmeta` VALUES("223", "71", "_um_register_primary_btn_word", "Register");
INSERT INTO `wp_postmeta` VALUES("224", "71", "_um_register_primary_btn_color", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("225", "71", "_um_register_primary_btn_hover", "#44b0ec");
INSERT INTO `wp_postmeta` VALUES("226", "71", "_um_register_primary_btn_text", "#fff");
INSERT INTO `wp_postmeta` VALUES("227", "71", "_um_register_secondary_btn", "1");
INSERT INTO `wp_postmeta` VALUES("228", "71", "_um_register_secondary_btn_word", "Login");
INSERT INTO `wp_postmeta` VALUES("229", "71", "_um_register_secondary_btn_color", "#eee");
INSERT INTO `wp_postmeta` VALUES("230", "71", "_um_register_secondary_btn_hover", "#e5e5e5");
INSERT INTO `wp_postmeta` VALUES("231", "71", "_um_register_secondary_btn_text", "#666");
INSERT INTO `wp_postmeta` VALUES("232", "71", "_um_register_custom_css", "");
INSERT INTO `wp_postmeta` VALUES("233", "71", "_um_profile_use_globals", "1");
INSERT INTO `wp_postmeta` VALUES("234", "71", "_um_profile_role", "0");
INSERT INTO `wp_postmeta` VALUES("235", "71", "_um_profile_template", "profile");
INSERT INTO `wp_postmeta` VALUES("236", "71", "_um_profile_max_width", "1000px");
INSERT INTO `wp_postmeta` VALUES("237", "71", "_um_profile_area_max_width", "600px");
INSERT INTO `wp_postmeta` VALUES("238", "71", "_um_profile_align", "center");
INSERT INTO `wp_postmeta` VALUES("239", "71", "_um_profile_icons", "label");
INSERT INTO `wp_postmeta` VALUES("240", "71", "_um_profile_primary_btn_word", "Update Profile");
INSERT INTO `wp_postmeta` VALUES("241", "71", "_um_profile_primary_btn_color", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("242", "71", "_um_profile_primary_btn_hover", "#44b0ec");
INSERT INTO `wp_postmeta` VALUES("243", "71", "_um_profile_primary_btn_text", "#fff");
INSERT INTO `wp_postmeta` VALUES("244", "71", "_um_profile_secondary_btn", "1");
INSERT INTO `wp_postmeta` VALUES("245", "71", "_um_profile_secondary_btn_word", "Cancel");
INSERT INTO `wp_postmeta` VALUES("246", "71", "_um_profile_secondary_btn_color", "#eee");
INSERT INTO `wp_postmeta` VALUES("247", "71", "_um_profile_secondary_btn_hover", "#e5e5e5");
INSERT INTO `wp_postmeta` VALUES("248", "71", "_um_profile_secondary_btn_text", "#666");
INSERT INTO `wp_postmeta` VALUES("249", "71", "_um_profile_main_bg", "0");
INSERT INTO `wp_postmeta` VALUES("250", "71", "_um_profile_main_text_color", "0");
INSERT INTO `wp_postmeta` VALUES("251", "71", "_um_profile_cover_enabled", "1");
INSERT INTO `wp_postmeta` VALUES("252", "71", "_um_profile_cover_ratio", "2.7:1");
INSERT INTO `wp_postmeta` VALUES("253", "71", "_um_profile_photosize", "190px");
INSERT INTO `wp_postmeta` VALUES("254", "71", "_um_profile_photocorner", "1");
INSERT INTO `wp_postmeta` VALUES("255", "71", "_um_profile_photo_required", "0");
INSERT INTO `wp_postmeta` VALUES("256", "71", "_um_profile_header_bg", "0");
INSERT INTO `wp_postmeta` VALUES("257", "71", "_um_profile_header_text", "#999");
INSERT INTO `wp_postmeta` VALUES("258", "71", "_um_profile_header_link_color", "#555");
INSERT INTO `wp_postmeta` VALUES("259", "71", "_um_profile_header_link_hcolor", "#444");
INSERT INTO `wp_postmeta` VALUES("260", "71", "_um_profile_header_icon_color", "#aaa");
INSERT INTO `wp_postmeta` VALUES("261", "71", "_um_profile_header_icon_hcolor", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("262", "71", "_um_profile_show_name", "1");
INSERT INTO `wp_postmeta` VALUES("263", "71", "_um_profile_show_social_links", "0");
INSERT INTO `wp_postmeta` VALUES("264", "71", "_um_profile_show_bio", "1");
INSERT INTO `wp_postmeta` VALUES("266", "71", "_um_profile_custom_css", "");
INSERT INTO `wp_postmeta` VALUES("267", "71", "_um_login_use_globals", "1");
INSERT INTO `wp_postmeta` VALUES("268", "71", "_um_login_template", "login");
INSERT INTO `wp_postmeta` VALUES("269", "71", "_um_login_max_width", "450px");
INSERT INTO `wp_postmeta` VALUES("270", "71", "_um_login_align", "center");
INSERT INTO `wp_postmeta` VALUES("271", "71", "_um_login_icons", "label");
INSERT INTO `wp_postmeta` VALUES("272", "71", "_um_login_primary_btn_word", "Login");
INSERT INTO `wp_postmeta` VALUES("273", "71", "_um_login_primary_btn_color", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("274", "71", "_um_login_primary_btn_hover", "#44b0ec");
INSERT INTO `wp_postmeta` VALUES("275", "71", "_um_login_primary_btn_text", "#fff");
INSERT INTO `wp_postmeta` VALUES("276", "71", "_um_login_secondary_btn", "1");
INSERT INTO `wp_postmeta` VALUES("277", "71", "_um_login_secondary_btn_word", "Register");
INSERT INTO `wp_postmeta` VALUES("278", "71", "_um_login_secondary_btn_color", "#eee");
INSERT INTO `wp_postmeta` VALUES("279", "71", "_um_login_secondary_btn_hover", "#e5e5e5");
INSERT INTO `wp_postmeta` VALUES("280", "71", "_um_login_secondary_btn_text", "#666");
INSERT INTO `wp_postmeta` VALUES("281", "71", "_um_login_forgot_pass_link", "1");
INSERT INTO `wp_postmeta` VALUES("282", "71", "_um_login_show_rememberme", "1");
INSERT INTO `wp_postmeta` VALUES("283", "71", "_um_login_after_login", "0");
INSERT INTO `wp_postmeta` VALUES("284", "71", "_um_login_redirect_url", "");
INSERT INTO `wp_postmeta` VALUES("285", "71", "_um_login_custom_css", "");
INSERT INTO `wp_postmeta` VALUES("286", "71", "_um_mode", "register");
INSERT INTO `wp_postmeta` VALUES("298", "71", "_wp_old_slug", "registration__trashed");
INSERT INTO `wp_postmeta` VALUES("323", "24", "_um_custom_access_settings", "0");
INSERT INTO `wp_postmeta` VALUES("324", "24", "_um_accessible", "0");
INSERT INTO `wp_postmeta` VALUES("325", "24", "_um_access_redirect2", "");
INSERT INTO `wp_postmeta` VALUES("326", "24", "_um_access_roles", "a:1:{i:0;s:1:\"0\";}");
INSERT INTO `wp_postmeta` VALUES("327", "24", "_um_access_redirect", "");
INSERT INTO `wp_postmeta` VALUES("328", "71", "_um_profile_metafields", "a:1:{i:0;s:1:\"0\";}");
INSERT INTO `wp_postmeta` VALUES("329", "74", "_um_custom_fields", "a:3:{s:10:\"user_login\";a:17:{s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:4:\"type\";s:4:\"text\";s:7:\"metakey\";s:10:\"user_login\";s:8:\"position\";s:1:\"1\";s:5:\"title\";s:8:\"Username\";s:9:\"min_chars\";s:1:\"3\";s:10:\"visibility\";s:3:\"all\";s:5:\"label\";s:8:\"Username\";s:6:\"public\";s:1:\"1\";s:8:\"validate\";s:15:\"unique_username\";s:9:\"max_chars\";s:2:\"24\";s:8:\"required\";s:1:\"1\";s:8:\"editable\";s:1:\"1\";s:17:\"conditional_value\";s:1:\"0\";s:8:\"in_group\";s:0:\"\";}s:13:\"user_password\";a:18:{s:6:\"in_row\";s:9:\"_um_row_1\";s:10:\"in_sub_row\";s:1:\"0\";s:9:\"in_column\";s:1:\"1\";s:4:\"type\";s:8:\"password\";s:7:\"metakey\";s:13:\"user_password\";s:8:\"position\";s:1:\"2\";s:5:\"title\";s:8:\"Password\";s:9:\"min_chars\";s:1:\"8\";s:9:\"max_chars\";s:2:\"30\";s:10:\"visibility\";s:3:\"all\";s:5:\"label\";s:8:\"Password\";s:6:\"public\";s:1:\"1\";s:15:\"force_good_pass\";s:1:\"1\";s:18:\"force_confirm_pass\";s:1:\"1\";s:8:\"required\";s:1:\"1\";s:8:\"editable\";s:1:\"1\";s:17:\"conditional_value\";s:1:\"0\";s:8:\"in_group\";s:0:\"\";}s:9:\"_um_row_1\";a:5:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";s:6:\"origin\";s:9:\"_um_row_1\";}}");
INSERT INTO `wp_postmeta` VALUES("330", "74", "_edit_lock", "1512487393:1");
INSERT INTO `wp_postmeta` VALUES("331", "74", "_edit_last", "1");
INSERT INTO `wp_postmeta` VALUES("332", "74", "_um_register_use_globals", "1");
INSERT INTO `wp_postmeta` VALUES("333", "74", "_um_register_role", "0");
INSERT INTO `wp_postmeta` VALUES("334", "74", "_um_register_template", "register");
INSERT INTO `wp_postmeta` VALUES("335", "74", "_um_register_max_width", "450px");
INSERT INTO `wp_postmeta` VALUES("336", "74", "_um_register_align", "center");
INSERT INTO `wp_postmeta` VALUES("337", "74", "_um_register_icons", "label");
INSERT INTO `wp_postmeta` VALUES("338", "74", "_um_register_primary_btn_word", "Register");
INSERT INTO `wp_postmeta` VALUES("339", "74", "_um_register_primary_btn_color", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("340", "74", "_um_register_primary_btn_hover", "#44b0ec");
INSERT INTO `wp_postmeta` VALUES("341", "74", "_um_register_primary_btn_text", "#ffffff");
INSERT INTO `wp_postmeta` VALUES("342", "74", "_um_register_secondary_btn", "");
INSERT INTO `wp_postmeta` VALUES("343", "74", "_um_register_secondary_btn_word", "Login");
INSERT INTO `wp_postmeta` VALUES("344", "74", "_um_register_secondary_btn_color", "#eeeeee");
INSERT INTO `wp_postmeta` VALUES("345", "74", "_um_register_secondary_btn_hover", "#e5e5e5");
INSERT INTO `wp_postmeta` VALUES("346", "74", "_um_register_secondary_btn_text", "#666666");
INSERT INTO `wp_postmeta` VALUES("347", "74", "_um_register_custom_css", "");
INSERT INTO `wp_postmeta` VALUES("348", "74", "_um_profile_use_globals", "1");
INSERT INTO `wp_postmeta` VALUES("349", "74", "_um_profile_role", "0");
INSERT INTO `wp_postmeta` VALUES("350", "74", "_um_profile_template", "profile");
INSERT INTO `wp_postmeta` VALUES("351", "74", "_um_profile_max_width", "1000px");
INSERT INTO `wp_postmeta` VALUES("352", "74", "_um_profile_area_max_width", "600px");
INSERT INTO `wp_postmeta` VALUES("353", "74", "_um_profile_align", "center");
INSERT INTO `wp_postmeta` VALUES("354", "74", "_um_profile_icons", "label");
INSERT INTO `wp_postmeta` VALUES("355", "74", "_um_profile_primary_btn_word", "Update Profile");
INSERT INTO `wp_postmeta` VALUES("356", "74", "_um_profile_primary_btn_color", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("357", "74", "_um_profile_primary_btn_hover", "#44b0ec");
INSERT INTO `wp_postmeta` VALUES("358", "74", "_um_profile_primary_btn_text", "#ffffff");
INSERT INTO `wp_postmeta` VALUES("359", "74", "_um_profile_secondary_btn", "1");
INSERT INTO `wp_postmeta` VALUES("360", "74", "_um_profile_secondary_btn_word", "Cancel");
INSERT INTO `wp_postmeta` VALUES("361", "74", "_um_profile_secondary_btn_color", "#eeeeee");
INSERT INTO `wp_postmeta` VALUES("362", "74", "_um_profile_secondary_btn_hover", "#e5e5e5");
INSERT INTO `wp_postmeta` VALUES("363", "74", "_um_profile_secondary_btn_text", "#666666");
INSERT INTO `wp_postmeta` VALUES("364", "74", "_um_profile_main_bg", "0");
INSERT INTO `wp_postmeta` VALUES("365", "74", "_um_profile_main_text_color", "0");
INSERT INTO `wp_postmeta` VALUES("366", "74", "_um_profile_cover_enabled", "1");
INSERT INTO `wp_postmeta` VALUES("367", "74", "_um_profile_cover_ratio", "2.7:1");
INSERT INTO `wp_postmeta` VALUES("368", "74", "_um_profile_photosize", "190px");
INSERT INTO `wp_postmeta` VALUES("369", "74", "_um_profile_photocorner", "1");
INSERT INTO `wp_postmeta` VALUES("370", "74", "_um_profile_photo_required", "0");
INSERT INTO `wp_postmeta` VALUES("371", "74", "_um_profile_header_bg", "0");
INSERT INTO `wp_postmeta` VALUES("372", "74", "_um_profile_header_text", "#999999");
INSERT INTO `wp_postmeta` VALUES("373", "74", "_um_profile_header_link_color", "#555555");
INSERT INTO `wp_postmeta` VALUES("374", "74", "_um_profile_header_link_hcolor", "#444444");
INSERT INTO `wp_postmeta` VALUES("375", "74", "_um_profile_header_icon_color", "#aaaaaa");
INSERT INTO `wp_postmeta` VALUES("376", "74", "_um_profile_header_icon_hcolor", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("377", "74", "_um_profile_show_name", "1");
INSERT INTO `wp_postmeta` VALUES("378", "74", "_um_profile_show_social_links", "0");
INSERT INTO `wp_postmeta` VALUES("379", "74", "_um_profile_show_bio", "1");
INSERT INTO `wp_postmeta` VALUES("381", "74", "_um_profile_custom_css", "");
INSERT INTO `wp_postmeta` VALUES("382", "74", "_um_login_use_globals", "1");
INSERT INTO `wp_postmeta` VALUES("383", "74", "_um_login_template", "login");
INSERT INTO `wp_postmeta` VALUES("384", "74", "_um_login_max_width", "450px");
INSERT INTO `wp_postmeta` VALUES("385", "74", "_um_login_align", "center");
INSERT INTO `wp_postmeta` VALUES("386", "74", "_um_login_icons", "label");
INSERT INTO `wp_postmeta` VALUES("387", "74", "_um_login_primary_btn_word", "Login");
INSERT INTO `wp_postmeta` VALUES("388", "74", "_um_login_primary_btn_color", "#3ba1da");
INSERT INTO `wp_postmeta` VALUES("389", "74", "_um_login_primary_btn_hover", "#44b0ec");
INSERT INTO `wp_postmeta` VALUES("390", "74", "_um_login_primary_btn_text", "#ffffff");
INSERT INTO `wp_postmeta` VALUES("391", "74", "_um_login_secondary_btn", "1");
INSERT INTO `wp_postmeta` VALUES("392", "74", "_um_login_secondary_btn_word", "Register");
INSERT INTO `wp_postmeta` VALUES("393", "74", "_um_login_secondary_btn_color", "#eeeeee");
INSERT INTO `wp_postmeta` VALUES("394", "74", "_um_login_secondary_btn_hover", "#e5e5e5");
INSERT INTO `wp_postmeta` VALUES("395", "74", "_um_login_secondary_btn_text", "#666666");
INSERT INTO `wp_postmeta` VALUES("396", "74", "_um_login_forgot_pass_link", "1");
INSERT INTO `wp_postmeta` VALUES("397", "74", "_um_login_show_rememberme", "1");
INSERT INTO `wp_postmeta` VALUES("398", "74", "_um_login_after_login", "redirect_url");
INSERT INTO `wp_postmeta` VALUES("399", "74", "_um_login_redirect_url", "http://localhost:8000/");
INSERT INTO `wp_postmeta` VALUES("400", "74", "_um_login_custom_css", "");
INSERT INTO `wp_postmeta` VALUES("401", "74", "_um_mode", "login");
INSERT INTO `wp_postmeta` VALUES("402", "26", "_um_custom_access_settings", "0");
INSERT INTO `wp_postmeta` VALUES("403", "26", "_um_accessible", "0");
INSERT INTO `wp_postmeta` VALUES("404", "26", "_um_access_redirect2", "");
INSERT INTO `wp_postmeta` VALUES("405", "26", "_um_access_roles", "a:1:{i:0;s:1:\"0\";}");
INSERT INTO `wp_postmeta` VALUES("406", "26", "_um_access_redirect", "");
INSERT INTO `wp_postmeta` VALUES("407", "54", "_edit_lock", "1512486609:1");
INSERT INTO `wp_postmeta` VALUES("411", "70", "_edit_lock", "1512486658:1");
INSERT INTO `wp_postmeta` VALUES("412", "54", "_wp_old_slug", "members__trashed");
INSERT INTO `wp_postmeta` VALUES("413", "54", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("414", "54", "_wp_trash_meta_time", "1512486828");
INSERT INTO `wp_postmeta` VALUES("415", "54", "_wp_desired_post_slug", "members");
INSERT INTO `wp_postmeta` VALUES("416", "74", "_um_profile_metafields", "a:1:{i:0;s:1:\"0\";}");
INSERT INTO `wp_postmeta` VALUES("421", "92", "_wp_attached_file", "2017/12/header2.jpg");
INSERT INTO `wp_postmeta` VALUES("422", "92", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:1350;s:6:\"height\";i:500;s:4:\"file\";s:19:\"2017/12/header2.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("423", "93", "_wp_attached_file", "2017/12/icon.png");
INSERT INTO `wp_postmeta` VALUES("424", "93", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:100;s:6:\"height\";i:100;s:4:\"file\";s:16:\"2017/12/icon.png\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("425", "94", "_wp_attached_file", "2017/12/list-of-different-types-of-coffee_23-2147573277.jpg");
INSERT INTO `wp_postmeta` VALUES("426", "94", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:626;s:6:\"height\";i:626;s:4:\"file\";s:59:\"2017/12/list-of-different-types-of-coffee_23-2147573277.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("427", "95", "_wp_attached_file", "2017/12/palkortum01.jpg");
INSERT INTO `wp_postmeta` VALUES("428", "95", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:224;s:6:\"height\";i:365;s:4:\"file\";s:23:\"2017/12/palkortum01.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("429", "96", "_wp_attached_file", "2017/12/palkortum20.jpg");
INSERT INTO `wp_postmeta` VALUES("430", "96", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:340;s:6:\"height\";i:331;s:4:\"file\";s:23:\"2017/12/palkortum20.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("431", "92", "_wp_attachment_custom_header_last_used_masonic_child", "1513627864");
INSERT INTO `wp_postmeta` VALUES("432", "92", "_wp_attachment_is_custom_header", "masonic_child");
INSERT INTO `wp_postmeta` VALUES("433", "97", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("434", "97", "_wp_trash_meta_time", "1513627864");
INSERT INTO `wp_postmeta` VALUES("435", "98", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("436", "98", "_wp_trash_meta_time", "1513627886");
INSERT INTO `wp_postmeta` VALUES("437", "99", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("438", "99", "_wp_trash_meta_time", "1513627901");
INSERT INTO `wp_postmeta` VALUES("439", "100", "_edit_lock", "1513628065:4");
INSERT INTO `wp_postmeta` VALUES("440", "100", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("441", "100", "_wp_trash_meta_time", "1513628065");
INSERT INTO `wp_postmeta` VALUES("442", "103", "_wp_attached_file", "2017/12/800px-John_Frederick_Lewis_004.jpg");
INSERT INTO `wp_postmeta` VALUES("443", "103", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:800;s:6:\"height\";i:1278;s:4:\"file\";s:42:\"2017/12/800px-John_Frederick_Lewis_004.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("444", "103", "_wp_attachment_image_alt", "Coffee");
INSERT INTO `wp_postmeta` VALUES("445", "96", "_wp_attachment_is_custom_background", "masonic_child");
INSERT INTO `wp_postmeta` VALUES("446", "109", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("447", "109", "_wp_trash_meta_time", "1513644436");
INSERT INTO `wp_postmeta` VALUES("448", "126", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("449", "126", "_wp_trash_meta_time", "1513646618");
INSERT INTO `wp_postmeta` VALUES("450", "132", "_wp_attached_file", "2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg");
INSERT INTO `wp_postmeta` VALUES("451", "132", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:800;s:6:\"height\";i:400;s:4:\"file\";s:81:\"2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385990792F1020846340632F12Foriginal.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("454", "17", "video_url", "");
INSERT INTO `wp_postmeta` VALUES("459", "136", "_edit_lock", "1513649003:4");
INSERT INTO `wp_postmeta` VALUES("460", "136", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("461", "137", "_wp_attached_file", "2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg");
INSERT INTO `wp_postmeta` VALUES("462", "137", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:800;s:6:\"height\";i:400;s:4:\"file\";s:81:\"2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385991882F1020846340632F12Foriginal.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("465", "136", "video_url", "");
INSERT INTO `wp_postmeta` VALUES("466", "140", "_edit_lock", "1513648978:4");
INSERT INTO `wp_postmeta` VALUES("467", "140", "_edit_last", "4");
INSERT INTO `wp_postmeta` VALUES("468", "141", "_wp_attached_file", "2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg");
INSERT INTO `wp_postmeta` VALUES("469", "141", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:800;s:6:\"height\";i:400;s:4:\"file\";s:81:\"2017/12/https_2F2Fcdn.evbuc_.com2Fimages2F385989662F1020846340632F12Foriginal.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("472", "140", "video_url", "");
INSERT INTO `wp_postmeta` VALUES("475", "144", "_edit_lock", "1513648703:4");
INSERT INTO `wp_postmeta` VALUES("476", "144", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("477", "144", "_wp_trash_meta_time", "1513648704");
INSERT INTO `wp_postmeta` VALUES("478", "146", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("479", "146", "_wp_trash_meta_time", "1513648756");
INSERT INTO `wp_postmeta` VALUES("480", "148", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("481", "148", "_wp_trash_meta_time", "1513648771");
INSERT INTO `wp_postmeta` VALUES("488", "156", "_wp_attached_file", "2017/12/535620b33317274.jpg");
INSERT INTO `wp_postmeta` VALUES("489", "156", "_wp_attachment_metadata", "a:4:{s:5:\"width\";i:617;s:6:\"height\";i:260;s:4:\"file\";s:27:\"2017/12/535620b33317274.jpg\";s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("490", "164", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("491", "164", "_wp_trash_meta_time", "1513650567");
INSERT INTO `wp_postmeta` VALUES("492", "167", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("493", "167", "_wp_trash_meta_time", "1513650759");
INSERT INTO `wp_postmeta` VALUES("494", "170", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("495", "170", "_wp_trash_meta_time", "1513650808");
INSERT INTO `wp_postmeta` VALUES("496", "172", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("497", "172", "_wp_trash_meta_time", "1513650849");
INSERT INTO `wp_postmeta` VALUES("498", "174", "_edit_lock", "1513650917:4");
INSERT INTO `wp_postmeta` VALUES("499", "174", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("500", "174", "_wp_trash_meta_time", "1513650918");
INSERT INTO `wp_postmeta` VALUES("501", "177", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("502", "177", "_wp_trash_meta_time", "1513650994");
INSERT INTO `wp_postmeta` VALUES("503", "186", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("504", "186", "_wp_trash_meta_time", "1513653766");
INSERT INTO `wp_postmeta` VALUES("505", "40", "_weforms_view_count", "5");
INSERT INTO `wp_postmeta` VALUES("506", "200", "_wp_trash_meta_status", "publish");
INSERT INTO `wp_postmeta` VALUES("507", "200", "_wp_trash_meta_time", "1513878485");

/* INSERT TABLE DATA: wp_options */
INSERT INTO `wp_options` VALUES("1", "siteurl", "http://localhost:8000", "yes");
INSERT INTO `wp_options` VALUES("2", "home", "http://localhost:8000", "yes");
INSERT INTO `wp_options` VALUES("3", "blogname", "Coffee Hall", "yes");
INSERT INTO `wp_options` VALUES("4", "blogdescription", "Find unique coffee!", "yes");
INSERT INTO `wp_options` VALUES("5", "users_can_register", "1", "yes");
INSERT INTO `wp_options` VALUES("6", "admin_email", "ebarber5969@conestogac.on.ca", "yes");
INSERT INTO `wp_options` VALUES("7", "start_of_week", "1", "yes");
INSERT INTO `wp_options` VALUES("8", "use_balanceTags", "0", "yes");
INSERT INTO `wp_options` VALUES("9", "use_smilies", "1", "yes");
INSERT INTO `wp_options` VALUES("10", "require_name_email", "1", "yes");
INSERT INTO `wp_options` VALUES("11", "comments_notify", "1", "yes");
INSERT INTO `wp_options` VALUES("12", "posts_per_rss", "10", "yes");
INSERT INTO `wp_options` VALUES("13", "rss_use_excerpt", "0", "yes");
INSERT INTO `wp_options` VALUES("14", "mailserver_url", "mail.example.com", "yes");
INSERT INTO `wp_options` VALUES("15", "mailserver_login", "login@example.com", "yes");
INSERT INTO `wp_options` VALUES("16", "mailserver_pass", "password", "yes");
INSERT INTO `wp_options` VALUES("17", "mailserver_port", "110", "yes");
INSERT INTO `wp_options` VALUES("18", "default_category", "1", "yes");
INSERT INTO `wp_options` VALUES("19", "default_comment_status", "open", "yes");
INSERT INTO `wp_options` VALUES("20", "default_ping_status", "open", "yes");
INSERT INTO `wp_options` VALUES("21", "default_pingback_flag", "1", "yes");
INSERT INTO `wp_options` VALUES("22", "posts_per_page", "10", "yes");
INSERT INTO `wp_options` VALUES("23", "date_format", "F j, Y", "yes");
INSERT INTO `wp_options` VALUES("24", "time_format", "g:i a", "yes");
INSERT INTO `wp_options` VALUES("25", "links_updated_date_format", "F j, Y g:i a", "yes");
INSERT INTO `wp_options` VALUES("26", "comment_moderation", "0", "yes");
INSERT INTO `wp_options` VALUES("27", "moderation_notify", "1", "yes");
INSERT INTO `wp_options` VALUES("28", "permalink_structure", "", "yes");
INSERT INTO `wp_options` VALUES("29", "rewrite_rules", "", "yes");
INSERT INTO `wp_options` VALUES("30", "hack_file", "0", "yes");
INSERT INTO `wp_options` VALUES("31", "blog_charset", "UTF-8", "yes");
INSERT INTO `wp_options` VALUES("32", "moderation_keys", "", "no");
INSERT INTO `wp_options` VALUES("33", "active_plugins", "a:5:{i:0;s:23:\"CoffeeOrderer/index.php\";i:1;s:25:\"duplicator/duplicator.php\";i:2;s:47:\"one-click-child-theme/one-click-child-theme.php\";i:3;s:25:\"profile-builder/index.php\";i:4;s:19:\"weforms/weforms.php\";}", "yes");
INSERT INTO `wp_options` VALUES("34", "category_base", "", "yes");
INSERT INTO `wp_options` VALUES("35", "ping_sites", "http://rpc.pingomatic.com/", "yes");
INSERT INTO `wp_options` VALUES("36", "comment_max_links", "2", "yes");
INSERT INTO `wp_options` VALUES("37", "gmt_offset", "", "yes");
INSERT INTO `wp_options` VALUES("38", "default_email_category", "1", "yes");
INSERT INTO `wp_options` VALUES("39", "recently_edited", "", "no");
INSERT INTO `wp_options` VALUES("40", "template", "masonic", "yes");
INSERT INTO `wp_options` VALUES("41", "stylesheet", "masonic_child", "yes");
INSERT INTO `wp_options` VALUES("42", "comment_whitelist", "1", "yes");
INSERT INTO `wp_options` VALUES("43", "blacklist_keys", "", "no");
INSERT INTO `wp_options` VALUES("44", "comment_registration", "0", "yes");
INSERT INTO `wp_options` VALUES("45", "html_type", "text/html", "yes");
INSERT INTO `wp_options` VALUES("46", "use_trackback", "0", "yes");
INSERT INTO `wp_options` VALUES("47", "default_role", "subscriber", "yes");
INSERT INTO `wp_options` VALUES("48", "db_version", "38590", "yes");
INSERT INTO `wp_options` VALUES("49", "uploads_use_yearmonth_folders", "1", "yes");
INSERT INTO `wp_options` VALUES("50", "upload_path", "", "yes");
INSERT INTO `wp_options` VALUES("51", "blog_public", "1", "yes");
INSERT INTO `wp_options` VALUES("52", "default_link_category", "2", "yes");
INSERT INTO `wp_options` VALUES("53", "show_on_front", "page", "yes");
INSERT INTO `wp_options` VALUES("54", "tag_base", "", "yes");
INSERT INTO `wp_options` VALUES("55", "show_avatars", "1", "yes");
INSERT INTO `wp_options` VALUES("56", "avatar_rating", "G", "yes");
INSERT INTO `wp_options` VALUES("57", "upload_url_path", "", "yes");
INSERT INTO `wp_options` VALUES("58", "thumbnail_size_w", "150", "yes");
INSERT INTO `wp_options` VALUES("59", "thumbnail_size_h", "150", "yes");
INSERT INTO `wp_options` VALUES("60", "thumbnail_crop", "1", "yes");
INSERT INTO `wp_options` VALUES("61", "medium_size_w", "300", "yes");
INSERT INTO `wp_options` VALUES("62", "medium_size_h", "300", "yes");
INSERT INTO `wp_options` VALUES("63", "avatar_default", "mystery", "yes");
INSERT INTO `wp_options` VALUES("64", "large_size_w", "1024", "yes");
INSERT INTO `wp_options` VALUES("65", "large_size_h", "1024", "yes");
INSERT INTO `wp_options` VALUES("66", "image_default_link_type", "none", "yes");
INSERT INTO `wp_options` VALUES("67", "image_default_size", "", "yes");
INSERT INTO `wp_options` VALUES("68", "image_default_align", "", "yes");
INSERT INTO `wp_options` VALUES("69", "close_comments_for_old_posts", "0", "yes");
INSERT INTO `wp_options` VALUES("70", "close_comments_days_old", "14", "yes");
INSERT INTO `wp_options` VALUES("71", "thread_comments", "1", "yes");
INSERT INTO `wp_options` VALUES("72", "thread_comments_depth", "5", "yes");
INSERT INTO `wp_options` VALUES("73", "page_comments", "0", "yes");
INSERT INTO `wp_options` VALUES("74", "comments_per_page", "50", "yes");
INSERT INTO `wp_options` VALUES("75", "default_comments_page", "newest", "yes");
INSERT INTO `wp_options` VALUES("76", "comment_order", "asc", "yes");
INSERT INTO `wp_options` VALUES("77", "sticky_posts", "a:0:{}", "yes");
INSERT INTO `wp_options` VALUES("78", "widget_categories", "a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("79", "widget_text", "a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("80", "widget_rss", "a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("81", "uninstall_plugins", "a:0:{}", "no");
INSERT INTO `wp_options` VALUES("82", "timezone_string", "America/Toronto", "yes");
INSERT INTO `wp_options` VALUES("83", "page_for_posts", "13", "yes");
INSERT INTO `wp_options` VALUES("84", "page_on_front", "6", "yes");
INSERT INTO `wp_options` VALUES("85", "default_post_format", "0", "yes");
INSERT INTO `wp_options` VALUES("86", "link_manager_enabled", "0", "yes");
INSERT INTO `wp_options` VALUES("87", "finished_splitting_shared_terms", "1", "yes");
INSERT INTO `wp_options` VALUES("88", "site_icon", "93", "yes");
INSERT INTO `wp_options` VALUES("89", "medium_large_size_w", "768", "yes");
INSERT INTO `wp_options` VALUES("90", "medium_large_size_h", "0", "yes");
INSERT INTO `wp_options` VALUES("91", "initial_db_version", "38590", "yes");
INSERT INTO `wp_options` VALUES("92", "wp_user_roles", "a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}", "yes");
INSERT INTO `wp_options` VALUES("93", "widget_search", "a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("94", "widget_recent-posts", "a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("95", "widget_recent-comments", "a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("96", "widget_archives", "a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("97", "widget_meta", "a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("98", "sidebars_widgets", "a:6:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:12:\"categories-2\";i:3;s:14:\"recent-posts-2\";i:4;s:17:\"recent-comments-2\";}s:13:\"right-sidebar\";a:1:{i:0;s:8:\"search-2\";}s:18:\"footer-sidebar-one\";a:0:{}s:18:\"footer-sidebar-two\";a:0:{}s:20:\"footer-sidebar-three\";a:0:{}s:13:\"array_version\";i:3;}", "yes");
INSERT INTO `wp_options` VALUES("99", "logged_in_key", ")?;?`p+{87_4ALa[**5Ff=wpxZxWCFesN.8Ny:e[`du `6i/bPK-j/kqZ:k=jVIf", "no");
INSERT INTO `wp_options` VALUES("100", "logged_in_salt", "^:h>V[^x@8HABhmkE`d<-5HH.7&I@ppy*KNaBjGu5vsu{qQf]$_6F0t4P^,wd_=$", "no");
INSERT INTO `wp_options` VALUES("101", "widget_pages", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("102", "widget_calendar", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("103", "widget_media_audio", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("104", "widget_media_image", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("105", "widget_media_gallery", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("106", "widget_media_video", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("107", "nonce_key", ";GN91Eu:6$drMiled~^GX~K8K$ek~c@kcu?HZR^`_?OFx1)mC4_t>6;-OO/2~RBR", "no");
INSERT INTO `wp_options` VALUES("108", "nonce_salt", "Ba);QlZfej h(d_pROxzUTwFwY~hu<<7F{d;s$T_a@Pa!ALoz:=&WCXmglmbu]^I", "no");
INSERT INTO `wp_options` VALUES("109", "widget_tag_cloud", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("110", "widget_nav_menu", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("111", "widget_custom_html", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("112", "cron", "a:8:{i:1514572437;a:1:{s:26:\"um_hourly_scheduled_events\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1514583237;a:1:{s:30:\"um_twicedaily_scheduled_events\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1514588804;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1514588821;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1514589354;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1514626437;a:1:{s:25:\"um_daily_scheduled_events\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1514885637;a:1:{s:26:\"um_weekly_scheduled_events\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}", "yes");
INSERT INTO `wp_options` VALUES("114", "auth_key", "=7>,a;`GM.*>{<%G9Rk;.R:(`5Z:Z2@0vvO+n1fL}]mr]%hH`e/_S/1@dQM]}*@-", "no");
INSERT INTO `wp_options` VALUES("115", "auth_salt", "8K:8;ynZn]R>Jkx$*>Cau$w1xBD|~}?##.-8z~&!6D{2:=XM%j&hvka4SG1xHrwn", "no");
INSERT INTO `wp_options` VALUES("122", "_site_transient_timeout_browser_cb0f25941c7ee58acd15fece4d84c18b", "1513033622", "no");
INSERT INTO `wp_options` VALUES("123", "_site_transient_browser_cb0f25941c7ee58acd15fece4d84c18b", "a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"62.0.3202.94\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}", "no");
INSERT INTO `wp_options` VALUES("137", "can_compress_scripts", "1", "no");
INSERT INTO `wp_options` VALUES("138", "fresh_site", "0", "yes");
INSERT INTO `wp_options` VALUES("139", "theme_mods_twentyfifteen", "a:3:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512670405;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:1:{i:0;s:8:\"search-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}", "yes");
INSERT INTO `wp_options` VALUES("149", "nav_menu_options", "a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}", "yes");
INSERT INTO `wp_options` VALUES("170", "_transient_timeout_plugin_slugs", "1514657687", "no");
INSERT INTO `wp_options` VALUES("171", "_transient_plugin_slugs", "a:16:{i:0;s:19:\"akismet/akismet.php\";i:1;s:33:\"BootstrapMenus/BootStrapMenus.php\";i:2;s:76:\"cloudinary-image-management-and-manipulation-in-the-cloud-cdn/cloudinary.php\";i:3;s:23:\"CoffeeOrderer/index.php\";i:4;s:25:\"duplicator/duplicator.php\";i:5;s:41:\"GitWordPressLayout/GitWordPressLayout.php\";i:6;s:9:\"hello.php\";i:7;s:19:\"jetpack/jetpack.php\";i:8;s:29:\"MigratePages/MigratePages.php\";i:9;s:47:\"one-click-child-theme/one-click-child-theme.php\";i:10;s:25:\"profile-builder/index.php\";i:11;s:41:\"sqlite-integration/sqlite-integration.php\";i:12;s:25:\"testplugin/TestPlugin.php\";i:13;s:33:\"unplug-jetpack/unplug-jetpack.php\";i:14;s:19:\"weforms/weforms.php\";i:15;s:27:\"woocommerce/woocommerce.php\";}", "no");
INSERT INTO `wp_options` VALUES("172", "recently_activated", "a:0:{}", "yes");
INSERT INTO `wp_options` VALUES("175", "weforms_settings", "a:3:{s:13:\"email_gateway\";s:9:\"wordpress\";s:6:\"credit\";b:0;s:9:\"recaptcha\";a:2:{s:3:\"key\";s:0:\"\";s:6:\"secret\";s:0:\"\";}}", "yes");
INSERT INTO `wp_options` VALUES("176", "weforms_installed", "1512482830", "yes");
INSERT INTO `wp_options` VALUES("177", "_transient_timeout_weforms_activation_redirect", "1512482861", "no");
INSERT INTO `wp_options` VALUES("178", "_transient_weforms_activation_redirect", "1", "no");
INSERT INTO `wp_options` VALUES("181", "weforms_version", "1.2.4", "yes");
INSERT INTO `wp_options` VALUES("186", "wpuf_installed", "1512483938", "yes");
INSERT INTO `wp_options` VALUES("189", "wpuf_version", "2.6.1", "yes");
INSERT INTO `wp_options` VALUES("191", "wpuf_general", "", "yes");
INSERT INTO `wp_options` VALUES("192", "wpuf_dashboard", "", "yes");
INSERT INTO `wp_options` VALUES("193", "wpuf_profile", "", "yes");
INSERT INTO `wp_options` VALUES("194", "wpuf_payment", "", "yes");
INSERT INTO `wp_options` VALUES("195", "wpuf_guest_mails", "", "yes");
INSERT INTO `wp_options` VALUES("196", "wpuf_expiry_posts_last_cleaned", "December 5, 2017 2:25 pm", "yes");
INSERT INTO `wp_options` VALUES("197", "_wpuf_page_created", "1", "yes");
INSERT INTO `wp_options` VALUES("200", "redux-framework-tracking", "a:3:{s:8:\"dev_mode\";b:0;s:4:\"hash\";s:32:\"e9bf6e362e05258449867104f0fdafbb\";s:14:\"allow_tracking\";s:2:\"no\";}", "yes");
INSERT INTO `wp_options` VALUES("201", "um_version", "1.3.88", "yes");
INSERT INTO `wp_options` VALUES("202", "um_cache_fonticons", "a:1218:{i:0;s:13:\"um-icon-alert\";i:1;s:21:\"um-icon-alert-circled\";i:2;s:19:\"um-icon-android-add\";i:3;s:26:\"um-icon-android-add-circle\";i:4;s:27:\"um-icon-android-alarm-clock\";i:5;s:21:\"um-icon-android-alert\";i:6;s:20:\"um-icon-android-apps\";i:7;s:23:\"um-icon-android-archive\";i:8;s:26:\"um-icon-android-arrow-back\";i:9;s:26:\"um-icon-android-arrow-down\";i:10;s:30:\"um-icon-android-arrow-dropdown\";i:11;s:37:\"um-icon-android-arrow-dropdown-circle\";i:12;s:30:\"um-icon-android-arrow-dropleft\";i:13;s:37:\"um-icon-android-arrow-dropleft-circle\";i:14;s:31:\"um-icon-android-arrow-dropright\";i:15;s:38:\"um-icon-android-arrow-dropright-circle\";i:16;s:28:\"um-icon-android-arrow-dropup\";i:17;s:35:\"um-icon-android-arrow-dropup-circle\";i:18;s:29:\"um-icon-android-arrow-forward\";i:19;s:24:\"um-icon-android-arrow-up\";i:20;s:22:\"um-icon-android-attach\";i:21;s:19:\"um-icon-android-bar\";i:22;s:23:\"um-icon-android-bicycle\";i:23;s:20:\"um-icon-android-boat\";i:24;s:24:\"um-icon-android-bookmark\";i:25;s:20:\"um-icon-android-bulb\";i:26;s:19:\"um-icon-android-bus\";i:27;s:24:\"um-icon-android-calendar\";i:28;s:20:\"um-icon-android-call\";i:29;s:22:\"um-icon-android-camera\";i:30;s:22:\"um-icon-android-cancel\";i:31;s:19:\"um-icon-android-car\";i:32;s:20:\"um-icon-android-cart\";i:33;s:20:\"um-icon-android-chat\";i:34;s:24:\"um-icon-android-checkbox\";i:35;s:30:\"um-icon-android-checkbox-blank\";i:36;s:32:\"um-icon-android-checkbox-outline\";i:37;s:38:\"um-icon-android-checkbox-outline-blank\";i:38;s:32:\"um-icon-android-checkmark-circle\";i:39;s:25:\"um-icon-android-clipboard\";i:40;s:21:\"um-icon-android-close\";i:41;s:21:\"um-icon-android-cloud\";i:42;s:28:\"um-icon-android-cloud-circle\";i:43;s:26:\"um-icon-android-cloud-done\";i:44;s:29:\"um-icon-android-cloud-outline\";i:45;s:29:\"um-icon-android-color-palette\";i:46;s:23:\"um-icon-android-compass\";i:47;s:23:\"um-icon-android-contact\";i:48;s:24:\"um-icon-android-contacts\";i:49;s:24:\"um-icon-android-contract\";i:50;s:22:\"um-icon-android-create\";i:51;s:22:\"um-icon-android-delete\";i:52;s:23:\"um-icon-android-desktop\";i:53;s:24:\"um-icon-android-document\";i:54;s:20:\"um-icon-android-done\";i:55;s:24:\"um-icon-android-done-all\";i:56;s:24:\"um-icon-android-download\";i:57;s:22:\"um-icon-android-drafts\";i:58;s:20:\"um-icon-android-exit\";i:59;s:22:\"um-icon-android-expand\";i:60;s:24:\"um-icon-android-favorite\";i:61;s:32:\"um-icon-android-favorite-outline\";i:62;s:20:\"um-icon-android-film\";i:63;s:22:\"um-icon-android-folder\";i:64;s:27:\"um-icon-android-folder-open\";i:65;s:22:\"um-icon-android-funnel\";i:66;s:21:\"um-icon-android-globe\";i:67;s:20:\"um-icon-android-hand\";i:68;s:23:\"um-icon-android-hangout\";i:69;s:21:\"um-icon-android-happy\";i:70;s:20:\"um-icon-android-home\";i:71;s:21:\"um-icon-android-image\";i:72;s:22:\"um-icon-android-laptop\";i:73;s:20:\"um-icon-android-list\";i:74;s:22:\"um-icon-android-locate\";i:75;s:20:\"um-icon-android-lock\";i:76;s:20:\"um-icon-android-mail\";i:77;s:19:\"um-icon-android-map\";i:78;s:20:\"um-icon-android-menu\";i:79;s:26:\"um-icon-android-microphone\";i:80;s:30:\"um-icon-android-microphone-off\";i:81;s:31:\"um-icon-android-more-horizontal\";i:82;s:29:\"um-icon-android-more-vertical\";i:83;s:24:\"um-icon-android-navigate\";i:84;s:29:\"um-icon-android-notifications\";i:85;s:34:\"um-icon-android-notifications-none\";i:86;s:33:\"um-icon-android-notifications-off\";i:87;s:20:\"um-icon-android-open\";i:88;s:23:\"um-icon-android-options\";i:89;s:22:\"um-icon-android-people\";i:90;s:22:\"um-icon-android-person\";i:91;s:26:\"um-icon-android-person-add\";i:92;s:31:\"um-icon-android-phone-landscape\";i:93;s:30:\"um-icon-android-phone-portrait\";i:94;s:19:\"um-icon-android-pin\";i:95;s:21:\"um-icon-android-plane\";i:96;s:25:\"um-icon-android-playstore\";i:97;s:21:\"um-icon-android-print\";i:98;s:32:\"um-icon-android-radio-button-off\";i:99;s:31:\"um-icon-android-radio-button-on\";i:100;s:23:\"um-icon-android-refresh\";i:101;s:22:\"um-icon-android-remove\";i:102;s:29:\"um-icon-android-remove-circle\";i:103;s:26:\"um-icon-android-restaurant\";i:104;s:19:\"um-icon-android-sad\";i:105;s:22:\"um-icon-android-search\";i:106;s:20:\"um-icon-android-send\";i:107;s:24:\"um-icon-android-settings\";i:108;s:21:\"um-icon-android-share\";i:109;s:25:\"um-icon-android-share-alt\";i:110;s:20:\"um-icon-android-star\";i:111;s:25:\"um-icon-android-star-half\";i:112;s:28:\"um-icon-android-star-outline\";i:113;s:25:\"um-icon-android-stopwatch\";i:114;s:22:\"um-icon-android-subway\";i:115;s:21:\"um-icon-android-sunny\";i:116;s:20:\"um-icon-android-sync\";i:117;s:23:\"um-icon-android-textsms\";i:118;s:20:\"um-icon-android-time\";i:119;s:21:\"um-icon-android-train\";i:120;s:22:\"um-icon-android-unlock\";i:121;s:22:\"um-icon-android-upload\";i:122;s:27:\"um-icon-android-volume-down\";i:123;s:27:\"um-icon-android-volume-mute\";i:124;s:26:\"um-icon-android-volume-off\";i:125;s:25:\"um-icon-android-volume-up\";i:126;s:20:\"um-icon-android-walk\";i:127;s:23:\"um-icon-android-warning\";i:128;s:21:\"um-icon-android-watch\";i:129;s:20:\"um-icon-android-wifi\";i:130;s:16:\"um-icon-aperture\";i:131;s:15:\"um-icon-archive\";i:132;s:20:\"um-icon-arrow-down-a\";i:133;s:20:\"um-icon-arrow-down-b\";i:134;s:20:\"um-icon-arrow-down-c\";i:135;s:20:\"um-icon-arrow-expand\";i:136;s:29:\"um-icon-arrow-graph-down-left\";i:137;s:30:\"um-icon-arrow-graph-down-right\";i:138;s:27:\"um-icon-arrow-graph-up-left\";i:139;s:28:\"um-icon-arrow-graph-up-right\";i:140;s:20:\"um-icon-arrow-left-a\";i:141;s:20:\"um-icon-arrow-left-b\";i:142;s:20:\"um-icon-arrow-left-c\";i:143;s:18:\"um-icon-arrow-move\";i:144;s:20:\"um-icon-arrow-resize\";i:145;s:25:\"um-icon-arrow-return-left\";i:146;s:26:\"um-icon-arrow-return-right\";i:147;s:21:\"um-icon-arrow-right-a\";i:148;s:21:\"um-icon-arrow-right-b\";i:149;s:21:\"um-icon-arrow-right-c\";i:150;s:20:\"um-icon-arrow-shrink\";i:151;s:18:\"um-icon-arrow-swap\";i:152;s:18:\"um-icon-arrow-up-a\";i:153;s:18:\"um-icon-arrow-up-b\";i:154;s:18:\"um-icon-arrow-up-c\";i:155;s:16:\"um-icon-asterisk\";i:156;s:10:\"um-icon-at\";i:157;s:17:\"um-icon-backspace\";i:158;s:25:\"um-icon-backspace-outline\";i:159;s:11:\"um-icon-bag\";i:160;s:24:\"um-icon-battery-charging\";i:161;s:21:\"um-icon-battery-empty\";i:162;s:20:\"um-icon-battery-full\";i:163;s:20:\"um-icon-battery-half\";i:164;s:19:\"um-icon-battery-low\";i:165;s:14:\"um-icon-beaker\";i:166;s:12:\"um-icon-beer\";i:167;s:17:\"um-icon-bluetooth\";i:168;s:15:\"um-icon-bonfire\";i:169;s:16:\"um-icon-bookmark\";i:170;s:14:\"um-icon-bowtie\";i:171;s:17:\"um-icon-briefcase\";i:172;s:11:\"um-icon-bug\";i:173;s:18:\"um-icon-calculator\";i:174;s:16:\"um-icon-calendar\";i:175;s:14:\"um-icon-camera\";i:176;s:12:\"um-icon-card\";i:177;s:12:\"um-icon-cash\";i:178;s:15:\"um-icon-chatbox\";i:179;s:23:\"um-icon-chatbox-working\";i:180;s:17:\"um-icon-chatboxes\";i:181;s:18:\"um-icon-chatbubble\";i:182;s:26:\"um-icon-chatbubble-working\";i:183;s:19:\"um-icon-chatbubbles\";i:184;s:17:\"um-icon-checkmark\";i:185;s:25:\"um-icon-checkmark-circled\";i:186;s:23:\"um-icon-checkmark-round\";i:187;s:20:\"um-icon-chevron-down\";i:188;s:20:\"um-icon-chevron-left\";i:189;s:21:\"um-icon-chevron-right\";i:190;s:18:\"um-icon-chevron-up\";i:191;s:17:\"um-icon-clipboard\";i:192;s:13:\"um-icon-clock\";i:193;s:13:\"um-icon-close\";i:194;s:21:\"um-icon-close-circled\";i:195;s:19:\"um-icon-close-round\";i:196;s:25:\"um-icon-closed-captioning\";i:197;s:13:\"um-icon-cloud\";i:198;s:12:\"um-icon-code\";i:199;s:21:\"um-icon-code-download\";i:200;s:20:\"um-icon-code-working\";i:201;s:14:\"um-icon-coffee\";i:202;s:15:\"um-icon-compass\";i:203;s:15:\"um-icon-compose\";i:204;s:23:\"um-icon-connection-bars\";i:205;s:16:\"um-icon-contrast\";i:206;s:12:\"um-icon-crop\";i:207;s:12:\"um-icon-cube\";i:208;s:12:\"um-icon-disc\";i:209;s:16:\"um-icon-document\";i:210;s:21:\"um-icon-document-text\";i:211;s:12:\"um-icon-drag\";i:212;s:13:\"um-icon-earth\";i:213;s:13:\"um-icon-easel\";i:214;s:12:\"um-icon-edit\";i:215;s:11:\"um-icon-egg\";i:216;s:13:\"um-icon-eject\";i:217;s:13:\"um-icon-email\";i:218;s:20:\"um-icon-email-unread\";i:219;s:24:\"um-icon-erlenmeyer-flask\";i:220;s:32:\"um-icon-erlenmeyer-flask-bubbles\";i:221;s:11:\"um-icon-eye\";i:222;s:20:\"um-icon-eye-disabled\";i:223;s:14:\"um-icon-female\";i:224;s:14:\"um-icon-filing\";i:225;s:19:\"um-icon-film-marker\";i:226;s:16:\"um-icon-fireball\";i:227;s:12:\"um-icon-flag\";i:228;s:13:\"um-icon-flame\";i:229;s:13:\"um-icon-flash\";i:230;s:17:\"um-icon-flash-off\";i:231;s:14:\"um-icon-folder\";i:232;s:12:\"um-icon-fork\";i:233;s:17:\"um-icon-fork-repo\";i:234;s:15:\"um-icon-forward\";i:235;s:14:\"um-icon-funnel\";i:236;s:14:\"um-icon-gear-a\";i:237;s:14:\"um-icon-gear-b\";i:238;s:12:\"um-icon-grid\";i:239;s:14:\"um-icon-hammer\";i:240;s:13:\"um-icon-happy\";i:241;s:21:\"um-icon-happy-outline\";i:242;s:17:\"um-icon-headphone\";i:243;s:13:\"um-icon-heart\";i:244;s:20:\"um-icon-heart-broken\";i:245;s:12:\"um-icon-help\";i:246;s:17:\"um-icon-help-buoy\";i:247;s:20:\"um-icon-help-circled\";i:248;s:12:\"um-icon-home\";i:249;s:16:\"um-icon-icecream\";i:250;s:13:\"um-icon-image\";i:251;s:14:\"um-icon-images\";i:252;s:19:\"um-icon-information\";i:253;s:27:\"um-icon-information-circled\";i:254;s:13:\"um-icon-ionic\";i:255;s:17:\"um-icon-ios-alarm\";i:256;s:25:\"um-icon-ios-alarm-outline\";i:257;s:18:\"um-icon-ios-albums\";i:258;s:26:\"um-icon-ios-albums-outline\";i:259;s:28:\"um-icon-ios-americanfootball\";i:260;s:36:\"um-icon-ios-americanfootball-outline\";i:261;s:21:\"um-icon-ios-analytics\";i:262;s:29:\"um-icon-ios-analytics-outline\";i:263;s:22:\"um-icon-ios-arrow-back\";i:264;s:22:\"um-icon-ios-arrow-down\";i:265;s:25:\"um-icon-ios-arrow-forward\";i:266;s:22:\"um-icon-ios-arrow-left\";i:267;s:23:\"um-icon-ios-arrow-right\";i:268;s:27:\"um-icon-ios-arrow-thin-down\";i:269;s:27:\"um-icon-ios-arrow-thin-left\";i:270;s:28:\"um-icon-ios-arrow-thin-right\";i:271;s:25:\"um-icon-ios-arrow-thin-up\";i:272;s:20:\"um-icon-ios-arrow-up\";i:273;s:14:\"um-icon-ios-at\";i:274;s:22:\"um-icon-ios-at-outline\";i:275;s:19:\"um-icon-ios-barcode\";i:276;s:27:\"um-icon-ios-barcode-outline\";i:277;s:20:\"um-icon-ios-baseball\";i:278;s:28:\"um-icon-ios-baseball-outline\";i:279;s:22:\"um-icon-ios-basketball\";i:280;s:30:\"um-icon-ios-basketball-outline\";i:281;s:16:\"um-icon-ios-bell\";i:282;s:24:\"um-icon-ios-bell-outline\";i:283;s:16:\"um-icon-ios-body\";i:284;s:24:\"um-icon-ios-body-outline\";i:285;s:16:\"um-icon-ios-bolt\";i:286;s:24:\"um-icon-ios-bolt-outline\";i:287;s:16:\"um-icon-ios-book\";i:288;s:24:\"um-icon-ios-book-outline\";i:289;s:21:\"um-icon-ios-bookmarks\";i:290;s:29:\"um-icon-ios-bookmarks-outline\";i:291;s:15:\"um-icon-ios-box\";i:292;s:23:\"um-icon-ios-box-outline\";i:293;s:21:\"um-icon-ios-briefcase\";i:294;s:29:\"um-icon-ios-briefcase-outline\";i:295;s:20:\"um-icon-ios-browsers\";i:296;s:28:\"um-icon-ios-browsers-outline\";i:297;s:22:\"um-icon-ios-calculator\";i:298;s:30:\"um-icon-ios-calculator-outline\";i:299;s:20:\"um-icon-ios-calendar\";i:300;s:28:\"um-icon-ios-calendar-outline\";i:301;s:18:\"um-icon-ios-camera\";i:302;s:26:\"um-icon-ios-camera-outline\";i:303;s:16:\"um-icon-ios-cart\";i:304;s:24:\"um-icon-ios-cart-outline\";i:305;s:21:\"um-icon-ios-chatboxes\";i:306;s:29:\"um-icon-ios-chatboxes-outline\";i:307;s:22:\"um-icon-ios-chatbubble\";i:308;s:30:\"um-icon-ios-chatbubble-outline\";i:309;s:21:\"um-icon-ios-checkmark\";i:310;s:27:\"um-icon-ios-checkmark-empty\";i:311;s:29:\"um-icon-ios-checkmark-outline\";i:312;s:25:\"um-icon-ios-circle-filled\";i:313;s:26:\"um-icon-ios-circle-outline\";i:314;s:17:\"um-icon-ios-clock\";i:315;s:25:\"um-icon-ios-clock-outline\";i:316;s:17:\"um-icon-ios-close\";i:317;s:23:\"um-icon-ios-close-empty\";i:318;s:25:\"um-icon-ios-close-outline\";i:319;s:17:\"um-icon-ios-cloud\";i:320;s:26:\"um-icon-ios-cloud-download\";i:321;s:34:\"um-icon-ios-cloud-download-outline\";i:322;s:25:\"um-icon-ios-cloud-outline\";i:323;s:24:\"um-icon-ios-cloud-upload\";i:324;s:32:\"um-icon-ios-cloud-upload-outline\";i:325;s:18:\"um-icon-ios-cloudy\";i:326;s:24:\"um-icon-ios-cloudy-night\";i:327;s:32:\"um-icon-ios-cloudy-night-outline\";i:328;s:26:\"um-icon-ios-cloudy-outline\";i:329;s:15:\"um-icon-ios-cog\";i:330;s:23:\"um-icon-ios-cog-outline\";i:331;s:24:\"um-icon-ios-color-filter\";i:332;s:32:\"um-icon-ios-color-filter-outline\";i:333;s:22:\"um-icon-ios-color-wand\";i:334;s:30:\"um-icon-ios-color-wand-outline\";i:335;s:19:\"um-icon-ios-compose\";i:336;s:27:\"um-icon-ios-compose-outline\";i:337;s:19:\"um-icon-ios-contact\";i:338;s:27:\"um-icon-ios-contact-outline\";i:339;s:16:\"um-icon-ios-copy\";i:340;s:24:\"um-icon-ios-copy-outline\";i:341;s:16:\"um-icon-ios-crop\";i:342;s:23:\"um-icon-ios-crop-strong\";i:343;s:20:\"um-icon-ios-download\";i:344;s:28:\"um-icon-ios-download-outline\";i:345;s:16:\"um-icon-ios-drag\";i:346;s:17:\"um-icon-ios-email\";i:347;s:25:\"um-icon-ios-email-outline\";i:348;s:15:\"um-icon-ios-eye\";i:349;s:23:\"um-icon-ios-eye-outline\";i:350;s:23:\"um-icon-ios-fastforward\";i:351;s:31:\"um-icon-ios-fastforward-outline\";i:352;s:18:\"um-icon-ios-filing\";i:353;s:26:\"um-icon-ios-filing-outline\";i:354;s:16:\"um-icon-ios-film\";i:355;s:24:\"um-icon-ios-film-outline\";i:356;s:16:\"um-icon-ios-flag\";i:357;s:24:\"um-icon-ios-flag-outline\";i:358;s:17:\"um-icon-ios-flame\";i:359;s:25:\"um-icon-ios-flame-outline\";i:360;s:17:\"um-icon-ios-flask\";i:361;s:25:\"um-icon-ios-flask-outline\";i:362;s:18:\"um-icon-ios-flower\";i:363;s:26:\"um-icon-ios-flower-outline\";i:364;s:18:\"um-icon-ios-folder\";i:365;s:26:\"um-icon-ios-folder-outline\";i:366;s:20:\"um-icon-ios-football\";i:367;s:28:\"um-icon-ios-football-outline\";i:368;s:29:\"um-icon-ios-game-controller-a\";i:369;s:37:\"um-icon-ios-game-controller-a-outline\";i:370;s:29:\"um-icon-ios-game-controller-b\";i:371;s:37:\"um-icon-ios-game-controller-b-outline\";i:372;s:16:\"um-icon-ios-gear\";i:373;s:24:\"um-icon-ios-gear-outline\";i:374;s:19:\"um-icon-ios-glasses\";i:375;s:27:\"um-icon-ios-glasses-outline\";i:376;s:21:\"um-icon-ios-grid-view\";i:377;s:29:\"um-icon-ios-grid-view-outline\";i:378;s:17:\"um-icon-ios-heart\";i:379;s:25:\"um-icon-ios-heart-outline\";i:380;s:16:\"um-icon-ios-help\";i:381;s:22:\"um-icon-ios-help-empty\";i:382;s:24:\"um-icon-ios-help-outline\";i:383;s:16:\"um-icon-ios-home\";i:384;s:24:\"um-icon-ios-home-outline\";i:385;s:20:\"um-icon-ios-infinite\";i:386;s:28:\"um-icon-ios-infinite-outline\";i:387;s:23:\"um-icon-ios-information\";i:388;s:29:\"um-icon-ios-information-empty\";i:389;s:31:\"um-icon-ios-information-outline\";i:390;s:25:\"um-icon-ios-ionic-outline\";i:391;s:18:\"um-icon-ios-keypad\";i:392;s:26:\"um-icon-ios-keypad-outline\";i:393;s:21:\"um-icon-ios-lightbulb\";i:394;s:29:\"um-icon-ios-lightbulb-outline\";i:395;s:16:\"um-icon-ios-list\";i:396;s:24:\"um-icon-ios-list-outline\";i:397;s:20:\"um-icon-ios-location\";i:398;s:28:\"um-icon-ios-location-outline\";i:399;s:18:\"um-icon-ios-locked\";i:400;s:26:\"um-icon-ios-locked-outline\";i:401;s:16:\"um-icon-ios-loop\";i:402;s:23:\"um-icon-ios-loop-strong\";i:403;s:19:\"um-icon-ios-medical\";i:404;s:27:\"um-icon-ios-medical-outline\";i:405;s:18:\"um-icon-ios-medkit\";i:406;s:26:\"um-icon-ios-medkit-outline\";i:407;s:15:\"um-icon-ios-mic\";i:408;s:19:\"um-icon-ios-mic-off\";i:409;s:23:\"um-icon-ios-mic-outline\";i:410;s:17:\"um-icon-ios-minus\";i:411;s:23:\"um-icon-ios-minus-empty\";i:412;s:25:\"um-icon-ios-minus-outline\";i:413;s:19:\"um-icon-ios-monitor\";i:414;s:27:\"um-icon-ios-monitor-outline\";i:415;s:16:\"um-icon-ios-moon\";i:416;s:24:\"um-icon-ios-moon-outline\";i:417;s:16:\"um-icon-ios-more\";i:418;s:24:\"um-icon-ios-more-outline\";i:419;s:24:\"um-icon-ios-musical-note\";i:420;s:25:\"um-icon-ios-musical-notes\";i:421;s:20:\"um-icon-ios-navigate\";i:422;s:28:\"um-icon-ios-navigate-outline\";i:423;s:21:\"um-icon-ios-nutrition\";i:424;s:29:\"um-icon-ios-nutrition-outline\";i:425;s:17:\"um-icon-ios-paper\";i:426;s:25:\"um-icon-ios-paper-outline\";i:427;s:22:\"um-icon-ios-paperplane\";i:428;s:30:\"um-icon-ios-paperplane-outline\";i:429;s:23:\"um-icon-ios-partlysunny\";i:430;s:31:\"um-icon-ios-partlysunny-outline\";i:431;s:17:\"um-icon-ios-pause\";i:432;s:25:\"um-icon-ios-pause-outline\";i:433;s:15:\"um-icon-ios-paw\";i:434;s:23:\"um-icon-ios-paw-outline\";i:435;s:18:\"um-icon-ios-people\";i:436;s:26:\"um-icon-ios-people-outline\";i:437;s:18:\"um-icon-ios-person\";i:438;s:26:\"um-icon-ios-person-outline\";i:439;s:21:\"um-icon-ios-personadd\";i:440;s:29:\"um-icon-ios-personadd-outline\";i:441;s:18:\"um-icon-ios-photos\";i:442;s:26:\"um-icon-ios-photos-outline\";i:443;s:15:\"um-icon-ios-pie\";i:444;s:23:\"um-icon-ios-pie-outline\";i:445;s:16:\"um-icon-ios-pint\";i:446;s:24:\"um-icon-ios-pint-outline\";i:447;s:16:\"um-icon-ios-play\";i:448;s:24:\"um-icon-ios-play-outline\";i:449;s:16:\"um-icon-ios-plus\";i:450;s:22:\"um-icon-ios-plus-empty\";i:451;s:24:\"um-icon-ios-plus-outline\";i:452;s:20:\"um-icon-ios-pricetag\";i:453;s:28:\"um-icon-ios-pricetag-outline\";i:454;s:21:\"um-icon-ios-pricetags\";i:455;s:29:\"um-icon-ios-pricetags-outline\";i:456;s:19:\"um-icon-ios-printer\";i:457;s:27:\"um-icon-ios-printer-outline\";i:458;s:17:\"um-icon-ios-pulse\";i:459;s:24:\"um-icon-ios-pulse-strong\";i:460;s:17:\"um-icon-ios-rainy\";i:461;s:25:\"um-icon-ios-rainy-outline\";i:462;s:21:\"um-icon-ios-recording\";i:463;s:29:\"um-icon-ios-recording-outline\";i:464;s:16:\"um-icon-ios-redo\";i:465;s:24:\"um-icon-ios-redo-outline\";i:466;s:19:\"um-icon-ios-refresh\";i:467;s:25:\"um-icon-ios-refresh-empty\";i:468;s:27:\"um-icon-ios-refresh-outline\";i:469;s:18:\"um-icon-ios-reload\";i:470;s:26:\"um-icon-ios-reverse-camera\";i:471;s:34:\"um-icon-ios-reverse-camera-outline\";i:472;s:18:\"um-icon-ios-rewind\";i:473;s:26:\"um-icon-ios-rewind-outline\";i:474;s:16:\"um-icon-ios-rose\";i:475;s:24:\"um-icon-ios-rose-outline\";i:476;s:18:\"um-icon-ios-search\";i:477;s:25:\"um-icon-ios-search-strong\";i:478;s:20:\"um-icon-ios-settings\";i:479;s:27:\"um-icon-ios-settings-strong\";i:480;s:19:\"um-icon-ios-shuffle\";i:481;s:26:\"um-icon-ios-shuffle-strong\";i:482;s:24:\"um-icon-ios-skipbackward\";i:483;s:32:\"um-icon-ios-skipbackward-outline\";i:484;s:23:\"um-icon-ios-skipforward\";i:485;s:31:\"um-icon-ios-skipforward-outline\";i:486;s:17:\"um-icon-ios-snowy\";i:487;s:23:\"um-icon-ios-speedometer\";i:488;s:31:\"um-icon-ios-speedometer-outline\";i:489;s:16:\"um-icon-ios-star\";i:490;s:21:\"um-icon-ios-star-half\";i:491;s:24:\"um-icon-ios-star-outline\";i:492;s:21:\"um-icon-ios-stopwatch\";i:493;s:29:\"um-icon-ios-stopwatch-outline\";i:494;s:17:\"um-icon-ios-sunny\";i:495;s:25:\"um-icon-ios-sunny-outline\";i:496;s:21:\"um-icon-ios-telephone\";i:497;s:29:\"um-icon-ios-telephone-outline\";i:498;s:22:\"um-icon-ios-tennisball\";i:499;s:30:\"um-icon-ios-tennisball-outline\";i:500;s:24:\"um-icon-ios-thunderstorm\";i:501;s:32:\"um-icon-ios-thunderstorm-outline\";i:502;s:16:\"um-icon-ios-time\";i:503;s:24:\"um-icon-ios-time-outline\";i:504;s:17:\"um-icon-ios-timer\";i:505;s:25:\"um-icon-ios-timer-outline\";i:506;s:18:\"um-icon-ios-toggle\";i:507;s:26:\"um-icon-ios-toggle-outline\";i:508;s:17:\"um-icon-ios-trash\";i:509;s:25:\"um-icon-ios-trash-outline\";i:510;s:16:\"um-icon-ios-undo\";i:511;s:24:\"um-icon-ios-undo-outline\";i:512;s:20:\"um-icon-ios-unlocked\";i:513;s:28:\"um-icon-ios-unlocked-outline\";i:514;s:18:\"um-icon-ios-upload\";i:515;s:26:\"um-icon-ios-upload-outline\";i:516;s:20:\"um-icon-ios-videocam\";i:517;s:28:\"um-icon-ios-videocam-outline\";i:518;s:23:\"um-icon-ios-volume-high\";i:519;s:22:\"um-icon-ios-volume-low\";i:520;s:21:\"um-icon-ios-wineglass\";i:521;s:29:\"um-icon-ios-wineglass-outline\";i:522;s:17:\"um-icon-ios-world\";i:523;s:25:\"um-icon-ios-world-outline\";i:524;s:12:\"um-icon-ipad\";i:525;s:14:\"um-icon-iphone\";i:526;s:12:\"um-icon-ipod\";i:527;s:11:\"um-icon-jet\";i:528;s:11:\"um-icon-key\";i:529;s:13:\"um-icon-knife\";i:530;s:14:\"um-icon-laptop\";i:531;s:12:\"um-icon-leaf\";i:532;s:14:\"um-icon-levels\";i:533;s:17:\"um-icon-lightbulb\";i:534;s:12:\"um-icon-link\";i:535;s:14:\"um-icon-load-a\";i:536;s:14:\"um-icon-load-b\";i:537;s:14:\"um-icon-load-c\";i:538;s:14:\"um-icon-load-d\";i:539;s:16:\"um-icon-location\";i:540;s:24:\"um-icon-lock-combination\";i:541;s:14:\"um-icon-locked\";i:542;s:14:\"um-icon-log-in\";i:543;s:15:\"um-icon-log-out\";i:544;s:12:\"um-icon-loop\";i:545;s:14:\"um-icon-magnet\";i:546;s:12:\"um-icon-male\";i:547;s:11:\"um-icon-man\";i:548;s:11:\"um-icon-map\";i:549;s:14:\"um-icon-medkit\";i:550;s:13:\"um-icon-merge\";i:551;s:13:\"um-icon-mic-a\";i:552;s:13:\"um-icon-mic-b\";i:553;s:13:\"um-icon-mic-c\";i:554;s:13:\"um-icon-minus\";i:555;s:21:\"um-icon-minus-circled\";i:556;s:19:\"um-icon-minus-round\";i:557;s:15:\"um-icon-model-s\";i:558;s:15:\"um-icon-monitor\";i:559;s:12:\"um-icon-more\";i:560;s:13:\"um-icon-mouse\";i:561;s:18:\"um-icon-music-note\";i:562;s:15:\"um-icon-navicon\";i:563;s:21:\"um-icon-navicon-round\";i:564;s:16:\"um-icon-navigate\";i:565;s:15:\"um-icon-network\";i:566;s:18:\"um-icon-no-smoking\";i:567;s:15:\"um-icon-nuclear\";i:568;s:14:\"um-icon-outlet\";i:569;s:18:\"um-icon-paintbrush\";i:570;s:19:\"um-icon-paintbucket\";i:571;s:22:\"um-icon-paper-airplane\";i:572;s:17:\"um-icon-paperclip\";i:573;s:13:\"um-icon-pause\";i:574;s:14:\"um-icon-person\";i:575;s:18:\"um-icon-person-add\";i:576;s:22:\"um-icon-person-stalker\";i:577;s:17:\"um-icon-pie-graph\";i:578;s:11:\"um-icon-pin\";i:579;s:16:\"um-icon-pinpoint\";i:580;s:13:\"um-icon-pizza\";i:581;s:13:\"um-icon-plane\";i:582;s:14:\"um-icon-planet\";i:583;s:12:\"um-icon-play\";i:584;s:19:\"um-icon-playstation\";i:585;s:12:\"um-icon-plus\";i:586;s:20:\"um-icon-plus-circled\";i:587;s:18:\"um-icon-plus-round\";i:588;s:14:\"um-icon-podium\";i:589;s:13:\"um-icon-pound\";i:590;s:13:\"um-icon-power\";i:591;s:16:\"um-icon-pricetag\";i:592;s:17:\"um-icon-pricetags\";i:593;s:15:\"um-icon-printer\";i:594;s:20:\"um-icon-pull-request\";i:595;s:18:\"um-icon-qr-scanner\";i:596;s:13:\"um-icon-quote\";i:597;s:19:\"um-icon-radio-waves\";i:598;s:14:\"um-icon-record\";i:599;s:15:\"um-icon-refresh\";i:600;s:13:\"um-icon-reply\";i:601;s:17:\"um-icon-reply-all\";i:602;s:16:\"um-icon-ribbon-a\";i:603;s:16:\"um-icon-ribbon-b\";i:604;s:11:\"um-icon-sad\";i:605;s:19:\"um-icon-sad-outline\";i:606;s:16:\"um-icon-scissors\";i:607;s:14:\"um-icon-search\";i:608;s:16:\"um-icon-settings\";i:609;s:13:\"um-icon-share\";i:610;s:15:\"um-icon-shuffle\";i:611;s:21:\"um-icon-skip-backward\";i:612;s:20:\"um-icon-skip-forward\";i:613;s:22:\"um-icon-social-android\";i:614;s:30:\"um-icon-social-android-outline\";i:615;s:22:\"um-icon-social-angular\";i:616;s:30:\"um-icon-social-angular-outline\";i:617;s:20:\"um-icon-social-apple\";i:618;s:28:\"um-icon-social-apple-outline\";i:619;s:22:\"um-icon-social-bitcoin\";i:620;s:30:\"um-icon-social-bitcoin-outline\";i:621;s:21:\"um-icon-social-buffer\";i:622;s:29:\"um-icon-social-buffer-outline\";i:623;s:21:\"um-icon-social-chrome\";i:624;s:29:\"um-icon-social-chrome-outline\";i:625;s:22:\"um-icon-social-codepen\";i:626;s:30:\"um-icon-social-codepen-outline\";i:627;s:19:\"um-icon-social-css3\";i:628;s:27:\"um-icon-social-css3-outline\";i:629;s:27:\"um-icon-social-designernews\";i:630;s:35:\"um-icon-social-designernews-outline\";i:631;s:23:\"um-icon-social-dribbble\";i:632;s:31:\"um-icon-social-dribbble-outline\";i:633;s:22:\"um-icon-social-dropbox\";i:634;s:30:\"um-icon-social-dropbox-outline\";i:635;s:19:\"um-icon-social-euro\";i:636;s:27:\"um-icon-social-euro-outline\";i:637;s:23:\"um-icon-social-facebook\";i:638;s:31:\"um-icon-social-facebook-outline\";i:639;s:25:\"um-icon-social-foursquare\";i:640;s:33:\"um-icon-social-foursquare-outline\";i:641;s:28:\"um-icon-social-freebsd-devil\";i:642;s:21:\"um-icon-social-github\";i:643;s:29:\"um-icon-social-github-outline\";i:644;s:21:\"um-icon-social-google\";i:645;s:29:\"um-icon-social-google-outline\";i:646;s:25:\"um-icon-social-googleplus\";i:647;s:33:\"um-icon-social-googleplus-outline\";i:648;s:25:\"um-icon-social-hackernews\";i:649;s:33:\"um-icon-social-hackernews-outline\";i:650;s:20:\"um-icon-social-html5\";i:651;s:28:\"um-icon-social-html5-outline\";i:652;s:24:\"um-icon-social-instagram\";i:653;s:32:\"um-icon-social-instagram-outline\";i:654;s:25:\"um-icon-social-javascript\";i:655;s:33:\"um-icon-social-javascript-outline\";i:656;s:23:\"um-icon-social-linkedin\";i:657;s:31:\"um-icon-social-linkedin-outline\";i:658;s:23:\"um-icon-social-markdown\";i:659;s:21:\"um-icon-social-nodejs\";i:660;s:22:\"um-icon-social-octocat\";i:661;s:24:\"um-icon-social-pinterest\";i:662;s:32:\"um-icon-social-pinterest-outline\";i:663;s:21:\"um-icon-social-python\";i:664;s:21:\"um-icon-social-reddit\";i:665;s:29:\"um-icon-social-reddit-outline\";i:666;s:18:\"um-icon-social-rss\";i:667;s:26:\"um-icon-social-rss-outline\";i:668;s:19:\"um-icon-social-sass\";i:669;s:20:\"um-icon-social-skype\";i:670;s:28:\"um-icon-social-skype-outline\";i:671;s:23:\"um-icon-social-snapchat\";i:672;s:31:\"um-icon-social-snapchat-outline\";i:673;s:21:\"um-icon-social-tumblr\";i:674;s:29:\"um-icon-social-tumblr-outline\";i:675;s:18:\"um-icon-social-tux\";i:676;s:21:\"um-icon-social-twitch\";i:677;s:29:\"um-icon-social-twitch-outline\";i:678;s:22:\"um-icon-social-twitter\";i:679;s:30:\"um-icon-social-twitter-outline\";i:680;s:18:\"um-icon-social-usd\";i:681;s:26:\"um-icon-social-usd-outline\";i:682;s:20:\"um-icon-social-vimeo\";i:683;s:28:\"um-icon-social-vimeo-outline\";i:684;s:23:\"um-icon-social-whatsapp\";i:685;s:31:\"um-icon-social-whatsapp-outline\";i:686;s:22:\"um-icon-social-windows\";i:687;s:30:\"um-icon-social-windows-outline\";i:688;s:24:\"um-icon-social-wordpress\";i:689;s:32:\"um-icon-social-wordpress-outline\";i:690;s:20:\"um-icon-social-yahoo\";i:691;s:28:\"um-icon-social-yahoo-outline\";i:692;s:18:\"um-icon-social-yen\";i:693;s:26:\"um-icon-social-yen-outline\";i:694;s:22:\"um-icon-social-youtube\";i:695;s:30:\"um-icon-social-youtube-outline\";i:696;s:16:\"um-icon-soup-can\";i:697;s:24:\"um-icon-soup-can-outline\";i:698;s:20:\"um-icon-speakerphone\";i:699;s:19:\"um-icon-speedometer\";i:700;s:13:\"um-icon-spoon\";i:701;s:12:\"um-icon-star\";i:702;s:18:\"um-icon-stats-bars\";i:703;s:13:\"um-icon-steam\";i:704;s:12:\"um-icon-stop\";i:705;s:19:\"um-icon-thermometer\";i:706;s:18:\"um-icon-thumbsdown\";i:707;s:16:\"um-icon-thumbsup\";i:708;s:14:\"um-icon-toggle\";i:709;s:21:\"um-icon-toggle-filled\";i:710;s:19:\"um-icon-transgender\";i:711;s:15:\"um-icon-trash-a\";i:712;s:15:\"um-icon-trash-b\";i:713;s:14:\"um-icon-trophy\";i:714;s:14:\"um-icon-tshirt\";i:715;s:22:\"um-icon-tshirt-outline\";i:716;s:16:\"um-icon-umbrella\";i:717;s:18:\"um-icon-university\";i:718;s:16:\"um-icon-unlocked\";i:719;s:14:\"um-icon-upload\";i:720;s:11:\"um-icon-usb\";i:721;s:19:\"um-icon-videocamera\";i:722;s:19:\"um-icon-volume-high\";i:723;s:18:\"um-icon-volume-low\";i:724;s:21:\"um-icon-volume-medium\";i:725;s:19:\"um-icon-volume-mute\";i:726;s:12:\"um-icon-wand\";i:727;s:17:\"um-icon-waterdrop\";i:728;s:12:\"um-icon-wifi\";i:729;s:17:\"um-icon-wineglass\";i:730;s:13:\"um-icon-woman\";i:731;s:14:\"um-icon-wrench\";i:732;s:12:\"um-icon-xbox\";i:733;s:15:\"um-faicon-glass\";i:734;s:15:\"um-faicon-music\";i:735;s:16:\"um-faicon-search\";i:736;s:20:\"um-faicon-envelope-o\";i:737;s:15:\"um-faicon-heart\";i:738;s:14:\"um-faicon-star\";i:739;s:16:\"um-faicon-star-o\";i:740;s:14:\"um-faicon-user\";i:741;s:14:\"um-faicon-film\";i:742;s:18:\"um-faicon-th-large\";i:743;s:12:\"um-faicon-th\";i:744;s:17:\"um-faicon-th-list\";i:745;s:15:\"um-faicon-check\";i:746;s:15:\"um-faicon-times\";i:747;s:21:\"um-faicon-search-plus\";i:748;s:22:\"um-faicon-search-minus\";i:749;s:19:\"um-faicon-power-off\";i:750;s:16:\"um-faicon-signal\";i:751;s:13:\"um-faicon-cog\";i:752;s:17:\"um-faicon-trash-o\";i:753;s:14:\"um-faicon-home\";i:754;s:16:\"um-faicon-file-o\";i:755;s:17:\"um-faicon-clock-o\";i:756;s:14:\"um-faicon-road\";i:757;s:18:\"um-faicon-download\";i:758;s:29:\"um-faicon-arrow-circle-o-down\";i:759;s:27:\"um-faicon-arrow-circle-o-up\";i:760;s:15:\"um-faicon-inbox\";i:761;s:23:\"um-faicon-play-circle-o\";i:762;s:16:\"um-faicon-repeat\";i:763;s:17:\"um-faicon-refresh\";i:764;s:18:\"um-faicon-list-alt\";i:765;s:14:\"um-faicon-lock\";i:766;s:14:\"um-faicon-flag\";i:767;s:20:\"um-faicon-headphones\";i:768;s:20:\"um-faicon-volume-off\";i:769;s:21:\"um-faicon-volume-down\";i:770;s:19:\"um-faicon-volume-up\";i:771;s:16:\"um-faicon-qrcode\";i:772;s:17:\"um-faicon-barcode\";i:773;s:13:\"um-faicon-tag\";i:774;s:14:\"um-faicon-tags\";i:775;s:14:\"um-faicon-book\";i:776;s:18:\"um-faicon-bookmark\";i:777;s:15:\"um-faicon-print\";i:778;s:16:\"um-faicon-camera\";i:779;s:14:\"um-faicon-font\";i:780;s:14:\"um-faicon-bold\";i:781;s:16:\"um-faicon-italic\";i:782;s:21:\"um-faicon-text-height\";i:783;s:20:\"um-faicon-text-width\";i:784;s:20:\"um-faicon-align-left\";i:785;s:22:\"um-faicon-align-center\";i:786;s:21:\"um-faicon-align-right\";i:787;s:23:\"um-faicon-align-justify\";i:788;s:14:\"um-faicon-list\";i:789;s:17:\"um-faicon-outdent\";i:790;s:16:\"um-faicon-indent\";i:791;s:22:\"um-faicon-video-camera\";i:792;s:19:\"um-faicon-picture-o\";i:793;s:16:\"um-faicon-pencil\";i:794;s:20:\"um-faicon-map-marker\";i:795;s:16:\"um-faicon-adjust\";i:796;s:14:\"um-faicon-tint\";i:797;s:25:\"um-faicon-pencil-square-o\";i:798;s:24:\"um-faicon-share-square-o\";i:799;s:24:\"um-faicon-check-square-o\";i:800;s:16:\"um-faicon-arrows\";i:801;s:23:\"um-faicon-step-backward\";i:802;s:23:\"um-faicon-fast-backward\";i:803;s:18:\"um-faicon-backward\";i:804;s:14:\"um-faicon-play\";i:805;s:15:\"um-faicon-pause\";i:806;s:14:\"um-faicon-stop\";i:807;s:17:\"um-faicon-forward\";i:808;s:22:\"um-faicon-fast-forward\";i:809;s:22:\"um-faicon-step-forward\";i:810;s:15:\"um-faicon-eject\";i:811;s:22:\"um-faicon-chevron-left\";i:812;s:23:\"um-faicon-chevron-right\";i:813;s:21:\"um-faicon-plus-circle\";i:814;s:22:\"um-faicon-minus-circle\";i:815;s:22:\"um-faicon-times-circle\";i:816;s:22:\"um-faicon-check-circle\";i:817;s:25:\"um-faicon-question-circle\";i:818;s:21:\"um-faicon-info-circle\";i:819;s:20:\"um-faicon-crosshairs\";i:820;s:24:\"um-faicon-times-circle-o\";i:821;s:24:\"um-faicon-check-circle-o\";i:822;s:13:\"um-faicon-ban\";i:823;s:20:\"um-faicon-arrow-left\";i:824;s:21:\"um-faicon-arrow-right\";i:825;s:18:\"um-faicon-arrow-up\";i:826;s:20:\"um-faicon-arrow-down\";i:827;s:15:\"um-faicon-share\";i:828;s:16:\"um-faicon-expand\";i:829;s:18:\"um-faicon-compress\";i:830;s:14:\"um-faicon-plus\";i:831;s:15:\"um-faicon-minus\";i:832;s:18:\"um-faicon-asterisk\";i:833;s:28:\"um-faicon-exclamation-circle\";i:834;s:14:\"um-faicon-gift\";i:835;s:14:\"um-faicon-leaf\";i:836;s:14:\"um-faicon-fire\";i:837;s:13:\"um-faicon-eye\";i:838;s:19:\"um-faicon-eye-slash\";i:839;s:30:\"um-faicon-exclamation-triangle\";i:840;s:15:\"um-faicon-plane\";i:841;s:18:\"um-faicon-calendar\";i:842;s:16:\"um-faicon-random\";i:843;s:17:\"um-faicon-comment\";i:844;s:16:\"um-faicon-magnet\";i:845;s:20:\"um-faicon-chevron-up\";i:846;s:22:\"um-faicon-chevron-down\";i:847;s:17:\"um-faicon-retweet\";i:848;s:23:\"um-faicon-shopping-cart\";i:849;s:16:\"um-faicon-folder\";i:850;s:21:\"um-faicon-folder-open\";i:851;s:18:\"um-faicon-arrows-v\";i:852;s:18:\"um-faicon-arrows-h\";i:853;s:19:\"um-faicon-bar-chart\";i:854;s:24:\"um-faicon-twitter-square\";i:855;s:25:\"um-faicon-facebook-square\";i:856;s:22:\"um-faicon-camera-retro\";i:857;s:13:\"um-faicon-key\";i:858;s:14:\"um-faicon-cogs\";i:859;s:18:\"um-faicon-comments\";i:860;s:21:\"um-faicon-thumbs-o-up\";i:861;s:23:\"um-faicon-thumbs-o-down\";i:862;s:19:\"um-faicon-star-half\";i:863;s:17:\"um-faicon-heart-o\";i:864;s:18:\"um-faicon-sign-out\";i:865;s:25:\"um-faicon-linkedin-square\";i:866;s:20:\"um-faicon-thumb-tack\";i:867;s:23:\"um-faicon-external-link\";i:868;s:17:\"um-faicon-sign-in\";i:869;s:16:\"um-faicon-trophy\";i:870;s:23:\"um-faicon-github-square\";i:871;s:16:\"um-faicon-upload\";i:872;s:17:\"um-faicon-lemon-o\";i:873;s:15:\"um-faicon-phone\";i:874;s:18:\"um-faicon-square-o\";i:875;s:20:\"um-faicon-bookmark-o\";i:876;s:22:\"um-faicon-phone-square\";i:877;s:17:\"um-faicon-twitter\";i:878;s:18:\"um-faicon-facebook\";i:879;s:16:\"um-faicon-github\";i:880;s:16:\"um-faicon-unlock\";i:881;s:21:\"um-faicon-credit-card\";i:882;s:13:\"um-faicon-rss\";i:883;s:15:\"um-faicon-hdd-o\";i:884;s:18:\"um-faicon-bullhorn\";i:885;s:14:\"um-faicon-bell\";i:886;s:21:\"um-faicon-certificate\";i:887;s:22:\"um-faicon-hand-o-right\";i:888;s:21:\"um-faicon-hand-o-left\";i:889;s:19:\"um-faicon-hand-o-up\";i:890;s:21:\"um-faicon-hand-o-down\";i:891;s:27:\"um-faicon-arrow-circle-left\";i:892;s:28:\"um-faicon-arrow-circle-right\";i:893;s:25:\"um-faicon-arrow-circle-up\";i:894;s:27:\"um-faicon-arrow-circle-down\";i:895;s:15:\"um-faicon-globe\";i:896;s:16:\"um-faicon-wrench\";i:897;s:15:\"um-faicon-tasks\";i:898;s:16:\"um-faicon-filter\";i:899;s:19:\"um-faicon-briefcase\";i:900;s:20:\"um-faicon-arrows-alt\";i:901;s:15:\"um-faicon-users\";i:902;s:14:\"um-faicon-link\";i:903;s:15:\"um-faicon-cloud\";i:904;s:15:\"um-faicon-flask\";i:905;s:18:\"um-faicon-scissors\";i:906;s:17:\"um-faicon-files-o\";i:907;s:19:\"um-faicon-paperclip\";i:908;s:18:\"um-faicon-floppy-o\";i:909;s:16:\"um-faicon-square\";i:910;s:14:\"um-faicon-bars\";i:911;s:17:\"um-faicon-list-ul\";i:912;s:17:\"um-faicon-list-ol\";i:913;s:23:\"um-faicon-strikethrough\";i:914;s:19:\"um-faicon-underline\";i:915;s:15:\"um-faicon-table\";i:916;s:15:\"um-faicon-magic\";i:917;s:15:\"um-faicon-truck\";i:918;s:19:\"um-faicon-pinterest\";i:919;s:26:\"um-faicon-pinterest-square\";i:920;s:28:\"um-faicon-google-plus-square\";i:921;s:21:\"um-faicon-google-plus\";i:922;s:15:\"um-faicon-money\";i:923;s:20:\"um-faicon-caret-down\";i:924;s:18:\"um-faicon-caret-up\";i:925;s:20:\"um-faicon-caret-left\";i:926;s:21:\"um-faicon-caret-right\";i:927;s:17:\"um-faicon-columns\";i:928;s:14:\"um-faicon-sort\";i:929;s:19:\"um-faicon-sort-desc\";i:930;s:18:\"um-faicon-sort-asc\";i:931;s:18:\"um-faicon-envelope\";i:932;s:18:\"um-faicon-linkedin\";i:933;s:14:\"um-faicon-undo\";i:934;s:15:\"um-faicon-gavel\";i:935;s:20:\"um-faicon-tachometer\";i:936;s:19:\"um-faicon-comment-o\";i:937;s:20:\"um-faicon-comments-o\";i:938;s:14:\"um-faicon-bolt\";i:939;s:17:\"um-faicon-sitemap\";i:940;s:18:\"um-faicon-umbrella\";i:941;s:19:\"um-faicon-clipboard\";i:942;s:21:\"um-faicon-lightbulb-o\";i:943;s:18:\"um-faicon-exchange\";i:944;s:24:\"um-faicon-cloud-download\";i:945;s:22:\"um-faicon-cloud-upload\";i:946;s:17:\"um-faicon-user-md\";i:947;s:21:\"um-faicon-stethoscope\";i:948;s:18:\"um-faicon-suitcase\";i:949;s:16:\"um-faicon-bell-o\";i:950;s:16:\"um-faicon-coffee\";i:951;s:17:\"um-faicon-cutlery\";i:952;s:21:\"um-faicon-file-text-o\";i:953;s:20:\"um-faicon-building-o\";i:954;s:20:\"um-faicon-hospital-o\";i:955;s:19:\"um-faicon-ambulance\";i:956;s:16:\"um-faicon-medkit\";i:957;s:21:\"um-faicon-fighter-jet\";i:958;s:14:\"um-faicon-beer\";i:959;s:18:\"um-faicon-h-square\";i:960;s:21:\"um-faicon-plus-square\";i:961;s:27:\"um-faicon-angle-double-left\";i:962;s:28:\"um-faicon-angle-double-right\";i:963;s:25:\"um-faicon-angle-double-up\";i:964;s:27:\"um-faicon-angle-double-down\";i:965;s:20:\"um-faicon-angle-left\";i:966;s:21:\"um-faicon-angle-right\";i:967;s:18:\"um-faicon-angle-up\";i:968;s:20:\"um-faicon-angle-down\";i:969;s:17:\"um-faicon-desktop\";i:970;s:16:\"um-faicon-laptop\";i:971;s:16:\"um-faicon-tablet\";i:972;s:16:\"um-faicon-mobile\";i:973;s:18:\"um-faicon-circle-o\";i:974;s:20:\"um-faicon-quote-left\";i:975;s:21:\"um-faicon-quote-right\";i:976;s:17:\"um-faicon-spinner\";i:977;s:14:\"um-faicon-spin\";i:978;s:16:\"um-faicon-circle\";i:979;s:15:\"um-faicon-reply\";i:980;s:20:\"um-faicon-github-alt\";i:981;s:18:\"um-faicon-folder-o\";i:982;s:23:\"um-faicon-folder-open-o\";i:983;s:17:\"um-faicon-smile-o\";i:984;s:17:\"um-faicon-frown-o\";i:985;s:15:\"um-faicon-meh-o\";i:986;s:17:\"um-faicon-gamepad\";i:987;s:20:\"um-faicon-keyboard-o\";i:988;s:16:\"um-faicon-flag-o\";i:989;s:24:\"um-faicon-flag-checkered\";i:990;s:18:\"um-faicon-terminal\";i:991;s:14:\"um-faicon-code\";i:992;s:19:\"um-faicon-reply-all\";i:993;s:21:\"um-faicon-star-half-o\";i:994;s:24:\"um-faicon-location-arrow\";i:995;s:14:\"um-faicon-crop\";i:996;s:19:\"um-faicon-code-fork\";i:997;s:22:\"um-faicon-chain-broken\";i:998;s:18:\"um-faicon-question\";i:999;s:14:\"um-faicon-info\";i:1000;s:21:\"um-faicon-exclamation\";i:1001;s:21:\"um-faicon-superscript\";i:1002;s:19:\"um-faicon-subscript\";i:1003;s:16:\"um-faicon-eraser\";i:1004;s:22:\"um-faicon-puzzle-piece\";i:1005;s:20:\"um-faicon-microphone\";i:1006;s:26:\"um-faicon-microphone-slash\";i:1007;s:16:\"um-faicon-shield\";i:1008;s:20:\"um-faicon-calendar-o\";i:1009;s:27:\"um-faicon-fire-extinguisher\";i:1010;s:16:\"um-faicon-rocket\";i:1011;s:16:\"um-faicon-maxcdn\";i:1012;s:29:\"um-faicon-chevron-circle-left\";i:1013;s:30:\"um-faicon-chevron-circle-right\";i:1014;s:27:\"um-faicon-chevron-circle-up\";i:1015;s:29:\"um-faicon-chevron-circle-down\";i:1016;s:15:\"um-faicon-html5\";i:1017;s:14:\"um-faicon-css3\";i:1018;s:16:\"um-faicon-anchor\";i:1019;s:20:\"um-faicon-unlock-alt\";i:1020;s:18:\"um-faicon-bullseye\";i:1021;s:20:\"um-faicon-ellipsis-h\";i:1022;s:20:\"um-faicon-ellipsis-v\";i:1023;s:20:\"um-faicon-rss-square\";i:1024;s:21:\"um-faicon-play-circle\";i:1025;s:16:\"um-faicon-ticket\";i:1026;s:22:\"um-faicon-minus-square\";i:1027;s:24:\"um-faicon-minus-square-o\";i:1028;s:18:\"um-faicon-level-up\";i:1029;s:20:\"um-faicon-level-down\";i:1030;s:22:\"um-faicon-check-square\";i:1031;s:23:\"um-faicon-pencil-square\";i:1032;s:30:\"um-faicon-external-link-square\";i:1033;s:22:\"um-faicon-share-square\";i:1034;s:17:\"um-faicon-compass\";i:1035;s:29:\"um-faicon-caret-square-o-down\";i:1036;s:27:\"um-faicon-caret-square-o-up\";i:1037;s:30:\"um-faicon-caret-square-o-right\";i:1038;s:13:\"um-faicon-eur\";i:1039;s:13:\"um-faicon-gbp\";i:1040;s:13:\"um-faicon-usd\";i:1041;s:13:\"um-faicon-inr\";i:1042;s:13:\"um-faicon-jpy\";i:1043;s:13:\"um-faicon-rub\";i:1044;s:13:\"um-faicon-krw\";i:1045;s:13:\"um-faicon-btc\";i:1046;s:14:\"um-faicon-file\";i:1047;s:19:\"um-faicon-file-text\";i:1048;s:24:\"um-faicon-sort-alpha-asc\";i:1049;s:25:\"um-faicon-sort-alpha-desc\";i:1050;s:25:\"um-faicon-sort-amount-asc\";i:1051;s:26:\"um-faicon-sort-amount-desc\";i:1052;s:26:\"um-faicon-sort-numeric-asc\";i:1053;s:27:\"um-faicon-sort-numeric-desc\";i:1054;s:19:\"um-faicon-thumbs-up\";i:1055;s:21:\"um-faicon-thumbs-down\";i:1056;s:24:\"um-faicon-youtube-square\";i:1057;s:17:\"um-faicon-youtube\";i:1058;s:14:\"um-faicon-xing\";i:1059;s:21:\"um-faicon-xing-square\";i:1060;s:22:\"um-faicon-youtube-play\";i:1061;s:17:\"um-faicon-dropbox\";i:1062;s:24:\"um-faicon-stack-overflow\";i:1063;s:19:\"um-faicon-instagram\";i:1064;s:16:\"um-faicon-flickr\";i:1065;s:13:\"um-faicon-adn\";i:1066;s:19:\"um-faicon-bitbucket\";i:1067;s:26:\"um-faicon-bitbucket-square\";i:1068;s:16:\"um-faicon-tumblr\";i:1069;s:23:\"um-faicon-tumblr-square\";i:1070;s:25:\"um-faicon-long-arrow-down\";i:1071;s:23:\"um-faicon-long-arrow-up\";i:1072;s:25:\"um-faicon-long-arrow-left\";i:1073;s:26:\"um-faicon-long-arrow-right\";i:1074;s:15:\"um-faicon-apple\";i:1075;s:17:\"um-faicon-windows\";i:1076;s:17:\"um-faicon-android\";i:1077;s:15:\"um-faicon-linux\";i:1078;s:18:\"um-faicon-dribbble\";i:1079;s:15:\"um-faicon-skype\";i:1080;s:20:\"um-faicon-foursquare\";i:1081;s:16:\"um-faicon-trello\";i:1082;s:16:\"um-faicon-female\";i:1083;s:14:\"um-faicon-male\";i:1084;s:16:\"um-faicon-gittip\";i:1085;s:15:\"um-faicon-sun-o\";i:1086;s:16:\"um-faicon-moon-o\";i:1087;s:17:\"um-faicon-archive\";i:1088;s:13:\"um-faicon-bug\";i:1089;s:12:\"um-faicon-vk\";i:1090;s:15:\"um-faicon-weibo\";i:1091;s:16:\"um-faicon-renren\";i:1092;s:19:\"um-faicon-pagelines\";i:1093;s:24:\"um-faicon-stack-exchange\";i:1094;s:30:\"um-faicon-arrow-circle-o-right\";i:1095;s:29:\"um-faicon-arrow-circle-o-left\";i:1096;s:29:\"um-faicon-caret-square-o-left\";i:1097;s:22:\"um-faicon-dot-circle-o\";i:1098;s:20:\"um-faicon-wheelchair\";i:1099;s:22:\"um-faicon-vimeo-square\";i:1100;s:13:\"um-faicon-try\";i:1101;s:23:\"um-faicon-plus-square-o\";i:1102;s:23:\"um-faicon-space-shuttle\";i:1103;s:15:\"um-faicon-slack\";i:1104;s:25:\"um-faicon-envelope-square\";i:1105;s:19:\"um-faicon-wordpress\";i:1106;s:16:\"um-faicon-openid\";i:1107;s:20:\"um-faicon-university\";i:1108;s:24:\"um-faicon-graduation-cap\";i:1109;s:15:\"um-faicon-yahoo\";i:1110;s:16:\"um-faicon-google\";i:1111;s:16:\"um-faicon-reddit\";i:1112;s:23:\"um-faicon-reddit-square\";i:1113;s:28:\"um-faicon-stumbleupon-circle\";i:1114;s:21:\"um-faicon-stumbleupon\";i:1115;s:19:\"um-faicon-delicious\";i:1116;s:14:\"um-faicon-digg\";i:1117;s:20:\"um-faicon-pied-piper\";i:1118;s:24:\"um-faicon-pied-piper-alt\";i:1119;s:16:\"um-faicon-drupal\";i:1120;s:16:\"um-faicon-joomla\";i:1121;s:18:\"um-faicon-language\";i:1122;s:13:\"um-faicon-fax\";i:1123;s:18:\"um-faicon-building\";i:1124;s:15:\"um-faicon-child\";i:1125;s:13:\"um-faicon-paw\";i:1126;s:15:\"um-faicon-spoon\";i:1127;s:14:\"um-faicon-cube\";i:1128;s:15:\"um-faicon-cubes\";i:1129;s:17:\"um-faicon-behance\";i:1130;s:24:\"um-faicon-behance-square\";i:1131;s:15:\"um-faicon-steam\";i:1132;s:22:\"um-faicon-steam-square\";i:1133;s:17:\"um-faicon-recycle\";i:1134;s:13:\"um-faicon-car\";i:1135;s:14:\"um-faicon-taxi\";i:1136;s:14:\"um-faicon-tree\";i:1137;s:17:\"um-faicon-spotify\";i:1138;s:20:\"um-faicon-deviantart\";i:1139;s:20:\"um-faicon-soundcloud\";i:1140;s:18:\"um-faicon-database\";i:1141;s:20:\"um-faicon-file-pdf-o\";i:1142;s:21:\"um-faicon-file-word-o\";i:1143;s:22:\"um-faicon-file-excel-o\";i:1144;s:27:\"um-faicon-file-powerpoint-o\";i:1145;s:22:\"um-faicon-file-image-o\";i:1146;s:24:\"um-faicon-file-archive-o\";i:1147;s:22:\"um-faicon-file-audio-o\";i:1148;s:22:\"um-faicon-file-video-o\";i:1149;s:21:\"um-faicon-file-code-o\";i:1150;s:14:\"um-faicon-vine\";i:1151;s:17:\"um-faicon-codepen\";i:1152;s:18:\"um-faicon-jsfiddle\";i:1153;s:19:\"um-faicon-life-ring\";i:1154;s:24:\"um-faicon-circle-o-notch\";i:1155;s:15:\"um-faicon-rebel\";i:1156;s:16:\"um-faicon-empire\";i:1157;s:20:\"um-faicon-git-square\";i:1158;s:13:\"um-faicon-git\";i:1159;s:21:\"um-faicon-hacker-news\";i:1160;s:23:\"um-faicon-tencent-weibo\";i:1161;s:12:\"um-faicon-qq\";i:1162;s:16:\"um-faicon-weixin\";i:1163;s:21:\"um-faicon-paper-plane\";i:1164;s:23:\"um-faicon-paper-plane-o\";i:1165;s:17:\"um-faicon-history\";i:1166;s:21:\"um-faicon-circle-thin\";i:1167;s:16:\"um-faicon-header\";i:1168;s:19:\"um-faicon-paragraph\";i:1169;s:17:\"um-faicon-sliders\";i:1170;s:19:\"um-faicon-share-alt\";i:1171;s:26:\"um-faicon-share-alt-square\";i:1172;s:14:\"um-faicon-bomb\";i:1173;s:18:\"um-faicon-futbol-o\";i:1174;s:13:\"um-faicon-tty\";i:1175;s:20:\"um-faicon-binoculars\";i:1176;s:14:\"um-faicon-plug\";i:1177;s:20:\"um-faicon-slideshare\";i:1178;s:16:\"um-faicon-twitch\";i:1179;s:14:\"um-faicon-yelp\";i:1180;s:21:\"um-faicon-newspaper-o\";i:1181;s:14:\"um-faicon-wifi\";i:1182;s:20:\"um-faicon-calculator\";i:1183;s:16:\"um-faicon-paypal\";i:1184;s:23:\"um-faicon-google-wallet\";i:1185;s:17:\"um-faicon-cc-visa\";i:1186;s:23:\"um-faicon-cc-mastercard\";i:1187;s:21:\"um-faicon-cc-discover\";i:1188;s:17:\"um-faicon-cc-amex\";i:1189;s:19:\"um-faicon-cc-paypal\";i:1190;s:19:\"um-faicon-cc-stripe\";i:1191;s:20:\"um-faicon-bell-slash\";i:1192;s:22:\"um-faicon-bell-slash-o\";i:1193;s:15:\"um-faicon-trash\";i:1194;s:19:\"um-faicon-copyright\";i:1195;s:12:\"um-faicon-at\";i:1196;s:20:\"um-faicon-eyedropper\";i:1197;s:21:\"um-faicon-paint-brush\";i:1198;s:23:\"um-faicon-birthday-cake\";i:1199;s:20:\"um-faicon-area-chart\";i:1200;s:19:\"um-faicon-pie-chart\";i:1201;s:20:\"um-faicon-line-chart\";i:1202;s:16:\"um-faicon-lastfm\";i:1203;s:23:\"um-faicon-lastfm-square\";i:1204;s:20:\"um-faicon-toggle-off\";i:1205;s:19:\"um-faicon-toggle-on\";i:1206;s:17:\"um-faicon-bicycle\";i:1207;s:13:\"um-faicon-bus\";i:1208;s:17:\"um-faicon-ioxhost\";i:1209;s:19:\"um-faicon-angellist\";i:1210;s:12:\"um-faicon-cc\";i:1211;s:13:\"um-faicon-ils\";i:1212;s:18:\"um-faicon-meanpath\";i:1213;s:14:\"um-faicon-spin\";i:1214;s:14:\"um-faicon-spin\";i:1215;s:14:\"um-faicon-spin\";i:1216;s:14:\"um-faicon-spin\";i:1217;s:14:\"um-faicon-spin\";}", "yes");
INSERT INTO `wp_options` VALUES("203", "widget_um_search_widget", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("204", "um_cached_role_admin", "a:15:{s:4:\"core\";s:5:\"admin\";s:18:\"can_access_wpadmin\";i:1;s:20:\"can_not_see_adminbar\";i:0;s:17:\"can_edit_everyone\";i:1;s:19:\"can_delete_everyone\";i:1;s:16:\"can_edit_profile\";i:1;s:18:\"can_delete_profile\";i:1;s:12:\"can_view_all\";i:1;s:24:\"can_make_private_profile\";i:1;s:26:\"can_access_private_profile\";i:1;s:16:\"default_homepage\";i:1;s:6:\"status\";s:8:\"approved\";s:16:\"auto_approve_act\";s:16:\"redirect_profile\";s:11:\"after_login\";s:14:\"redirect_admin\";s:12:\"after_logout\";s:13:\"redirect_home\";}", "yes");
INSERT INTO `wp_options` VALUES("206", "__ultimatemember_sitekey", "localhost:8000-9x3FgZvUJ1Xz9TM4tKck", "yes");
INSERT INTO `wp_options` VALUES("207", "um_is_installed", "1", "yes");
INSERT INTO `wp_options` VALUES("208", "um_core_forms", "a:3:{i:51;i:51;i:52;i:52;i:53;i:53;}", "yes");
INSERT INTO `wp_options` VALUES("209", "um_core_directories", "a:1:{i:54;i:54;}", "yes");
INSERT INTO `wp_options` VALUES("210", "um_core_pages", "a:7:{s:4:\"user\";s:0:\"\";s:5:\"login\";s:2:\"26\";s:8:\"register\";s:2:\"24\";s:7:\"members\";s:0:\"\";s:6:\"logout\";s:0:\"\";s:7:\"account\";s:0:\"\";s:14:\"password-reset\";s:0:\"\";}", "yes");
INSERT INTO `wp_options` VALUES("211", "um_options", "a:201:{s:8:\"last_tab\";s:0:\"\";s:9:\"core_user\";s:0:\"\";s:12:\"core_account\";s:0:\"\";s:12:\"core_members\";s:0:\"\";s:13:\"core_register\";s:2:\"24\";s:10:\"core_login\";s:2:\"26\";s:11:\"core_logout\";s:0:\"\";s:19:\"core_password-reset\";s:0:\"\";s:12:\"default_role\";s:6:\"member\";s:14:\"permalink_base\";s:10:\"user_login\";s:12:\"display_name\";s:9:\"full_name\";s:18:\"display_name_field\";s:0:\"\";s:29:\"force_display_name_capitlized\";s:1:\"1\";s:15:\"author_redirect\";s:1:\"1\";s:12:\"members_page\";s:1:\"1\";s:13:\"use_gravatars\";s:1:\"0\";s:37:\"use_um_gravatar_default_builtin_image\";s:7:\"default\";s:29:\"use_um_gravatar_default_image\";s:1:\"0\";s:24:\"reset_require_strongpass\";s:1:\"0\";s:33:\"editable_primary_email_in_profile\";s:1:\"0\";s:20:\"account_tab_password\";s:1:\"1\";s:19:\"account_tab_privacy\";s:1:\"1\";s:25:\"account_tab_notifications\";s:1:\"1\";s:18:\"account_tab_delete\";s:1:\"1\";s:19:\"delete_account_text\";s:150:\"Are you sure you want to delete your account? This will erase all of your account data from the site. To delete your account enter your password below\";s:12:\"account_name\";s:1:\"1\";s:20:\"account_name_disable\";s:1:\"0\";s:20:\"account_name_require\";s:1:\"1\";s:13:\"account_email\";s:1:\"1\";s:25:\"account_hide_in_directory\";s:1:\"1\";s:26:\"account_require_strongpass\";s:1:\"0\";s:9:\"panic_key\";s:10:\"BR2VqGO0C1\";s:10:\"accessible\";s:1:\"0\";s:15:\"access_redirect\";s:0:\"\";s:20:\"home_page_accessible\";s:1:\"1\";s:24:\"category_page_accessible\";s:1:\"1\";s:13:\"wpadmin_login\";s:1:\"1\";s:25:\"deny_admin_frontend_login\";s:1:\"0\";s:22:\"wpadmin_login_redirect\";s:13:\"um_login_page\";s:26:\"wpadmin_login_redirect_url\";s:0:\"\";s:16:\"wpadmin_register\";s:1:\"1\";s:25:\"wpadmin_register_redirect\";s:16:\"um_register_page\";s:29:\"wpadmin_register_redirect_url\";s:0:\"\";s:24:\"access_widget_admin_only\";s:1:\"1\";s:27:\"enable_reset_password_limit\";s:1:\"1\";s:27:\"reset_password_limit_number\";s:1:\"3\";s:34:\"disable_admin_reset_password_limit\";s:1:\"0\";s:17:\"wpadmin_allow_ips\";s:0:\"\";s:11:\"blocked_ips\";s:0:\"\";s:14:\"blocked_emails\";s:0:\"\";s:13:\"blocked_words\";s:47:\"admin
administrator
webmaster
support
staff\";s:9:\"mail_from\";s:11:\"Coffee Hall\";s:14:\"mail_from_addr\";s:28:\"ebarber5969@conestogac.on.ca\";s:10:\"email_html\";s:1:\"0\";s:16:\"welcome_email_on\";s:1:\"1\";s:17:\"welcome_email_sub\";s:23:\"Welcome to {site_name}!\";s:13:\"welcome_email\";s:306:\"Hi {display_name},

Thank you for signing up with {site_name}! Your account is now active.

To login please visit the following url:

{login_url}

Your account e-mail: {email}
Your account username: {username}

If you have any problems, please contact us at {admin_email}

Thanks,
{site_name}\";s:18:\"checkmail_email_on\";s:1:\"1\";s:19:\"checkmail_email_sub\";s:28:\"Please activate your account\";s:15:\"checkmail_email\";s:266:\"Hi {display_name},

Thank you for signing up with {site_name}! To activate your account, please click the link below to confirm your email address:

{account_activation_link}

If you have any problems, please contact us at {admin_email}

Thanks,
{site_name}\";s:16:\"pending_email_on\";s:1:\"1\";s:17:\"pending_email_sub\";s:30:\"Your account is pending review\";s:13:\"pending_email\";s:272:\"Hi {display_name},

Thank you for signing up with {site_name}! Your account is currently being reviewed by a member of our team.

Please allow us some time to process your request.

If you have any problems, please contact us at {admin_email}

Thanks,
{site_name}\";s:17:\"approved_email_on\";s:1:\"1\";s:18:\"approved_email_sub\";s:41:\"Your account at {site_name} is now active\";s:14:\"approved_email\";s:378:\"Hi {display_name},

Thank you for signing up with {site_name}! Your account has been approved and is now active.

To login please visit the following url:

{login_url}

Your account e-mail: {email}
Your account username: {username}
Set your account password: {password_reset_link}

If you have any problems, please contact us at {admin_email}

Thanks,
{site_name}\";s:17:\"rejected_email_on\";s:1:\"1\";s:18:\"rejected_email_sub\";s:30:\"Your account has been rejected\";s:14:\"rejected_email\";s:260:\"Hi {display_name},

Thank you for applying for membership to {site_name}! We have reviewed your information and unfortunately we are unable to accept you as a member at this moment.

Please feel free to apply again at a future date.

Thanks,
{site_name}\";s:17:\"inactive_email_on\";s:1:\"1\";s:18:\"inactive_email_sub\";s:33:\"Your account has been deactivated\";s:14:\"inactive_email\";s:222:\"Hi {display_name},

This is an automated email to let you know your {site_name} account has been deactivated.

If you would like your account to be reactivated please contact us at {admin_email}

Thanks,
{site_name}\";s:17:\"deletion_email_on\";s:1:\"1\";s:18:\"deletion_email_sub\";s:29:\"Your account has been deleted\";s:14:\"deletion_email\";s:332:\"Hi {display_name},

This is an automated email to let you know your {site_name} account has been deleted. All of your personal information has been permanently deleted and you will no longer be able to login to {site_name}.

If your account has been deleted by accident please contact us at {admin_email}

Thanks,
{site_name}\";s:16:\"resetpw_email_on\";s:1:\"1\";s:17:\"resetpw_email_sub\";s:19:\"Reset your password\";s:13:\"resetpw_email\";s:266:\"Hi {display_name},

We received a request to reset the password for your account. If you made this request, click the link below to change your password:

{password_reset_link}

If you didn\'t make this request, you can ignore this email

Thanks,
{site_name}\";s:18:\"changedpw_email_on\";s:1:\"1\";s:19:\"changedpw_email_sub\";s:42:\"Your {site_name} password has been changed\";s:15:\"changedpw_email\";s:279:\"Hi {display_name},

You recently changed the password associated with your {site_name} account.

If you did not make this change and believe your {site_name} account has been compromised, please contact us at the following email address: {admin_email}

Thanks,
{site_name}\";s:11:\"admin_email\";s:28:\"ebarber5969@conestogac.on.ca\";s:24:\"notification_new_user_on\";s:1:\"1\";s:25:\"notification_new_user_sub\";s:30:\"[{site_name}] New user account\";s:21:\"notification_new_user\";s:187:\"{display_name} has just created an account on {site_name}. To view their profile click here:

{user_profile_link}

Here is the submitted registration form:

{submitted_registration}\";s:22:\"notification_review_on\";s:1:\"0\";s:23:\"notification_review_sub\";s:38:\"[{site_name}] New user awaiting review\";s:19:\"notification_review\";s:245:\"{display_name} has just applied for membership to {site_name} and is waiting to be reviewed.

To review this member please click the following link:

{user_profile_link}

Here is the submitted registration form:

{submitted_registration}\";s:24:\"notification_deletion_on\";s:1:\"0\";s:25:\"notification_deletion_sub\";s:29:\"[{site_name}] Account deleted\";s:21:\"notification_deletion\";s:58:\"{display_name} has just deleted their {site_name} account.\";s:22:\"profile_photo_max_size\";s:0:\"\";s:20:\"cover_photo_max_size\";s:0:\"\";s:17:\"photo_thumb_sizes\";a:3:{i:0;s:2:\"40\";i:1;s:2:\"80\";i:2;s:3:\"190\";}s:17:\"cover_thumb_sizes\";a:2:{i:0;s:3:\"300\";i:1;s:3:\"600\";}s:17:\"image_compression\";s:2:\"60\";s:15:\"image_max_width\";s:4:\"1000\";s:15:\"cover_min_width\";s:4:\"1000\";s:13:\"profile_title\";s:28:\"{display_name} | Coffee Hall\";s:12:\"profile_desc\";s:83:\"{display_name} is on {site_name}. Join {site_name} to view {display_name}\'s profile\";s:18:\"directory_template\";s:7:\"members\";s:12:\"active_color\";s:7:\"#3ba1da\";s:15:\"secondary_color\";s:7:\"#44b0ec\";s:17:\"primary_btn_color\";s:7:\"#3ba1da\";s:17:\"primary_btn_hover\";s:7:\"#44b0ec\";s:16:\"primary_btn_text\";s:7:\"#ffffff\";s:19:\"secondary_btn_color\";s:7:\"#eeeeee\";s:19:\"secondary_btn_hover\";s:7:\"#e5e5e5\";s:18:\"secondary_btn_text\";s:7:\"#666666\";s:14:\"help_tip_color\";s:7:\"#cccccc\";s:16:\"form_field_label\";s:7:\"#555555\";s:11:\"form_border\";s:14:\"2px solid #ddd\";s:17:\"form_border_hover\";s:14:\"2px solid #bbb\";s:13:\"form_bg_color\";s:7:\"#ffffff\";s:19:\"form_bg_color_focus\";s:7:\"#ffffff\";s:15:\"form_text_color\";s:7:\"#666666\";s:16:\"form_placeholder\";s:7:\"#aaaaaa\";s:15:\"form_icon_color\";s:7:\"#aaaaaa\";s:13:\"form_asterisk\";s:1:\"0\";s:19:\"form_asterisk_color\";s:7:\"#aaaaaa\";s:16:\"profile_template\";s:7:\"profile\";s:17:\"profile_max_width\";s:6:\"1000px\";s:22:\"profile_area_max_width\";s:5:\"600px\";s:13:\"profile_align\";s:6:\"center\";s:13:\"profile_icons\";s:5:\"label\";s:24:\"profile_primary_btn_word\";s:14:\"Update Profile\";s:21:\"profile_secondary_btn\";s:1:\"1\";s:26:\"profile_secondary_btn_word\";s:6:\"Cancel\";s:12:\"profile_role\";s:1:\"0\";s:15:\"profile_main_bg\";s:0:\"\";s:17:\"profile_header_bg\";s:0:\"\";s:14:\"default_avatar\";a:5:{s:3:\"url\";s:86:\"http://localhost:8000/wp-content/plugins/ultimate-member/assets/img/default_avatar.jpg\";s:2:\"id\";s:0:\"\";s:6:\"height\";s:0:\"\";s:5:\"width\";s:0:\"\";s:9:\"thumbnail\";s:0:\"\";}s:13:\"default_cover\";a:5:{s:3:\"url\";s:0:\"\";s:2:\"id\";s:0:\"\";s:6:\"height\";s:0:\"\";s:5:\"width\";s:0:\"\";s:9:\"thumbnail\";s:0:\"\";}s:17:\"profile_photosize\";s:5:\"190px\";s:19:\"profile_photocorner\";s:1:\"1\";s:21:\"profile_cover_enabled\";s:1:\"1\";s:19:\"profile_cover_ratio\";s:5:\"2.7:1\";s:21:\"profile_show_metaicon\";s:1:\"0\";s:19:\"profile_header_text\";s:7:\"#999999\";s:25:\"profile_header_link_color\";s:7:\"#555555\";s:26:\"profile_header_link_hcolor\";s:7:\"#444444\";s:25:\"profile_header_icon_color\";s:7:\"#aaaaaa\";s:26:\"profile_header_icon_hcolor\";s:7:\"#3ba1da\";s:17:\"profile_show_name\";s:1:\"1\";s:25:\"profile_show_social_links\";s:1:\"0\";s:16:\"profile_show_bio\";s:1:\"1\";s:21:\"profile_show_html_bio\";s:0:\"\";s:20:\"profile_bio_maxchars\";s:3:\"180\";s:19:\"profile_header_menu\";s:2:\"bc\";s:18:\"profile_empty_text\";s:1:\"1\";s:22:\"profile_empty_text_emo\";s:1:\"1\";s:12:\"profile_menu\";s:1:\"1\";s:16:\"profile_tab_main\";s:1:\"1\";s:24:\"profile_tab_main_privacy\";s:1:\"0\";s:17:\"profile_tab_posts\";s:1:\"1\";s:25:\"profile_tab_posts_privacy\";s:1:\"0\";s:20:\"profile_tab_comments\";s:1:\"1\";s:28:\"profile_tab_comments_privacy\";s:1:\"0\";s:24:\"profile_menu_default_tab\";s:4:\"main\";s:18:\"profile_menu_icons\";s:1:\"1\";s:17:\"register_template\";s:8:\"register\";s:18:\"register_max_width\";s:5:\"450px\";s:14:\"register_align\";s:6:\"center\";s:14:\"register_icons\";s:5:\"label\";s:25:\"register_primary_btn_word\";s:8:\"Register\";s:22:\"register_secondary_btn\";s:1:\"0\";s:27:\"register_secondary_btn_word\";s:5:\"Login\";s:26:\"register_secondary_btn_url\";s:0:\"\";s:13:\"register_role\";s:1:\"0\";s:14:\"login_template\";s:5:\"login\";s:15:\"login_max_width\";s:5:\"450px\";s:11:\"login_align\";s:6:\"center\";s:11:\"login_icons\";s:5:\"label\";s:22:\"login_primary_btn_word\";s:5:\"Login\";s:19:\"login_secondary_btn\";s:1:\"1\";s:24:\"login_secondary_btn_word\";s:8:\"Register\";s:23:\"login_secondary_btn_url\";s:0:\"\";s:22:\"login_forgot_pass_link\";s:1:\"1\";s:21:\"login_show_rememberme\";s:1:\"1\";s:28:\"um_profile_object_cache_stop\";s:1:\"1\";s:13:\"um_flush_stop\";s:1:\"0\";s:29:\"um_generate_slug_in_directory\";s:1:\"0\";s:18:\"current_url_method\";s:11:\"SERVER_NAME\";s:22:\"um_port_forwarding_url\";s:1:\"0\";s:21:\"um_force_utf8_strings\";s:1:\"0\";s:14:\"enable_timebot\";s:1:\"1\";s:14:\"disable_minify\";s:1:\"0\";s:12:\"disable_menu\";s:1:\"0\";s:19:\"js_css_exlcude_home\";s:1:\"0\";s:17:\"enable_custom_css\";s:1:\"0\";s:14:\"allow_tracking\";s:1:\"0\";s:24:\"addon_bp_avatar_transfer\";s:0:\"\";s:23:\"addon_gravatar_transfer\";s:0:\"\";s:27:\"addon_generate_random_users\";s:0:\"\";s:18:\"addon_install_info\";s:0:\"\";s:19:\"access_exclude_uris\";a:0:{}s:22:\"profile_tab_main_roles\";s:0:\"\";s:23:\"profile_tab_posts_roles\";s:0:\"\";s:26:\"profile_tab_comments_roles\";s:0:\"\";s:14:\"js_css_exclude\";a:0:{}s:14:\"js_css_include\";a:0:{}}", "yes");
INSERT INTO `wp_options` VALUES("212", "um_first_setup_roles", "1", "yes");
INSERT INTO `wp_options` VALUES("213", "um_hashed_passwords_fix", "1", "yes");
INSERT INTO `wp_options` VALUES("215", "redux_version_upgraded_from", "3.6.2", "yes");
INSERT INTO `wp_options` VALUES("216", "_transient_timeout__redux_activation_redirect", "1512487798", "no");
INSERT INTO `wp_options` VALUES("217", "_transient__redux_activation_redirect", "1", "no");
INSERT INTO `wp_options` VALUES("218", "um_options-transients", "a:3:{s:14:\"changed_values\";a:2:{s:13:\"core_register\";s:0:\"\";s:10:\"core_login\";s:0:\"\";}s:9:\"last_save\";i:1512487710;s:13:\"last_compiler\";i:1512487677;}", "yes");
INSERT INTO `wp_options` VALUES("221", "um_tracking_notice", "1", "yes");
INSERT INTO `wp_options` VALUES("226", "WPLANG", "en_CA", "yes");
INSERT INTO `wp_options` VALUES("227", "new_admin_email", "ebarber5969@conestogac.on.ca", "yes");
INSERT INTO `wp_options` VALUES("234", "um_existing_rows_53", "a:1:{i:0;s:9:\"_um_row_1\";}", "yes");
INSERT INTO `wp_options` VALUES("235", "um_form_rowdata_53", "a:1:{s:9:\"_um_row_1\";a:4:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";}}", "yes");
INSERT INTO `wp_options` VALUES("238", "um_existing_rows_71", "a:1:{i:0;s:9:\"_um_row_1\";}", "yes");
INSERT INTO `wp_options` VALUES("239", "um_form_rowdata_71", "a:1:{s:9:\"_um_row_1\";a:5:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";s:6:\"origin\";s:9:\"_um_row_1\";}}", "yes");
INSERT INTO `wp_options` VALUES("274", "um_cached_role_member", "a:16:{s:4:\"role\";s:6:\"member\";s:4:\"core\";s:6:\"member\";s:18:\"can_access_wpadmin\";s:1:\"0\";s:20:\"can_not_see_adminbar\";s:1:\"1\";s:17:\"can_edit_everyone\";s:1:\"0\";s:19:\"can_delete_everyone\";s:1:\"0\";s:16:\"can_edit_profile\";s:1:\"1\";s:18:\"can_delete_profile\";s:1:\"1\";s:12:\"can_view_all\";s:1:\"1\";s:24:\"can_make_private_profile\";s:1:\"0\";s:26:\"can_access_private_profile\";s:1:\"0\";s:16:\"default_homepage\";s:1:\"1\";s:6:\"status\";s:8:\"approved\";s:16:\"auto_approve_act\";s:16:\"redirect_profile\";s:11:\"after_login\";s:16:\"redirect_profile\";s:12:\"after_logout\";s:13:\"redirect_home\";}", "yes");
INSERT INTO `wp_options` VALUES("280", "um_existing_rows_74", "a:1:{i:0;s:9:\"_um_row_1\";}", "yes");
INSERT INTO `wp_options` VALUES("281", "um_form_rowdata_74", "a:1:{s:9:\"_um_row_1\";a:5:{s:4:\"type\";s:3:\"row\";s:2:\"id\";s:9:\"_um_row_1\";s:8:\"sub_rows\";s:1:\"1\";s:4:\"cols\";s:1:\"1\";s:6:\"origin\";s:9:\"_um_row_1\";}}", "yes");
INSERT INTO `wp_options` VALUES("327", "_transient_timeout_feed_2b16a4f9a2b7110ce37a7c1a0e3bbb94", "1512530936", "no");
INSERT INTO `wp_options` VALUES("328", "_transient_feed_2b16a4f9a2b7110ce37a7c1a0e3bbb94", "a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:52:\"
	
	
	
	
	
	
	
	
	

 
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:8:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Blog – Ultimate Member\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://ultimatemember.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"A Free Community & User Profile WordPress Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Nov 2017 03:32:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"https://wordpress.org/?v=4.8.4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"image\";a:1:{i:0;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:3:\"url\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://ultimatemember.com/wp-content/uploads/2017/06/cropped-favicon-32x32.png\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Blog – Ultimate Member\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://ultimatemember.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:5:\"width\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"32\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:6:\"height\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"32\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Product Update: October\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://ultimatemember.com/product-update-october/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://ultimatemember.com/product-update-october/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Nov 2017 02:12:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=384708\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:571:\"<p>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in October. What&#8217;s new 🚀 Ultimate Member 2.0 After over a month in beta, UM2.0 is officially here. As this is a significant update to the plugin&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-october/\">Product Update: October</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2924:\"<p><em>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in October.</em></p>
<h3>What&#8217;s new <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f680.png\" alt=\"🚀\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>Ultimate Member 2.0</h4>
<p>After over a month in beta, UM2.0 is officially here. As this is a significant update to the plugin the release of 2.0 will happen in two stages. The first stage is manual updating of the plugin. This will allow for more people to update to 2.0 and give feedback on it before an update is pushed to the 70,000+ websites that use Ultimate Member.</p>
<p>After a period of manual updating to 2.0, we will then release the plugin on the repo so that automatic updates are made available to all websites. You will not receive an update notice if you have already updated to 2.0 manually.</p>
<p>Because of the significant changes made to the code base in UM2.0, all extensions need to be updated to their 2.0 versions as well to work with core 2.0.</p>
<p>For instructions on updating to 2.0 fore core plugin and extensions please read this <a href=\"http://docs.ultimatemember.com/article/262-manually-updating-to-2-0\">doc</a></p>
<p>Before updating to 2.0, make sure you make a full site backup which can be restored in case of any issues. If you have any issues after updating to 2.0, please submit a support ticket so we can help you out.</p>
<h3>What&#8217;s next <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f52e.png\" alt=\"🔮\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>Member directory improvements</h4>
<p>After 2.0 release, the next update will see improvements to member directories with:</p>
<ul>
<li>List display for directories</li>
<li>Directories now use ajax (no reloading of page)</li>
<li>General search feature</li>
<li>Filters appearing in reveal section</li>
<li>Front-end sorting e.g New users, oldest users, first name etc</li>
</ul>
<h4>Groups extension</h4>
<p>The groups extension has mostly been finished and the extension is now being reviewed, checked and tweaked. We will release this to beta once it is ready for testing by users.</p>
<h4>User location extension</h4>
<p>As well as releasing the groups extension shortly, we have also been working on a user location extension utilising Google Places API. This extension will allow users to add their address/location on registration/profile and then their location will appear on a google map on the directory. Users will then be able to search the directory for users by location.</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-october/\">Product Update: October</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://ultimatemember.com/product-update-october/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Product Update: September\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://ultimatemember.com/product-update-september/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://ultimatemember.com/product-update-september/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 08 Oct 2017 09:44:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Product\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=362111\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:604:\"<p>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in September. What&#8217;s new 🚀 Private Content Extension September saw the release of the Private Content extension. With the private content extension you can provide logged in&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-september/\">Product Update: September</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2715:\"<p><em>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in September.</em></p>
<h3>What&#8217;s new <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f680.png\" alt=\"🚀\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>Private Content Extension</h4>
<p>September saw the release of the <a href=\"https://ultimatemember.com/extensions/private-content/\">Private Content</a> extension. With the private content extension you can provide logged in users with content that only they can access and view.</p>
<p><img class=\"alignnone size-full wp-image-346284\" src=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin.png\" alt=\"\" width=\"1000\" height=\"454\" srcset=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin.png 1000w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-300x136.png 300w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-768x349.png 768w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-265x120.png 265w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-530x241.png 530w\" sizes=\"(max-width: 1000px) 100vw, 1000px\" /></p>
<h4>UM2.0 Beta Release</h4>
<p>We also released the beta for 2.0 and extensions. We&#8217;ve been fixing issues and making improvements based on the feedback we have received for it so far.</p>
<h3>What&#8217;s next <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f52e.png\" alt=\"🔮\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>Member directory improvements</h4>
<p>Whilst UM2.0 is in beta, we have started working on improvements to member directories. This following improvement/changes have been made to directories:</p>
<ul>
<li>List display for directories</li>
<li>Directories now use ajax (no reloading of page)</li>
<li>General search feature</li>
<li>Filters appearing in reveal section</li>
<li>Front-end sorting e.g New users, oldest users, first name etc</li>
</ul>
<h4>UM2.0 release</h4>
<p>UM2.0 will be released once the beta period ends. We hope to have UM2.0 released within the next 1-2 weeks.</p>
<h4>Groups extension</h4>
<p>Work is continuing on the groups extension and we hope to release this shortly after UM2.0 is released.</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-september/\">Product Update: September</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ultimatemember.com/product-update-september/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"New extension: Private Content\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ultimatemember.com/new-extension-private-content/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://ultimatemember.com/new-extension-private-content/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Sep 2017 13:47:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Product\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=346985\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:547:\"<p>Do you want to show unique private content to each user when they are logged in to your site? Now you can with our latest extension Private Content. The private content extension provides each user with their own content area in the wp-admin which you can use to provide each user with customized content on&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/new-extension-private-content/\">New extension: Private Content</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5317:\"<p>Do you want to show unique private content to each user when they are logged in to your site? Now you can with our latest extension <a href=\"https://ultimatemember.com/extensions/private-content/\">Private Content</a>.</p>
<p>The private content extension provides each user with their own content area in the wp-admin which you can use to provide each user with customized content on their user profile (or anywhere on your site using a shortcode).</p>
<h3 style=\"text-align: center;\">How does it work?</h3>
<p>The extension adds a private content area for each user. You can access this by going to your wp-admin &gt; all users page and hovering over a user and clicking the private content link.</p>
<div id=\"attachment_346232\" style=\"width: 1210px\" class=\"wp-caption alignnone\"><img class=\"size-full wp-image-346232\" src=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users.png\" alt=\"\" width=\"1200\" height=\"617\" srcset=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users.png 1200w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users-300x154.png 300w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users-768x395.png 768w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users-1024x527.png 1024w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users-265x136.png 265w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-all-users-530x273.png 530w\" sizes=\"(max-width: 1200px) 100vw, 1200px\" /><p class=\"wp-caption-text\">Admin can create private content for each user via the all users page in wp-admin</p></div>
<p>You will then be taking to the page where you can add content that only that particular user can view.</p>
<p><img class=\"alignnone size-full wp-image-346284\" src=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin.png\" alt=\"\" width=\"1000\" height=\"454\" srcset=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin.png 1000w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-300x136.png 300w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-768x349.png 768w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-265x120.png 265w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-user-admin-530x241.png 530w\" sizes=\"(max-width: 1000px) 100vw, 1000px\" /></p>
<p>Once you&#8217;ve added private content for the user, the user will then be able to see this private content by going to their profile &gt; private content tab.</p>
<p>This tab is optional and if you dont want to include it on the profile it can be disabled in the settings. You can also give the profile tab a unique name and icon from settings.</p>
<p><img class=\"alignnone size-full wp-image-346291\" src=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-profile.png\" alt=\"\" width=\"800\" height=\"439\" srcset=\"https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-profile.png 800w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-profile-300x165.png 300w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-profile-768x421.png 768w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-profile-265x145.png 265w, https://ultimatemember.com/wp-content/uploads/edd/2017/09/private-content-profile-530x291.png 530w\" sizes=\"(max-width: 800px) 100vw, 800px\" /></p>
<p>The tab will only appear in the profile menu for a user if you have added private content for them. If their private content page in wp-admin is empty then no profile tab will show.</p>
<p>If you dont want the private content to be shown on the profile, you can have users view it anywhere on your site using the shortcode: [um_private_content]</p>
<h3 style=\"text-align: center;\">What can I use this for?</h3>
<p>The private content extension is perfect for when you need to provide private information to users which varies for each user.</p>
<p>This could be a workout routine, results from a test, a diet plan, job feedback or anything else that requires personalised information on a user to user basis.</p>
<h3 style=\"text-align: center;\">How to get the extension?</h3>
<p>The extension can be bought <a href=\"https://ultimatemember.com/extensions/private-content/\">individually</a> or as part of our <a href=\"https://ultimatemember.com/core-extensions-bundle/\">bundle</a> package. If you already have an active license for bundle you will be able to download the extension from your <a href=\"https://ultimatemember.com/account/\">account</a> page &gt; downloads tab.</p>
<h3 style=\"text-align: center;\">Let us know your thoughts</h3>
<p>We&#8217;re excited to see how people implement this into their sites. So if you install private content on your site, let us and everyone else know how you are using the extension.</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/new-extension-private-content/\">New extension: Private Content</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://ultimatemember.com/new-extension-private-content/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Product Update: August\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://ultimatemember.com/product-update-august/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://ultimatemember.com/product-update-august/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Sep 2017 02:30:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=341945\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:583:\"<p>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in August. What&#8217;s new 🚀 UM2.0 beta After several months of development, UM2.0 is now available for beta testing. It can be downloaded directly here using this&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-august/\">Product Update: August</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8416:\"<p><em>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in August.</em></p>
<h3 style=\"text-align: center;\">What&#8217;s new <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f680.png\" alt=\"🚀\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>UM2.0 beta</h4>
<p>After several months of development, UM2.0 is now available for beta testing. It can be downloaded directly here using this <a href=\"https://ultimatemember.com/wp-content/uploads/2017/09/ultimate-member.zip\">link</a>.</p>
<p>A lot has been changed in UM2.0, so if you want to test UM2.0 beta, please <strong>do not install on your live site</strong>.</p>
<p>If you want to test it, please create a clone of your existing site or create a new install of WordPress to test it out.</p>
<p>UM2.0 should only be installed on your live site once it has been officially released on the wp.org repo.</p>
<p>If you find an issue with UM2.0 please create an issue on Github for it.</p>
<h4>Main changes</h4>
<p>The main focus for UM2.0 has been to make improvements to Ultimate Member for the long term future of the plugin.</p>
<p>The biggest changes to the plugin have been removing UM roles from the plugin and using WP native roles and switching from using the redux framework for settings to using native WP settings.</p>
<p>Improvements have also been made to content restriction and emails.</p>
<p>There is a lot more we plan on improving in the future and the initial release of UM2.0 has been  focused on providing the solid platform for new functionality/extensions to be added to the plugin.</p>
<h4>Extensions 2.0 beta</h4>
<p>We&#8217;ve also created beta versions for all UM extensions which are compatible with UM2.0. To download the beta versions of the extensions please login to your account page and go to the downloads tab to download the beta versions of the extensions. You will need to make sure the license keys for each extension are activated and linked to a site to be able to see the beta versions.</p>
<p>For the free extensions you can download the beta versions here: <a href=\"https://ultimatemember.com/wp-content/uploads/2017/09/um-terms-conditions-beta.zip\">Terms &amp; Conditions</a>, <a href=\"https://ultimatemember.com/wp-content/uploads/2017/09/um-recaptcha-beta.zip\">Google reCAPTCHA</a>, <a href=\"https://ultimatemember.com/wp-content/uploads/2017/09/um-online-beta.zip\">Online Users</a></p>
<p>If you find an issue with a 2.0 extension please submit a ticket via our site and mention in the ticket it is with the 2.0 version.</p>
<h4>Installing UM2.0 and extensions</h4>
<p>If you&#8217;re installing UM2.0 and 2.0 extensions on a clean install of WP, you can install the plugins by simply going to the add new plugins page and clicking the upload plugin link then selecting the plugin from your computer.</p>
<p>If you&#8217;ve created a clone of your existing site and want to update the plugin/extensions to 2.0, you should install this <a href=\"https://wordpress.org/plugins/easy-theme-and-plugin-upgrades/\">plugin</a> on your site first.</p>
<p>This will allow you to manually update existing plugins using the same upload plugin method.</p>
<p>Before installing UM2.0 you should take a full backup of your site/database so you can restore your site if needed. You can use a backup/restore plugin if your hosting does not offer backup/restore services.</p>
<p>If you need to rollback to previous version of core plugin, you can install this <a href=\"https://wordpress.org/plugins/wp-rollback/\">plugin</a>, which makes it easy to rollback to a previous version of the plugin.</p>
<h4>2.0 Changelog</h4>
<p>For Users:</p>
<ul>
<li>added activation dependencies for extensions;</li>
<li>added Licenses checking and changed Licenses page;</li>
<li>added uninstall.php file for delete permanently all UM settings;</li>
<li>added ability to register users without WP Registration enabled;</li>
<li>Account page shortcodes for each tab content;</li>
<li>changed UM Option View (deprecated/added options);</li>
<li>changed UM Roles, optimized for WP native logic;</li>
<li>changed backend forms/fields to WP native styles;</li>
<li>changed Content Restriction feature for posts, taxonomies, menus;</li>
<li>changed Email Notifications settings and using templates logic;</li>
<li>deprecated Redux Framework;</li>
<li>deprecated old unusable options</li>
<li>deprecated old unusable forms metadata;</li>
<li>deprecated old unusable member directories metadata;</li>
<li>deprecated old unusable user roles metadata;</li>
<li>optimized registration/upgrade profile process (some hook deprecated);</li>
<li>optimized some code parts, deprecated some functions;</li>
<li>fixed avatars on some SSL installs;</li>
<li>fixed some vulnerabilities;</li>
<li>fixed integrations with core/extensions;</li>
<li>fixed &#8220;Edit Profile&#8221; button at members directory;</li>
<li>fixed conditional logic PHP validation and JS validation (for IE,Edge browsers);</li>
<li>updated FontAwesome library;</li>
<li>removed addons to separate extensions;</li>
</ul>
<p>For Developers:</p>
<ul>
<li>new code structure, optimized for next development;</li>
<li>created spl_autoloader for remove includes;</li>
<li>UM classes with namespaces;</li>
<li>deprecated global $ultimatemember; variable (use UM() instead);</li>
<li>new ajax handlers in separate classes (by objects);</li>
</ul>
<p>Deprecated hooks:</p>
<ul>
<li>um_new_user_registration_plain</li>
<li>um_user_registration_extra_hook</li>
<li>um_add_user_frontend</li>
<li>um_post_registration_global_hook</li>
<li>um_admin_extend_directory_options_general (was action&#8230;will be filter)</li>
<li>um_account_tab__{$tab_id}</li>
<li>um_account_display_tabs_hook</li>
<li>um_account_user_photo_hook__mobile</li>
<li>um_account_user_photo_hook</li>
<li>um_after_follow_button_profile</li>
<li>um_after_new_user_register will be &#8220;um_user_register&#8221;</li>
<li>um_user_registration</li>
<li>um_before_new_user_register</li>
<li>um_post_registration will be &#8220;um_registration_complete&#8221;</li>
<li>um_post_registration_listener</li>
<li>&#8220;um_post_registration_save&#8221; will be &#8220;um_registration_set_extra_data&#8221;</li>
<li>um_user_profile_extra_hook</li>
</ul>
<p>UM Extensions General:</p>
<ul>
<li>created Plugin Updater for getting updates and license details from Shop;</li>
<li>removed old EDD updates class;</li>
<li>added uninstall.php file for delete permanently UM extensions settings;</li>
<li>textdomain fixes;</li>
</ul>
<p>UM bbPress:</p>
<ul>
<li>fixed the calculation of all subscriptions;</li>
</ul>
<p>UM Friends:</p>
<ul>
<li>fixed sorting members directory by &#8220;most friends&#8221; and &#8220;least friends&#8221;;</li>
<li>fixed allow admin to edit friends only profile;</li>
</ul>
<p>UM Recatpcha:</p>
<ul>
<li>fixed initialization two captcha v2 in single page;</li>
</ul>
<p>UM Reviews:</p>
<ul>
<li>fixed display of stars in Member Directories;</li>
<li>fixed when creating the review, two Ajax requests were sent in Firefox;</li>
</ul>
<p>UM Social Activity:</p>
<ul>
<li>fixed Chinese and Russian Hashtags working;</li>
<li>added GravityForms add form/submit form activities;</li>
</ul>
<p>UM Social Login:</p>
<ul>
<li>fixed Facebook autoload;</li>
</ul>
<p>UM User Tags:</p>
<ul>
<li>fixed filter and widget when user have 2 fields with the same tax attribute(tag group);</li>
</ul>
<p>UM Woocommerce:</p>
<ul>
<li>fixed displaying of &#8220;Total Orders&#8221; and &#8220;Total Spent&#8221; in Member Directories</li>
</ul>
<h3 style=\"text-align: center;\">What&#8217;s next <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f52e.png\" alt=\"🔮\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>UM2.0 release</h4>
<p>UM2.0 will be released once the beta period ends. We hope to have UM2.0 released by the end of this month but this will depend on the feedback we receive on UM2.0.</p>
<h4>Groups extension</h4>
<p>Work is continuing on the groups extension and we hope to release this shortly after UM2.0 is released.</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-august/\">Product Update: August</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://ultimatemember.com/product-update-august/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"10\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Product Update: July\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://ultimatemember.com/product-update-july/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://ultimatemember.com/product-update-july/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 31 Jul 2017 09:01:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Product\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=319273\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:600:\"<p>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in July. What&#8217;s new 🚀 Terms &#38; Conditions extension Want to have your users agree to your terms &#38; conditions before registering? We&#8217;ve created a free extension which&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-july/\">Product Update: July</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2922:\"<p><span style=\"font-size: 16px;\"><em>Product Update is our monthly update that highlights the recent product improvements we’ve made, so you can easily stay up to date on what’s new. Here&#8217;s what&#8217;s been happening in July.</em></span></p>
<h3 style=\"text-align: center;\">What&#8217;s new <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f680.png\" alt=\"🚀\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>Terms &amp; Conditions extension</h4>
<p>Want to have your users agree to your terms &amp; conditions before registering? We&#8217;ve created a free extension which adds a T&amp;C checkbox to the registration form with a show/hide toggle so users can view the terms and conditions without leaving the registration page.</p>
<p>You can download the extension <a href=\"https://ultimatemember.com/extensions/terms-conditions/\">here</a> and you can read the doc <a href=\"http://docs.ultimatemember.com/article/260-terms-conditions\">here</a>.</p>
<p>You can also see how it works on our <a href=\"https://ultimatememberdemo.com/register/\">demo site</a>.</p>
<h4>Google reCAPTCHA update</h4>
<p>We&#8217;ve updated the Google reCAPTCHA extension so you can now use Google&#8217;s invisible captcha. This means that users won&#8217;t see the captcha unless Google suspects suspicious activity, which will then cause the captcha to appear on the page.</p>
<p>To use invisible captcha your site must be using SSL (https). You can download the latest version of the extension <a href=\"https://ultimatemember.com/extensions/google-recaptcha/\">here</a>.</p>
<h4>UM core update 1.3.88</h4>
<p>We released one core plugin update during July. 1.3.88. adds support for the latest version of reCAPTCHA and the new Terms &amp; Conditions extension as well as fixing a few bugs and a couple of enhancements to the plugin including update the extensions page to match the new branding of Ultimate Member.</p>
<h3 style=\"text-align: center;\">What&#8217;s next <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f52e.png\" alt=\"🔮\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></h3>
<h4>UM 2.0 Beta Period</h4>
<p>Work continues on UM2.0 with the plugin close to being ready for public beta testing. The last couple of weeks has seen tweaks made and some bugs fixed from internal testing.</p>
<p>A blog post will go out when UM2.0 is ready for testing asking users to test out the plugin.</p>
<h4>Groups extension</h4>
<p>We&#8217;re just about to get started working on Groups extension again, so this will be the next extension to be released.</p>
<p>The extension will allow users to join groups and interact with other members of the group (similar to FB groups).</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/product-update-july/\">Product Update: July</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://ultimatemember.com/product-update-july/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"New website &amp; Ultimate Member 2.0 update\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://ultimatemember.com/new-website-ultimate-member-2-0-update/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://ultimatemember.com/new-website-ultimate-member-2-0-update/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 Jun 2017 11:11:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=307935\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:553:\"<p>If you are reading this blog post you may have noticed our website looks a bit different to the last time you were on it. That&#8217;s because we have been working on a completely new design for the site over the last couple of months and today the new site design went live. We decided to&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/new-website-ultimate-member-2-0-update/\">New website &amp; Ultimate Member 2.0 update</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4957:\"<p>If you are reading this blog post you may have noticed our website looks a bit different to the last time you were on it.</p>
<p>That&#8217;s because we have been working on a completely new design for the site over the last couple of months and today the new site design went live.</p>
<p>We decided to switch themes and build the site using the Beaver Builder theme and plugin.</p>
<p>However, we&#8217;ve not only just switched themes and changed the design. We&#8217;ve also created a new logo and changed our branding to incorporate a new color scheme.</p>
<h3 style=\"text-align: center\">Why?</h3>
<p style=\"text-align: left\">Our website design hasn&#8217;t changed much since we launched UM over two years ago. Things start to look old so we decided that with us working on a big update to UM (2.0) that now was the right time to create a fresh new look for the UM brand.</p>
<p style=\"text-align: left\">With the new branding/website and UM 2.0 being released soon (no exact ETA at the moment), this marks an important new chapter in our business as we take UM to new levels.</p>
<p style=\"text-align: left\">We hope you like the new site design as much as we do <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f600.png\" alt=\"😀\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>
<h3 style=\"text-align: center\">UM 2.0 update</h3>
<p>It&#8217;s been over month since we announced we were working on UM 2.0 and I am happy to say that most of the major coding work for the 2.0 update has been written.</p>
<p>We are now internally testing and reviewing all of the proposed code for UM 2.0 and making any necessary tweaks/adjustments.</p>
<p>Once we are happy with how it is looking, we will make UM 2.0 available for beta testing by our users. So far we have:</p>
<ul>
<li>Built a native settings framework and removed the redux framework from the plugin</li>
<li>Implemented a new extension license management system into the settings</li>
<li>Switched UM to use default WP roles</li>
<li>Edit default WP capabilities for user roles</li>
<li>Improved content restriction with new meta box</li>
<li>Improved emails</li>
<li>Removed feature bloat from settings to keep only important settings that are core to the plugin’s functionality and purpose</li>
<li>Changed the uninstall process</li>
<li>Optimized UM class structures</li>
<li>Added new dependencies logic for extensions</li>
</ul>
<h3 style=\"text-align: center\">Screenshots</h3>
<p>Here are a couple of screenshots of UM 2.0 so you can see some of the changes that have been made.</p>
<div id=\"attachment_307938\" style=\"width: 1034px\" class=\"wp-caption aligncenter\"><img class=\"wp-image-307938 size-large\" src=\"https://ultimatemember.com/wp-content/uploads/2017/06/new-website-1-1024x875.png\" alt=\"\" width=\"1024\" height=\"875\" srcset=\"https://ultimatemember.com/wp-content/uploads/2017/06/new-website-1-1024x875.png 1024w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-1-300x256.png 300w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-1-768x656.png 768w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-1.png 1578w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><p class=\"wp-caption-text\">New content restriction meta box for pages/posts/CPTs</p></div>
<div id=\"attachment_307939\" style=\"width: 1034px\" class=\"wp-caption aligncenter\"><img class=\"wp-image-307939 size-large\" src=\"https://ultimatemember.com/wp-content/uploads/2017/06/new-website-2-1024x610.png\" alt=\"\" width=\"1024\" height=\"610\" srcset=\"https://ultimatemember.com/wp-content/uploads/2017/06/new-website-2-1024x610.png 1024w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-2-300x179.png 300w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-2-768x458.png 768w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-2.png 1570w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><p class=\"wp-caption-text\">UM will allow admins to edit the default capabilities of user roles</p></div>
<div id=\"attachment_307940\" style=\"width: 1034px\" class=\"wp-caption aligncenter\"><img class=\"wp-image-307940 size-large\" src=\"https://ultimatemember.com/wp-content/uploads/2017/06/new-website-3-1024x575.png\" alt=\"\" width=\"1024\" height=\"575\" srcset=\"https://ultimatemember.com/wp-content/uploads/2017/06/new-website-3.png 1024w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-3-300x168.png 300w, https://ultimatemember.com/wp-content/uploads/2017/06/new-website-3-768x431.png 768w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><p class=\"wp-caption-text\">New email interface in the plugin settings for managing user emails and admin notifications</p></div>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/new-website-ultimate-member-2-0-update/\">New website &amp; Ultimate Member 2.0 update</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://ultimatemember.com/new-website-ultimate-member-2-0-update/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"20\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Ultimate Member 2.0: Announcement\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://ultimatemember.com/ultimate-member-2-announcement/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://ultimatemember.com/ultimate-member-2-announcement/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 May 2017 07:00:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=289809\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:558:\"<p>Ultimate Member launched in January 2015 and since then the plugin has grown to a stage where it is now installed on over 50,000 websites! The popularity of Ultimate Member from the day we launched, meant that after only a few months, the plugin was already making enough revenue to be a viable full-time business.&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/ultimate-member-2-announcement/\">Ultimate Member 2.0: Announcement</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5288:\"<p>Ultimate Member launched in January 2015 and since then the plugin has grown to a stage where it is now installed on over 50,000 websites!</p>
<p>The popularity of Ultimate Member from the day we launched, meant that after only a few months, the plugin was already making enough <a href=\"https://ultimatemember.com/open-metrics/\">revenue</a> to be a viable full-time business.</p>
<p>Whilst the popularity of the plugin has been better than we could ever have imagined, it has not been without its challenges. The main one being customer support.</p>
<p>Providing support to free users and paying customers has caused a significant drain on our resources, which has affected our ability to develop the plugin at the speed we were able to when we first launched.</p>
<p>Whilst hiring support staff helped to ease the support burden it still wasn&#8217;t enough to allow us to develop new features and extensions, as our developers were also still having to dedicate a lot of their time to helping with the most technical of support requests.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px;\"><strong>Moving forward<br />
</strong></span></p>
<p style=\"text-align: left;\">I believe Ultimate Member has yet to reach its full potential, which is why I decided a couple of months ago to grow the team further and create a dev team within the business which will only focus on development and not spend any of their working hours dealing with support requests.</p>
<p style=\"text-align: left;\">This change is already in motion and we currently have one developer working exclusively on development and another developer joining the team within the next 1-2 weeks to also focus on development.</p>
<p>Our goal is to make Ultimate Member the very best user profile and membership plugin for WordPress. Which is why we have made this change. With our bigger team, we are going to be building new extensions, improving existing ones and making big improvements to the core plugin.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px;\"><strong>Ultimate Member 2.0<br />
</strong></span></p>
<p style=\"text-align: left;\">Which brings us to this blog post. This is an announcement, to let you know that we are working on a significant update to the core plugin, which will be launched as Ultimate Member 2.0. This is the first step in us achieving our goal for Ultimate Member.</p>
<p style=\"text-align: left;\">Work began on UM 2.0 a few weeks ago. Our first aim with UM core 2.0 is to make the plugin leaner, more efficient and improve the code base. So far we have:</p>
<ul>
<li style=\"text-align: left;\">Built a native settings framework and removed the redux framework from the plugin</li>
<li style=\"text-align: left;\">Implemented a new extension license management system into the settings</li>
<li style=\"text-align: left;\">Improved emails</li>
<li style=\"text-align: left;\">Removed feature bloat from settings to keep only important settings that are core to the plugin&#8217;s functionality and purpose</li>
<li style=\"text-align: left;\">Changed the uninstall process</li>
<li style=\"text-align: left;\">Optimized UM class structures</li>
<li style=\"text-align: left;\">Added new dependencies logic for extensions</li>
</ul>
<p>Another major undertaking we are also working on is moving away from UM roles to using native WordPress roles. This will make it much easier for UM to interact with other plugins without the need for custom coding.</p>
<p>As well as this we will also be making other various changes to the core plugin so that the plugin is more tightly integrated with WordPress and generally just better and easier to use.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px;\"><strong>Extension development<br />
</strong></span></p>
<p style=\"text-align: left;\">Once we have UM 2.0 launched our attention will turn to creating new extensions and making improvements to existing extensions. The will include finishing off the groups extension which is already part-coded.</p>
<p style=\"text-align: left;\">We will also be looking at new functionality to add into the core plugin.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px;\"><strong>New branding<br />
</strong></span></p>
<p style=\"text-align: left;\">As UM 2.0 will almost feel like a re-launch of the plugin, we&#8217;re also going to be making some changes to the website and brand. The website is currently being re-designed, with a new color scheme and also a new logo.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px;\"><strong>Thank you<br />
</strong></span></p>
<p style=\"text-align: left;\">Finally, I just want to say a big thank you to everyone who uses our plugin and especially our paying customers. Without you Ultimate Member would not still be run as a full-time business today. We are going to be working tirelessly to make Ultimate Member into the very best plugin it can be. We are excited to see where we can take Ultimate Member moving forward and hope you will continue to join us on this journey.</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/ultimate-member-2-announcement/\">Ultimate Member 2.0: Announcement</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://ultimatemember.com/ultimate-member-2-announcement/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"11\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"Christmas &amp; New Year Support Schedule\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://ultimatemember.com/christmas-new-year-support-schedule/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://ultimatemember.com/christmas-new-year-support-schedule/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 20 Dec 2016 04:04:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=243089\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:582:\"<p>With Christmas and the New Year fast approaching, I wanted to let you know about support over the holidays. We are going to be closing support ticket submission on Thursday 22nd (5am GMT time). This will allow us to spend Thursday and Friday answering any outstanding tickets before stopping work on the 24th. Support ticket&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/christmas-new-year-support-schedule/\">Christmas &#038; New Year Support Schedule</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2765:\"<p>With Christmas and the New Year fast approaching, I wanted to let you know about support over the holidays.</p>
<p>We are going to be closing support ticket submission on Thursday 22nd (5am GMT time). This will allow us to spend Thursday and Friday answering any outstanding tickets before stopping work on the 24th.</p>
<p>Support ticket submission will then be closed until Saturday the 31st of December.</p>
<p>All of our support staff will then be back to work on Monday the 2nd of January.</p>
<p>We will be using the holidays to catch up with family and friends and recharge the batteries. Then in January we will be working hard to get the groups extension finished and released, plus other improvements to the plugin.</p>
<p>We wish you a Merry Christmas and a Happy New Year and  we look forward to improving Ultimate Member in 2017!</p>
<p><strong>Christmas &amp; New Year Support Schedule:</strong></p>
<ul>
<li>Tuesday 20th Dec – New Ticket Creation: <strong>YES</strong> – Support Team Working:<strong>YES</strong></li>
<li>Wednesday 21st Dec – New Ticket Creation: <strong>YES</strong> – Support Team Working: <strong>YES</strong></li>
<li>Thursday 22nd Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working: <strong>YES</strong></li>
<li>Friday 23rd Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working: <strong>YES</strong></li>
<li>Saturday 24th Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working: <strong>NO</strong></li>
<li>Sunday 25th Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working: <strong>NO</strong></li>
<li>Monday 26th Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working: <strong>NO</strong></li>
<li>Tuesday 27th Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working: <strong>NO</strong></li>
<li>Wednesday 28th Dec – New Ticket Creation:<strong>NO</strong> – Support Team Working:<strong>NO</strong></li>
<li>Thursday 29th Dec – New Ticket Creation:<strong>NO</strong> – Support Team Working:<strong>NO</strong></li>
<li>Friday 30th Dec – New Ticket Creation: <strong>NO</strong> – Support Team Working:<strong>NO</strong></li>
<li>Saturday 31st Dec – New Ticket Creation: <strong>YES</strong> – Support Team Working: <strong>NO</strong></li>
<li>Sunday 1st Jan – New Ticket Creation: <strong>YES</strong> – Support Team Working: <strong>NO</strong></li>
<li>Monday 2nd Jan –Normal support resumes</li>
</ul>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/christmas-new-year-support-schedule/\">Christmas &#038; New Year Support Schedule</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"https://ultimatemember.com/christmas-new-year-support-schedule/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Submit your website for showcase\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://ultimatemember.com/submit-website-showcase/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://ultimatemember.com/submit-website-showcase/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 May 2016 11:15:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=179139\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:534:\"<p>Want to show your website to the rest of the Ultimate Member community? Now you can, as we are adding a showcase page to our website so members of the community and people interested in the plugin can see what sort of websites are getting built with Ultimate Member. To submit your website, just go&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/submit-website-showcase/\">Submit your website for showcase</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:648:\"<p>Want to show your website to the rest of the Ultimate Member community?</p>
<p>Now you can, as we are adding a showcase page to our website so members of the community and people interested in the plugin can see what sort of websites are getting built with Ultimate Member.</p>
<p>To submit your website, just go to this <a href=\"https://ultimatemember.com/showcase/\">page</a> and fill in the short form.</p>
<p>Thanks!</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/submit-website-showcase/\">Submit your website for showcase</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://ultimatemember.com/submit-website-showcase/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"5\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"2015 Year in Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://ultimatemember.com/2015-year-review/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://ultimatemember.com/2015-year-review/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Jan 2016 13:09:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://ultimatemember.com/?p=133524\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:555:\"<p>It&#8217;s hard to believe but Ultimate Member turned 1 yesterday. The last year has flown by and whilst it has been a very successful first year for us, it has not been without its challenges. Let’s take a look back at everything that happened during 2015. Growth Launching Ultimate Member was scary, especially when the plan was for&#8230;</p>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/2015-year-review/\">2015 Year in Review</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Calum Allison\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:8065:\"<p>It&#8217;s hard to believe but Ultimate Member turned 1 yesterday. The last year has flown by and whilst it has been a very successful first year for us, it has not been without its challenges.</p>
<p>Let’s take a look back at everything that happened during 2015.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px; font-weight: 600;\">Growth</span></p>
<p style=\"text-align: left;\">Launching <a href=\"https://wordpress.org/plugins/ultimate-member/\">Ultimate Member</a> was scary, especially when the plan was for the plugin to provide a full-time income for two people.</p>
<p style=\"text-align: left;\">We didn&#8217;t have a mailing list, friends in the WordPress community or an established reputation to help us increase awareness of the plugin.</p>
<p style=\"text-align: left;\">We started from scratch.</p>
<p style=\"text-align: left;\">We had invested over six months into building the plugin and it would be a lie to say the first weeks and months of the plugin being on the repo were not stressful.</p>
<p style=\"text-align: left;\">Thankfully, Ultimate Member proved to be popular with WordPress users and it didn&#8217;t take long for us to get to an average new active installs of around 2000 a month.</p>
<p style=\"text-align: left;\">We ended the year with over 20,000 active installs.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px; font-weight: 600;\">The Team</span></p>
<p style=\"text-align: left;\">For most of the year it was just Ahmed and me running the business by ourselves. This was fine to begin with but as our user base grew and more support tickets were submitted it became harder and harder to manage the plugin.</p>
<p style=\"text-align: left;\">So in October we decided to grow the team and bring in three new developers to help with technical support and product improvements.</p>
<p style=\"text-align: left;\">Their names are Champ, Jon and Alex and they have made a huge difference in helping to improve support and make the plugin and the extensions better.</p>
<p style=\"text-align: left;\">As well as helping the business, they have also had a major impact on me personally, as I am less stressed and can take more breaks knowing that our plugin&#8217;s users are in good hands.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px; font-weight: 600;\">Revenue</span></p>
<p style=\"text-align: left;\">I am a big believer in business transparency.</p>
<p style=\"text-align: left;\">Seeing revenue figures for plugins such as <a href=\"https://easydigitaldownloads.com/\">EDD</a> and <a href=\"https://ninjaforms.com/\">Ninja Forms</a> made it much easier for us to commit to creating Ultimate Member as we were able to see just how well other plugin businesses were doing.</p>
<p style=\"text-align: left;\">We decided to embrace transparency fully and from the very beginning we have had a <a href=\"https://ultimatemember.com/open-metrics/\">real-time metrics page</a> where anyone can see how much money the plugin makes.</p>
<p style=\"text-align: left;\">Total revenue for 2015 was <strong>$210,142.46</strong> from 2,336 sales. This was earned over 295 days as we did not start selling extensions until the 11th of march. This gives us a daily average total revenue of $712.</p>
<p style=\"text-align: left;\">Our highest monthly revenue was in October where we earned $28,518 and since June our revenue has been above $20,000 each month.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px; font-weight: 600;\">Support</span></p>
<p style=\"text-align: center;\"><img class=\"aligncenter size-full wp-image-134555\" src=\"https://ultimatemember.com/wp-content/uploads/2016/01/Screen-Shot-2016-01-21-at-16.12.58.png\" alt=\"Screen Shot 2016-01-21 at 16.12.58\" width=\"1000\" height=\"268\" srcset=\"https://ultimatemember.com/wp-content/uploads/2016/01/Screen-Shot-2016-01-21-at-16.12.58.png 1000w, https://ultimatemember.com/wp-content/uploads/2016/01/Screen-Shot-2016-01-21-at-16.12.58-300x80.png 300w, https://ultimatemember.com/wp-content/uploads/2016/01/Screen-Shot-2016-01-21-at-16.12.58-768x206.png 768w\" sizes=\"(max-width: 1000px) 100vw, 1000px\" /></p>
<p style=\"text-align: left;\">Without a doubt, the biggest challenge of running a WordPress plugin is providing support. It can consume up all the hours in a day and bring development to a halt, which is what happened to us a few months ago.</p>
<p style=\"text-align: left;\">When we first launched Ultimate Member we decided to use a forum as our means of providing support. Whilst this worked to begin with, as our user base continued to grow each month it became harder to support the plugin.</p>
<p style=\"text-align: left;\">So in October we decided to switch from a forum to email ticketing support using <a href=\"http://www.helpscout.net/\">HelpScout</a> and hired 3 people to help with support.</p>
<p style=\"text-align: left;\">In total, we have had over 6100 requests for support during 2015. This works out at $34.40 in revenue per support ticket.</p>
<p style=\"text-align: left;\">Whilst a large plugin with lots of functionality is always going to have a higher support-user ratio than a more basic plugin, this is a number that is too high for me and is something we will be working on actively over the next year to reduce.</p>
<p style=\"text-align: left;\">Here are some other support stats:</p>
<ul>
<li style=\"text-align: left;\">Number of tickets resolved on first reply &#8211; 45%</li>
<li style=\"text-align: left;\">Average first response time &#8211; 16h59m</li>
<li style=\"text-align: left;\">Average response time &#8211; 21h9m</li>
<li style=\"text-align: left;\">Average resolution time &#8211; 3d17h</li>
<li style=\"text-align: left;\">Average number of replies to resolve &#8211; 2.63</li>
</ul>
<p style=\"text-align: center;\"><span style=\"font-size: 28px; font-weight: 600;\">Reviews</span></p>
<p style=\"text-align: left;\">As well as the number of active installs, another great indicator of how popular a plugin is, are the reviews it receives. Ultimate Member received the following reviews during 2015:</p>
<ul>
<li style=\"text-align: left;\">⭐️⭐️⭐️⭐️⭐️ &#8211; 236</li>
<li style=\"text-align: left;\">⭐️⭐️⭐️⭐️ &#8211; 11</li>
<li style=\"text-align: left;\">⭐️⭐️⭐️ &#8211; 4</li>
<li style=\"text-align: left;\">⭐️⭐️ &#8211; 5</li>
<li style=\"text-align: left;\">⭐️ &#8211; 5</li>
</ul>
<p>Overall, our average star rating is 4.8/5, which is something we are very happy about as it tells us that the vast majority of users are happy with Ultimate Member.</p>
<p style=\"text-align: center;\"><span style=\"font-size: 28px; font-weight: 600;\">2016 &amp; Beyond</span></p>
<p style=\"text-align: left;\">2016 promises to be an exciting year for Ultimate Member, with many improvements to the plugin and new extensions to be built and released.</p>
<p style=\"text-align: left;\">There is definitely a lot more growth in the plugin and we will be looking to increase the scope and usage potential of Ultimate Member to reach a greater user base and make the plugin the go-to plugin for membership/community sites.</p>
<p style=\"text-align: left;\">Here are some of our goals for 2016:</p>
<ul>
<li style=\"text-align: left;\">Reduce support tickets by improving documentation</li>
<li style=\"text-align: left;\">Develop more extensions &amp; continue to improve plugin</li>
<li style=\"text-align: left;\">Grow team further to allow for faster support &amp; development</li>
<li style=\"text-align: left;\">Increase monthly revenue to $30,000+ via new sales &amp; license renewals</li>
<li style=\"text-align: left;\">Better content marketing with more blog posts</li>
<li style=\"text-align: left;\">Continue to improve business transparency</li>
<li style=\"text-align: left;\">Improve health &amp; wellbeing with more breaks and holidays</li>
</ul>
<p>The post <a rel=\"nofollow\" href=\"https://ultimatemember.com/2015-year-review/\">2015 Year in Review</a> appeared first on <a rel=\"nofollow\" href=\"https://ultimatemember.com\">Ultimate Member</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://ultimatemember.com/2015-year-review/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"14\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:37:\"https://ultimatemember.com/blog/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:17:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 05 Dec 2017 15:28:56 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:14:\"content-length\";s:5:\"13067\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:10:\"set-cookie\";s:44:\"PHPSESSID=ia7icf2b8ihpg8cfp2903dhjg3; path=/\";s:7:\"expires\";s:29:\"Thu, 19 Nov 1981 08:52:00 GMT\";s:13:\"cache-control\";s:70:\"no-store, no-cache, must-revalidate, post-check=0, pre-check=0, public\";s:6:\"pragma\";s:8:\"no-cache\";s:13:\"last-modified\";s:29:\"Tue, 05 Dec 2017 15:26:53 GMT\";s:4:\"etag\";s:34:\"\"8a1e3af297ae379c5cd03cbddc75874c\"\";s:12:\"x-robots-tag\";s:15:\"noindex, follow\";s:4:\"link\";s:63:\"<https://ultimatemember.com/wp-json/>; rel=\"https://api.w.org/\"\";s:16:\"x-xss-protection\";s:13:\"1; mode=block\";s:22:\"x-content-type-options\";s:7:\"nosniff\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20171205133848\";}", "no");
INSERT INTO `wp_options` VALUES("329", "_transient_timeout_feed_mod_2b16a4f9a2b7110ce37a7c1a0e3bbb94", "1512530937", "no");
INSERT INTO `wp_options` VALUES("330", "_transient_feed_mod_2b16a4f9a2b7110ce37a7c1a0e3bbb94", "1512487737", "no");
INSERT INTO `wp_options` VALUES("332", "um_cached_users_queue", "0", "no");
INSERT INTO `wp_options` VALUES("340", "widget_wppb-login-widget", "a:1:{s:12:\"_multiwidget\";i:1;}", "yes");
INSERT INTO `wp_options` VALUES("341", "wppb_version", "2.7.2", "yes");
INSERT INTO `wp_options` VALUES("342", "wppb_manage_fields", "a:6:{i:0;a:21:{s:2:\"id\";i:2;s:5:\"field\";s:18:\"Default - Username\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:8:\"Username\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:1;a:21:{s:2:\"id\";i:3;s:5:\"field\";s:20:\"Default - First Name\";s:9:\"meta-name\";s:10:\"first_name\";s:11:\"field-title\";s:10:\"First Name\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:2;a:21:{s:2:\"id\";i:4;s:5:\"field\";s:19:\"Default - Last Name\";s:9:\"meta-name\";s:9:\"last_name\";s:11:\"field-title\";s:9:\"Last Name\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:2:\"No\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:3;a:21:{s:2:\"id\";i:8;s:5:\"field\";s:16:\"Default - E-mail\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:6:\"E-mail\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:4;a:21:{s:2:\"id\";i:12;s:5:\"field\";s:18:\"Default - Password\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:8:\"Password\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}i:5;a:21:{s:2:\"id\";i:13;s:5:\"field\";s:25:\"Default - Repeat Password\";s:9:\"meta-name\";s:0:\"\";s:11:\"field-title\";s:15:\"Repeat Password\";s:11:\"description\";s:0:\"\";s:8:\"required\";s:3:\"Yes\";s:18:\"overwrite-existing\";s:2:\"No\";s:9:\"row-count\";s:1:\"5\";s:24:\"allowed-image-extensions\";s:2:\".*\";s:25:\"allowed-upload-extensions\";s:2:\".*\";s:11:\"avatar-size\";s:3:\"100\";s:11:\"date-format\";s:8:\"mm/dd/yy\";s:18:\"terms-of-agreement\";s:0:\"\";s:7:\"options\";s:0:\"\";s:6:\"labels\";s:0:\"\";s:10:\"public-key\";s:0:\"\";s:11:\"private-key\";s:0:\"\";s:13:\"default-value\";s:0:\"\";s:14:\"default-option\";s:0:\"\";s:15:\"default-options\";s:0:\"\";s:15:\"default-content\";s:0:\"\";}}", "yes");
INSERT INTO `wp_options` VALUES("343", "wppb_general_settings", "a:7:{s:17:\"extraFieldsLayout\";s:7:\"default\";s:17:\"emailConfirmation\";s:2:\"no\";s:21:\"activationLandingPage\";s:0:\"\";s:13:\"adminApproval\";s:2:\"no\";s:9:\"loginWith\";s:13:\"usernameemail\";s:11:\"rolesEditor\";s:2:\"no\";s:18:\"contentRestriction\";s:2:\"no\";}", "yes");
INSERT INTO `wp_options` VALUES("344", "wppb_display_admin_settings", "a:5:{s:13:\"Administrator\";s:7:\"default\";s:6:\"Editor\";s:4:\"hide\";s:6:\"Author\";s:4:\"hide\";s:11:\"Contributor\";s:4:\"hide\";s:10:\"Subscriber\";s:4:\"hide\";}", "yes");
INSERT INTO `wp_options` VALUES("369", "allowedthemes", "a:2:{s:15:\"dark_shop_child\";b:1;s:13:\"masonic_child\";b:1;}", "no");
INSERT INTO `wp_options` VALUES("371", "current_theme", "Masonic_Child", "yes");
INSERT INTO `wp_options` VALUES("372", "theme_mods_dark_shop_child", "a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1513612958;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:12:\"categories-2\";i:3;s:14:\"recent-posts-2\";i:4;s:17:\"recent-comments-2\";}s:12:\"sidebar-left\";a:1:{i:0;s:8:\"search-2\";}s:14:\"sidebar-header\";a:0:{}s:15:\"sidebar-footer1\";a:0:{}}}s:18:\"custom_css_post_id\";i:-1;}", "yes");
INSERT INTO `wp_options` VALUES("373", "theme_switched", "", "yes");
INSERT INTO `wp_options` VALUES("375", "theme_mods_dark-shop-lite", "a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"header-menu\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1512670572;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:12:\"categories-2\";i:3;s:14:\"recent-posts-2\";i:4;s:17:\"recent-comments-2\";}s:12:\"sidebar-left\";a:1:{i:0;s:8:\"search-2\";}s:14:\"sidebar-header\";a:0:{}s:15:\"sidebar-footer1\";a:0:{}}}}", "yes");
INSERT INTO `wp_options` VALUES("460", "theme_mods_masonic", "a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1513613004;s:4:\"data\";a:5:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:10:\"archives-2\";i:1;s:6:\"meta-2\";i:2;s:12:\"categories-2\";i:3;s:14:\"recent-posts-2\";i:4;s:17:\"recent-comments-2\";}s:13:\"right-sidebar\";a:1:{i:0;s:8:\"search-2\";}s:18:\"footer-sidebar-one\";a:0:{}s:18:\"footer-sidebar-two\";a:0:{}s:20:\"footer-sidebar-three\";a:0:{}}}}", "yes");
INSERT INTO `wp_options` VALUES("461", "masonic_admin_notice_welcome", "1", "yes");
INSERT INTO `wp_options` VALUES("464", "theme_mods_masonic_child", "a:10:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:18:\"custom_css_post_id\";i:127;s:12:\"header_image\";s:60:\"http://localhost:8000/wp-content/uploads/2017/12/header2.jpg\";s:17:\"header_image_data\";O:8:\"stdClass\":5:{s:13:\"attachment_id\";i:92;s:3:\"url\";s:60:\"http://localhost:8000/wp-content/uploads/2017/12/header2.jpg\";s:13:\"thumbnail_url\";s:60:\"http://localhost:8000/wp-content/uploads/2017/12/header2.jpg\";s:6:\"height\";i:500;s:5:\"width\";i:1350;}s:11:\"custom_logo\";i:93;s:21:\"masonic_primary_color\";s:7:\"#893b00\";s:16:\"header_textcolor\";s:6:\"dd9933\";s:18:\"masonic_link_color\";s:7:\"#6a6a6a\";s:16:\"background_image\";s:64:\"http://localhost:8000/wp-content/uploads/2017/12/palkortum20.jpg\";}", "yes");
INSERT INTO `wp_options` VALUES("481", "_site_transient_timeout_browser_da4804949398f905dcef757ac82cf2c1", "1514248222", "no");
INSERT INTO `wp_options` VALUES("482", "_site_transient_browser_da4804949398f905dcef757ac82cf2c1", "a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"63.0.3239.84\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}", "no");
INSERT INTO `wp_options` VALUES("510", "category_children", "a:0:{}", "yes");
INSERT INTO `wp_options` VALUES("648", "_site_transient_timeout_browser_3cfaef5423baa1c8c41dc485a8b13be3", "1515174263", "no");
INSERT INTO `wp_options` VALUES("649", "_site_transient_browser_3cfaef5423baa1c8c41dc485a8b13be3", "a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"63.0.3239.108\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}", "no");
INSERT INTO `wp_options` VALUES("650", "_site_transient_timeout_community-events-4501c091b0366d76ea3218b6cfdd8097", "1514612666", "no");
INSERT INTO `wp_options` VALUES("651", "_site_transient_community-events-4501c091b0366d76ea3218b6cfdd8097", "a:2:{s:8:\"location\";a:1:{s:2:\"ip\";s:2:\"::\";}s:6:\"events\";a:5:{i:0;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:24:\"WordPress Durham Revival\";s:3:\"url\";s:67:\"https://www.meetup.com/Durham-WordPress-Meetup/events/smxbxmyxcbgb/\";s:6:\"meetup\";s:23:\"Durham WordPress Meetup\";s:10:\"meetup_url\";s:47:\"https://www.meetup.com/Durham-WordPress-Meetup/\";s:4:\"date\";s:19:\"2018-01-04 19:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:18:\"Whitby, ON, Canada\";s:7:\"country\";s:2:\"ca\";s:8:\"latitude\";d:43.878571;s:9:\"longitude\";d:-78.946281;}}i:1;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:33:\"Virtual Contrib2Core [Developers]\";s:3:\"url\";s:50:\"https://www.meetup.com/WPToronto/events/245802897/\";s:6:\"meetup\";s:27:\"The Toronto WordPress Group\";s:10:\"meetup_url\";s:33:\"https://www.meetup.com/WPToronto/\";s:4:\"date\";s:19:\"2018-01-08 12:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Toronto, ON, Canada\";s:7:\"country\";s:2:\"ca\";s:8:\"latitude\";d:43.781216;s:9:\"longitude\";d:-79.416267;}}i:2;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:33:\"Virtual Contrib2Core [Developers]\";s:3:\"url\";s:53:\"https://www.meetup.com/WPToronto/events/qglxfmyxcblb/\";s:6:\"meetup\";s:27:\"The Toronto WordPress Group\";s:10:\"meetup_url\";s:33:\"https://www.meetup.com/WPToronto/\";s:4:\"date\";s:19:\"2018-01-08 18:30:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Toronto, ON, Canada\";s:7:\"country\";s:2:\"ca\";s:8:\"latitude\";d:43.781216;s:9:\"longitude\";d:-79.416267;}}i:3;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:33:\"WordPress Toronto - North Edition\";s:3:\"url\";s:53:\"https://www.meetup.com/WPToronto/events/gnjbwnyxcbtb/\";s:6:\"meetup\";s:27:\"The Toronto WordPress Group\";s:10:\"meetup_url\";s:33:\"https://www.meetup.com/WPToronto/\";s:4:\"date\";s:19:\"2018-01-15 15:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Toronto, ON, Canada\";s:7:\"country\";s:2:\"ca\";s:8:\"latitude\";d:43.659999847412;s:9:\"longitude\";d:-79.379997253418;}}i:4;a:7:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:51:\"WordPress Toronto - North Edition - Let\'s fix it #4\";s:3:\"url\";s:50:\"https://www.meetup.com/WPToronto/events/245342129/\";s:6:\"meetup\";s:27:\"The Toronto WordPress Group\";s:10:\"meetup_url\";s:33:\"https://www.meetup.com/WPToronto/\";s:4:\"date\";s:19:\"2018-01-15 15:00:00\";s:8:\"location\";a:4:{s:8:\"location\";s:19:\"Toronto, ON, Canada\";s:7:\"country\";s:2:\"ca\";s:8:\"latitude\";d:43.659999847412;s:9:\"longitude\";d:-79.379997253418;}}}}", "no");
INSERT INTO `wp_options` VALUES("652", "_transient_timeout_feed_53c6368e164927c356de1596c8cebec9", "1514612668", "no");
INSERT INTO `wp_options` VALUES("653", "_transient_feed_53c6368e164927c356de1596c8cebec9", "a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Blog – English (Canada)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"https://en-ca.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"
	Tue, 01 Aug 2017 16:33:12 +0000	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.0-alpha-42419\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:78:\"
		
		
		
		
		
				
		
		
		
		
		
		
		
		
		
		
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"WordCamp Coming to Halifax, Nova Scotia!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://en-ca.wordpress.org/2017/04/18/wordcamp-coming-to-halifax-nova-scotia/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://en-ca.wordpress.org/2017/04/18/wordcamp-coming-to-halifax-nova-scotia/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Apr 2017 18:20:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:13:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Canada\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:8:\"Canadian\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:9:\"community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:4;a:5:{s:4:\"data\";s:20:\"Dalhousie University\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:5;a:5:{s:4:\"data\";s:10:\"East Coast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:6;a:5:{s:4:\"data\";s:11:\"habourfront\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:7;a:5:{s:4:\"data\";s:7:\"Halifax\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:8;a:5:{s:4:\"data\";s:13:\"Happiness Bar\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:9;a:5:{s:4:\"data\";s:11:\"Nova Scotia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:10;a:5:{s:4:\"data\";s:5:\"tours\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:11;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:12;a:5:{s:4:\"data\";s:16:\"WordCamp Halifax\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://en-ca.wordpress.org/?p=409\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:320:\"This May marks a very special month for people in Atlantic Canada. Not only will the first signs of spring appear in the area (finally), but a new conference will be popping up as well. WordCamp Halifax is happening on May 27th at Marion McCain Building at Dalhousie University. This will be the first WordCamp [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Alison Knott\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3604:\"<figure id=\"attachment_412\" style=\"max-width: 290px\" class=\"wp-caption alignright\"><img class=\"wp-image-412 size-medium\" src=\"https://en-ca.wordpress.org/files/2017/04/Large_lobster_wapuu-290x300.jpg\" alt=\"offical wapuu of WordCamp Halifax\" width=\"290\" height=\"300\" srcset=\"https://en-ca.wordpress.org/files/2017/04/Large_lobster_wapuu-290x300.jpg 290w, https://en-ca.wordpress.org/files/2017/04/Large_lobster_wapuu.jpg 400w\" sizes=\"(max-width: 290px) 100vw, 290px\" /><figcaption class=\"wp-caption-text\">Meet &#8216;Wabster&#8217;, WordCamp Halifax&#8217;s official wapuu!</figcaption></figure>
<p>This May marks a very special month for people in Atlantic Canada. Not only will the first signs of spring appear in the area (finally), but a new conference will be popping up as well.</p>
<p><a href=\"https://2017.halifax.wordcamp.org/\" target=\"_blank\" rel=\"noopener noreferrer\">WordCamp Halifax</a> is happening on May 27th at Marion McCain Building at Dalhousie University. This will be the first WordCamp in Canada East of Montreal, making it <em>the</em> web-related event of the season for Maritimers.</p>
<p>&nbsp;</p>
<h2>Get To Know Halifax</h2>
<p>Halifax is best known for its friendly community and beautiful harbour. Take in cafes, beer gardens, the Citadel Hill, a farmers market and more pubs than you can count! May is a lovely time of year on the peninsula with lots of sunshine and occasional shower. Be sure to check out the newly built Central Library downtown &#8211; a spectacular architectural feat. Spend the whole week in Halifax to take road trips to other beautiful parts of the province: wine tours, U-picks and quaint fishing villages can all be found within a few hours drive away from the capital.</p>
<p>WordCamp has affordable accommodations if you want to stay close to the venue. More information can be <a href=\"https://2017.halifax.wordcamp.org/venue/\" target=\"_blank\" rel=\"noopener noreferrer\">found here</a>.</p>
<p>&nbsp;</p>
<h2>What To Expect At WordCamp Halifax</h2>
<p>With a mere $25 price tag, attendees can expect to enjoy:</p>
<ul>
<li>Catered lunch</li>
<li>Swag bag with lots of goodies</li>
<li>Happiness Bar where attendees can get one-on-one help with their website</li>
<li>Lots of networking with people from a multitude of industries and skill levels</li>
<li>25 local, national and international <a href=\"https://2017.halifax.wordcamp.org/speakers/\" target=\"_blank\" rel=\"noopener noreferrer\">speakers</a></li>
<li>21 <a href=\"https://2017.halifax.wordcamp.org/sessions/\" target=\"_blank\" rel=\"noopener noreferrer\">informative sessions</a> in three tracks</li>
<li>An After Party five minutes from the venue, with affordable bevvy&#8217;s &amp; snacks (you know how Haligonians love a good kitchen party!)</li>
</ul>
<p>The team has worked hard to bring diverse programming to this inaugural WordCamp with three tracks of learning:</p>
<ul>
<li><strong>Content Creators:</strong> Easiest sessions. Little prior WordPress experience expected</li>
<li><strong>Site Creators:</strong> Some WordPress experience would be beneficial for these sessions, but is not required. Small amounts of HTML, CSS, PHP and Javascript might be presented in some talks</li>
<li><strong>Code Creators:</strong> Advanced WordPress concepts, HTML, CSS, PHP and Javascript will be presented.</li>
</ul>
<p>&nbsp;</p>
<p>We can&#8217;t wait to see everyone this May, so <a href=\"https://2017.halifax.wordcamp.org/tickets/\" target=\"_blank\" rel=\"noopener noreferrer\">nab a ticket</a>. With a limited seating of 185, you&#8217;ll have to grab one before they&#8217;re gone!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://en-ca.wordpress.org/2017/04/18/wordcamp-coming-to-halifax-nova-scotia/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"Canadian English Theme Translations\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://en-ca.wordpress.org/2015/07/20/themes-in-en-ca/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://en-ca.wordpress.org/2015/07/20/themes-in-en-ca/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 20 Jul 2015 01:33:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:4:\"l10n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:6:\"Themes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://en-ca.wordpress.org/?p=303\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:396:\"The core WordPress project, have now opened up supported themes for translation into local languages. This has opened up thousands of new text strings to translate from US English to Canadian English. If you would like to assist, then you can head on over to https://translate.wordpress.org/locale/en-ca/default/wp-themes and start translating. We will then review all submitted stings [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:574:\"<p>The core WordPress project, have now opened up supported themes for translation into local languages. This has opened up thousands of new text strings to translate from US English to Canadian English.</p>
<p>If you would like to assist, then you can head on over to <a href=\"https://translate.wordpress.org/locale/en-ca/default/wp-themes\">https://translate.wordpress.org/locale/en-ca/default/wp-themes</a> and start translating.</p>
<p>We will then review all submitted stings for accuracy. You can post a comment to this post of the themes you have contributed to.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://en-ca.wordpress.org/2015/07/20/themes-in-en-ca/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:54:\"
		
		
		
		
		
				
		
		
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"WordPress 4.0 “Benny”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://en-ca.wordpress.org/2014/09/04/wordpress-4-0-benny/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://en-ca.wordpress.org/2014/09/04/wordpress-4-0-benny/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Sep 2014 22:34:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:5:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:16:\"English (Canada)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:5:\"en_CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:4;a:5:{s:4:\"data\";s:9:\"WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=278\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:366:\"The Canadian English version of WordPress 4.0 is now released! Official Notice from the Core team: Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleaderBenny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we’ve put a [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:701:\"<p>The Canadian English version of WordPress 4.0 is now released!</p>
<p><a href=\"https://wordpress.org/news/2014/09/benny/\" target=\"_blank\">Official Notice from the Core team:</a></p>
<blockquote><p>Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader<a href=\"http://en.wikipedia.org/wiki/Benny_Goodman\">Benny Goodman</a>, is available <a href=\"https://wordpress.org/download/\">for download</a> or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we’ve put a little extra polish into it. This release brings you a smoother writing and management experience we think you’ll enjoy.</p></blockquote>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://en-ca.wordpress.org/2014/09/04/wordpress-4-0-benny/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"WordPress 3.9 “Smith”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://en-ca.wordpress.org/2014/04/21/wordpress-3-9-smith/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://en-ca.wordpress.org/2014/04/21/wordpress-3-9-smith/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 Apr 2014 00:41:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:16:\"English (Canada)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:5:\"en_CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=263\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:293:\"Version 3.9 of WordPress, named “Smith” in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you’ll love. The full description of the update can be read on the official post.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:630:\"<p><span style=\"color: #444444\">Version 3.9 of WordPress, named “Smith” in honor of jazz organist </span><a style=\"color: #4ca6cf\" href=\"http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)\">Jimmy Smith</a><span style=\"color: #444444\">, is available </span><a style=\"color: #4ca6cf\" href=\"https://wordpress.org/download/\">for download</a><span style=\"color: #444444\"> or update in your WordPress dashboard. This release features a number of refinements that we hope you’ll love.</span></p>
<p>The full description of the update can be <a href=\"https://wordpress.org/news/2014/04/smith/\">read on the official post.</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://en-ca.wordpress.org/2014/04/21/wordpress-3-9-smith/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"WordPress 3.8 is Out!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://en-ca.wordpress.org/2013/12/12/i-didnt-know-what-time-it-was-wordpress-3-8-is-out/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://en-ca.wordpress.org/2013/12/12/i-didnt-know-what-time-it-was-wordpress-3-8-is-out/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Dec 2013 23:57:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:16:\"English (Canada)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:5:\"en_CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=245\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:156:\"After lots of work by many. WordPress 3.8 is out in Canadian English. Update your sites now! It will look amazing! You can also read the release notes here.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:273:\"<p>After lots of work by many. WordPress 3.8 is out in Canadian English.</p>
<p>Update your sites now! It will look amazing! You can also read the release notes <a title=\"WordPress 3.8 Parker\" href=\"https://wordpress.org/news/2013/12/parker/\" target=\"_blank\">here</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://en-ca.wordpress.org/2013/12/12/i-didnt-know-what-time-it-was-wordpress-3-8-is-out/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"WordPress 3.7 “Basie” in Canadian English, Eh!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://en-ca.wordpress.org/2013/10/24/wordpress-3-7-basie-in-canadian-english-eh/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"https://en-ca.wordpress.org/2013/10/24/wordpress-3-7-basie-in-canadian-english-eh/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 24 Oct 2013 23:42:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:16:\"English (Canada)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:5:\"en_CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=241\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:360:\"It is that time that we get to release a brand new major release of WordPress. There are a lot of changes in the backend, not that you should notice. WordPress 3.7 “Basie” Posted October 24, 2013 by Matt Mullenweg. Filed under Releases. Version 3.7 of WordPress, named “Basie” in honor of Count Basie, is available for download or update [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2585:\"<p>It is that time that we get to release a brand new major release of WordPress. There are a lot of changes in the backend, not that you should notice.</p>
<blockquote>
<h2><a href=\"https://wordpress.org/news/2013/10/basie/\">WordPress 3.7 “Basie”</a></h2>
<div>Posted October 24, 2013 by <a href=\"http://ma.tt/\">Matt Mullenweg</a>. Filed under <a title=\"View all posts in Releases\" href=\"https://wordpress.org/news/category/releases/\" rel=\"category tag\">Releases</a>.</div>
</blockquote>
<div>
<blockquote><p>Version 3.7 of WordPress, named “Basie” in honor of <a href=\"http://en.wikipedia.org/wiki/Count_basie\">Count Basie</a>, is available <a href=\"https://wordpress.org/download/\">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we’ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don’t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site’s first line of defense. It’s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you’re hungry for more <a href=\"https://codex.wordpress.org/Version_3.7\">dive into the Codex</a> or browse the <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7\">over 400 closed tickets on Trac</a>.</p>
<p>Read full post &gt;&gt; <a href=\"https://wordpress.org/news/2013/10/basie/\">https://wordpress.org/news/2013/10/basie/</a></p></blockquote>
</div>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://en-ca.wordpress.org/2013/10/24/wordpress-3-7-basie-in-canadian-english-eh/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:51:\"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Error in 3.6 Build\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://en-ca.wordpress.org/2013/08/06/error-in-3-6-build/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://en-ca.wordpress.org/2013/08/06/error-in-3-6-build/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 06 Aug 2013 00:43:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:4:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:16:\"English (Canada)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:5:\"en_CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:3;a:5:{s:4:\"data\";s:9:\"WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=234\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:233:\"There was an error with the original build of the Canadian English 3.6 that was giving version 3.6-beta3-24485. I have fixed the build if you have the incorrect version then use the built-in updater now, or re-download on the right.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:241:\"<p>There was an error with the original build of the Canadian English 3.6 that was giving version 3.6-beta3-24485. I have fixed the build if you have the incorrect version then use the built-in updater now, or re-download on the right.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://en-ca.wordpress.org/2013/08/06/error-in-3-6-build/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"Long Weekend, Long Awaite WordPress 3.6 Released\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://en-ca.wordpress.org/2013/08/01/long-weekend-long-awaite-wordpress-3-6-released/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://en-ca.wordpress.org/2013/08/01/long-weekend-long-awaite-wordpress-3-6-released/#respond\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Aug 2013 23:02:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=229\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:176:\"Hello everyone, it is the Thursday before the long weekend across Canada, and the next edition of WordPress 3.6. It is named Oscar after the legendary preformer Oscar Peterson.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:191:\"<p>Hello everyone, it is the Thursday before the long weekend across Canada, and the next edition of WordPress 3.6.</p>
<p>It is named Oscar after the legendary preformer Oscar Peterson.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://en-ca.wordpress.org/2013/08/01/long-weekend-long-awaite-wordpress-3-6-released/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:39:\"
		
		
		
		
				
		
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"WordPress 3.5.2 – Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://en-ca.wordpress.org/2013/06/21/wordpress-3-5-2-security-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 21 Jun 2013 20:56:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:5:\"en_CA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=218\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:358:\"Good day folks! The core WordPress team has released an important security release. Please update you sites now. If there are any problems with the update, post a comment here. Update: The post about the update is here https://wordpress.org/news/2013/06/wordpress-3-5-2/ There was an issue with the original file. It has been rebuilt and can be updated now.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:462:\"<p>Good day folks! The core WordPress team has released an important security release. Please update you sites now. If there are any problems with the update, post a comment here.</p>
<p>Update: The post about the update is here <a href=\"https://wordpress.org/news/2013/06/wordpress-3-5-2/\" target=\"_blank\">https://wordpress.org/news/2013/06/wordpress-3-5-2/</a></p>
<p>There was an issue with the original file. It has been rebuilt and can be updated now.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:36:\"
		
		
		
		
				
		

		
		
				
			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Support Questions\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://en-ca.wordpress.org/2013/03/03/support-questions/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 03 Mar 2013 15:06:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:4:\"News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:7:\"support\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://en-ca.wordpress.org/?p=127\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:342:\"I have been getting quite a few questions in the contact form. Here are the common questions and answers. 1. I lost my password: You can find help here Resetting Your Password « WordPress Codex or if you are using WordPress.com then try here Passwords — Support — WordPress.com 2. My site is not loading/working: Try to find [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Charles E. Frees-Melvin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1379:\"<p>I have been getting quite a few questions in the contact form. Here are the common questions and answers.</p>
<p>1. I lost my password: You can find help here <a href=\"https://codex.wordpress.org/Resetting_Your_Password\">Resetting Your Password « WordPress Codex</a> or if you are using WordPress.com then try here <a href=\"http://en.support.wordpress.com/passwords/\">Passwords — Support — WordPress.com</a></p>
<p>2. My site is not loading/working: Try to find your answer here <a href=\"https://codex.wordpress.org/Troubleshooting\">https://codex.wordpress.org/Troubleshooting</a></p>
<p>3. A WordPress site has information I want taken down. You need to contact the site owner or their web host. WordPress is open source software users can install on a web server, it is not hosted by us. If it is on a WordPress.com site then you should report it here <a href=\"http://en.wordpress.com/abuse/\">http://en.wordpress.com/abuse/</a>. A good resource on this topic is available here <a href=\"http://lorelle.wordpress.com/2006/04/10/what-do-you-do-when-someone-steals-your-content\">What Do You Do When Someone Steals Your Content « Lorelle on WordPress</a>.</p>
<p>Also if it is a general support question and not specific to the Canadian English translation the there is a support forum at <a href=\"https://wordpress.org/support\">https://wordpress.org/support</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:38:\"https://en-ca.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 29 Dec 2017 17:44:29 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Fri, 29 Dec 2017 17:38:54 GMT\";s:4:\"link\";s:64:\"<https://en-ca.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}}s:5:\"build\";s:14:\"20171220203310\";}", "no");
INSERT INTO `wp_options` VALUES("654", "_transient_timeout_feed_mod_53c6368e164927c356de1596c8cebec9", "1514612669", "no");
INSERT INTO `wp_options` VALUES("655", "_transient_feed_mod_53c6368e164927c356de1596c8cebec9", "1514569469", "no");
INSERT INTO `wp_options` VALUES("656", "_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9", "1514612671", "no");
INSERT INTO `wp_options` VALUES("657", "_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9", "a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: WPWeekly Episode 299 – 2017 Year in Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=77120&preview=true&preview_id=77120\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wptavern.com/wpweekly-episode-299-2017-year-in-review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:19514:\"<p>In this episode, <a href=\"https://jjj.blog/\">John James Jacoby</a> and I review the WordPress news that made headlines on the Tavern in 2017. Among the stories we talk about more in-depth was Headway Themes, WP-CLI becoming a WordPress.org sanctioned project, and Disqus being acquired. We also talked about the future of comments in WordPress and what circumstances could lead to <a href=\"https://intensedebate.com/\">Intense Debate</a> being relevant again.</p>
<p>Last but not least, we offered up our thoughts for the New Year. Shout out to <a href=\"https://gist.github.com/kevinwhoffman\">Kevin Hoffman</a> who submitted a five-star review for WP Weekly on <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">iTunes</a>. Thank you to all of the listeners who have and continue to listen to WordPress Weekly.</p>
<h2>Stories Discussed:</h2>
<h3>January</h3>
<p><a href=\"https://wptavern.com/wp-cli-gets-official-wordpress-org-support\">WP-CLI Gets Official WordPress.org Support</a><br />
<a href=\"https://wptavern.com/wordpress-4-7-1-fixes-eight-security-issues\">WordPress 4.7.1 Fixes Eight Security Issues</a><br />
<a href=\"https://wptavern.com/automattic-releases-free-plugin-for-exporting-photos-from-lightroom-to-wordpress\">Automattic Releases Free Plugin for Exporting Photos from Lightroom to WordPress</a><br />
<a href=\"https://wptavern.com/aaron-d-campbell-replaces-nikolay-bachiyski-as-wordpress-security-czar\">Aaron D. Campbell Replaces Nikolay Bachiyski as WordPress&#8217; Security Czar</a><br />
<a href=\"https://wptavern.com/postmatic-basic-rebrands-as-replyable-moves-two-way-email-commenting-to-saas-product\">Postmatic Basic Rebrands as Replyable, Moves Two-Way Email Commenting to SaaS Product</a><br />
<a href=\"https://wptavern.com/jetpack-4-5-expands-monetization-with-wordads-integration\">Jetpack 4.5 Expands Monetization with WordAds Integration</a><br />
<a href=\"https://wptavern.com/obama-foundation-launches-new-website-powered-by-wordpress\">Obama Foundation Launches New Website Powered by WordPress</a><br />
<a href=\"https://wptavern.com/wix-removes-gpl-licensed-wordpress-code-from-mobile-app-forks-original-mit-library\">Wix Removes GPL-Licensed WordPress Code from Mobile App, Forks Original MIT Library</a></p>
<h3>February</h3>
<p><a href=\"https://wptavern.com/10up-unveils-elasticpress-io-elasticsearch-as-a-service-for-wordpress-sites\">10up Unveils ElasticPress.io: Elasticsearch as a Service for WordPress Sites</a><br />
<a href=\"https://wptavern.com/matt-mullenweg-responds-to-security-rant-digital-signatures-for-wordpress-updates-are-important-but-not-a-priority\">Matt Mullenweg Responds to Security Rant: Digital Signatures for WordPress Updates Are Important but Not a Priority</a><br />
<a href=\"https://wptavern.com/buddypress-2-8-boosts-minimum-php-requirement-adds-twenty-seventeen-companion-stylesheet\">BuddyPress 2.8 Boosts Minimum PHP Requirement, Adds Twenty Seventeen Companion Stylesheet</a><br />
<a href=\"https://wptavern.com/wordpress-core-editor-team-publishes-ui-prototype-for-gutenberg-an-experimental-block-based-editor\">WordPress Core Editor Team Publishes UI Prototype for &#8220;Gutenberg,&#8221; an Experimental Block Based Editor</a><br />
<a href=\"https://wptavern.com/zerif-lite-returns-to-wordpress-org-after-5-month-suspension-and-63-decline-in-revenue\">Zerif Lite Returns to WordPress.org after 5-Month Suspension and 63% Decline in Revenue</a><br />
<a href=\"https://wptavern.com/cloudflare-memory-leak-exposes-private-data\">Cloudflare Memory Leak Exposes Private Data</a><br />
<a href=\"https://wptavern.com/freemius-launches-insights-for-wordpress-themes\">Freemius Launches Insights for WordPress Themes</a><br />
<a href=\"https://wptavern.com/hackerone-launches-free-community-edition-for-non-commercial-open-source-projects\">HackerOne Launches Free Community Edition for Non-Commercial Open Source Projects</a></p>
<h3>March</h3>
<p><a href=\"https://wptavern.com/web-annotations-are-now-a-w3c-standard-paving-the-way-for-decentralized-annotation-infrastructure\">Web Annotations are Now a W3C Standard, Paving the Way for Decentralized Annotation Infrastructure</a><br />
<a href=\"https://wptavern.com/wordpress-4-7-3-patches-six-security-vulnerabilities-immediate-update-advised\">WordPress 4.7.3 Patches Six Security Vulnerabilities, Immediate Update Advised</a><br />
<a href=\"https://wptavern.com/wefoster-launches-hosting-platform-catered-to-online-communities\">WeFoster Launches Hosting Platform Catered to Online Communities</a><br />
<a href=\"https://wptavern.com/jetpack-introduces-theme-installation-from-wordpress-com-sparks-controversy-with-alternative-marketplace-for-free-themes\">Jetpack Introduces Theme Installation from WordPress.com, Sparks Controversy with Alternative Marketplace for Free Themes</a><br />
<a href=\"https://wptavern.com/pressshack-forks-edit-flow-to-create-publishpress-aims-to-improve-multi-user-editorial-workflow-in-wordpress\">PressShack Forks Edit Flow to Create PublishPress, Aims to Improve Multi-User Editorial Workflow in WordPress</a><br />
<a href=\"https://wptavern.com/yoast-seo-4-5-urges-users-to-upgrade-to-php-7\">Yoast SEO 4.5 Urges Users to Upgrade to PHP 7</a><br />
<a href=\"https://wptavern.com/foxhound-is-the-first-rest-api-powered-theme-on-wordpress-org\">Foxhound Is the First REST API Powered Theme on WordPress.org</a><br />
<a href=\"https://wptavern.com/godaddy-acquires-sucuri\">GoDaddy Acquires Sucuri</a><br />
<a href=\"https://wptavern.com/wordpress-relaunches-plugin-directory-with-new-design-and-improved-search-algorithm\">WordPress Relaunches Plugin Directory with New Design and Improved Search Algorithm</a><br />
<a href=\"https://wptavern.com/poopy-life-lets-you-create-free-unlimited-wordpress-test-installs\">Poopy.life Lets You Create Free, Unlimited WordPress Test Installs</a><br />
<a href=\"https://wptavern.com/wordpress-community-support-shuts-down-wordcamp-netherlands-in-favor-of-city-based-wordcamps\">WordPress Community Support Shuts Down WordCamp Netherlands in Favor of City-Based WordCamps</a></p>
<h3>April</h3>
<p><a href=\"https://wptavern.com/woocommerce-3-0-brings-major-improvements-to-product-gallery-introduces-crud-classes-and-a-new-cli\">WooCommerce 3.0 Brings Major Improvements to Product Gallery, Introduces CRUD Classes and a New CLI</a><br />
<a href=\"https://wptavern.com/jetpack-4-8-introduces-settings-redesign-adds-global-wordpress-com-toolbar\">Jetpack 4.8 Introduces Settings Redesign, Adds Global WordPress.com Toolbar</a><br />
<a href=\"https://wptavern.com/yoast-seos-php-upgrade-nag-is-producing-a-significant-increase-in-sites-upgrading-to-php-7\">Yoast SEO&#8217;s PHP Upgrade Nag is Producing a Significant Increase in Sites Upgrading to PHP 7</a><br />
<a href=\"https://wptavern.com/buddypress-2016-survey-results-show-54-of-respondents-are-on-php-7-0\">BuddyPress 2016 Survey Results Show 54% of Respondents are on PHP 7.0+</a><br />
<a href=\"https://wptavern.com/wordpress-4-7-4-fixes-visual-editor-incompatibility-with-upcoming-version-of-chrome\">WordPress 4.7.4 Fixes 47 Issues</a><br />
<a href=\"https://wptavern.com/headway-themes-appears-to-be-dying-a-slow-death\">Headway Themes Appears to be Dying a Slow Death</a><br />
<a href=\"https://wptavern.com/shopify-discontinues-its-official-plugin-for-wordpress\">Shopify Discontinues Its Official Plugin for WordPress</a></p>
<h3>May</h3>
<p><a href=\"https://wptavern.com/10up-releases-wp-docker-an-open-source-docker-configuration-for-local-wordpress-development\">10up Releases WP Docker, an Open Source Docker Configuration for Local WordPress Development</a><br />
<a href=\"https://wptavern.com/jetpack-4-9-introduces-eu-cookie-law-banner-widget\">Jetpack 4.9 Introduces EU Cookie Law Banner Widget</a><br />
<a href=\"https://wptavern.com/weglot-multilingual-plugin-closes-450k-in-seed-funding\">Weglot Multilingual Plugin Closes €450K in Seed Funding</a><br />
<a href=\"https://wptavern.com/wordpress-is-now-on-hackerone-launches-bug-bounties\">WordPress Is Now on HackerOne, Launches Bug Bounties</a><br />
<a href=\"https://wptavern.com/hookr-plugin-rebrands-as-wp-inspect-project-to-shift-to-a-module-based-architecture\">Hookr Plugin Rebrands as WP Inspect, Project to Shift to a Module-Based Architecture</a><br />
<a href=\"https://wptavern.com/wordpress-4-7-5-patches-six-security-issues-immediate-update-recommended\">WordPress 4.7.5 Patches Six Security Issues, Immediate Update Recommended</a><br />
<a href=\"https://wptavern.com/storefront-2-2-0-released-includes-design-refresh-and-major-improvements-to-new-user-experience\">Storefront 2.2.0 Released, Includes Design Refresh and Major Improvements to New User Experience</a><br />
<a href=\"https://wptavern.com/rainmaker-digital-to-partner-with-nimble-worldwide\">Rainmaker Digital to Partner with Nimble Worldwide</a><br />
<a href=\"https://wptavern.com/wordpress-removes-hhvm-from-testing-infrastructure\">WordPress Removes HHVM from Testing Infrastructure</a><br />
<a href=\"https://wptavern.com/wp-cli-1-2-0-released-project-unveils-new-logo\">WP-CLI 1.2.0 Released, Project Unveils New Logo</a></p>
<h3>June</h3>
<p><a href=\"https://wptavern.com/wpforms-acquires-wp-mail-smtp-plugin\">WPForms Acquires WP Mail SMTP Plugin</a><br />
<a href=\"https://wptavern.com/versionpress-launches-versionpress-com-to-fund-open-source-project\">VersionPress Launches VersionPress.com to Fund Open Source Project</a><br />
<a href=\"https://wptavern.com/wordpress-4-8-evans-released-featuring-nearby-wordpress-events-new-media-widgets-and-link-boundaries\">WordPress 4.8 &#8220;Evans&#8221; Released Featuring Nearby WordPress Events, New Media Widgets, and Link Boundaries</a><br />
<a href=\"https://wptavern.com/imagely-acquires-teslathemes-is-seeking-other-acquisition-opportunities\">Imagely Acquires TeslaThemes, Is Seeking Other Acquisition Opportunities</a><br />
<a href=\"https://wptavern.com/9seeds-acquires-web-savvy-marketings-genesis-theme-store\">9seeds Acquires Web Savvy Marketing&#8217;s Genesis Theme Store</a><br />
<a href=\"https://wptavern.com/wordcamp-europe-2017-draws-1900-attendees-from-79-countries\">WordCamp Europe 2017 Draws 1900 Attendees from 79 Countries</a><br />
<a href=\"https://wptavern.com/woocommerce-drops-50-renewal-discount-on-subscriptions\">WooCommerce Drops 50% Renewal Discount on Subscriptions</a><br />
<a href=\"https://wptavern.com/wpshout-updates-and-acquires-wphierarchy-com\">WPShout Updates and Acquires WPHierarchy.com</a><br />
<a href=\"https://wptavern.com/wordpress-new-gutenberg-editor-now-available-as-a-plugin-for-testing\">WordPress&#8217; New Gutenberg Editor Now Available as a Plugin for Testing</a><br />
<a href=\"https://wptavern.com/automattic-to-renew-efforts-on-underscores-retire-components-starter-theme-generator\">Automattic to Renew Efforts on Underscores, Retire Components Starter-Theme Generator</a><br />
<a href=\"https://wptavern.com/woocommerce-3-1-adds-new-csv-product-importerexporter-improves-extension-management\">WooCommerce 3.1 Adds New CSV Product Importer/Exporter, Improves Extension Management</a><br />
<a href=\"https://wptavern.com/clef-is-shutting-down-june-6th\">Clef Shuts Down</a></p>
<h3>July</h3>
<p><a href=\"https://wptavern.com/jesse-petersen-founder-of-genesis-the-me-passes-away\">Jesse Petersen, Founder of Genesis The.me Passes Away</a><br />
<a href=\"https://wptavern.com/wangguard-plugin-author-shuts-down-splog-hunting-service-due-to-trauma-and-death-threats\">WangGuard Plugin Author Shuts Down Splog Hunting Service Due to Trauma and Death Threats</a><br />
<a href=\"https://wptavern.com/lets-encrypt-passes-100-million-certificates-issued-will-offer-wildcard-certificates-in-january-2018\">Let&#8217;s Encrypt Passes 100 Million Certificates Issued, Will Offer Wildcard Certificates in January 2018</a><br />
<a href=\"https://wptavern.com/10up-acquires-lift-ux\">10up Acquires Lift UX</a><br />
<a href=\"https://wptavern.com/aj-morris-acquires-ithemes-exchange\">AJ Morris Acquires iThemes Exchange</a><br />
<a href=\"https://wptavern.com/react-users-petition-facebook-to-re-license-react-js-after-apache-software-foundation-bans-bsdpatents-license-in-dependencies\">React Users Petition Facebook to Re-license React.js after Apache Software Foundation Bans BSD+Patents License in Dependencies</a><br />
<a href=\"https://wptavern.com/sitelock-acquires-patchmans-malware-and-vulnerability-detection-technology-expands-wordpress-customer-base-to-4-million\">SiteLock Acquires Patchman&#8217;s Malware and Vulnerability Detection Technology, Expands WordPress Customer Base to 4 Million</a><br />
<a href=\"https://wptavern.com/adobe-to-discontinue-flash-support-and-updates-in-2020\">Adobe to Discontinue Flash Support and Updates in 2020</a><br />
<a href=\"https://wptavern.com/blog-passes-100000-registrations-66-5-of-purchased-domains-are-in-use\">.blog Passes 100,000 Registrations, 66.5% of Purchased Domains are in Use</a></p>
<h3>August</h3>
<p><a href=\"https://wptavern.com/jetpack-5-2-brings-major-improvements-to-the-contact-form-module\">Jetpack 5.2 Brings Major Improvements to the Contact Form Module</a><br />
<a href=\"https://wptavern.com/wordpress-polyglots-team-fuels-international-community-growth-with-3rd-global-translation-day\">WordPress Polyglots Team Fuels International Community Growth with 3rd Global Translation Day</a><br />
<a href=\"https://wptavern.com/wordpress-4-8-1-released-adds-custom-html-widget\">WordPress 4.8.1 Released, Adds Custom HTML Widget</a><br />
<a href=\"https://wptavern.com/trademark-trial-and-appeal-board-dismisses-automattics-trademark-dispute-against-chris-pearson\">Trademark Trial and Appeal Board Dismisses Automattic&#8217;s Trademark Dispute Against Chris Pearson</a><br />
<a href=\"https://wptavern.com/wordpress-coms-business-plan-gives-subscribers-a-way-to-tap-into-wordpress-orgs-third-party-ecosystem\">WordPress.com&#8217;s Business Plan Gives Subscribers a Way to Tap into WordPress.org&#8217;s Third-party Ecosystem</a><br />
<a href=\"https://wptavern.com/maekit-acquires-wp-remote-plans-to-add-cloud-based-backup-services\">maekit Acquires WP Remote, Plans to Add Cloud-Based Backup Services</a><br />
<a href=\"https://wptavern.com/wordpress-org-now-allows-plugin-authors-to-specify-a-minimum-php-version-requirement\">WordPress.org Now Allows Plugin Authors to Specify a Minimum PHP Version Requirement</a><br />
<a href=\"https://wptavern.com/gutenberg-1-0-0-introduces-drag-and-drop-for-adding-image-blocks\">Gutenberg 1.0.0 Introduces Drag and Drop for Adding Image Blocks</a></p>
<h3>September</h3>
<p><a href=\"https://wptavern.com/jetpack-5-3-adds-php-7-1-compatibility-better-control-for-wordads-placement\">Jetpack 5.3 Adds PHP 7.1 Compatibility, Better Control for WordAds Placement</a><br />
<a href=\"https://wptavern.com/wordpress-org-adds-new-support-rep-role-for-plugin-pages\">WordPress.org Adds New Support Rep Role for Plugin Pages</a><br />
<a href=\"https://wptavern.com/wordpress-abandons-react-due-to-patents-clause-gutenberg-to-be-rewritten-with-a-different-library\">WordPress Abandons React due to Patents Clause, Gutenberg to be Rewritten with a Different Library</a><br />
<a href=\"https://wptavern.com/wordpress-4-8-2-patches-eight-security-vulnerabilities\">WordPress 4.8.2 Patches Eight Security Vulnerabilities</a><br />
<a href=\"https://wptavern.com/apply-filters-podcast-to-be-retired-after-83-episodes\">Apply Filters Podcast to be Retired after 83 Episodes</a><br />
<a href=\"https://wptavern.com/wordpress-com-adds-google-photos-integration-available-now-for-jetpack-enabled-sites\">WordPress.com Adds Google Photos Integration, Available Now for Jetpack-Enabled Sites</a></p>
<h3>October</h3>
<p><a href=\"https://wptavern.com/poopy-life-launches-pro-version-at-wpsandbox-io-aimed-at-theme-and-plugin-developers\">Poopy.life Launches Pro Version at WPsandbox.io Aimed at Theme and Plugin Developers</a><br />
<a href=\"https://wptavern.com/disqus-data-breach-affects-17-5-million-accounts\">Disqus Data Breach Affects 17.5 Million Accounts</a><br />
<a href=\"https://wptavern.com/gitlab-raises-20-million-series-c-round-adds-matt-mullenweg-to-board-of-directors\">GitLab Raises $20 Million Series C Round, Adds Matt Mullenweg to Board of Directors</a><br />
<a href=\"https://wptavern.com/woocommerce-3-2-adds-ability-to-apply-coupons-in-the-admin-introduces-pre-update-version-checks-for-extensions\">WooCommerce 3.2 Adds Ability to Apply Coupons in the Admin, Introduces Pre-Update Version Checks for Extensions</a><br />
<a href=\"https://wptavern.com/postman-smtp-plugin-forked-after-removal-from-wordpress-org-for-security-issues\">Postman SMTP Plugin Forked after Removal from WordPress.org for Security Issues</a><br />
<a href=\"https://wptavern.com/woocommerce-retires-canvas-theme-recommends-customers-migrate-to-storefront-theme\">WooCommerce Retires Canvas Theme, Recommends Customers Migrate to Storefront Theme</a><br />
<a href=\"https://wptavern.com/goodnight-firebug\">Firebug is Retired</a></p>
<h3>November</h3>
<p><a href=\"https://wptavern.com/wordpress-4-8-3-a-security-release-six-weeks-in-the-making\">WordPress 4.8.3, A Security Release Six Weeks in the Making</a><br />
<a href=\"https://wptavern.com/press-this-removed-from-wordpress-4-9-in-favor-of-a-plugin\">Press This Removed from WordPress 4.9 in Favor of a Plugin</a><br />
<a href=\"https://wptavern.com/bianca-welds-awarded-kim-parsell-travel-scholarship\">Bianca Welds Awarded Kim Parsell Travel Scholarship</a><br />
<a href=\"https://wptavern.com/jetpack-5-5-removes-syntax-highlighting-and-gallery-widget-for-compatibility-with-upcoming-wordpress-4-9-release\">Jetpack 5.5 Removes Syntax Highlighting and Gallery Widget for Compatibility</a><br />
<a href=\"https://wptavern.com/wordpress-4-9-released-with-major-improvements-to-customizer-workflow-updated-code-editors-and-new-core-gallery-widget\">WordPress 4.9 Released with Major Improvements to Customizer Workflow, Updated Code Editors, and New Core Gallery Widget</a><br />
<a href=\"https://wptavern.com/tailor-page-builder-plugin-discontinued-owners-cite-funding-gutenberg-and-competition\">Tailor Page Builder Plugin Discontinued, Owners Cite Funding, Gutenberg, and Competition</a><br />
<a href=\"https://wptavern.com/wordpress-4-9-1-released-fixes-page-template-bug\">WordPress 4.9.1 Released, Fixes Page Template Bug</a><br />
<a href=\"https://wptavern.com/wpweekly-episode-296-gutenberg-telemetry-calypso-and-more-with-matt-mullenweg\">WPWeekly Episode 296 – Gutenberg, Telemetry, Calypso, and More With Matt Mullenweg</a></p>
<h3>December</h3>
<p><a href=\"https://wptavern.com/storify-to-close-may-16-2018-wordpress-plugin-discontinued\">Storify to Close May 16, 2018, WordPress Plugin Discontinued</a><br />
<a href=\"https://wptavern.com/jetpack-5-6-1-increases-security-of-the-contact-form-module\">Jetpack 5.6.1 Increases Security of the Contact Form Module</a><br />
<a href=\"https://wptavern.com/wp-site-care-acquires-wp-radius\">WP Site Care Acquires WP Radius<b></b></a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, January 3rd at 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p><strong>Listen To Episode #299:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 28 Dec 2017 02:08:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"HeroPress: My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2369\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:190:\"https://heropress.com/essays/journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai/#utm_source=rss&utm_medium=rss&utm_campaign=journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:16183:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/12/122717-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: My WordPress journey over the last two years has been excellent, filled with beautiful surprises.\" /><p>In my early childhood, my parents were told that I had <a href=\"https://en.wikipedia.org/wiki/Dyslexia\">dyslexia</a> and <a href=\"https://en.wikipedia.org/wiki/Dyscalculia\">dyscalculia</a>. They were told that with this drawback, I would never achieve anything constructive in my life. My parents were a little shocked as they had no clue what was dyslexia and dyscalculia and how to handle the situation. They never gave up on me and believe that I could reach great success in life. They found a tutor for me who was able to train me to do better and gave me the same treatment as other students.</p>
<p>As a student suffering from dyslexia and dyscalculia, I had an option to skip Maths and opt for an additional subject in  in 8th grade. Computer as an additional subject was introduced to me. It was the first time I was introduced to the world of internet. I started researching what internet has to offer and how it works. Those days email and website were all new and fascinating. My father bought our first desktop so I can do my research at home.</p>
<blockquote><p>My father wanted to turn my love for the computer into something more constructive to help me in my future.</p></blockquote>
<p>After 12th standard, my father enrolled me in a short computer course from NIIT to develop new skills and polish my old skills. Once the course was over, my teacher was so impressed with my performance that she advised my father to enroll me in a 3 years Software Development course. This course was carried out in parallel with my regular college. I would become both a graduate and a software developer at the same time. My father happily enrolled me.</p>
<p>(PS: I was a bit disappointed as I had to juggle 2 courses together during my college days. I thought it would be very difficult to concentrate on both things. BUT to be honest today when I look back, I feel that I enjoyed doing both college and NIIT together.)</p>
<p>During the 3 year period, I learned different languages like C Sharp, C, C++, Java, and dotNet.</p>
<p>After I completed my graduation and NIIT course, I was confused which field to select and apply for a job. There was a rule in NIIT, I had to complete 1 year of internship after my course. If due to any circumstance I could not complete, I would not get the certificate. My parents had spent a lot of money on my course and I didn&#8217;t want their hard earned money to go down the drain so I started going for different interviews in the IT field. My father had advised me that if after one year I was not happy with my IT job, I can quit and pursue Banking career.</p>
<blockquote><p>In 2009 on my birthday to my surprise and good fortune, I passed an interview and joined a company. On the first day, I was introduced to WordPress.</p></blockquote>
<p>I got an assignment to change the look and feel of WordPress dashboard. This assignment had to be completed within the next 6 hours. I had no clue what WordPress was. I was looking at the whiteboard in front of me and thinking this assignment is not possible to complete within 6 hours. I thought my boss was joking (Bosses generally joke with interns).</p>
<p>Guess who came to the rescue. GOOGLE. <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>
<p>I started researching about WordPress on how it works and how to use it. After 2 hours, when I was comfortable using WordPress, I started searching how to change look and feel of WordPress Admin Dashboard. Thankfully, I found a plugin which can change the look and feel of the WordPress Dashboard. I learned how to install and work with it. After trying different combinations of color and style, I finally completed the assignment with 2 hours to spare. My boss was happy.</p>
<p>Unfortunately after 4 days of working with WordPress, I was shifted to another CMS. I started working with the other CMS for so long that I completely forgot about WordPress. I worked with that particular CMS for 5 years.</p>
<h3>Coming Back To WordPress</h3>
<p>After 5 years, my office got an international project in WordPress. My boss told me to lead the project. I was hesitant since I had lost touch with WordPress. But I decided this is a great opportunity to become a team leader and lead from front. I decided to update my WordPress skills. Google GOD came to my rescue again. I updated my skills and also taught my junior team members all about WordPress. My juniors team members who never knew anything about WordPress, started to love and use WordPress frequently after my training. My team completed the project in 2 weeks. This project got me back in WordPress for good.</p>
<p>As a team leader, one needs to help juniors to solve issues and guide them wherever necessary. I never always had the answer to their problems. I did not have any friends from the WordPress world who I can just talk to and discuss things. All my friends were either in dotNet OR commerce fields. For this reason, I was in look out for some kind group which would help me expand my scope of knowledge in WordPress.</p>
<h3>Finding the Community</h3>
<p>In 2015, when I was browsing Facebook, I came across an ad about WordCamp Mumbai. I missed out on the event by 2 days. Somehow I found the meetup website and joined the WordPress Mumbai meetup group.</p>
<p>At the beginning, I didn’t have time and there wasn’t any topic that interested or motivated me to attend the meetup. It was either clashing with shopping or work or outing with friends or something or the other. Finally, after months I found one interesting topic, and in the comments section, they had mentioned that it will be a beginner level workshop. Finally I decided attend the meetup at any cost. I rescheduled all my plans so I could attend the meetup.</p>
<p>I remember I was on my way to the meetup and was talking to my best friend on phone. I was a bit nervous as I didn’t know anyone there. I could not find the place for the meetup. I told my friend that I am taking a U-turn and going home. BUT to my disadvantage, I finally found the venue and I decided to attend the meetup. In the first 15 mins of the meetup I realized that it’s not a beginners topics. Once the meetup ended, I got up from my seat and left immediately. I was unhappy with the way it was presented.</p>
<blockquote><p>After a few months, another great topic was announced in the meetup group. My heart told me to take a chance again.</p></blockquote>
<p>Thankfully this time I knew the venue (same as last time). I attend the meetup and was happy with the way it was presented and learnt a few important tips. After the meetup was over the speaker took time and spoke to individual attendees. When he come to me, I took the opportunity and asked a couple of issues I had with one of my project. He sweetly gave me tips how to deal with my issues.</p>
<p>The next day to my surprise I receive a message from the team leader Alexander Gounder. He asked me if I want to speak at a meetup. I politely declined the offer as I was not confident. After this, for a couple of the next meetup, I attended and got to know a few people. During that period, there were talks about WordCamp Mumbai 2016.</p>
<h3>Taking Part In WordCamp</h3>
<p>I showed an interest to be a part of the team who handles WordCamp Mumbai. I thought WordCamp was a conference where 100 or more people attend it. On the first day of WordCamp Mumbai, I was surprised to see so many WordCamp enthusiastic attending and enjoying this event.</p>
<a href=\"https://heropress.com/wp-content/uploads/2018/12/wcmumbai16-group_photo.jpg\"><img class=\"wp-image-2374 size-full\" src=\"https://heropress.com/wp-content/uploads/2018/12/wcmumbai16-group_photo.jpg\" alt=\"WordCamp Mumbai 2016\" width=\"1000\" height=\"358\" /></a>WordCamp Mumbai 2016
<p>&nbsp;</p>
<a href=\"https://heropress.com/wp-content/uploads/2018/12/wcmumbai16-localhost-min.jpg\"><img class=\"wp-image-2382 size-full\" src=\"https://heropress.com/wp-content/uploads/2018/12/wcmumbai16-localhost-min.jpg\" alt=\"\" width=\"1000\" height=\"664\" /></a>WordCamp Mumbai 2016
<p>After seeing a successful WordCamp 2016, I try to attend as many meetups as possible.</p>
<p>I started with an entry-level role with basic responsibilities in my first WordCamp 2016. Gradually I started taking an active part in volunteering taking over more responsibilities. In WordCamp 2017 I handled speaker profiles and social media promotions. In WordCamp 2018, I am getting to know more about what all an organiser needs to do from planning to execution, to make the event the WordCamp an successful event.</p>
<p><b>WordCamp Mumbai 2017</b></p>
<a href=\"https://heropress.com/wp-content/uploads/2018/12/wcmumbai2017-1.jpg\"><img class=\"size-full wp-image-2375\" src=\"https://heropress.com/wp-content/uploads/2018/12/wcmumbai2017-1.jpg\" alt=\"WordCamp Mumbai 2017\" width=\"668\" height=\"337\" /></a>WordCamp Mumbai 2017
<p>After spending 3 years with WordPress Mumbai Community, I am glad to be part of this amazing team. My WordPress journey over the last two years has been excellent, filled with beautiful surprises.</p>
<p>I have been interviewed twice. Never in my wildest dreams did I ever thought that someone would interview me. <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /> My first ever interview was with <a href=\"https://www.wpwatercooler.com/video/community-connections-wordpress-at-home-in-india-w-meher-bala/\">Bridget and Jen for Community Connections by WPwatercooler</a>. Second was with <a href=\"https://courses.wpshout.com/\">David Hayes for WPShout on WordPress Security</a>.</p>
<p>Some highlights events are as below:</p>
<ol>
<li>Introduced to Rosie pins &#8211; Wapuu for Women Who WordPress.</li>
<li>Travelled to different cities across India, just to attended wordcamps.</li>
<li>Made many new friends locally and international.</li>
<li>Conducted a meetup on “Contributing to WordPress”.</li>
<li>Conducted a panel discussion at WC Nashik 2017.</li>
<li>Running a FB group especially for Indian WordPress Women Community.</li>
<li>Writing an article for HeroPress.</li>
<li>Contributing my part in the Marketing Team WordPress .</li>
</ol>
<table border=\"0\">
<tbody>
<tr>
<td>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/12/speaker-badge.jpg\"><img class=\"wp-image-2376\" src=\"https://heropress.com/wp-content/uploads/2018/12/speaker-badge-215x300.jpg\" alt=\"Speaker Badge - WC Nashik 2017\" width=\"300\" height=\"418\" /></a>Speaker Badge &#8211; WC Nashik 2017</td>
<td>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/12/panel-discussion-selfie.jpg\"><img class=\"wp-image-2377\" src=\"https://heropress.com/wp-content/uploads/2018/12/panel-discussion-selfie-300x225.jpg\" alt=\"Panel Group Selfie - WC Nashik 2017\" width=\"400\" height=\"300\" /></a>Panel Group Selfie &#8211; WC Nashik 2017</td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr>
<td>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/12/wp-profile.png\"><img class=\"size-medium wp-image-2378\" src=\"https://heropress.com/wp-content/uploads/2018/12/wp-profile-300x132.png\" alt=\"Different Badges - WordPress Profile\" width=\"300\" height=\"132\" /></a>Different Badges &#8211; WordPress Profile</td>
<td>
<p><a href=\"https://heropress.com/wp-content/uploads/2018/12/presentation-my-talk.jpg\"><img class=\"wp-image-2379\" src=\"https://heropress.com/wp-content/uploads/2018/12/presentation-my-talk-300x153.jpg\" alt=\"Conducted my first meetup - WordPress Mumbai\" width=\"400\" height=\"204\" /></a>Conducted my first meetup &#8211; WordPress Mumbai</td>
</tr>
</tbody>
</table>
<p><b>My wish list for 2018:</b></p>
<ol>
<li>Apply as a speaker in at least one the WordCamp.</li>
<li>Attend and volunteer at an International WordCamp.</li>
<li>Attend and volunteer at WordCamp US 2018.</li>
<li>Meeting Matt Mullenweg hopefully (Fingers crossed!).</li>
<li>Meeting all my lovely international virtual friends at one of the WordCamps.</li>
</ol>
<p>One of my biggest dreams would be to lead WordCamp Mumbai as a lead organiser.</p>
<blockquote><p>My advice to all who earn their livelihood from WordPress is to try and give back to the WordPress community in any way possible.</p></blockquote>
<p>I am sure you will either learn something new <b>or</b> teach something new to someone else <b>or</b> just make new friendships.</p>
<p>At the end of the article, I take the opportunity to thank my grantparents, parents and my sister for always standing by me and believing me. I thank my teacher Ms. Amita, my boss Mr. Ivan Bayross, my WordPress friends, and my virtual international friends for always guiding and motivating me to stay focussed and to keep learning new things in life.</p>
<p>A big thank you to Topher for giving me an opportunity to write about my life journey.</p>
<p>Being dyslexic I still make mistakes and I know that I&#8217;m not perfect. But I know for sure there is no harm in making mistakes. You need to learn from them and grow your skills. Don&#8217;t let your disabilities get in the way of your success. If you are reading this article and can connect with my story, do let me know in the comment section. I would love to hear from you.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=My%20Journey%20from%20being%20a%20Dyslexic%20kid%20to%20becoming%20A%20Co-organiser%20For%20WordCamp%20Mumbai&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fjourney-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fjourney-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fjourney-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai%2F&title=My+Journey+from+being+a+Dyslexic+kid+to+becoming+A+Co-organiser+For+WordCamp+Mumbai\" rel=\"nofollow\" target=\"_blank\" title=\"Share: My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai/&media=https://heropress.com/wp-content/uploads/2018/12/122717-150x150.jpg&description=My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai/\" title=\"My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai/\">My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Dec 2017 02:23:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Meher Bala\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: NORAD’s Santa Tracker\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://ma.tt/2017/12/norads-santa-tracker/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://ma.tt/2017/12/norads-santa-tracker/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:432:\"<p>Politico has <a href=\"https://www.politico.com/amp/story/2017/12/24/norads-crazy-santa-cause-260254\">a lovely story on the history and present of the NORAD Santa Tracker</a>, which started because a 1955 Sears department store ad had &#8220;a digit wrong — and was instead the direct line into the secret military nerve center in Colorado Springs, Colo., where the Pentagon was on the lookout to prevent nuclear war.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 24 Dec 2017 14:25:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"Dev Blog: WordPress User Survey Data for 2015-2017\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5310\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wordpress.org/news/2017/12/wordpress-user-survey-data-for-2015-2017/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:61756:\"<p>For many years, we&#8217;ve invited folks to tell us how they use WordPress by filling out an annual survey. In the past, interesting results from this survey have been shared in the annual <a href=\"https://ma.tt/2017/12/state-of-the-word-2017/\">State of the Word</a> address. This year, for the first time, the results of the 2017 survey are being published on WordPress News, along with the results of the 2015 and 2016 survey.</p>
<p>So that information from the survey doesn&#8217;t reveal anything that respondents might consider private, we do not publish a full export of the raw data. We’d love to make this information as accessible as possible, though, so if you have a suggestion for an OS project or tool we can put the data into that allows people to play with it that still protects individual response privacy, please leave a comment on this post!</p>
<h4>Major Groups</h4>
<p>This survey features multiple groups, dividing respondents at the first question:</p>
<blockquote><p>Which of the following best describes how you use WordPress? (<em>Mandatory</em>)</p></blockquote>
<p>Those who selected &#8220;I&#8217;m a designer or developer, or I work for a company that designs/develops websites; I use WordPress to build websites and/or blogs for others. (This might include theme development, writing plugins, or other custom work.)&#8221; were served questions from what we&#8217;ll call the &#8220;WordPress Professionals&#8221; group.</p>
<p>This &#8220;WordPress Professionals&#8221; group is further divided into WordPress Company and WordPress Freelancer/Hobbyist groups, based on how the respondent answered the question, &#8220;Which of the following best describes your involvement with WordPress? (2015) / Do you work for a company, or on your own? (2016-17).&#8221;</p>
<p>Those who selected &#8220;I own, run, or contribute to a blog or website that is built with WordPress.&#8221; were served questions in what we&#8217;re calling the &#8220;WordPress Users&#8221; group.</p>
<p>The relevant survey group is noted in each table below. In the case of questions that were served to different groups in 2015 but then served to all respondents in 2016 and 2017, the group responses from 2015 have been consolidated into one set of data for easier comparison between years.</p>
<h4>Survey results</h4>
<p><a href=\"https://wordpress.org/news/feed/#pro\">Jump to answers from WordPress Professionals</a></p>
<p><a href=\"https://wordpress.org/news/feed/#user\">Jump to answers from WordPress Users</a></p>
<p><a href=\"https://wordpress.org/news/feed/#all\">Jump to answers from All Respondents</a></p>
<p><!--td {border: 1px solid #ccc;}br {mso-data-placement:same-cell;}--></p>
<h3>Which of the following best describes how you use WordPress? (Mandatory)</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td>Number of responses (since this question was mandatory, the number of responses here is the total number for the survey)</td>
<td>45,995</td>
<td></td>
<td>15,585</td>
<td></td>
<td>16,029</td>
<td></td>
</tr>
<tr>
<td>I&#8217;m a designer or developer, or I work for a company that designs/develops websites; I use WordPress to build websites and/or blogs for others. (This might include theme development, writing plugins, other custom work.)</td>
<td>26,662</td>
<td>58%</td>
<td>8,838</td>
<td>57%</td>
<td>9,099</td>
<td>57%</td>
</tr>
<tr>
<td>I own, run, or contribute to a blog or website that is built with WordPress.</td>
<td>16,130</td>
<td>35%</td>
<td>5,293</td>
<td>34%</td>
<td>5,625</td>
<td>35%</td>
</tr>
<tr>
<td>Neither of the above.</td>
<td>3,204</td>
<td>7%</td>
<td>1,460</td>
<td>9%</td>
<td>1,306</td>
<td>8%</td>
</tr>
</tbody>
</table>
<h2 id=\"pro\">WordPress Professionals</h2>
<h3><strong>Which of the following best describes your involvement with WordPress? (Mandatory, 2015) / Do you work for a company, or on your own? (Mandatory, 2016-17)</strong></h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Professional</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>26,699</td>
<td></td>
<td>8,838</td>
<td></td>
<td>9,101</td>
<td></td>
</tr>
<tr>
<td>My primary job is working for a company or organization that uses WordPress.</td>
<td>9,505</td>
<td>36%</td>
<td>3,529</td>
<td>40%</td>
<td>3,660</td>
<td>40%</td>
</tr>
<tr>
<td>My primary job is as a self-employed designer or developer that uses WordPress.</td>
<td>9,310</td>
<td>35%</td>
<td>3,188</td>
<td>36%</td>
<td>3,440</td>
<td>38%</td>
</tr>
<tr>
<td>I earn money from part-time or occasional freelance work involving WordPress.</td>
<td>5,954</td>
<td>22%</td>
<td>1,633</td>
<td>18%</td>
<td>1,590</td>
<td>17%</td>
</tr>
<tr>
<td>Work that I do involving WordPress is just a hobby, I don&#8217;t make money from it.</td>
<td>1,930</td>
<td>7%</td>
<td>491</td>
<td>6%</td>
<td>411</td>
<td>5%</td>
</tr>
</tbody>
</table>
<h3>How does your company or organization work with WordPress?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>9,342</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Build/design and/or maintain websites or blogs for other people, companies, or organizations.</td>
<td>7,772</td>
<td>27%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Develop or customize themes.</td>
<td>5,404</td>
<td>19%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Build/design and/or maintain websites or blogs for my own use.</td>
<td>4,733</td>
<td>16%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Host websites for customers.</td>
<td>4,397</td>
<td>15%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Develop or distribute plugins.</td>
<td>3,181</td>
<td>11%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Provide educational resources to help others to use WordPress.</td>
<td>1,349</td>
<td>5%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Sponsor and/or attend WordCamps.</td>
<td>1,127</td>
<td>4%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Contribute bug reports and/or patches to WordPress core.</td>
<td>914</td>
<td>3%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Other Option</td>
<td>182</td>
<td> 1%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td></td>
<td></td>
<td>3,457</td>
<td></td>
<td>3,598</td>
<td></td>
</tr>
<tr>
<td>We make websites for others.</td>
<td></td>
<td></td>
<td>2,695</td>
<td>24%</td>
<td>2,722</td>
<td>23%</td>
</tr>
<tr>
<td>We make websites for ourselves.</td>
<td></td>
<td></td>
<td>2,355</td>
<td>21%</td>
<td>2,470</td>
<td>21%</td>
</tr>
<tr>
<td>We develop or customize themes.</td>
<td></td>
<td></td>
<td>1,866</td>
<td>16%</td>
<td>1,910</td>
<td>16%</td>
</tr>
<tr>
<td>We host websites for others.</td>
<td></td>
<td></td>
<td>1,564</td>
<td>14%</td>
<td>1,595</td>
<td>14%</td>
</tr>
<tr>
<td>We develop or distribute plugins.</td>
<td></td>
<td></td>
<td>1,283</td>
<td>11%</td>
<td>1,342</td>
<td>11%</td>
</tr>
<tr>
<td>We provide educational resources to help others to use WordPress.</td>
<td></td>
<td></td>
<td>581</td>
<td>5%</td>
<td>631</td>
<td>5%</td>
</tr>
<tr>
<td>We sponsor and/or attend WordCamps.</td>
<td></td>
<td></td>
<td>561</td>
<td>5%</td>
<td>579</td>
<td>5%</td>
</tr>
<tr>
<td>We contribute bug reports and/or patches to WordPress core.</td>
<td></td>
<td></td>
<td>444</td>
<td>4%</td>
<td>468</td>
<td>4%</td>
</tr>
<tr>
<td>Other Option</td>
<td></td>
<td></td>
<td>98</td>
<td>1%</td>
<td>96</td>
<td>1%</td>
</tr>
</tbody>
</table>
<p><strong>How would you describe the business of your typical client(s)? (2015) / How would you describe the business of your typical client/customer? (2016, 2017)</strong></p>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>9,154</td>
<td></td>
<td>3,317</td>
<td></td>
<td>3,498</td>
<td></td>
</tr>
<tr>
<td>Small business</td>
<td>6,893</td>
<td>32%</td>
<td>2,398</td>
<td>31%</td>
<td>2,510</td>
<td>31%</td>
</tr>
<tr>
<td>Large business or Enterprise</td>
<td>3,635</td>
<td>17%</td>
<td>1,361</td>
<td>18%</td>
<td>1,447</td>
<td>18%</td>
</tr>
<tr>
<td>Non-profit</td>
<td>2,644</td>
<td>12%</td>
<td>934</td>
<td>12%</td>
<td>992</td>
<td>12%</td>
</tr>
<tr>
<td>Individual</td>
<td>2,600</td>
<td>12%</td>
<td>888</td>
<td>12%</td>
<td>1,022</td>
<td>12%</td>
</tr>
<tr>
<td>Education</td>
<td>2,344</td>
<td>11%</td>
<td>854</td>
<td>11%</td>
<td>966</td>
<td>12%</td>
</tr>
<tr>
<td>Website development (sub-contracting)</td>
<td>2,065</td>
<td>10%</td>
<td>637</td>
<td>8%</td>
<td>677</td>
<td>8%</td>
</tr>
<tr>
<td>Government</td>
<td>1,410</td>
<td>6%</td>
<td>524</td>
<td>7%</td>
<td>552</td>
<td>7%</td>
</tr>
<tr>
<td>Other Option</td>
<td>127</td>
<td>1%</td>
<td>66</td>
<td>1%</td>
<td>64</td>
<td>1%</td>
</tr>
</tbody>
</table>
<p><strong>How does your company or organization use WordPress when developing websites? (2015) / When making websites, how does your company or organization use WordPress? (2016, 2017)</strong></p>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>9,078</td>
<td></td>
<td>3,369</td>
<td></td>
<td>3,552</td>
<td></td>
</tr>
<tr>
<td>Mostly as a content management system (CMS)</td>
<td>6,361</td>
<td>70%</td>
<td>2,482</td>
<td>74%</td>
<td>2,640</td>
<td>74%</td>
</tr>
<tr>
<td>About half the time as a blogging platform and half the time as a CMS</td>
<td>1,222</td>
<td>13%</td>
<td>370</td>
<td>11%</td>
<td>383</td>
<td>11%</td>
</tr>
<tr>
<td>Mostly as a blogging platform</td>
<td>721</td>
<td>8%</td>
<td>137</td>
<td>4%</td>
<td>129</td>
<td>4%</td>
</tr>
<tr>
<td>Mostly as an application framework</td>
<td>629</td>
<td>7%</td>
<td>303</td>
<td>9%</td>
<td>303</td>
<td>9%</td>
</tr>
<tr>
<td>Other Option</td>
<td>145</td>
<td>2%</td>
<td>78</td>
<td>2%</td>
<td>97</td>
<td>3%</td>
</tr>
</tbody>
</table>
<h3>How much is your average WordPress site customized from the original WordPress installation?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>9,054</td>
<td></td>
<td>3,302</td>
<td></td>
<td>3,473</td>
<td></td>
</tr>
<tr>
<td>A lot of work has been done, the front end is unrecognizable, but the Dashboard still looks like the usual WordPress interface.</td>
<td>5,651</td>
<td>62%</td>
<td>2,025</td>
<td>61%</td>
<td>2,105</td>
<td>61%</td>
</tr>
<tr>
<td>There&#8217;s a different theme and some plugins have been added.</td>
<td>2,230</td>
<td>25%</td>
<td>799</td>
<td>24%</td>
<td>905</td>
<td>26%</td>
</tr>
<tr>
<td>Not at all, it&#8217;s still pretty much the same as the original download.</td>
<td>756</td>
<td>8%</td>
<td>302</td>
<td>9%</td>
<td>298</td>
<td>9%</td>
</tr>
<tr>
<td>You&#8217;d never know this was a WordPress installation, everything (including the admin) has been customized.</td>
<td>417</td>
<td>5%</td>
<td>177</td>
<td>5%</td>
<td>165</td>
<td>5%</td>
</tr>
</tbody>
</table>
<h3>Roughly how many currently active WordPress sites has your company or organization built?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>8,801</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>200 +</td>
<td>1,074</td>
<td>12%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>51 &#8211; 200</td>
<td>1,721</td>
<td>20%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>21 &#8211; 50</td>
<td>1,718</td>
<td>20%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>11 &#8211; 20</td>
<td>1,284</td>
<td>15%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>6 &#8211; 10</td>
<td>1,109</td>
<td>13%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>2 &#8211; 5</td>
<td>1,418</td>
<td>16%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1</td>
<td>390</td>
<td>4%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>0</td>
<td>87</td>
<td>1%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td></td>
<td></td>
<td>3,358</td>
<td></td>
<td>3,540</td>
<td></td>
</tr>
<tr>
<td>Thousands.</td>
<td></td>
<td></td>
<td>291</td>
<td>9%</td>
<td>331</td>
<td>9%</td>
</tr>
<tr>
<td>Hundreds.</td>
<td></td>
<td></td>
<td>770</td>
<td>23%</td>
<td>894</td>
<td>25%</td>
</tr>
<tr>
<td>Fewer than a hundred.</td>
<td></td>
<td></td>
<td>1,144</td>
<td>34%</td>
<td>1,177</td>
<td>33%</td>
</tr>
<tr>
<td>Just a few, but they are really great.</td>
<td></td>
<td></td>
<td>926</td>
<td>28%</td>
<td>896</td>
<td>25%</td>
</tr>
<tr>
<td>Prefer not to answer.</td>
<td></td>
<td></td>
<td>228</td>
<td>7%</td>
<td>242</td>
<td>7%</td>
</tr>
</tbody>
</table>
<h3>How many person-hours (of your company&#8217;s work) does the typical site take to complete?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>9,091</td>
<td></td>
<td>3,353</td>
<td></td>
<td>3,522</td>
<td></td>
</tr>
<tr>
<td>More than 200</td>
<td>939</td>
<td>10%</td>
<td>309</td>
<td>9%</td>
<td>325</td>
<td>9%</td>
</tr>
<tr>
<td>100 &#8211; 200</td>
<td>1080</td>
<td>12%</td>
<td>329</td>
<td>10%</td>
<td>367</td>
<td>10%</td>
</tr>
<tr>
<td>60 &#8211; 100</td>
<td>1541</td>
<td>17%</td>
<td>527</td>
<td>16%</td>
<td>513</td>
<td>15%</td>
</tr>
<tr>
<td>40 &#8211; 60</td>
<td>1854</td>
<td>20%</td>
<td>583</td>
<td>17%</td>
<td>620</td>
<td>18%</td>
</tr>
<tr>
<td>20 &#8211; 40</td>
<td>2066</td>
<td>23%</td>
<td>691</td>
<td>21%</td>
<td>685</td>
<td>19%</td>
</tr>
<tr>
<td>Fewer than 20</td>
<td>1611</td>
<td>18%</td>
<td>479</td>
<td>14%</td>
<td>519</td>
<td>15%</td>
</tr>
<tr>
<td>Prefer not to answer (2016, 2017)</td>
<td></td>
<td></td>
<td>436</td>
<td>13%</td>
<td>493</td>
<td>14%</td>
</tr>
</tbody>
</table>
<h3>Roughly what percentage of your company or organization&#8217;s output is based around WordPress (as opposed to other platforms or software)?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Company</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>8,950</td>
<td></td>
<td>3,345</td>
<td></td>
<td>3,503</td>
<td></td>
</tr>
<tr>
<td>100 %</td>
<td>1,089</td>
<td>12%</td>
<td>438</td>
<td>13%</td>
<td>480</td>
<td>14%</td>
</tr>
<tr>
<td>90 %</td>
<td>1,043</td>
<td>12%</td>
<td>417</td>
<td>12%</td>
<td>459</td>
<td>13%</td>
</tr>
<tr>
<td>80 %</td>
<td>955</td>
<td>11%</td>
<td>367</td>
<td>11%</td>
<td>424</td>
<td>12%</td>
</tr>
<tr>
<td>70 %</td>
<td>831</td>
<td>9%</td>
<td>305</td>
<td>9%</td>
<td>344</td>
<td>10%</td>
</tr>
<tr>
<td>60 %</td>
<td>534</td>
<td>6%</td>
<td>246</td>
<td>7%</td>
<td>226</td>
<td>6%</td>
</tr>
<tr>
<td>50 %</td>
<td>973</td>
<td>11%</td>
<td>335</td>
<td>10%</td>
<td>338</td>
<td>10%</td>
</tr>
<tr>
<td>40 %</td>
<td>613</td>
<td>7%</td>
<td>245</td>
<td>7%</td>
<td>202</td>
<td>6%</td>
</tr>
<tr>
<td>30 %</td>
<td>877</td>
<td>10%</td>
<td>335</td>
<td>10%</td>
<td>310</td>
<td>9%</td>
</tr>
<tr>
<td>20 %</td>
<td>806</td>
<td>9%</td>
<td>242</td>
<td>7%</td>
<td>280</td>
<td>8%</td>
</tr>
<tr>
<td>10 %</td>
<td>1,039</td>
<td>12%</td>
<td>344</td>
<td>10%</td>
<td>348</td>
<td>10%</td>
</tr>
<tr>
<td>0 %</td>
<td>190</td>
<td>2%</td>
<td>72</td>
<td>2%</td>
<td>92</td>
<td>3%</td>
</tr>
</tbody>
</table>
<h3>In which of the following ways do you work with WordPress?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>17,009</td>
<td></td>
<td>5,221</td>
<td></td>
<td>5,425</td>
<td></td>
</tr>
<tr>
<td>Build/design and/or maintain websites or blogs for other people, companies, or organizations</td>
<td>15,342</td>
<td>34%</td>
<td>4,795</td>
<td>34%</td>
<td>5,064</td>
<td>34%</td>
</tr>
<tr>
<td>Develop or customize themes</td>
<td>10,549</td>
<td>24%</td>
<td>2,997</td>
<td>21%</td>
<td>3,021</td>
<td>20%</td>
</tr>
<tr>
<td>Host websites for customers</td>
<td>8,142</td>
<td>18%</td>
<td>2,466</td>
<td>17%</td>
<td>2,728</td>
<td>18%</td>
</tr>
<tr>
<td>Develop or distribute plugins</td>
<td>4,125</td>
<td>9%</td>
<td>1,395</td>
<td>10%</td>
<td>1,416</td>
<td>9%</td>
</tr>
<tr>
<td>Provide educational resources to help others to use WordPress</td>
<td>3,276</td>
<td>7%</td>
<td>1,187</td>
<td>8%</td>
<td>1,308</td>
<td>9%</td>
</tr>
<tr>
<td>Sponsor and/or attend WordCamps</td>
<td>1,559</td>
<td>4%</td>
<td>648</td>
<td>5%</td>
<td>724</td>
<td>5%</td>
</tr>
<tr>
<td>Contribute bug reports and/or patches to WordPress core</td>
<td>1,107</td>
<td>2%</td>
<td>381</td>
<td>3%</td>
<td>393</td>
<td>3%</td>
</tr>
<tr>
<td>Other Option</td>
<td>389</td>
<td>1%</td>
<td>243</td>
<td>2%</td>
<td>299</td>
<td>2%</td>
</tr>
</tbody>
</table>
<h3>How would you describe the business of your typical client(s)?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>16,863</td>
<td></td>
<td>5,151</td>
<td></td>
<td>5,353</td>
<td></td>
</tr>
<tr>
<td>Small business</td>
<td>14,185</td>
<td>35%</td>
<td>4,342</td>
<td>35%</td>
<td>4,622</td>
<td>36%</td>
</tr>
<tr>
<td>Individual</td>
<td>8,513</td>
<td>21%</td>
<td>2,581</td>
<td>21%</td>
<td>2,583</td>
<td>20%</td>
</tr>
<tr>
<td>Non-profit</td>
<td>6,585</td>
<td>16%</td>
<td>2,004</td>
<td>16%</td>
<td>2,113</td>
<td>16%</td>
</tr>
<tr>
<td>Website development (sub-contracting)</td>
<td>4,301</td>
<td>11%</td>
<td>1,258</td>
<td>10%</td>
<td>1,216</td>
<td>9%</td>
</tr>
<tr>
<td>Education</td>
<td>3,458</td>
<td>8%</td>
<td>1,049</td>
<td>8%</td>
<td>1,139</td>
<td>9%</td>
</tr>
<tr>
<td>Large business or Enterprise</td>
<td>2,391</td>
<td>6%</td>
<td>805</td>
<td>6%</td>
<td>857</td>
<td>7%</td>
</tr>
<tr>
<td>Government</td>
<td>1,150</td>
<td>3%</td>
<td>300</td>
<td>2%</td>
<td>329</td>
<td>3%</td>
</tr>
<tr>
<td>Other Option</td>
<td>173</td>
<td>0%</td>
<td>101</td>
<td>1%</td>
<td>99</td>
<td>1%</td>
</tr>
</tbody>
</table>
<h3>How do you use WordPress in your development?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>16,768</td>
<td></td>
<td>5,145</td>
<td></td>
<td>5,372</td>
<td></td>
</tr>
<tr>
<td>Mostly as a content management system (CMS)</td>
<td>11,754</td>
<td>70%</td>
<td>3,641</td>
<td>71%</td>
<td>3,959</td>
<td>74%</td>
</tr>
<tr>
<td>About half the time as a blogging platform and half the time as a CMS</td>
<td>2,825</td>
<td>17%</td>
<td>812</td>
<td>16%</td>
<td>721</td>
<td>13%</td>
</tr>
<tr>
<td>Mostly as an application framework</td>
<td>1,012</td>
<td>6%</td>
<td>343</td>
<td>7%</td>
<td>344</td>
<td>6%</td>
</tr>
<tr>
<td>Mostly as a blogging platform</td>
<td>992</td>
<td>6%</td>
<td>246</td>
<td>5%</td>
<td>226</td>
<td>4%</td>
</tr>
<tr>
<td>Other Option</td>
<td>185</td>
<td>1%</td>
<td>105</td>
<td>2%</td>
<td>122</td>
<td>2%</td>
</tr>
</tbody>
</table>
<h3>How much is your average WordPress site customized from the original WordPress installation?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>16,699</td>
<td></td>
<td>5,131</td>
<td></td>
<td>5,317</td>
<td></td>
</tr>
<tr>
<td>A lot of work has been done, the front end is unrecognizable, but the Dashboard still looks like the usual WordPress interface.</td>
<td>9,457</td>
<td>57%</td>
<td>2,837</td>
<td>55%</td>
<td>2,998</td>
<td>56%</td>
</tr>
<tr>
<td>There&#8217;s a different theme and some plugins have been added.</td>
<td>5,526</td>
<td>33%</td>
<td>1,694</td>
<td>33%</td>
<td>1,781</td>
<td>34%</td>
</tr>
<tr>
<td>Not at all, it&#8217;s still pretty much the same as the original download.</td>
<td>977</td>
<td>6%</td>
<td>341</td>
<td>7%</td>
<td>310</td>
<td>6%</td>
</tr>
<tr>
<td>You&#8217;d never know this was a WordPress installation, everything (including the admin) has been customized.</td>
<td>739</td>
<td>4%</td>
<td>261</td>
<td>5%</td>
<td>228</td>
<td>4%</td>
</tr>
</tbody>
</table>
<h3>How many currently active WordPress sites have you built? (2015) / Roughly how many currently active WordPress sites have you built? (2016, 2017)</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>16,690</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>200 +</td>
<td>514</td>
<td>3%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>51 &#8211; 200</td>
<td>1,728</td>
<td>10%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>21 &#8211; 50</td>
<td>3,000</td>
<td>18%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>11 &#8211; 20</td>
<td>3,146</td>
<td>19%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>6 &#8211; 10</td>
<td>3,405</td>
<td>20%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>2 &#8211; 5</td>
<td>3,838</td>
<td>23%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>1</td>
<td>698</td>
<td>4%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>0</td>
<td>361</td>
<td>2%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td></td>
<td></td>
<td>5,165</td>
<td></td>
<td>5367</td>
<td></td>
</tr>
<tr>
<td>Thousands.</td>
<td></td>
<td></td>
<td>110</td>
<td>2%</td>
<td>104</td>
<td>2%</td>
</tr>
<tr>
<td>Hundreds.</td>
<td></td>
<td></td>
<td>603</td>
<td>12%</td>
<td>713</td>
<td>13%</td>
</tr>
<tr>
<td>Fewer than a hundred.</td>
<td></td>
<td></td>
<td>2,264</td>
<td>44%</td>
<td>2,457</td>
<td>46%</td>
</tr>
<tr>
<td>Just a few, but they are really great.</td>
<td></td>
<td></td>
<td>1,871</td>
<td>36%</td>
<td>1,813</td>
<td>34%</td>
</tr>
<tr>
<td>Prefer not to answer.</td>
<td></td>
<td></td>
<td>319</td>
<td>6%</td>
<td>280</td>
<td>5%</td>
</tr>
</tbody>
</table>
<h3>Roughly what percentage of your working time is spent working with WordPress?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>16,658</td>
<td></td>
<td>5,039</td>
<td></td>
<td>5,241</td>
<td></td>
</tr>
<tr>
<td>100 %</td>
<td>949</td>
<td>6%</td>
<td>459</td>
<td>9%</td>
<td>461</td>
<td>9%</td>
</tr>
<tr>
<td>90 %</td>
<td>1,300</td>
<td>8%</td>
<td>527</td>
<td>10%</td>
<td>540</td>
<td>10%</td>
</tr>
<tr>
<td>80 %</td>
<td>1,784</td>
<td>11%</td>
<td>637</td>
<td>13%</td>
<td>711</td>
<td>14%</td>
</tr>
<tr>
<td>70 %</td>
<td>1,850</td>
<td>11%</td>
<td>608</td>
<td>12%</td>
<td>627</td>
<td>12%</td>
</tr>
<tr>
<td>60 %</td>
<td>1,313</td>
<td>8%</td>
<td>438</td>
<td>9%</td>
<td>465</td>
<td>9%</td>
</tr>
<tr>
<td>50 %</td>
<td>2,095</td>
<td>13%</td>
<td>612</td>
<td>12%</td>
<td>639</td>
<td>12%</td>
</tr>
<tr>
<td>40 %</td>
<td>1,438</td>
<td>9%</td>
<td>391</td>
<td>8%</td>
<td>384</td>
<td>7%</td>
</tr>
<tr>
<td>30 %</td>
<td>2,076</td>
<td>12%</td>
<td>530</td>
<td>11%</td>
<td>511</td>
<td>10%</td>
</tr>
<tr>
<td>20 %</td>
<td>1,743</td>
<td>10%</td>
<td>445</td>
<td>9%</td>
<td>429</td>
<td>8%</td>
</tr>
<tr>
<td>10 %</td>
<td>1,819</td>
<td>11%</td>
<td>342</td>
<td>7%</td>
<td>419</td>
<td>8%</td>
</tr>
<tr>
<td>0 %</td>
<td>291</td>
<td>2%</td>
<td>52</td>
<td>1%</td>
<td>55</td>
<td>1%</td>
</tr>
</tbody>
</table>
<h3>How many hours of your work does the typical site take to complete? (2015) / How many hours of work does your typical WordPress project take to launch? (2016, 2017)</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Freelancer/Hobbyist</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>16,670</td>
<td></td>
<td>5,164</td>
<td></td>
<td>5,378</td>
<td></td>
</tr>
<tr>
<td>More than 200</td>
<td>503</td>
<td>3%</td>
<td>222</td>
<td>4%</td>
<td>245</td>
<td>5%</td>
</tr>
<tr>
<td>100 &#8211; 200</td>
<td>973</td>
<td>6%</td>
<td>386</td>
<td>7%</td>
<td>393</td>
<td>7%</td>
</tr>
<tr>
<td>60 &#8211; 100</td>
<td>2,277</td>
<td>14%</td>
<td>788</td>
<td>15%</td>
<td>815</td>
<td>15%</td>
</tr>
<tr>
<td>40 &#8211; 60</td>
<td>3,896</td>
<td>23%</td>
<td>1,153</td>
<td>22%</td>
<td>1,216</td>
<td>23%</td>
</tr>
<tr>
<td>20 &#8211; 40</td>
<td>6,068</td>
<td>36%</td>
<td>1,487</td>
<td>29%</td>
<td>1,582</td>
<td>29%</td>
</tr>
<tr>
<td>Fewer than 20</td>
<td>2,953</td>
<td>18%</td>
<td>712</td>
<td>14%</td>
<td>751</td>
<td>14%</td>
</tr>
<tr>
<td>Prefer not to answer</td>
<td></td>
<td></td>
<td>418</td>
<td>8%</td>
<td>376</td>
<td>7%</td>
</tr>
</tbody>
</table>
<h3>Which of the following have you done with WordPress?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" /> </colgroup>
</table>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Professional (Company/Freelancer/Hobbyist)</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>20,687</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I’ve written a theme from scratch.</td>
<td>11,894</td>
<td>25%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I’ve written a plugin.</td>
<td>9,719</td>
<td>21%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;ve answered a question in the WordPress forum.</td>
<td>8,805</td>
<td>19%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;ve attended a WordPress meetup.</td>
<td>4,062</td>
<td>9%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;ve submitted a WordPress bug report.</td>
<td>4,062</td>
<td>9%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;ve attended a WordCamp.</td>
<td>3,571</td>
<td>8%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;ve contributed to WordPress documentation.</td>
<td>1,778</td>
<td>4%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Other Option</td>
<td>1,739</td>
<td>4%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;ve contributed a WordPress core patch.</td>
<td>1,055</td>
<td>2%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>
<h3>What&#8217;s the best thing about WordPress?<a href=\"https://wordpress.org/news/feed/#text\">*</a></h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Professional</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>22,718</td>
<td></td>
<td>7,891</td>
<td></td>
<td>8,267</td>
<td></td>
</tr>
<tr>
<td>Easy/simple/user-friendly</td>
<td>9,450</td>
<td>42%</td>
<td>3,454</td>
<td>44%</td>
<td>3,852</td>
<td>47%</td>
</tr>
<tr>
<td>Customizable/extensible/modular/plugins/themes</td>
<td>8,601</td>
<td>38%</td>
<td>3,116</td>
<td>39%</td>
<td>3,555</td>
<td>43%</td>
</tr>
<tr>
<td>Community/support/documentation/help</td>
<td>3,806</td>
<td>17%</td>
<td>1,211</td>
<td>15%</td>
<td>1,340</td>
<td>16%</td>
</tr>
<tr>
<td>Free/open/open source</td>
<td>2,291</td>
<td>10%</td>
<td>802</td>
<td>10%</td>
<td>908</td>
<td>11%</td>
</tr>
<tr>
<td>Popular/ubiquitous</td>
<td>249</td>
<td>1%</td>
<td>86</td>
<td>1%</td>
<td>187</td>
<td>2%</td>
</tr>
</tbody>
</table>
<h3> What&#8217;s the most frustrating thing about WordPress?<a href=\"https://wordpress.org/news/feed/#text\">*</a></h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Professional</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>21,144</td>
<td></td>
<td>7,294</td>
<td></td>
<td>7,691</td>
<td></td>
</tr>
<tr>
<td>Plugins &amp; themes (abandoned/conflicts/coding standards)</td>
<td>6,122</td>
<td>29%</td>
<td>2,194</td>
<td>30%</td>
<td>2,187</td>
<td>28%</td>
</tr>
<tr>
<td>Security/vulnerabilities/hacks</td>
<td>2,321</td>
<td>11%</td>
<td>712</td>
<td>10%</td>
<td>829</td>
<td>11%</td>
</tr>
<tr>
<td>Updates</td>
<td>1,544</td>
<td>7%</td>
<td>422</td>
<td>6%</td>
<td>508</td>
<td>7%</td>
</tr>
<tr>
<td>Nothing/I don&#8217;t know/can&#8217;t think of anything</td>
<td>1,276</td>
<td>6%</td>
<td>344</td>
<td>5%</td>
<td>476</td>
<td>6%</td>
</tr>
<tr>
<td>Speed/performance/slow/heavy</td>
<td>1,196</td>
<td>6%</td>
<td>644</td>
<td>9%</td>
<td>516</td>
<td>7%</td>
</tr>
</tbody>
</table>
<h3>WordPress is as good as, or better than, its main competitors.</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress Professional</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses (this question was not asked in the 2015 survey)</td>
<td></td>
<td></td>
<td>8,672</td>
<td></td>
<td>9,059</td>
<td></td>
</tr>
<tr>
<td>Agree</td>
<td></td>
<td></td>
<td>7551</td>
<td>87%</td>
<td>7836</td>
<td>87%</td>
</tr>
<tr>
<td>Prefer not to answer</td>
<td></td>
<td></td>
<td>754</td>
<td>9%</td>
<td>795</td>
<td>9%</td>
</tr>
<tr>
<td>Disagree</td>
<td></td>
<td></td>
<td>370</td>
<td>4%</td>
<td>428</td>
<td>5%</td>
</tr>
</tbody>
</table>
<h2 id=\"user\">WordPress Users</h2>
<h3>Which of the following describes how you use WordPress?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress User</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>15,169</td>
<td></td>
<td>5,043</td>
<td></td>
<td>5,521</td>
<td></td>
</tr>
<tr>
<td>My personal blog (or blogs) uses WordPress.</td>
<td>9,395</td>
<td>36%</td>
<td>3,117</td>
<td>36%</td>
<td>3,424</td>
<td>36%</td>
</tr>
<tr>
<td>My company or organization&#8217;s website is built with WordPress software.</td>
<td>7,480</td>
<td>29%</td>
<td>2,519</td>
<td>29%</td>
<td>2,841</td>
<td>30%</td>
</tr>
<tr>
<td>I have a hobby or side project that has a website built with WordPress.</td>
<td>6,112</td>
<td>23%</td>
<td>1,973</td>
<td>23%</td>
<td>2,200</td>
<td>23%</td>
</tr>
<tr>
<td>I write (or otherwise work) for an online publication that uses WordPress.</td>
<td>2,329</td>
<td>9%</td>
<td>806</td>
<td>9%</td>
<td>821</td>
<td>9%</td>
</tr>
<tr>
<td>Other Option</td>
<td>872</td>
<td>3%</td>
<td>234</td>
<td>3%</td>
<td>288</td>
<td>3%</td>
</tr>
</tbody>
</table>
<h3>Who installed your WordPress website?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress User</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>15,055</td>
<td></td>
<td>5,020</td>
<td></td>
<td>5,523</td>
<td></td>
</tr>
<tr>
<td>I did.</td>
<td>11,216</td>
<td>66%</td>
<td>3,659</td>
<td>73%</td>
<td>4,129</td>
<td>75%</td>
</tr>
<tr>
<td>My hosting provider</td>
<td>2,236</td>
<td>13%</td>
<td>667</td>
<td>13%</td>
<td>767</td>
<td>14%</td>
</tr>
<tr>
<td>An external company</td>
<td>909</td>
<td>5%</td>
<td>182</td>
<td>4%</td>
<td>178</td>
<td>3%</td>
</tr>
<tr>
<td>An internal web person/team or a colleague</td>
<td>874</td>
<td>5%</td>
<td>178</td>
<td>4%</td>
<td>191</td>
<td>3%</td>
</tr>
<tr>
<td>A friend or family member</td>
<td>787</td>
<td>5%</td>
<td>192</td>
<td>4%</td>
<td>172</td>
<td>3%</td>
</tr>
<tr>
<td>I don&#8217;t know</td>
<td>502</td>
<td>3%</td>
<td>145</td>
<td>3%</td>
<td>87</td>
<td>2%</td>
</tr>
<tr>
<td>Other Option</td>
<td>345</td>
<td>2%</td>
<td>n/a</td>
<td>n/a</td>
<td>n/a</td>
<td>n/a</td>
</tr>
</tbody>
</table>
<h3>How much has the site been customized from the original WordPress installation?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress User</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>14,789</td>
<td></td>
<td>4,997</td>
<td></td>
<td>5,494</td>
<td></td>
</tr>
<tr>
<td>There&#8217;s a different theme and some plugins have been added.</td>
<td>7,465</td>
<td>50%</td>
<td>2,337</td>
<td>47%</td>
<td>2,660</td>
<td>48%</td>
</tr>
<tr>
<td>A lot of work has been done, the site itself is unrecognizable from the original theme, but the Dashboard still looks like the usual WordPress interface.</td>
<td>4,715</td>
<td>32%</td>
<td>1,707</td>
<td>34%</td>
<td>1,872</td>
<td>34%</td>
</tr>
<tr>
<td>Not at all, it&#8217;s still pretty much the same as it was when I started out.</td>
<td>1,841</td>
<td>12%</td>
<td>635</td>
<td>13%</td>
<td>673</td>
<td>12%</td>
</tr>
<tr>
<td>You&#8217;d never know this was a WordPress installation, everything has been customized.</td>
<td>768</td>
<td>5%</td>
<td>321</td>
<td>6%</td>
<td>290</td>
<td>5%</td>
</tr>
</tbody>
</table>
<h3>What&#8217;s the best thing about WordPress?<a href=\"https://wordpress.org/news/feed/#text\">*</a></h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress User</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>14,328</td>
<td></td>
<td>4,613</td>
<td></td>
<td>5,076</td>
<td></td>
</tr>
<tr>
<td>Easy/simple/user-friendly</td>
<td>7,391</td>
<td>52%</td>
<td>2,276</td>
<td>49%</td>
<td>2,511</td>
<td>49%</td>
</tr>
<tr>
<td>Customizable/extensible/modular/plugins/themes</td>
<td>4,219</td>
<td>29%</td>
<td>1,569</td>
<td>34%</td>
<td>1,632</td>
<td>32%</td>
</tr>
<tr>
<td>Free/open/open source</td>
<td>1,586</td>
<td>11%</td>
<td>493</td>
<td>11%</td>
<td>538</td>
<td>11%</td>
</tr>
<tr>
<td>Community/support/documentation/help</td>
<td>1,085</td>
<td>8%</td>
<td>388</td>
<td>8%</td>
<td>458</td>
<td>9%</td>
</tr>
<tr>
<td>Popular/ubiquitous</td>
<td>223</td>
<td>2%</td>
<td>74</td>
<td>2%</td>
<td>48</td>
<td>1%</td>
</tr>
</tbody>
</table>
<h3>What&#8217;s the most frustrating thing about WordPress?<a href=\"https://wordpress.org/news/feed/#text\">*</a></h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress User</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td>13,681</td>
<td></td>
<td>4,287</td>
<td></td>
<td>4,758</td>
<td></td>
</tr>
<tr>
<td>Plugins &amp; themes (abandoned/conflicts/coding standards)</td>
<td>2,531</td>
<td>19%</td>
<td>1,183</td>
<td>28%</td>
<td>1,300</td>
<td>27%</td>
</tr>
<tr>
<td>Customization/design/look/template</td>
<td>1,273</td>
<td>9%</td>
<td>381</td>
<td>9%</td>
<td>408</td>
<td>9%</td>
</tr>
<tr>
<td>Code/coding/PHP</td>
<td>931</td>
<td>7%</td>
<td>306</td>
<td>7%</td>
<td>277</td>
<td>6%</td>
</tr>
<tr>
<td>Updates</td>
<td>926</td>
<td>7%</td>
<td>209</td>
<td>5%</td>
<td>296</td>
<td>6%</td>
</tr>
<tr>
<td>Security/vulnerabilites/hacks</td>
<td>785</td>
<td>6%</td>
<td>255</td>
<td>6%</td>
<td>292</td>
<td>6%</td>
</tr>
</tbody>
</table>
<h3>WordPress is as good as, or better than, its main competitors.</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: WordPress User</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td></td>
<td></td>
<td>5,026</td>
<td></td>
<td>5,498</td>
<td></td>
</tr>
<tr>
<td>Agree</td>
<td></td>
<td></td>
<td>4,038</td>
<td>80%</td>
<td>4,462</td>
<td>81%</td>
</tr>
<tr>
<td>Prefer not to answer</td>
<td></td>
<td></td>
<td>737</td>
<td>15%</td>
<td>782</td>
<td>14%</td>
</tr>
<tr>
<td>Disagree</td>
<td></td>
<td></td>
<td>254</td>
<td>5%</td>
<td>255</td>
<td>5%</td>
</tr>
</tbody>
</table>
<h2 id=\"all\">All Respondents</h2>
<h3>Can you (truthfully!) say &#8220;I make my living from WordPress&#8221;?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: All Respondents</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses (combination of all three groups from 2015; this question was not broken out by group in 2016-2017)</td>
<td>42,236</td>
<td></td>
<td>14,906</td>
<td></td>
<td>15,616</td>
<td></td>
</tr>
<tr>
<td>Not really, but I do get some or all of my income as a result of working with WordPress.</td>
<td>16,607</td>
<td>39%</td>
<td>5,408</td>
<td>36%</td>
<td>5,702</td>
<td>37%</td>
</tr>
<tr>
<td>Yes.</td>
<td>9,635</td>
<td>23%</td>
<td>4,791</td>
<td>32%</td>
<td>5,033</td>
<td>32%</td>
</tr>
<tr>
<td>No.</td>
<td>15,995</td>
<td>38%</td>
<td>4,713</td>
<td>32%</td>
<td>4,882</td>
<td>31%</td>
</tr>
</tbody>
</table>
<h3>Which devices do you access WordPress on?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: All Respondents</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses (combination of all three groups from 2015; this question was not broken out by group in 2016-2017)</td>
<td>42,433</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Web</td>
<td>40,503</td>
<td>95%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Android phone</td>
<td>15,396</td>
<td>36%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>iPhone</td>
<td>12,353</td>
<td>29%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>iPad</td>
<td>11,748</td>
<td>28%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Android tablet</td>
<td>9,223</td>
<td>22%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Desktop app, like MarsEdit</td>
<td>6,018</td>
<td>14%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Other Option</td>
<td>1837</td>
<td>4%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses (this question was not broken out by group in 2016-2017)</td>
<td></td>
<td></td>
<td>14,840</td>
<td></td>
<td>15,597</td>
<td></td>
</tr>
<tr>
<td>Web browser on a desktop or laptop</td>
<td></td>
<td></td>
<td>14,160</td>
<td>54%</td>
<td>15,052</td>
<td>55%</td>
</tr>
<tr>
<td>Web browser on a mobile device (tablet or phone)</td>
<td></td>
<td></td>
<td>7,952</td>
<td>30%</td>
<td>8,248</td>
<td>30%</td>
</tr>
<tr>
<td>An app on a mobile device (table or phone)</td>
<td></td>
<td></td>
<td>3,309</td>
<td>13%</td>
<td>3,311</td>
<td>12%</td>
</tr>
<tr>
<td>A desktop app like MarsEdit</td>
<td></td>
<td></td>
<td>517</td>
<td>2%</td>
<td>498</td>
<td>2%</td>
</tr>
<tr>
<td>Other Option</td>
<td></td>
<td></td>
<td>282</td>
<td>1%</td>
<td>240</td>
<td>1%</td>
</tr>
</tbody>
</table>
<h3>WordPress now updates minor &amp; security releases automatically for you. Check all that apply: (question not asked in 2016, 2017)</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"36\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: All Respondents</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses (combination of all three groups)</td>
<td>39,726</td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I love auto-updates.</td>
<td>17,367</td>
<td>44%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;d like to see auto-updates for plugins.</td>
<td>12,796</td>
<td>32%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Initially, I was nervous about auto updates.</td>
<td>11,868</td>
<td>30%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Auto updates still make me nervous.</td>
<td>10,809</td>
<td>27%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Auto updates don&#8217;t make me nervous now.</td>
<td>10,708</td>
<td>27%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;d like to see auto-updates for themes.</td>
<td>10,449</td>
<td>26%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I&#8217;d like to see auto updates for major versions of WordPress.</td>
<td>10,225</td>
<td>26%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>This is the first I&#8217;ve heard of auto-updates.</td>
<td>8,660</td>
<td>22%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>I hate auto-updates.</td>
<td>3,293</td>
<td>8%</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>
<h3>What is your gender?<a href=\"https://wordpress.org/news/feed/#text\">*</a></h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: All respondents (This question was not asked in the 2015 survey.)</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td></td>
<td></td>
<td>13,953</td>
<td></td>
<td>14,680</td>
<td></td>
</tr>
<tr>
<td>Male</td>
<td></td>
<td></td>
<td>10,978</td>
<td>78.68%</td>
<td>11,570</td>
<td>78.81%</td>
</tr>
<tr>
<td>Female</td>
<td></td>
<td></td>
<td>2,340</td>
<td>16.77%</td>
<td>2,511</td>
<td>21.70%</td>
</tr>
<tr>
<td>Prefer not to answer</td>
<td></td>
<td></td>
<td>601</td>
<td>4.31%</td>
<td>562</td>
<td>3.83%</td>
</tr>
<tr>
<td>Transgender</td>
<td></td>
<td></td>
<td>11</td>
<td>0.08%</td>
<td>8</td>
<td>0.05%</td>
</tr>
<tr>
<td>Nonbinary</td>
<td></td>
<td></td>
<td>8</td>
<td>0.06%</td>
<td>17</td>
<td>0.12%</td>
</tr>
<tr>
<td>Genderqueer</td>
<td></td>
<td></td>
<td>4</td>
<td>0.03%</td>
<td>3</td>
<td>0.02%</td>
</tr>
<tr>
<td>Androgynous</td>
<td></td>
<td></td>
<td>6</td>
<td>0.04%</td>
<td>5</td>
<td>0.03%</td>
</tr>
<tr>
<td>Fluid</td>
<td></td>
<td></td>
<td>3</td>
<td>0.02%</td>
<td>4</td>
<td>0.03%</td>
</tr>
<tr>
<td>Demimale</td>
<td></td>
<td></td>
<td>2</td>
<td>0.01%</td>
<td>0</td>
<td>0</td>
</tr>
</tbody>
</table>
<h3>Where are you located?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: All respondents (This question was not asked in the 2015 survey.)</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses</td>
<td></td>
<td></td>
<td>14,562</td>
<td></td>
<td>15,343</td>
<td></td>
</tr>
<tr>
<td>United States</td>
<td></td>
<td></td>
<td>3,770</td>
<td>25.89%</td>
<td>4,067</td>
<td>26.51%</td>
</tr>
<tr>
<td>India</td>
<td></td>
<td></td>
<td>1,456</td>
<td>10.00%</td>
<td>1,424</td>
<td>9.28%</td>
</tr>
<tr>
<td>United Kingdom</td>
<td></td>
<td></td>
<td>810</td>
<td>5.56%</td>
<td>900</td>
<td>5.87%</td>
</tr>
<tr>
<td>Germany</td>
<td></td>
<td></td>
<td>555</td>
<td>3.81%</td>
<td>729</td>
<td>4.75%</td>
</tr>
<tr>
<td>Canada</td>
<td></td>
<td></td>
<td>511</td>
<td>3.51%</td>
<td>599</td>
<td>3.90%</td>
</tr>
<tr>
<td>Australia</td>
<td></td>
<td></td>
<td>389</td>
<td>2.67%</td>
<td>460</td>
<td>3.00%</td>
</tr>
<tr>
<td>Italy</td>
<td></td>
<td></td>
<td>298</td>
<td>2.05%</td>
<td>356</td>
<td>2.32%</td>
</tr>
<tr>
<td>Netherlands</td>
<td></td>
<td></td>
<td>343</td>
<td>2.36%</td>
<td>350</td>
<td>2.28%</td>
</tr>
<tr>
<td>France</td>
<td></td>
<td></td>
<td>232</td>
<td>1.59%</td>
<td>283</td>
<td>1.84%</td>
</tr>
<tr>
<td>Bangladesh</td>
<td></td>
<td></td>
<td>257</td>
<td>1.76%</td>
<td>263</td>
<td>1.71%</td>
</tr>
<tr>
<td>Spain</td>
<td></td>
<td></td>
<td>271</td>
<td>1.86%</td>
<td>252</td>
<td>1.64%</td>
</tr>
<tr>
<td>Brazil</td>
<td></td>
<td></td>
<td>239</td>
<td>1.64%</td>
<td>251</td>
<td>1.64%</td>
</tr>
<tr>
<td>Pakistan</td>
<td></td>
<td></td>
<td>254</td>
<td>1.74%</td>
<td>240</td>
<td>1.56%</td>
</tr>
<tr>
<td>Indonesia</td>
<td></td>
<td></td>
<td>230</td>
<td>1.58%</td>
<td>226</td>
<td>1.47%</td>
</tr>
<tr>
<td>Iran, Islamic Republic of</td>
<td></td>
<td></td>
<td>190</td>
<td>1.30%</td>
<td>173</td>
<td>1.13%</td>
</tr>
<tr>
<td>Sweden</td>
<td></td>
<td></td>
<td>144</td>
<td>0.99%</td>
<td>173</td>
<td>1.13%</td>
</tr>
<tr>
<td>Nigeria</td>
<td></td>
<td></td>
<td>196</td>
<td>1.35%</td>
<td>172</td>
<td>1.12%</td>
</tr>
<tr>
<td>South Africa</td>
<td></td>
<td></td>
<td>193</td>
<td>1.33%</td>
<td>172</td>
<td>1.12%</td>
</tr>
<tr>
<td>Russian Federation</td>
<td></td>
<td></td>
<td>181</td>
<td>1.24%</td>
<td>151</td>
<td>0.98%</td>
</tr>
<tr>
<td>Poland</td>
<td></td>
<td></td>
<td>129</td>
<td>0.89%</td>
<td>137</td>
<td>0.89%</td>
</tr>
<tr>
<td>Romania</td>
<td></td>
<td></td>
<td>144</td>
<td>0.99%</td>
<td>132</td>
<td>0.86%</td>
</tr>
<tr>
<td>Switzerland</td>
<td></td>
<td></td>
<td>122</td>
<td>0.84%</td>
<td>130</td>
<td>0.85%</td>
</tr>
<tr>
<td>Philippines</td>
<td></td>
<td></td>
<td>92</td>
<td>0.63%</td>
<td>125</td>
<td>0.81%</td>
</tr>
<tr>
<td>China</td>
<td></td>
<td></td>
<td>136</td>
<td>0.93%</td>
<td>123</td>
<td>0.80%</td>
</tr>
<tr>
<td>Austria</td>
<td></td>
<td></td>
<td>89</td>
<td>0.61%</td>
<td>122</td>
<td>0.80%</td>
</tr>
<tr>
<td>Ukraine</td>
<td></td>
<td></td>
<td>105</td>
<td>0.72%</td>
<td>118</td>
<td>0.77%</td>
</tr>
<tr>
<td>Denmark</td>
<td></td>
<td></td>
<td>107</td>
<td>0.73%</td>
<td>114</td>
<td>0.74%</td>
</tr>
<tr>
<td>Greece</td>
<td></td>
<td></td>
<td>120</td>
<td>0.82%</td>
<td>114</td>
<td>0.74%</td>
</tr>
<tr>
<td>Portugal</td>
<td></td>
<td></td>
<td>94</td>
<td>0.65%</td>
<td>109</td>
<td>0.71%</td>
</tr>
<tr>
<td>Vietnam</td>
<td></td>
<td></td>
<td>101</td>
<td>0.69%</td>
<td>108</td>
<td>0.70%</td>
</tr>
<tr>
<td>Mexico</td>
<td></td>
<td></td>
<td>94</td>
<td>0.65%</td>
<td>105</td>
<td>0.68%</td>
</tr>
<tr>
<td>Nepal</td>
<td></td>
<td></td>
<td>76</td>
<td>0.52%</td>
<td>97</td>
<td>0.63%</td>
</tr>
<tr>
<td>Ireland</td>
<td></td>
<td></td>
<td>72</td>
<td>0.49%</td>
<td>94</td>
<td>0.61%</td>
</tr>
<tr>
<td>Israel</td>
<td></td>
<td></td>
<td>78</td>
<td>0.54%</td>
<td>94</td>
<td>0.61%</td>
</tr>
<tr>
<td>New Zealand</td>
<td></td>
<td></td>
<td>77</td>
<td>0.53%</td>
<td>91</td>
<td>0.59%</td>
</tr>
<tr>
<td>Finland</td>
<td></td>
<td></td>
<td>63</td>
<td>0.43%</td>
<td>90</td>
<td>0.59%</td>
</tr>
<tr>
<td>Turkey</td>
<td></td>
<td></td>
<td>91</td>
<td>0.62%</td>
<td>86</td>
<td>0.56%</td>
</tr>
<tr>
<td>Malaysia</td>
<td></td>
<td></td>
<td>91</td>
<td>0.62%</td>
<td>81</td>
<td>0.53%</td>
</tr>
<tr>
<td>Belgium</td>
<td></td>
<td></td>
<td>84</td>
<td>0.58%</td>
<td>79</td>
<td>0.51%</td>
</tr>
<tr>
<td>Norway</td>
<td></td>
<td></td>
<td>66</td>
<td>0.45%</td>
<td>79</td>
<td>0.51%</td>
</tr>
<tr>
<td>Argentina</td>
<td></td>
<td></td>
<td>65</td>
<td>0.45%</td>
<td>76</td>
<td>0.50%</td>
</tr>
<tr>
<td>Bulgaria</td>
<td></td>
<td></td>
<td>74</td>
<td>0.51%</td>
<td>72</td>
<td>0.47%</td>
</tr>
<tr>
<td>Japan</td>
<td></td>
<td></td>
<td>61</td>
<td>0.42%</td>
<td>68</td>
<td>0.44%</td>
</tr>
<tr>
<td>Thailand</td>
<td></td>
<td></td>
<td>69</td>
<td>0.47%</td>
<td>67</td>
<td>0.44%</td>
</tr>
<tr>
<td>Czech Republic</td>
<td></td>
<td></td>
<td>76</td>
<td>0.52%</td>
<td>66</td>
<td>0.43%</td>
</tr>
<tr>
<td>Serbia</td>
<td></td>
<td></td>
<td>89</td>
<td>0.61%</td>
<td>63</td>
<td>0.41%</td>
</tr>
<tr>
<td>Kenya</td>
<td></td>
<td></td>
<td>58</td>
<td>0.40%</td>
<td>62</td>
<td>0.40%</td>
</tr>
<tr>
<td>Colombia</td>
<td></td>
<td></td>
<td>39</td>
<td>0.27%</td>
<td>59</td>
<td>0.38%</td>
</tr>
<tr>
<td>Egypt</td>
<td></td>
<td></td>
<td>40</td>
<td>0.27%</td>
<td>52</td>
<td>0.34%</td>
</tr>
</tbody>
</table>
<h3>What is your age?</h3>
<table dir=\"ltr\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">
<colgroup>
<col width=\"554\" />
<col width=\"47\" />
<col width=\"36\" />
<col width=\"47\" />
<col width=\"51\" />
<col width=\"47\" />
<col width=\"51\" /></colgroup>
<tbody>
<tr>
<td></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2015</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2016</strong></td>
<td colspan=\"2\" rowspan=\"1\"><strong>2017</strong></td>
</tr>
<tr>
<td><em>Group: All Respondents</em></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>
<tr>
<td>Number of responses (This question was not asked in 2015.)</td>
<td></td>
<td></td>
<td>14,944</td>
<td></td>
<td>15,636</td>
<td></td>
</tr>
<tr>
<td>60 and over</td>
<td></td>
<td></td>
<td>1,139</td>
<td>8%</td>
<td>1,641</td>
<td>11%</td>
</tr>
<tr>
<td>50-59</td>
<td></td>
<td></td>
<td>1,537</td>
<td>10%</td>
<td>1,996</td>
<td>13%</td>
</tr>
<tr>
<td>40-49</td>
<td></td>
<td></td>
<td>2,205</td>
<td>15%</td>
<td>2,643</td>
<td>17%</td>
</tr>
<tr>
<td>30-39</td>
<td></td>
<td></td>
<td>3,914</td>
<td>26%</td>
<td>3,972</td>
<td>25%</td>
</tr>
<tr>
<td>20-29</td>
<td></td>
<td></td>
<td>5,013</td>
<td>34%</td>
<td>4,444</td>
<td>28%</td>
</tr>
<tr>
<td>Under 20</td>
<td></td>
<td></td>
<td>1142</td>
<td>8%</td>
<td>941</td>
<td>6%</td>
</tr>
</tbody>
</table>
<p>Thank you to everyone who made time to fill out the survey &#8212; we&#8217;re so happy you use WordPress, and we&#8217;re very grateful that you&#8217;re willing to share your experiences with us! Thanks also to everyone who spread the word about this survey, and to those of you who read all the way to the bottom of this post. <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f609.png\" alt=\"😉\" class=\"wp-smiley\" /></p>
<p><small><a id=\"text\"></a>*Text Field Questions: Each survey included some questions that could be answered only by filling out a text field. In the case of the questions &#8220;What is the best thing about WordPress?&#8221; and &#8220;What is the most frustrating thing about WordPress?&#8221; we listed the five most common responses, aggregated when applicable. In the case of the question “What is your gender?” in the 2016 and 2017 surveys, we aggregated responses as best we could. Responses meant to obscure respondents’ gender entirely are aggregated in “prefer not to answer.”</small></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Dec 2017 21:40:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Andrea Middleton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: WPWeekly Episode 298 – GDPR, User Privacy, and More With Heather Burns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=77110&preview=true&preview_id=77110\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"https://wptavern.com/wpweekly-episode-298-gdpr-user-privacy-and-more-with-heather-burns\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2570:\"<p>In this episode, <a href=\"https://jjj.blog/\">John James Jacoby</a> and I are joined by <a href=\"https://twitter.com/webdevlaw?lang=en\">Heather Burns</a>, Founder of <a href=\"https://webdevlaw.uk/\">WebDevLaw</a>. We have a lengthy discussion about <a href=\"https://www.eugdpr.org/\">GDPR</a> (General Data Protection Regulation), what it is, what&#8217;s at stake, and its potential impacts on the WordPress ecosystem. We also discuss the cultural differences between the North American and European views on user privacy.</p>
<p>When asked what she hopes to see as we approach May of 2018, Burns replied:</p>
<p>&#8220;I want to see all hands on deck making WordPress a force for good, that people can trust, and that people can be empowered to change for the better. Don&#8217;t let the fact that it involves law put you off. GDPR is a toolkit for empowerment, it&#8217;s a means for protecting and safeguarding your users in these quite scary times we&#8217;re living in. And it will make you a better developer and site administrator in the end.&#8221;</p>
<p>For questions related to GDPR or how to make your site or WordPress plugins compliant, <a href=\"https://webdevlaw.uk/\">please get in touch with Burns</a>. You can also <a href=\"https://videopress.com/v/JkKwb2zi\">view her presentation</a> on WordPress.TV from WordCamp Belfast, 2016.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/wp-site-care-acquires-wp-radius\">WP Site Care Acquires WP Radius</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://frontenberg.tomjn.com/\">Frontenberg</a> by Tom J. Nowell is a new site that displays Gutenberg to the frontend of WordPress. It allows visitors to tinker with Gutenberg without having to login to a site or install a plugin.</p>
<p>John gave props to <a href=\"https://github.com/renatonascalves\">Renato Alves</a> who has been working on adding WP-CLI support for <a href=\"https://github.com/bbpress/wp-cli-bbpress\">bbPress</a> and <a href=\"https://github.com/buddypress/wp-cli-buddypress\">BuddyPress</a>.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, December 27th 18th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p><strong>Listen To Episode #298:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Dec 2017 01:21:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: Design in Kentucky\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47730\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"https://ma.tt/2017/12/design-in-kentucky/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:352:\"<p>Fast Company Design has written ﻿<a href=\"https://www.fastcodesign.com/90154530/tech-has-a-diversity-problem-so-this-designer-went-to-kentucky\">Tech Has A Diversity Problem–So This Designer Went To Kentucky</a>, about John Maeda&#x27;s work pairing some of the top designers in the world with students in Paintsville, Kentucky. </p>



<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Dec 2017 21:17:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"WPTavern: WP Site Care Acquires WP Radius\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77086\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wptavern.com/wp-site-care-acquires-wp-radius\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1407:\"<p><a href=\"https://www.wpsitecare.com\">WP Site Care</a>, a WordPress management and maintenance service provider<a href=\"https://www.wpsitecare.com/weve-acquired-wp-radius/\"> has acquired</a> <a href=\"https://www.wpradius.com/\">WP Radius</a>.﻿ Ryan Sullivan, Founder of WP Site Care, says the acquisition has been in the works for some time. </p>



<p>\"We’ve been working toward growing our customer base and learning about new business models in the WordPress support space for quite some time, and the WP Radius acquisition allows us to accomplish both of those goals,\" he said.<br /></p>



<p>The move increases WP Site Care&#x27;s customer base by 20% and will allow it to experiment with <a href=\"https://www.wpradius.com/plans/\">an unlimited jobs model</a>, something that set WP Radius apart. </p>



<p>\"We’ve been very interested in the unlimited jobs model and what that really means from an operations standpoint for quite some time, and whether or not it’s <em>actually</em> better for customers, so this move will allow us to learn a lot more about how that all plays out in the real world,\" Sullivan said.</p>



<p>WP Radius will continue to operate as a separate entity and will eventually be consolidated into the WP Site Care brand. </p>



<p>WP Radius was founded in 2015 by Todd Schwartzfarb and Brandon Yanofsky. Financial details of the acquisition were not disclosed. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Dec 2017 19:38:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"HeroPress: WordPress allowed me to have a Dream Job\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2357\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:128:\"https://heropress.com/essays/wordpress-allowed-dream-job/#utm_source=rss&utm_medium=rss&utm_campaign=wordpress-allowed-dream-job\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:13836:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2017/12/121917-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: You know that you should never stop dreaming, right?\" /><p>I was always interested in computers but I did not know I would become a developer. As a kid, a dream job, was playing and reviewing video games. I believe, many kids had a similar dream job. I guess, that’s where I started seeing a dream job would be a job where you would be happy to go to and maybe even sad when going from it.</p>
<p>Today, I see myself as having a dream job. Let me tell you how I got to my current situation.</p>
<h3>Programming was not for me</h3>
<p>While going to high school, I was introduced to programming. We did some Turbo C++ and I could not understand a thing. Even a simple for-loop was hard for me. I would rather play Counter-Strike with friends who attended that class. After that, as I did not understand programming, I chose not to follow such career path. I did not want my parents to pay for my college expenses since I would have to go to another city. Especially since I realised I don’t understand how to code.</p>
<p>Since I live in Croatia, I did not have access to a high speed internet. At that time, a high speed internet was an ADSL with a download speed of 200kb/s.</p>
<blockquote><p>I was using the 56k modem which was too expensive so I had only 2 hours per week to spend on it.</p></blockquote>
<p>I used those 2 hours for playing games instead of learning.</p>
<p>Once I got the ADSL, somewhere near the end of high school, I was able to get my hands on Photoshop and learned how to manipulate images. After high school, I went to the Maritime College but soon after I knew I did not want to spend years and years working on ships, not seeing my family or friends. That was not my dream job.</p>
<h3>Second Try</h3>
<p>I decided to give another chance to programming, but with a different learning path. Since I already knew how to use Photoshop, I realized there was an option “Slice for Web..”. That was my first introduction to web development.</p>
<p>I knew having a web page composed of images from Photoshop was not how it should be done. I was used to 56k modem and I knew how a page like that would take long to load.</p>
<p>The luck was on my side now since I had ADSL and I could spend hours and hours weekly search the Internet. I searched how to slice images and prepare them for web pages by reading PSD Tuts+. Back then there were only PSD and Net TutsPlus sites in their network.</p>
<p>I learned a lot on PSD to HTML and how to use CSS to style your web sites. After that, I wanted to learn how do blogging sites work. How do they show those articles. I mean, it couldn’t be that for each article, they would open one HTML file and edit it. That’s just too much work. So, I found about PHP and MySQL and got some courses on Lynda on that.</p>
<p>I learned about creating a blog using PHP and MySQL. I also learned a little on advanced coding and I was really happy with my knowledge. All that was just a month or two from where I knew nothing on programming.</p>
<h3>Looking for a CMS</h3>
<p>With my knowledge, I knew how to build various types of sites. I asked other businesses if I could build a site for them in return of a favour or even product. Some of them were up to that. I didn’t want to charge since I knew I still had a lot to learn.</p>
<p>After a while, I was a bit tired (read: lazy) of building SQL tables and all the base functions for each project. I wanted to see if there are some tools I could use for a faster development. Something that would give me a starting point with basic functionalities such as content, users, settings etc.</p>
<p>After reading a lot of tutorials on PHP, I also read about Joomla, WordPress and similar. So I went for both. I was so confused by Joomla and how everything I wanted to do required me several clicks. After that, I tried WordPress. I loved it. Joomla had articles, which you could set as pages. WordPress had Posts and Pages. I really loved how everything was so easy to setup. At that time, there were no custom post types or featured images, but I did not need them yet. I was just beginning my journey with WordPress.</p>
<p>From there forward I downloaded many themes and plugins just to read their code and learn how they’ve been developed.</p>
<h3>The First Breadcrumbs &amp; Disappointments</h3>
<p>Even though I did not know too much, I did know how to develop something, how to use a library and integrate it into my own and so on.</p>
<blockquote><p>The first time I realised that WordPress could help me have a dream job is when I created a simple Dropbox plugin for my own needs.</p></blockquote>
<p>Once I’ve built it and scanned through CodeCanyon, I saw there was nothing like that (now there are several). So I went and uploaded it there. It went live after a week or so.</p>
<p>I did not expect much from it. I could gather around $300 from it after several months. As a college student who didn’t work on a side job, such income was really great for me.</p>
<p>That is where it all started for me. I decided to use WordPress for any new projects and build custom ones to learn more.</p>
<p>Don’t get me wrong. It was not so easy to get new projects. I did get a job as a student which was a failure in the sense that I did not get paid for it. I also had another freelancing experience that was not good. But that did not let me down.</p>
<p>You WILL get those clients from hell. It is something I think most of us get to know. But in time, you will learn how to identify such clients and pass on such projects.</p>
<p>Fast forward a year and I got a job where I did not use WordPress. But I did not intend to leave it. I joined Elance (now Upwork) so I could earn some side money using WordPress.</p>
<p>I did not earn anything on Elance and on my daily job, for a year, I was getting only 60% of the monthly paycheck because the Company did not have enough money. Somehow they did get the other 40% by the end of the month.</p>
<p>But can you imagine how stressful was that? You can never know if you can travel or save some money. I could not afford purchasing a course which could improve my knowledge.</p>
<p>I had a job where I liked to work, but the money situation was really stressful and I did not want to rely just on the company. WordPress to the rescue!</p>
<h3>WordPress Community</h3>
<p>Not long after, I learned about WordPress Croatia. Before that, I never used social media for such discussions and networking. That Facebook group was the first group I joined to discuss about WordPress and help each other.</p>
<p>That was really a great experience. I learned about WordCamps and Meetups and that group pushed me into making my first eBook on WordPress. Another product I was able to earn some side money which involved WordPress. My mindset started to change.</p>
<blockquote><p>By helping others through teaching and discussion, I can also help the WordPress Community.</p></blockquote>
<p>My first experience on public speaking was on a WordPress Meetup in Zagreb. I would never go if I was not invited by Emanuel Blagonić. A great guy who with his brother Lucijan and several other folks really started a WordPress movement in Croatia.</p>
<p>I never seen anything like that before. People helping each others, going so much to take their own free time to fix or at least investigate a bug on someone else’s site. I really liked it and wanted to be a part of such a community.</p>
<p>Even if such a community does not help you directly to land a job or get a new gig, it really does help you indirectly with all the knowledge that is shared (from development to business).</p>
<h3>Teaching &amp; Job Opportunities</h3>
<p>Because of the WordPress community in Croatia, I wanted to help by teaching others. So I also started a site where I have written a lot of tutorials on WordPress development. That site was in Croatian so people can start much sooner (even if they don’t know English).</p>
<p>I used to sleep only for 2 to 3 hours so I could get up much earlier and start to write tutorials or make videos. I did not have a microphone at first, so I used a webcam as a microphone. You can imagine how awful the audio was. Even if it’s in Croatian, you can check the quality of it on <a href=\"https://www.youtube.com/channel/UCzcRclnBSnJRPM5h4PfnqWw\">YouTube</a>.</p>
<blockquote><p>But I was really happy I could help someone who knows less than me.</p></blockquote>
<p>By teaching, I have learned a lot and I am so thankful to the community which was one of the reasons I kept going like that. I also got invited to several WordPress projects just because people saw me as someone who understands WordPress.</p>
<h3>WordCamps &amp; WebCamps</h3>
<p>You can make friends there. Seems a bit odd maybe, but you can. Due to the community I made some friends such as Ana &amp; Marko from <a href=\"https://www.anarieldesign.com/\">anarieldesign.com</a> and Goran Jakovljević from <a href=\"https://wpgens.com/\">wpgens.com</a>.</p>
<p>We have become friends through the community on social media. I’ve met them all just after a year or so on WordCamp Zagreb 2017. But we talked as if we were friends for years and years. I’ve seen how people from all over the world talk to each other and how a friendly and welcoming this WordPress Community is.</p>
<p>Even today, I frequently talk to all of them and we help each other as we can. That is something that you can’t have everywhere.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2017/12/codeable.png\"><img class=\"alignleft size-medium wp-image-2359\" src=\"https://heropress.com/wp-content/uploads/2017/12/codeable-300x270.png\" alt=\"Codeable sticker on a ski helmet\" width=\"300\" height=\"270\" /></a>My dream job progress came after WebCamp Zagreb 2016 where I met other people from the IT community. I got introduced to Toptal and just a month from it, I joined Toptal. Codeable was also something I wanted to try and I did. As if those platform communicated together, I got invited into <a href=\"https://codeable.io/\">Codeable</a> a week after I joined <a href=\"https://www.toptal.com/\">Toptal</a>.</p>
<p>That is where it all has started getting real to me. I was able to freelance as much as I wanted and when I wanted. It was the first time I could go do my hobbies without worrying about money.</p>
<h3>The Dream Job we all seek</h3>
<p>My definition of a dream job is the feeling when you’re waking up happy and not sad because you have to go to work. Such job should also challenge you so you learn something new. Sometimes it may even get you out of your comfort zone, but you’ll be a better person because of it.</p>
<p>I still have an occupied day, working on a daily job and then working with my own clients. It may not suit all. But I am finally able to feel somehow financially free, going happy to work and making friends while doing it. Even if I don’t have any side projects, I am working on my plugins and writing tutorials on my own site (I love it).</p>
<p>Today, for the first time, I am planning to go to a WordCamp outside Croatia.</p>
<p><strong>That is all thanks to WordPress.</strong></p>
<p>You know that you should never stop dreaming, right?</p>
<p>I guess, I wanted to let you know that WordPress can help you get a dream job! It can be something totally different, but as long as it involves Internet, I think WordPress can help you with it.</p>
<p><strong>WordPress would not be where it is today if it was not to the whole WordPress Community. So, thanks to all involved in it!</strong></p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: WordPress allowed me to have a Dream Job\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=WordPress%20allowed%20me%20to%20have%20a%20Dream%20Job&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-allowed-dream-job%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: WordPress allowed me to have a Dream Job\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-allowed-dream-job%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-allowed-dream-job%2F&title=WordPress+allowed+me+to+have+a+Dream+Job\" rel=\"nofollow\" target=\"_blank\" title=\"Share: WordPress allowed me to have a Dream Job\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/wordpress-allowed-dream-job/&media=https://heropress.com/wp-content/uploads/2017/12/121917-150x150.jpg&description=WordPress allowed me to have a Dream Job\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: WordPress allowed me to have a Dream Job\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/wordpress-allowed-dream-job/\" title=\"WordPress allowed me to have a Dream Job\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/wordpress-allowed-dream-job/\">WordPress allowed me to have a Dream Job</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Dec 2017 07:00:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Igor Benić\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Akismet: Version 4.0.2 of the Akismet WordPress Plugin Is Now Available\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=1982\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"https://blog.akismet.com/2017/12/18/version-4-0-2-of-the-akismet-wordpress-plugin-is-now-available/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1161:\"<p>Version 4.0.2 of <a href=\"http://wordpress.org/plugins/akismet/\">the Akismet plugin for WordPress</a> is now available.</p>
<p>4.0.2 contains a few helpful changes:</p>
<ul>
<li class=\"p1\"><span class=\"s1\">Fixed a bug that could cause Akismet to recheck a comment that has already been manually approved or marked as spam.</span></li>
<li class=\"p1\"><span class=\"s1\">Fixed a bug that could cause Akismet to claim that some comments are still waiting to be checked when no comments are waiting to be checked.</span></li>
</ul>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href=\"http://wordpress.org/plugins/akismet/\">the WordPress plugins directory</a>.</p><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1982/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1982/\" /></a> <img alt=\"\" border=\"0\" src=\"https://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1982&subd=akismet&ref=&feed=1\" width=\"1\" height=\"1\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 Dec 2017 16:56:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Stephane Daury\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Jetpack 5.6.1 Increases Security of the Contact Form Module\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=77061\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://wptavern.com/jetpack-5-6-1-increases-security-of-the-contact-form-module\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:575:\"<p>Jetpack has <a href=\"https://jetpack.com/2017/12/14/jetpack-5-6-1/\">released version 5.6.1</a> which hardens the Contact Form module by improving permissions checking when updating a form&#x27;s settings. In addition to security fixes, the character count for when Publicize publishes content to Twitter has been increased to 280. </p>



<p>This release also fixes a bug that disabled the ability to save widgets after removing a Widget Visibility rule. Users are encouraged to update as soon as possible, especially if you make heavy use of the Contact Form module. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 15 Dec 2017 22:49:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: WPWeekly Episode 297 – WordCamp US 2017 Recap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=77042&preview=true&preview_id=77042\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wptavern.com/wpweekly-episode-297-wordcamp-us-2017-recap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2715:\"<p>In this episode, <a href=\"https://jjj.blog/\">John James Jacoby</a> and I are joined by <a href=\"https://mor10.com/\">Morten Rand-Hendriksen</a>. We have an engaging conversation about WordCamp US 2017, Gutenberg, and what it&#8217;s going to take for it to succeed. Rand-Hendriksen shared what he thinks are <a href=\"https://mor10.com/gutenberg-and-the-future-of-wordpress-conditions-for-success/\">the three conditions</a> that need to be met before Gutenberg can be shipped.</p>
<p>Near the end of the show, we discuss the possible impacts Gutenberg&#8217;s timeline may have on the WordPress economy. Jacoby and I round out the show by reviewing the 2017 State of the Word and our picks of the week.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/storify-to-close-may-16-2018-wordpress-plugin-discontinued\">Storify to Close May 16, 2018, WordPress Plugin Discontinued</a><br />
<a href=\"https://wptavern.com/gutenberg-and-the-wordpress-of-tomorrow-by-morten-rand-hendriksen\" rel=\"bookmark\">Gutenberg and the WordPress of Tomorrow by Morten Rand-Hendriksen</a><br />
<a href=\"https://bridgetwillard.com/economic-impact-timeline-gutenberg-rollout/\">The Economic Impact of the Timeline of the Gutenberg Rollout</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://www.copytrans.net/copytransheic/\">CopyTrans</a> is a plugin for Windows to view HEIC files. In iOS 11, Apple started using HEIC/HEIF. HEIF stands for High Efficiency Image Format, and, as the name suggests, is a more streamlined way to store image files. It allows digital photographs to be created in smaller files sizes while retaining higher image quality than its JPEG alternative. The image format is currently not supported in Windows 7, 8, and 10.</p>
<p>CopyTrans HEIC for Windows is a simple Windows plugin that allows you to open HEIC files using Windows Photo Viewer. This format is also <a href=\"https://core.trac.wordpress.org/ticket/42775\">not compatible with WordPress.</a></p>
<p><a href=\"http://github.com/10up/wpsnapshots\">WP Snapshots</a> is a command line interface (CLI) tool by 10Up that empowers engineering teams to quickly share WordPress projects, including files and the database.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, December 20th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p><strong>Listen To Episode #297:</strong> </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Dec 2017 00:59:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"HeroPress: Finding My Way Out Of My Comfort Zone\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2341\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:122:\"https://heropress.com/essays/finding-way-comfort-zone/#utm_source=rss&utm_medium=rss&utm_campaign=finding-way-comfort-zone\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:20133:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2017/12/121317-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: As web developers, programmers, people who speak English, people who have internet access to read this article, are incredibly, very, very, very lucky.\" /><p>I don&#8217;t remember when we had a computer for the first time. I practically grew up with them. Hungary was a communist country when I was born in &#8217;84, so while everyone had a job, no one could really do their own thing. Everything was state owned.</p>
<p>In 1989-1990 there was a change of regime which followed the collapse of the Berlin wall, and suddenly the country became a democracy, and people were free to start and own companies. Yes, the era also had other problems, like 35% inflation at one point, but at least we were &#8220;free&#8221;.</p>
<p>My parents started out by importing computers from Hong Kong. That was a huge thing. We had one of the first of those, a 286 with a whopping speed of 8 Mhz which went up to 16 if I pressed the Turbo button! I had no idea what that meant though besides the number being higher.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2017/12/young_gabor.jpg\"><img class=\"aligncenter size-large wp-image-2343\" src=\"https://heropress.com/wp-content/uploads/2017/12/young_gabor-1024x576.jpg\" alt=\"Gabor about age 3, at a computer\" width=\"960\" height=\"540\" /></a></p>
<p>It was a good time of Sim City, Prince of Persia, and Sokoban.</p>
<h3>Finding the Web</h3>
<p>My first &#8220;website&#8221; was one my grandmother asked me to make for her Quaker group. I was 12. I created it with tables and inline styling (CSS wasn&#8217;t a thing back then), but never got it live &#8211; hosting wasn&#8217;t something I really knew about.</p>
<p>Fast forward to 2003 when I started university studying architecture in Budapest. It was fun, I loved physics, I loved drawing, I loved math, I <em>especially</em> loved descriptive geometry! The latter is pretty much &#8220;how to represent a 3d thing on a sheet of paper&#8221;. Incidentally that brought me my first high paying consulting job. As a student in 2nd year I coached a student in first year in descriptive geometry &#8211; he had broken his leg so couldn&#8217;t actually make the classes, but he had to pass that subject to advance. So every week I would go to their house and spend about 3 hours helping him draw and figure out how to draw what to draw and why to draw those things that way. That experience taught him everything he needed to know to pass with a 4 (on a scale of 5, 5 being best), which translates to around 80%. I had my first satisfied customer. <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /></p>
<p>It also taught me two very important things:</p>
<ol>
<li>if you&#8217;re good at it, they will overlook the fact that you&#8217;re not actually &#8220;qualified&#8221; to do the thing (I wasn&#8217;t a TA / lecturer. I was merely another student in an upper class. An upperclassman. 先輩)</li>
<li>if you&#8217;re good at it, you can charge people a lot more than you otherwise think. I got paid about 3x the standard hourly wage of adults working the majority of hourly jobs, and as a student, that was awesome!</li>
</ol>
<p>For context though, there is no tuition fee for your first degree (i.e.: it&#8217;s paid for by the government for you which gets that money from taxes).</p>
<p>The second formative experience was between 2004-2006. I joined an extracurricular architecture club. Basically students who don&#8217;t just want to bumble through the university but actually get good! Like, REALLY GOOD. We pitched to host EASA &#8211; European Architecture Students&#8217; Assembly &#8211; in Budapest in 2006. For that we needed a website, both an internal forum, and a public facing site for sponsors / attendees / workshops / visitors / everyone.</p>
<p>I knew nothing besides basic html.</p>
<p>So naturally I volunteered.</p>
<h3>Leveling up</h3>
<p>I learned PHP, MySQL, and Flash from books: learn php in 24 hours, PHP 4 reference, learn mysql in 24 hours, learn flash in 24 hours, etc. I had one guy over the internet who helped me figure out things in PHP, but other than that I was all alone. Stack Overflow wasn&#8217;t a thing either. Wild times. From memory I could probably exploit that engine in one of 284 ways today. I&#8217;m glad it&#8217;s not online any more. The flash site is, it&#8217;s somewhat broken, but here you go: <a href=\"https://javorszky.github.io/ancientflashsite/\" rel=\"nofollow\">https://javorszky.github.io/ancientflashsite/</a></p>
<p>I built a forum engine and a full actionscript site. We also had a requirement that whoever applies to host whatever workshop, we need to judge the workshop on its own merit, not on who submits it, so I built the submit form in such a way that it took the files, and renamed them, scrubbed the email addresses that reached the judging committee, and we made it a rule that if there&#8217;s any identifying information ON the pdf, it&#8217;s immediately disqualified. The year is 2005.</p>
<p>Looking back, I realized two things:</p>
<ol>
<li>learn to learn on the job, and learn to enjoy not knowing stuff. Nobody does, really</li>
<li>biases are real. Mitigate them. Even the ones you don&#8217;t know about. Especially the ones you don&#8217;t know about! Or at least have a framework by which you acknowledge if you&#8217;re called out</li>
</ol>
<h3>Moving On</h3>
<p>I then decided to not continue my studies there. I was failed in one class where I expected a strong pass. We were split into 12 groups, and groups 1 and 2 got mostly failed, and groups 3-12 got overwhelmingly passed. Something wasn&#8217;t right, I spoke up, but I was a student, and they were faculty. I left because I didn&#8217;t feel like fighting and losing my soul over it.</p>
<blockquote><p>Something wasn&#8217;t right, I spoke up, but I was a student, and they were faculty. I left because I didn&#8217;t feel like fighting and losing my soul over it.</p></blockquote>
<p>I continued making websites for myself and got introduced to WordPress around this time. I don&#8217;t remember my first project. I <em>think</em> it was a site I built for myself in 8 hours for a competition which led me to my first paying website job, which I totally screwed up.</p>
<p>In 2010 I decided to move countries with 3 friends I went to university with, at the time I was studying International Tourism Management, and I could transfer to Oxford Brookes University (not the one you heard about).</p>
<p>I missed the application deadline.</p>
<p>Which meant that I had to find work. When I bought my plane ticket I decided that whatever it takes, I will make it work. Staying in Hungary was not an option for me: I didn&#8217;t like the politics, I didn&#8217;t like where the country was heading economically, and I longed for a more cheerful society to surround me. Movement rights and language I can speak and other people going the same way helped me decide on the UK.</p>
<h3>Restarting</h3>
<p>So I made it work: I accepted the first full time job that I got offered. I worked as a wait staff at the restaurant of one of the luxury hotels in the city. It had very little to do with computers, but I had income, I could pay back the help I got from my friends (and by extension, their families), and I could actually take control of my own life instead of just bumping into furniture.</p>
<blockquote><p>It had very little to do with computers, but I had income, I could pay back the help I got from my friends (and by extension, their families), and I could actually take control of my own life [&#8230;]</p></blockquote>
<p>I&#8217;ve learned a lot from working there. Chef taught me that literally no one cares WHY there was a mistake at that time in putting through an order &#8211; what&#8217;s important is what the error was, what&#8217;s needed to correct it. Everything else is wasting everyone&#8217;s time. Of course we&#8217;d go through these after the service.</p>
<p>I&#8217;ve learned that to work in hospitality, you have to leave your ego at the door. Doesn&#8217;t mean you should take abuse, but there you&#8217;re part of a &#8211; hopefully &#8211; finely tuned, oiled machinery, and keeping the whole thing operating is the number one goal. Turns out that&#8217;s also applicable to working in teams in general.</p>
<p>A year goes by, and we need to move out of the house we&#8217;re renting. In a break between morning and evening shifts I look at the job postings in the local newspaper: someone&#8217;s looking for a developer! It was a Wednesday. I got an interview for Friday, and started on Monday. I had to talk to my supervisor to move me to evening-only shifts because I have a second desk job. My days: 9am &#8211; 4:45pm developer, 5pm &#8211; 2am (ish, whenever we finished) waiting tables. Rinse and repeat.</p>
<p>Working 60-80 hours could only go on for so long. After about 3 months I had a very sharp chest pain while on shift at the restaurant. Had to walk home (normally I cycle), and then made my way to the emergency room where after having waited 5 hours, I got an X-ray, and EKG, and the doctor determined there&#8217;s nothing wrong, so here&#8217;s some Ibuprofen (3&#215;1) and some Paracetamol (1&#215;1).</p>
<blockquote><p>Kids, don&#8217;t work 60-80 hours a week.</p></blockquote>
<p>&#8220;Uh, which one should I take on a day?&#8221; &#8220;Oh&#8230; both!&#8221;</p>
<p>I went home, took the first dose, and slept for 22 hours. I handed in my resignation 2 days later at the restaurant because I needed to not work that much. My manager pleaded me to stay at least on part time, which I did, because they were genuinely lovely people.</p>
<p>Kids, don&#8217;t work 60-80 hours a week.</p>
<h3>Back to the web with full steam</h3>
<p>After a year at the development agency + restaurant combo, I got hired to a WordPress agency through recruiters. My new boss asked me why I haven&#8217;t applied to them directly, even though I saw their ad, why I waited to go through a recruiter. I said I didn&#8217;t think I was good enough. That decision ended up costing him a few thousand pounds in recruitment fees.</p>
<p>I quit my restaurant job for good. I also learned a lesson to actually trust myself.</p>
<p>Something that during the 2,5 years with them I would question a lot of times. There have been instances when I made mistakes that were incredibly easy to avoid had I just taken 5 more minutes to think. But every time it was something we could correct fairly fast (shoutout to hospitality experience!) and then I had a postmortem, and changed the way I work to avoid similar problems.</p>
<p>I had the privilege to work on some seriously challenging WordPress sites while with them. That was my first actual commercial experience with it. We built blogs from Oxford University (the one you heard about) to eCommerce site migrations from Magento using Jigoshop and later WooCommerce.</p>
<p>I&#8217;ve had to disassemble how WooCommerce worked fairly fast because of some of the client requirements, and I got pretty good at it.</p>
<p>In November 2014 I got hired to one of the product companies around WooCommerce and spent a year and a half with them maintaining their plugins, answering customer queries and helping them fix their sites occasionally. That was my first help desk experience.</p>
<p>I got access to some incredibly large eCommerce stores and I quickly discovered where the bottlenecks were in our plugins, WordPress, and WooCommerce itself. Some of the customers had access to New Relic, which I could use to help me find what&#8217;s taking so long.</p>
<p>From then on it was just a case of finding what&#8217;s slow, following it back, reading the documentation and code on why it&#8217;s slow, and coming up with ideas on how to fix it.</p>
<p>I got really good at this.</p>
<h3>The Freelance Days</h3>
<p>At the end of July 2016 our ways parted, and I had a buffer of about 3 months when I didn&#8217;t need to worry about having to find another job. While trying to figure out what to do, where next, I started getting requests to work on some projects. They asked me my hourly rate. I said a number I was slightly uncomfortable with, they said yeah, and off I went.</p>
<blockquote><p>[&#8230;] I started getting requests to work on some projects. They asked me my hourly rate. I said a number I was slightly uncomfortable with, they said yeah [&#8230;]</p></blockquote>
<p>It also helped that I was at the time known for my love of hard problems and actually figuring out why things break and fixing them.</p>
<p>I thought &#8220;hey, if I can command that much hourly rate, I could make this work!&#8221;</p>
<p>I took on clients, and managed to make things work for&#8230; a surprisingly long time. Having GREAT accountants is a must for self employment.</p>
<p>I suddenly also had time to pursue some of my other interests: I learned how to ride a motorcycle.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2017/12/gabor_motorcycle.jpg\"><img class=\"aligncenter size-large wp-image-2344\" src=\"https://heropress.com/wp-content/uploads/2017/12/gabor_motorcycle-1024x576.jpg\" alt=\"Gabor standing by a sporty motorcycle\" width=\"960\" height=\"540\" /></a></p>
<p>I started learning Japanese! I got back onto the slackline.</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2017/12/gabor_slackline.jpg\"><img class=\"aligncenter size-large wp-image-2345\" src=\"https://heropress.com/wp-content/uploads/2017/12/gabor_slackline-1024x768.jpg\" alt=\"Gabor balancing on a narrow strap hung between two trees\" width=\"960\" height=\"720\" /></a></p>
<p>I got to speak at WordCamp Brighton in 2017!</p>
<p><a href=\"https://heropress.com/wp-content/uploads/2017/12/gabor_wordcamp.jpg\"><img class=\"aligncenter wp-image-2346 size-large\" src=\"https://heropress.com/wp-content/uploads/2017/12/gabor_wordcamp-1024x683.jpg\" alt=\"Gabor, on stage at WordCamp Brighton\" width=\"960\" height=\"640\" /></a></p>
<p>Until very recently, it was a game of &#8220;how long can I be self employed before I need to look for a job?&#8221; Turns out I couldn&#8217;t answer this, because an opportunity came up to join Mindsize as a lead backend developer.</p>
<p>When I heard about them starting up a few months prior, I had two thoughts:</p>
<ol>
<li>they are probably the only company I would stop doing freelance work for</li>
<li>I&#8217;m not good enough to work with them yet</li>
</ol>
<p>Statement 1 was true :).</p>
<h3>Catching up with the present</h3>
<p>This brings us into the very recent present. It&#8217;s maybe a month old development at the time of publication. Since then I&#8217;ve been working really hard to reclaim my time of about 40 hours worked a week. With the holiday push of the clients I had as a freelancer, there was a transition phase where I had to work 60-80 hours.</p>
<p>Don&#8217;t work 60-80 hours a week, kids!</p>
<p>Looking back it was incredibly humbling experience so far, but also exciting, and full of challenges, and learnings. I&#8217;ve made a lot of excellent friends, and luckily very few enemies. I am grateful for each and every one of them.</p>
<p>I don&#8217;t know where life takes me. For the foreseeable future I&#8217;ll be with Mindsize and will make eCommerce sites awesome, and will make awesome eCommerce sites. But I&#8217;ll also try and pass on some of the things I&#8217;ve learned by helping people new to the industry.</p>
<p>There are a lot more things I could say, but they aren&#8217;t necessarily part of my journey, so I&#8217;ll save them for some other time.</p>
<h3>On privilege</h3>
<blockquote><p>We, as web developers, programmers, people who speak English, people who have internet access to read this article, are incredibly, very, very, very lucky.</p></blockquote>
<p>Except for one thing. When I worked at the WordPress agency, Twitter, and by extension, society, started the &#8220;check your privilege&#8221; trend. It took a while to understand what it was all about, but it&#8217;s something I wish everyone did.</p>
<p>We, as web developers, programmers, people who speak English, people who have internet access to read this article, are incredibly, very, very, very lucky. I&#8217;ve realized that my journey wouldn&#8217;t have been possible had I been born to less fortunate circumstances:</p>
<p>If my parents didn&#8217;t make the decision to start teaching me English when I was 3.</p>
<p>If I didn&#8217;t have the financial stability in my family to be able to just explore what I like to do.</p>
<p>If I didn&#8217;t have the financial stability to just drop out of university after 3 years because &#8220;I didn&#8217;t like it&#8221;. And another one after a semester. And never finish my Tourism Management course.</p>
<p>If I didn&#8217;t live in a developed nation with easy access and high standards of living.</p>
<p>This brings into mind one of my favorite tweets:</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Your job, lucky person, is to help others less lucky than you to improve their odds.</p>
<p>&mdash; Dylan Wilbanks, Human Grumpy Cat (@dylanw) <a href=\"https://twitter.com/dylanw/status/522060876304486400?ref_src=twsrc%5Etfw\">October 14, 2014</a></p></blockquote>
<p></p>
<p>Not everyone has these opportunities and every day I am conscious of it.</p>
<p>Humans are hard. Interpersonal skills are hard. Treating each other with dignity, respect, and grace is hard if you haven&#8217;t been brought up with those values as a kid. It&#8217;s been a challenge for me to shed the &#8220;boys will be boys&#8221; upbringing I was carrying.</p>
<p>Let&#8217;s use our power and means and help the less fortunate walk their own paths. Let&#8217;s lessen marginalization with the view of ending it. Let&#8217;s be excellent to each other!</p>
<p>And don&#8217;t use &#8220;guys&#8221; to mean everyone!</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Finding My Way Out Of My Comfort Zone\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Finding%20My%20Way%20Out%20Of%20My%20Comfort%20Zone&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Ffinding-way-comfort-zone%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Finding My Way Out Of My Comfort Zone\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Ffinding-way-comfort-zone%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Ffinding-way-comfort-zone%2F&title=Finding+My+Way+Out+Of+My+Comfort+Zone\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Finding My Way Out Of My Comfort Zone\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/finding-way-comfort-zone/&media=https://heropress.com/wp-content/uploads/2017/12/121317-150x150.jpg&description=Finding My Way Out Of My Comfort Zone\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Finding My Way Out Of My Comfort Zone\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/finding-way-comfort-zone/\" title=\"Finding My Way Out Of My Comfort Zone\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/finding-way-comfort-zone/\">Finding My Way Out Of My Comfort Zone</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Dec 2017 08:00:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gabor Javorszky\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Storify to Close May 16, 2018, WordPress Plugin Discontinued\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76992\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/storify-to-close-may-16-2018-wordpress-plugin-discontinued\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2906:\"<p><a href=\"https://storify.com/\">Storify</a>, a service that launched in 2010 and opened to the public in 2013 has announced that it is shutting down version one of its service on May 16th, 2018. Concurrently, its WordPress plugin that is actively installed on more than 2,000 sites has been <a href=\"https://wordpress.org/plugins/storify/\">discontinued</a>. </p>



<img src=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/12/StorifyPluginDiscontinued.png?w=627&ssl=1\" />
    Storify Plugin is Discontinued




<p>Storify enabled journalists and others to build stories and timelines similar to Twitter and other social networks. The service <a href=\"https://techcrunch.com/2013/09/09/livefyre-acquires-storify/\">was acquired</a> by <a href=\"http://www.livefyre.com\">Livefyre</a> in 2013 and became part of Adobe when it <a href=\"https://techcrunch.com/2016/05/03/adobe-acquires-livefyre/\">acquired Livefyre</a> in 2016. </p>



<p>Storify has disabled new accounts from being created and will delete stories and accounts on May 16th, 2018. Existing users who want to move to Storify 2, a paid feature of Livefyre, will need to purchase a license. The service has <a href=\"https://storify.com/faq-eol\">published a FAQ</a> that includes directions on how to export content. </p>



<h2>New Plugin Opportunity</h2>



<p>According to some users, the export process is cumbersome, providing an excellent opportunity for a prospecting developer to create a WordPress plugin that makes the process easier. A search of the WordPress plugin directory for Storify Export produces zero results. <br /></p>




    <blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">A fantastic <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> dev opportunity: <a href=\"https://twitter.com/Storify?ref_src=twsrc%5Etfw\">@Storify</a> just announced its \"End of Life\" for May 2018. The export is kinda lame. If I could import a story from Storify into a WordPress Post/Page that would be fabulous! I have a few stories that I wouldn\'t want to lose. <a href=\"https://twitter.com/hashtag/biz?src=hash&ref_src=twsrc%5Etfw\">#biz</a></p>&mdash; Birgit Pauli-Haack (@bph) <a href=\"https://twitter.com/bph/status/940706045449703424?ref_src=twsrc%5Etfw\">December 12, 2017</a></blockquote>





    <blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">I have a lot of Storify stories I\'d hate to lose, too. If you hear of someone doing this, I\'d love to know about it.</p>&mdash; Deborah Edwards-Onoro (@redcrew) <a href=\"https://twitter.com/redcrew/status/940729186469253120?ref_src=twsrc%5Etfw\">December 12, 2017</a></blockquote>




<p>If you know of any methods or plugins that eases the process of exporting content from Storify and importing it to WordPress, please share them in the comments. Also feel free to let us know if you create a plugin that performs this task. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Dec 2017 07:30:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Gutenberg and the WordPress of Tomorrow by Morten Rand-Hendriksen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76959\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://wptavern.com/gutenberg-and-the-wordpress-of-tomorrow-by-morten-rand-hendriksen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1054:\"<p>While attending WordCamp US 2017, there were a number of sessions that stood out to me. <a href=\"https://wordpress.tv/2017/12/10/morten-rand-hendriksen-gutenberg-and-the-wordpress-of-tomorrow/\">Gutenberg and the WordPress of Tomorrow</a> by Morten Rand-Hendriksen was one of them. </p>



<p>Hendriksen explains the state of WYSIWYG in WordPress and how it doesn&#x27;t really exist but Gutenberg provides opportunities to change that. He explores developing sites without being confined to a small view port. He also performs a live demo of Gutenberg showing off its capabilities.</p>



<p>An interesting outcome from his presentation is the amount of optimism and excitement it generated from the audience. During the question and answer session, a member of the audience commented on how far Gutenberg has advanced in the last three months and that it looks cool to use now. </p>



<p>To gain insight into how Gutenberg can moonshot WordPress over its competition, watch Hendriksen&#x27;s presentation. </p>




    <div class=\"embed-wrap\"></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Dec 2017 20:57:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Post-Verbal Language\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47705\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"https://ma.tt/2017/12/post-verbal-language/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1800:\"<p>James Beshara has a <a href=\"https://jjbeshara.com/2017/12/09/a-post-verbal-world/\">really interesting read on how communication will change and evolve in a post-verbal world</a>, namely one where human/brain interfaces like <a href=\"https://waitbutwhy.com/2017/04/neuralink.html\">Neuralink</a> can more directly transmit thought between people than the medium of language allows today. </p>



<p>After reading the essay I wonder if people&#x27;s thoughts or the neural pathways they activate, if they could be directly transmitted into another brain, would actually make any sense to someone else with a unique internal set of pathways and framework for parsing and understanding the world. The essay assumes we&#x27;d understand and have more empathy with each other, but that seems like a leap. It seems likely the neural link would need it own set of abstractions, perhaps even unique per person, similar to how <a href=\"https://www.newscientist.com/article/2114748-google-translate-ai-invents-its-own-language-to-translate-with/\">Google Translate AI invented its own meta-language</a>. </p>



<p>Today <a href=\"https://www.economist.com/news/leaders/21730871-facebook-google-and-twitter-were-supposed-save-politics-good-information-drove-out\">idea-viruses that cause outrage (outrageous?) in today&#x27;s discourse  have been weaponized by algorithms optimizing for engagement</a>, and directly brain-transmitted memes seem especially risky for appealing to our base natures or causing <a href=\"https://en.wikipedia.org/wiki/Amygdala_hijack\">amygdala hijack</a>. But perhaps a feature of these neural interface devices could counteract that, with a command like \"tell me this piece of news but suppress my confirmation bias and tribal emotional reactions while I&#x27;m taking it in.\"</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Dec 2017 03:09:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: iPhone Fast Charging\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47682\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"https://ma.tt/2017/12/iphone-charging/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:382:\"<p>I love USB, cables, and charging things. <a href=\"https://www.macrumors.com/guide/iphone-x-fast-charging-speeds-compared/\">So MacRumors comparison of different wired and wireless charging options and speed for the iPhone X is my catnip</a>. tl; dr: USB-C + USB-C-to-Lightning cable gives you far and away the fastest times. I&#x27;ve found this true for the iPad Pro as well.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 Dec 2017 16:51:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: State of the Word, 2017\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47687\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://ma.tt/2017/12/state-of-the-word-2017/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:524:\"<p>I really enjoyed connecting with the WordPress community in Nashville this previous weekend. On Saturday I delivered the State of the Word presentation alongside <a href=\"https://choycedesign.com/\">Mel</a>, <a href=\"https://weston.ruter.net/\">Weston</a>, and <a href=\"https://matiasventura.com/\">Matías</a>. There&#x27;s always a post-event buzz but I definitely noticed a change in tenor of people&#x27;s thoughts on Gutenberg after the presentation and demo. The video is above, check it out when you get a chance.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Dec 2017 23:38:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"HeroPress: Remote Work Brings Freedom\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2324\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"https://heropress.com/essays/remote-work-brings-freedom/#utm_source=rss&utm_medium=rss&utm_campaign=remote-work-brings-freedom\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:20981:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2017/12/120617-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: WordPress is not just a CMS, it\'s a Community of lovely people!\" /><p><a href=\"https://heropress.com/feed/#gujarati\">આ નિબંધ ગુજરાતીમાં પણ ઉપલબ્ધ છે</a></p>
<p>First of all, I want to say thank you to HeroPress for reaching out and letting so many people share their stories. I am a follower of HeroPress and read new stories every week! A few months ago my friend <a href=\"https://heropress.com/essays/wordpress-good-indian-women/\">Juhi Patel shared her great WordPress story</a>, and I was inspired by her to share my own and how it has changed my way of working.</p>
<blockquote><p>I am that guy who hates theory and loves to do practical programming.</p></blockquote>
<p>After completing my bachelor of engineering with Information Technology in 2013, I was looking for a job. I found that there were many different kinds of programming language jobs that were available. I was really not sure which one I needed or wanted to choose. After getting advice from a senior, I started training for PHP because it was easy and quick to learn. A few days before I had completed Training, I got selected in small company (5 Employees) as a PHP Developer. I was making websites there using PHP codeigniter framework.</p>
<p>I was belong from a small town, and everyday it took me around 3 hours to travel to my job. After about 2 months, I applied for a job at another big company and was selected as Web Developer. There I was working on CMS Framework (not WordPress <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f600.png\" alt=\"😀\" class=\"wp-smiley\" /> ) for website projects. After a few days, I made my personal site using WordPress in my free time.</p>
<blockquote><p>At that time, I was not aware of themes and plugins. I was just playing with theme files and editor to make changes on my website! <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f61c.png\" alt=\"😜\" class=\"wp-smiley\" /></p></blockquote>
<p>After a month, my team leader got to know about that I was interested in WordPress. I got the opportunity to learn WordPress. I learned and explored WordPress with some demo projects by understanding how plugins and themes work. After 3 weeks of learning WordPress, I worked on my first WordPress project. This project took around 4 months to complete <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f600.png\" alt=\"😀\" class=\"wp-smiley\" /> After this successful project, the whole CMS Team migrated to WordPress.</p>
<blockquote><p>I realized that, WordPress is so easy to learn, get help and work on it!</p></blockquote>
<p>After around 1 year and 3 months of working with that company, I was told to work after working hours due to heavy requirements from our projects. I felt really stressed and frustrated at work and during that time…</p>
<blockquote><p>I got to know about “Remote” work. But I didn’t know what that was or how it works?</p></blockquote>
<p>I explored about remote work and found that this is a career that you can work from your home, workplace or anywhere you like. I saw that many people in world are doing remote work happily. I decided to switch my job from Office Job to Remote Job. My parents, family and relatives advised me to not leave office job because they believed Remote Job is not as secure as an Office Job. But I stuck with my decision. In March 2015, I resigned from my job without notice period with the condition of no experience letter would be provided to me of this job.</p>
<blockquote><p>At the initial stage it was hard to be freelancer. But I was trying and trying to get that started.</p></blockquote>
<p>I had registered in one popular freelancer marketplace. After 1 week of trying very hard I got my first project. It was just for $5 to make an HTML page with a countdown timer. I did it successfully and got the best review. After that I had also completed many projects successfully. That’s it! I was done with my decision. Within the first few weeks I made a website for one US Client. They were impressed by my work and hired me as Full time Web Developer for their company in April 2015. I am remotely working with them happily still today from my home!</p>
<blockquote><p>Everything is going smoothly. I am enjoying Work from Home, Freedom and Quality time with Family.</p></blockquote>
<p>In October 2016, I learned about WordCamp. I attended my first WordCamp Nashik 2016. I met many WordPress Developers, Freelancers, Professionals, Users and many other people at this WordCamp. After that, I became a fan of WordCamp. We started organizing Meetups in our City. Within the last year, I have attended, volunteered and contributed as a friend and sponsor at more than 6 WordCamps. Currently I am active member of Ahmedabad WordPress Community.</p>
<blockquote><p>I am a WordCamp Lover. WordCamp is a way to meet new people, learn and share knowledge!</p></blockquote>
<p>In October 2017, we successfully organized WordCamp in our city. I have been speaking about how remote job can be a good opportunity as a career to students and newbie in panel discussion of WordCamp Ahmedabad.</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/12/wcahmedabad-panel-discussion.jpg\"><img class=\"size-large wp-image-2325\" src=\"https://heropress.com/wp-content/uploads/2017/12/wcahmedabad-panel-discussion-1024x683.jpg\" alt=\"4 men on a couch at the front of a room.\" width=\"960\" height=\"640\" /></a>Panel Discussion &#8211; WordCamp Ahmedabad 2017 (PC. Meher Bala)
<blockquote><p>WordPress is not just a CMS, It&#8217;s a community of lovely people!</p></blockquote>
<hr />
<h1 id=\"gujarati\">રિમોટ કામ સ્વતંત્રતા લાવે છે.</h1>
<blockquote><p>“મને હીરોપ્રેસ સ્ટોરીમાં ભાગ લેવામાં કેવી રીતે પ્રેરણા મળી?”</p></blockquote>
<p>સૌ પ્રથમ, ઘણા લોકો સુધી પહોંચીને અને તેમની વાર્તાઓ કહેવા માટે હું હીરોપ્રેસનો ખુબ જ આભાર માનું છું. હું હિરોપ્રેસનો અનુયાયી છું અને દર અઠવાડિયે નવી વાર્તાઓ વાંચું છું! થોડા મહિના પહેલા મારી મિત્ર જુહી પટેલે તેની વર્ડપ્રેસની રસપ્રદ વાર્તા હીરોપ્રેસ પર કહી હતી. તે વાંચીને મને, મારા પોતાની વાર્તા, મારા કામ કરવાની રીત કઇ રીતે બદલાઈ તે કહેવા માટે પ્રેરણા મળી હતી.</p>
<blockquote><p>&#8220;હું તે વ્યક્તિ છું જે થિયોરીને નફરત કરે છે અને પ્રાયોગિક પ્રોગ્રામિંગ કરવા માટે પ્રેમ કરે છે. &#8220;</p></blockquote>
<p>2013 માં ઇન્ફોર્મેશન ટેકનોલોજી સાથે મારી સ્નાતક એન્જિનિયરિંગ પૂર્ણ કર્યા પછી, હું નોકરી શોધી રહ્યો હતો ત્યારે મેં જોયું કે અહીં ઘણી બધી પ્રોગ્રામિંગ ભાષાની નોકરીઓ ઉપલબ્ધ છે. ત્યારે હું ચોક્કસ ન હતો કે મારે કઈ પ્રોગ્રામિંગ ભાષા પસંદ કરવાની જરૂર છે? વરિષ્ઠ પાસેથી સલાહ મેળવ્યા પછી, મેં PHP માટે તાલીમ શરૂ કરી, કારણ કે તે શીખવા માટે સરળ અને ઝડપી હતી. તાલીમ પૂર્ણ થયાના થોડા દિવસો પહેલાં, મારી નાની કંપની (5 કર્મચારીઓ) માં PHP ડેવલપર તરીકે પસંદગી થઇ. હું PHP Codeigniter ફ્રેમવર્કનો ઉપયોગ કરીને ત્યાં વેબસાઇટ્સ બતાવતો હતો.</p>
<p>હું એક નાનકડા શહેરમાંથી આવતો હતો, અને દરરોજ મને મારી નોકરી પર મુસાફરી કરવા માટે 3 કલાક જેવા થતા હતા. લગભગ 2 મહિના પછી, મેં બીજી મોટી કંપનીમાં નોકરી માટે અરજી કરી હતી અને ત્યાં મારી વેબ ડેવલપર તરીકે પસંદગી કરવામાં આવી હતી. ત્યાં હું વેબસાઇટ સંબંધિત પ્રોજેક્ટ્સ માટે સીએમએસ ફ્રેમવર્ક (વર્ડપ્રેસ સિવાયની <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f600.png\" alt=\"😀\" class=\"wp-smiley\" />) પર કામ કરતો હતો. થોડા દિવસો પછી, મેં મારી વ્યક્તિગત વેબસાઈટને મારા સ્વતંત્ર સમય દરમિયાન વર્ડપ્રેસની મદદથી બનાવી.</p>
<blockquote><p>&#8220;તે સમયે, હું થીમ્સ અને પ્લગિન્સથી વાકેફ ન હતો. હું મારી વેબસાઇટ પર ફેરફારો કરવા માટે માત્ર થીમ ફાઇલો અને એડિટર સાથે રમી રહ્યો હતો! <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f61c.png\" alt=\"😜\" class=\"wp-smiley\" />&#8221;</p></blockquote>
<p>એક મહિના પછી, મારી ટીમના આગેવાનને જાણવા મળ્યું કે મને વર્ડપ્રેસમાં રસ હતો. ત્યારે મને વર્ડપ્રેસ શીખવાની તક મળી. વર્ડપ્રેસ થીમ્સ અને પ્લગીંસ કેવી રીતે કામ કરે છે એ સમજવા, મેં જાતે શીખીને કેટલાક ડેમો પ્રોજેક્ટસ બનાવ્યા. વર્ડપ્રેસ શીખવાના 3 અઠવાડિયા પછી, મેં મારા પ્રથમ વર્ડપ્રેસ લાઈવ પ્રોજેક્ટ પર કામ કર્યું હતું. આ પ્રોજેક્ટ પૂર્ણ કરવા માટે મને લગભગ 4 મહિના લાગ્યા હતા <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f600.png\" alt=\"😀\" class=\"wp-smiley\" /> આ સફળ પ્રોજેક્ટ પછી, સમગ્ર સીએમએસ ટીમ વર્ડપ્રેસમાં જોડાઈ ગઈ.</p>
<blockquote><p>&#8220;મેં અનુભવ કર્યો કે, વર્ડપ્રેસ શીખવું, સહાય મેળવવી અને તેના પર કાર્ય કરવુ ખૂબ જ સરળ છે!&#8221;</p></blockquote>
<p>લગભગ 1 વર્ષ અને 3 મહિના તે કંપની સાથે કામ કર્યા પછી, મને અમારા પ્રોજેક્ટ્સની ભારે આવશ્યકતાના કારણે કામના કલાકો પછી પણ વધારે રોકાઈને કામ કરવા કહેવામાં આવતું હતું અને તે 2 સપ્તાહથી વધુ ચાલુ રહ્યું. ત્યારે મને કામ કરવું ખરેખર ભારયુક્ત અને નિરાશાજનક લાગવા લાગ્યું, તે સમય દરમિયાન ..</p>
<blockquote><p>&#8220;મને &#8220;રિમોટ&#8221; કામ વિશે જાણવા મળ્યું. પરંતુ મને ખબર નહોતી કે તે કે તે કેવી રીતે કાર્ય કરે છે?&#8221;</p></blockquote>
<p>મેં રિમોટ કામ વિશે તપાસ કરી અને જાણવા મળ્યું કે આ એક કારકિર્દી છે જે તમે તમારા ઘર, કાર્યસ્થળ અથવા તમને પસંદ હોય એ જગ્યાએથી કામ કરી શકો છો. મેં જોયું કે દુનિયામાં ઘણા લોકો રિમોટ કામ ખુબ જ ખુશીથી કરી રહ્યા હતા. મેં ઑફિસ જોબ છોડીને રિમોટ કામ કરવાનું નક્કી કર્યું. મારા માતાપિતા, કુટુંબીજનો અને સંબંધીઓએ મને ઓફિસની નોકરી ના છોડવાની સલાહ આપી કારણ કે તેઓ માનતા હતા કે રિમોટ કામ એ ઓફિસ જોબ જેટલું સુરક્ષિત નથી. પરંતુ હું મારા નિર્ણય સાથે જોડાઈ રહ્યો. માર્ચ 2015 માં, મેં નોટિસના સમયગાળા વગર મારા કામમાંથી રાજીનામું આપ્યું હતું અને શરત હતી કે આ નોકરીનો કોઈપણ અનુભવ પત્ર મને પૂરો પાડવામાં આવશે નહીં.</p>
<blockquote><p>&#8220;પ્રારંભિક તબક્કે ફ્રીલાન્સર બનવું મુશ્કેલ હતું. પરંતુ હું તે ગમે તેમ કરીને શરૂ કરવાનો ખુબ જ પ્રયાસ કરી રહ્યો હતો.&#8221;</p></blockquote>
<p>મેં એક લોકપ્રિય ફ્રીલાન્સર માર્કેટપ્લેસમાં રજીસ્ટર કર્યું હતું. 1 અઠવાડિયાના સખત પ્રયાસ કાર્ય પછી મને પહેલો પ્રોજેક્ટ મળ્યો. આ પ્રોજેક્ટ કાઉન્ટડાઉન ટાઈમર સાથે એક HTML પેજ બનાવવા માટે મને માત્ર $5 મળ્યા હતા. મેં એ પ્રોજેક્ટ સફળતાપૂર્વક પૂરો કર્યો અને શ્રેષ્ઠ રિવ્યૂ મેળવ્યો. તે પછી મેં ઘણા પ્રોજેક્ટ્સ પણ સફળતાપૂર્વક પૂર્ણ કર્યા હતા. બસ આ જ! મને મારો નિર્ણય સાચો પુરવાર થયો. પ્રથમ થોડા અઠવાડિયાની અંદર મેં એક યુએસ ક્લાયન્ટ માટે વેબસાઇટ બનાવી. તેઓ મારા કામથી પ્રભાવિત થયા હતા અને એપ્રિલ 2015 માં મને તેમની કંપની માટે સંપૂર્ણ સમય માટે વેબ ડેવલપર તરીકે નિયુક્ત કર્યો. હું આજે પણ તેમની સાથે ખુબ જ ખુશીપૂર્વક મારા ઘરેથી રિમોટ કામ કરું છું!</p>
<blockquote><p>&#8220;બધું સરળતાપૂર્વક જઈ રહ્યું છે. હું ઘરેથી કામ કરીને સ્વતંત્રતા અને પરિવાર સાથે ગુણવત્તાભર્યો સમય પસાર કરવાનો આનંદ અનુભવું છું.&#8221;</p></blockquote>
<p>ઑક્ટોબર 2016 માં, મને વર્ડકેમ્પ વિશે જાણવા મળ્યું. મેં મારી પહેલી વર્ડકેમ્પ નાસિક 2016 માં હાજરી આપી હતી. હું ઘણા વર્ડપ્રેસ ડેવલપર્સ, ફ્રીલાન્સર્સ, પ્રોફેશનલ્સ, યુઝર્સ અને ઘણા અન્ય લોકોને આ વર્ડકેમ્પ પર મળ્યો હતો. તે પછી, હું વર્ડકેમ્પ નો ચાહક બની ગયો. અમે અમારા શહેરમાં મીટપનું નું આયોજન કરવાનું શરૂ કર્યું. છેલ્લા વર્ષમાં, 6 થી વધુ વર્ડકેમ્પ પર મેં હાજરી આપીને, સ્વયંસેવક અને મિત્ર સ્પોન્સર તરીકે ફાળો આપ્યો છે. હાલમાં હું અમદાવાદ વર્ડપ્રેસ સમુદાયનો સક્રિય સભ્ય છું</p>
<blockquote><p>&#8220;હું વર્ડકેમ્પનો પ્રેમી છું. વર્ડકેમ્પ નવા લોકોને મળવાનો, પોતાના જ્ઞાનની આપ-લે કરવાનો એક માર્ગ છે!&#8221;</p></blockquote>
<p>ઓક્ટોબર 2017 માં, અમે અમારા શહેરમાં સફળતાપૂર્વક વર્ડકૅમ્પનું આયોજન કર્યું હતું. વર્ડકૅમ્પ અમદાવાદની પેનલ ચર્ચામાં મેં વિદ્યાર્થીઓ અને વપરાશકર્તાઓ માટે રિમોટ કામ કેવી રીતે સારી કારકિર્દી હોઈ શકે તે વિશે ચર્ચા કરી હતી.</p>
<blockquote><p>&#8220;વર્ડપ્રેસ ફક્ત સીએમએસ નથી, પણ તે શ્રેષ્ઠ લોકોનો સમુદાય છે.&#8221;</p></blockquote>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Remote Work Brings Freedom\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Remote%20Work%20Brings%20Freedom&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fremote-work-brings-freedom%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Remote Work Brings Freedom\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fremote-work-brings-freedom%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fremote-work-brings-freedom%2F&title=Remote+Work+Brings+Freedom\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Remote Work Brings Freedom\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/remote-work-brings-freedom/&media=https://heropress.com/wp-content/uploads/2017/12/120617-150x150.jpg&description=Remote Work Brings Freedom\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Remote Work Brings Freedom\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/remote-work-brings-freedom/\" title=\"Remote Work Brings Freedom\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/remote-work-brings-freedom/\">Remote Work Brings Freedom</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Dec 2017 02:30:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Chetan Prajapati\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: WordCamp US 2017 is Livestreaming All Sessions for Free\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76937\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/wordcamp-us-2017-is-livestreaming-all-sessions-for-free\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2781:\"<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2017/04/wordcamp-us-nashville.jpeg?ssl=1\"><img /></a></p>
<p>WordCamp US is kicking off this morning. If you couldn&#8217;t make the journey to Nashville, you can still follow along at home or wherever you are in the world. <a href=\"https://2017.us.wordcamp.org/tickets/\" rel=\"noopener\" target=\"_blank\">Livestream Tickets</a> are free on the event&#8217;s website. Once you&#8217;ve registered for a ticket, head on over to <a href=\"https://2017.us.wordcamp.org/live-stream/\" rel=\"noopener\" target=\"_blank\">2017.us.wordcamp.org/live-stream/</a> and you&#8217;ll be able to tune in to the Fiddle Track, Banjo Track, Guitar Track, and the State of the Word (scheduled for Saturday, December 2, at 4PM CST).</p>
<p>WordCamp US will be running three tracks simultaneously for both days of the conference and all sessions will be livestreamed. Check out the <a href=\"https://2017.us.wordcamp.org/schedule/\" rel=\"noopener\" target=\"_blank\">schedule</a> to find sessions you want to attend from home. Volunteers will also include captions, which will be embedded within the live stream video. If you have any problems with the stream, the event has a page dedicated to <a href=\"https://2017.us.wordcamp.org/live-stream/attendee-test/\" rel=\"noopener\" target=\"_blank\">livestream attendees</a> with a backup stream, as well as a troubleshooting page for <a href=\"https://2017.us.wordcamp.org/live-stream/support/\" rel=\"noopener\" target=\"_blank\">livestream support</a>.</p>
<p>If you&#8217;re following along on Twitter, the <a href=\"https://twitter.com/wordcampus\" rel=\"noopener\" target=\"_blank\">WCUS Twitter</a> volunteers will be providing threaded coverage of sessions. This should keep your Twitter stream a little tidier with a kickoff tweet for each session, followed by live coverage threaded under each as replies.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Want to follow along with WCUS coverage at home? It will be easy by following our threaded coverage.  Each session will start with a tweet that looks like this, All coverage of that session will be threaded to that kick-off tweet. <a href=\"https://t.co/J0M6jo6GEi\">pic.twitter.com/J0M6jo6GEi</a></p>
<p>&mdash; WordCamp US (@WordCampUS) <a href=\"https://twitter.com/WordCampUS/status/936595172485468160?ref_src=twsrc%5Etfw\">December 1, 2017</a></p></blockquote>
<p></p>
<p>Want to see WCUS hosted near you in 2019/2020? <a href=\"https://wordcampcentral.polldaddy.com/s/wcus-2019-2020\" rel=\"noopener\" target=\"_blank\">Applications for host cities</a> opened today. If you want to be part of the team that makes WCUS happen in your city, talk to your local WordPress community organizers about filling out an application for the next host city.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 01 Dec 2017 15:34:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"Dev Blog: The Month in WordPress: November 2017\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5290\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2017/12/the-month-in-wordpress-november-2017/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4232:\"<p>The WordPress project recently released WordPress 4.9, “Tipton” — a new major release named in honor of musician and band leader Billy Tipton. Read on to find out more about this and other interesting news from around the WordPress world in November.</p>



<hr class=\"wp-block-separator\" />



<h2>WordPress 4.9 “Tipton”</h2>



<p>On November 16, <a href=\"https://wordpress.org/news/2017/11/tipton/\">WordPress 4.9 was released</a> with new features for publishers and developers alike. Release highlights include design locking, scheduling, and previews in the Customizer, an even more secure and usable code editing experience, a new gallery widget, and text widget improvements.</p>



<p>The follow up security and maintenance, v4.9.1, <a href=\"https://wordpress.org/news/2017/11/wordpress-4-9-1-security-and-maintenance-release/\">has now been released</a> to tighten up the security of WordPress as a whole.</p>



<p>To get involved in building WordPress Core, jump into the #core channel in the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>, and follow<a href=\"https://make.wordpress.org/core/\"> the Core team blog</a>.</p>



<h2>Apply to Speak At WordCamp Europe 2018</h2>



<p>The next edition of WordCamp Europe takes place in June, 2018. While the organizing team is still in the early stages of planning, <a href=\"https://2018.europe.wordcamp.org/2017/11/15/are-you-ready-to-speak-at-the-largest-wordpress-event-in-europe/\">they are accepting speaker applications</a>.</p>



<p>WordCamp Europe is the largest WordCamp in the world and, along with WordCamp US, one of the flagship events of the WordCamp program — speaking at this event is a great way to give back to the global WordPress community by sharing your knowledge and expertise with thousands of WordPress enthusiasts.</p>



<h2>Diversity Outreach Speaker Training Initiative</h2>



<p>To help WordPress community organizers offer diverse speaker lineups, <a href=\"https://make.wordpress.org/community/2017/11/13/call-for-volunteers-diversity-outreach-speaker-training/\">a new community initiative has kicked off</a> to use existing <a href=\"https://make.wordpress.org/training/handbook/speaker-training/\">speaker training workshops</a> to demystify speaking requirements and help participants gain confidence in their ability to share their WordPress knowledge in a WordCamp session.</p>



<p>The working group behind this initiative will be meeting regularly to discuss and plan how they can help local communities to train speakers for WordCamps and other events.</p>



<p>To get involved in this initiative, you can join the meetings at 5pm UTC every other Wednesday in the #community-team channel of the<a href=\"https://make.wordpress.org/chat/\"> Making WordPress Slack group</a>.</p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul>
    <li><a href=\"https://2017.us.wordcamp.org/\">WordCamp US 2017</a> is happening on December 1-3 in Nashville, with the annual State of the Word talk happening on Saturday afternoon — <a href=\"https://2017.us.wordcamp.org/live-stream/\">the live stream of the entire event is available to view for free</a>.</li>
    <li><a href=\"https://xwp.co/tide-a-path-to-better-code-across-the-wordpress-ecosystem/\">Tide</a>, a new service from XWP designed to help users make informed plugin choices, is due to launch at WordCamp US.</li>
    <li>Gutenberg development is continuing rapidly, with <a href=\"https://make.wordpress.org/core/2017/11/28/whats-new-in-gutenberg-28th-november/\">a packed new release</a> and a focus on <a href=\"https://make.wordpress.org/test/2017/11/22/testing-flow-in-gutenberg/\">usability testing</a>.</li>
    <li>After some discussion among the community, <a href=\"https://make.wordpress.org/community/2017/11/10/discussion-micro-regional-wordcamps/\">a new type of micro-regional WordCamp</a> is going to be introduced into the global WordCamp program.</li>
</ul>



<p><em></em></p>



<p><em>If you have a story we should consider including in the next “Month in WordPress” post, please <a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\">submit it here</a>.</em></p>



<p><em></em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 01 Dec 2017 11:00:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"BuddyPress: BuddyPress 2018 Survey\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=269296\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://buddypress.org/2017/12/buddypress-2018-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:630:\"<p>What would you like BuddyPress to focus on in 2018? The core team has ideas of where BuddyPress can expand on and your input is important to harness the time and resources of an all-volunteer crew.</p>
<p>The survey will take 10-15 minutes to complete. Be assured that we will not publish your name, email address, nor IP address when we post the results of this survey at BuddyPress.org.</p>
<p>Thank you for your time and cooperation. Your feedback will help us improve BuddyPress for you.</p>
<p>=&gt;  <strong><a href=\"https://mercime.polldaddy.com/s/buddypress-2018-survey\">Take the 2018 BuddyPress Survey</a></strong></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 01 Dec 2017 10:26:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"@mercime\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Gutenberg 1.8 Adds Greater Extensibility for Plugin Developers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76855\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"https://wptavern.com/gutenberg-1-8-adds-greater-extensibility-for-plugin-developers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3668:\"<p><a href=\"https://make.wordpress.org/core/2017/11/28/whats-new-in-gutenberg-28th-november/\" rel=\"noopener\" target=\"_blank\">Gutenberg 1.8</a> was released this week with several notable improvements that will give plugin developers more flexibility in extending the editor. It introduces <a href=\"https://github.com/WordPress/gutenberg/pull/3668\" rel=\"noopener\" target=\"_blank\">block templates</a>, which developers can use when registering a new custom post type. The block templates define a set of pre-configured blocks that will initialize when a user creates a new post. In the example below, Gutenberg lead engineer Matias Ventura demonstrates what a block template for a book custom post type might look like.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/block-template-book.gif?ssl=1\"><img /></a></p>
<p>This release also <a href=\"https://github.com/WordPress/gutenberg/pull/3456\" rel=\"noopener\" target=\"_blank\">improves the design of the tools menu</a> (toggled by the ellipses at the top of the editor) to have a more lightweight UI that will lend itself better to displaying items added by extensions in the future. The new design displays multiple menu items as a radio group where the selected item shows a checkmark, an approach that Gutenberg designers found to be more intuitive after some research.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-29-at-10.02.09-PM.png?ssl=1\"><img /></a></p>
<p>Version 1.8 adds the ability for developers to <a href=\"https://github.com/WordPress/gutenberg/pull/3577\" rel=\"noopener\" target=\"_blank\">filter allowed block types</a> by specifying an array of type names that can be shown in the inserter component. This capability paves the way for block nesting where developers can define allowed children types. It also allows custom post types to specify which blocks are allowed or restricted, which will be useful for keeping CPTs lean as Gutenberg already has a large number of block types.</p>
<p>The release also <a href=\"https://github.com/WordPress/gutenberg/pull/3554\" rel=\"noopener\" target=\"_blank\">improves meta box compatibility</a> with a fallback to the classic editor if Gutenberg detects that the meta box is unsupported. Plugin authors can now explicitly declare Gutenberg incompatibility when registering meta boxes, which will trigger a warning to the end user that explains which meta boxes have caused the fallback to the classic editor.</p>
<p>In addition to all the improvements for extending Gutenberg, version 1.8 makes many small design tweaks, including <a href=\"https://github.com/WordPress/gutenberg/pull/3054\" rel=\"noopener\" target=\"_blank\">updated color pickers</a> with color indications and collapsible panels, <a href=\"https://github.com/WordPress/gutenberg/pull/3563\" rel=\"noopener\" target=\"_blank\">updated icon and tooltip</a> for table of contents menu, and a new <a href=\"https://github.com/WordPress/gutenberg/pull/3483\" rel=\"noopener\" target=\"_blank\">contrast checker</a> for paragraph color options. It also <a href=\"https://github.com/WordPress/gutenberg/pull/3632\" rel=\"noopener\" target=\"_blank\">puts block actions back on the block level</a> for the default, while still preserving the option to change it to a fixed toolbar at the top of the screen.</p>
<p>For a full list of all the changes in version 1.8, check out the <a href=\"https://make.wordpress.org/core/2017/11/28/whats-new-in-gutenberg-28th-november/\" rel=\"noopener\" target=\"_blank\">release post</a> and the <a href=\"https://wordpress.org/plugins/gutenberg/#developers\" rel=\"noopener\" target=\"_blank\">changelog</a> on WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Nov 2017 17:23:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: WPWeekly Episode 296 – Gutenberg, Telemetry, Calypso, and More With Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=76917&preview=true&preview_id=76917\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://wptavern.com/wpweekly-episode-296-gutenberg-telemetry-calypso-and-more-with-matt-mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1249:\"<p>In this episode, <a href=\"https://jjj.blog/\">John James Jacoby</a> and I are joined by <a href=\"https://ma.tt/\">Matt Mullenweg</a>, co-creator of the WordPress project and CEO of Automattic. We discussed a wide range of topics including, his role on the board of directors at GitLab, Telemetry or data-usage gathering in WordPress, and the WordPress Growth Council.</p>
<p>We learned what&#8217;s happening with the Mobile teams inside Automattic, the future of Calypso, and the role of Pressable as a testing bed. Last but not least, we find out how beneficial joining HackerOne has been for WordPress and why WordPress.com finally allowed the installation of third-party themes and plugins through its Business Plan.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, December 13th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p><strong>Listen To Episode #296:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Nov 2017 04:40:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: WordPress 4.9.1 Released, Fixes Page Template Bug\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76879\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wptavern.com/wordpress-4-9-1-released-fixes-page-template-bug\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1473:\"<p>WordPress 4.9.1 <a href=\"https://wordpress.org/news/2017/11/wordpress-4-9-1-security-and-maintenance-release/\">is available</a> for download and is a maintenance and security release. This release addresses four security issues in WordPress 4.9 and below that could potentially be used as part of a multi-vector attack. According to the release notes, the following changes have been made to WordPress to protect against these vulnerabilities.</p>
<ol>
<li>Use a properly generated hash for the <code>newbloguser</code> key instead of a determinate substring.</li>
<li>Add escaping to the language attributes used on <code>html</code> elements.</li>
<li>Ensure the attributes of enclosures are correctly escaped in RSS and Atom feeds.</li>
<li>Remove the ability to upload JavaScript files for users who do not have the <code>unfiltered_html</code> capability.</li>
</ol>
<p><a href=\"https://twitter.com/0x62626262\">Rahul Pratap Singh</a> and John Blackbourn are credited with responsibly disclosing the vulnerabilities. In addition to the changes above, 4.9.1 fixes eleven bugs, including the Page Template issue <a href=\"https://wptavern.com/workarounds-for-the-page-template-bug-in-wordpress-4-9\">we wrote about</a> last week. Many sites have already updated to 4.9.1 automatically. To see a list of detailed changes, check out <a href=\"https://make.wordpress.org/core/2017/11/28/wordpress-4-9-1-scheduled-for-november-29th/\">this post</a> on Make WordPress Core.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Nov 2017 04:07:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WPTavern: Distributor Plugin Now in Beta: A New WordPress Content Syndication Solution from 10up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76871\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"https://wptavern.com/distributor-plugin-now-in-beta-a-new-wordpress-content-syndication-solution-from-10up\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6117:\"<p>10up published a <a href=\"https://10up.com/blog/2017/distributor-plugin/\" rel=\"noopener\" target=\"_blank\">preview of its Distributor plugin</a> today, a new solution for syndicating content across WordPress multisite networks and the web. The <a href=\"https://distributorplugin.com/\" rel=\"noopener\" target=\"_blank\">plugin</a>, which the company plans to release for free, is currently in final closed beta. It enables content managers to either &#8220;push&#8221; or &#8220;pull&#8221; content to/from sites where they have permission to publish.</p>
<a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/distributor-push-screenshot.jpg?ssl=1\"><img /></a>image credit: <a href=\"https://10up.com/blog/2017/distributor-plugin/\">10up</a>
<p>Distributor includes the ability for editors to make changes to the original post and have linked copies automatically inherit the changes. This includes post content, post meta (custom fields), and taxonomy terms. It also ensures that content is SEO-friendly by providing canonical links that prevent duplicate content issues.</p>
<p>The plugin differs from many <a href=\"https://wordpress.org/plugins/search/syndicate/\" rel=\"noopener\" target=\"_blank\">existing content syndication solutions</a>, which traditionally make use of RSS or XML/RPC, in that it is built using the <a href=\"https://developer.wordpress.org/rest-api/\" rel=\"noopener\" target=\"_blank\">REST API</a>.</p>
<p>&#8220;The main technical advantage of the REST API is that it’s a &#8216;standard&#8217; inside core for sharing information across sites,&#8221; 10up President Jake Goldman said. &#8220;Outside of multisite, we never even considered another approach. It is worth saying that you do need Distributor installed on both &#8216;ends&#8217; for all of its features to work across the REST API &#8211; we need to extend the REST API a bit to get everything to pull across (plus the handling of &#8216;linked&#8217; copies).&#8221;</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/distributor-pull-screenshot.jpg?ssl=1\"><img /></a></p>
<p>Goldman said that although &#8220;syndication&#8221; means many different things to different people, the &#8220;classic&#8221; use case of simply pulling from a source, such as ingesting content from a newswire, is not exactly the use case for Distributor. He said the team behind the plugin is perhaps more excited about the &#8220;push&#8221; implementation. In building their own solution, 10up also incorporated its trademark lean/streamlined UI, as many existing solutions are more complicated to use.</p>
<p>&#8220;We’re definitely aware that there are other takes at a good content sharing workflow,&#8221; Goldman said. &#8220;We even helped Automattic refactor their solution a few years ago, which they use on VIP. We took a bit of inspiration from that project, including the modular &#8216;connection&#8217; types. In earnest, when trying to help our clients find solutions that were intuitive, extensible, and engineered to an enterprise grade, we just couldn’t endorse any of the options we found. It’s more a UX problem &#8211; clunky workflows, overwhelming interfaces, feature overload (I prefer a certain simplicity) &#8211; than anything, though we also have concerns about how modular / customizable some of the other solutions are.&#8221;</p>
<h3>10up Plans to Release Distributor on WordPress.org Following the Closed Beta</h3>
<p>10up currently has several clients using Distributor, including large publishers with several properties/magazines/newspapers, as well as large technology businesses using it for their news and media features across a network of sites. The plugin is in final closed beta but 10up is granting early access to those with interesting use cases.</p>
<p>&#8220;We’re casting a pretty broad net in terms of &#8216;appropriate&#8217; use cases for the beta; in fact, we’re hoping that broader beta testing will open our eyes to great use cases within the scope of its purpose that we hadn’t  considered,&#8221; Goldman said. &#8220;We’ve already heard from some very large publishers, some smaller digital publishers, universities, public school systems, some enterprises with multiple properties, agencies interested in staging content, and just engineers who own multiple sites that share content &#8211; we’re excited about all of these use cases!&#8221;</p>
<p>Goldman said his team is most curious to see Distributor applied to use cases that aren&#8217;t simply &#8220;news and publishing,&#8221; including CRMs and product businesses with multiples sites that share content. 10up has not yet tested specific plugins for full compatibility with Distributor, but Goldman said pre-version 1.0, it should work with any plugin that adds custom post types and fields/taxonomies &#8220;the WordPress way.&#8221;</p>
<p>&#8220;In fact, Distributor checks to see which sites support the same post type and terms before it offers a list of sites you can &#8216;distribute&#8217; content to (so you can’t &#8216;distribute&#8217; a WooCommerce product to a site not running WooCommerce),&#8221; he said. Selling the same products across multiple stores, with automatically updating inventory and price changes, is just one of the many interesting use cases for Distributor.</p>
<p>Goldman said the team anticipates taking the plugin out of beta and putting it on WordPress.org by mid to late Q1 of 2018, in approximately 2-3 months, depending on feedback from testers. 10up does not currently have a plan to monetize the plugin.</p>
<p>&#8220;I never want to rule out that there are &#8216;eventually&#8217; opportunities for commercialization, but I can honestly say that isn’t anywhere on our roadmap or consideration set at the moment,&#8221; Goldman said.</p>
<p>Those who want to get in on the Distributor beta before it is publicly available can <a href=\"https://distributorplugin.com/\" rel=\"noopener\" target=\"_blank\">sign up on the plugin&#8217;s website </a>with a quick explanation of your use case. 10up will send a copy of the plugin for testing.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Nov 2017 23:19:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"Dev Blog: WordPress 4.9.1 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=5215\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2017/11/wordpress-4-9-1-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4275:\"<p>WordPress 4.9.1 is now available. This is a <strong>security and maintenance release</strong> for all versions since WordPress 3.7. We strongly encourage you to update your sites immediately.</p>



<p>WordPress versions 4.9 and earlier are affected by four security issues which could potentially be exploited as part of a multi-vector attack. As part of the core team&#x27;s ongoing commitment to security hardening, the following fixes have been implemented in 4.9.1:</p>



<ol>
    <li>Use a properly generated hash for the <code>newbloguser</code> key instead of a determinate substring.</li>
    <li>Add escaping to the language attributes used on <code>html</code> elements.</li>
    <li>Ensure the attributes of enclosures are correctly escaped in RSS and Atom feeds.</li>
    <li>Remove the ability to upload JavaScript files for users who do not have the <code>unfiltered_html</code> capability.</li>
</ol>



<p>Thank you to the reporters of these issues for practicing <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">responsible security disclosure</a>: <a href=\"https://twitter.com/0x62626262\">Rahul Pratap Singh</a> and John Blackbourn.</p>



<p>Eleven other bugs were fixed in WordPress 4.9.1. Particularly of note were:</p>



<ul>
    <li>Issues relating to the caching of theme template files.</li>
    <li>A MediaElement JavaScript error preventing users of certain languages from being able to upload media files.</li>
    <li>The inability to edit theme and plugin files on Windows based servers.</li>
</ul>



<p><a href=\"https://make.wordpress.org/core/2017/11/28/wordpress-4-9-1-scheduled-for-november-29th/\">This post has more information about all of the issues fixed in 4.9.1 if you&#x27;d like to learn more</a>.</p>



<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.9.1</a> or venture over to Dashboard → Updates and click \"Update Now.\" Sites that support automatic background updates are already beginning to update automatically.</p>



<p>Thank you to everyone who contributed to WordPress 4.9.1:</p>



<p><a href=\"https://profiles.wordpress.org/schlessera/\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/la-geek/\">Angelika Reisiger</a>, <a href=\"https://profiles.wordpress.org/blobfolio/\">Blobfolio</a>, <a href=\"https://profiles.wordpress.org/bobbingwide/\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling (ocean90)</a>, <a href=\"https://profiles.wordpress.org/edo888/\">edo888</a>, <a href=\"https://profiles.wordpress.org/erich_k4wp/\">Erich Munz</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/mista-flo/\">Florian TIAR</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/ibenic/\">Igor Benic</a>, <a href=\"https://profiles.wordpress.org/jfarthing84/\">Jeff Farthing</a>, <a href=\"https://profiles.wordpress.org/jbpaul17/\">Jeffrey Paul</a>, <a href=\"https://profiles.wordpress.org/jeremyescott/\">jeremyescott</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnpgreen/\">johnpgreen</a>, <a href=\"https://profiles.wordpress.org/ryelle/\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/lenasterg/\">lenasterg</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mariovalney/\">Mário Valney</a>, <a href=\"https://profiles.wordpress.org/natacado/\">natacado</a>, <a href=\"https://profiles.wordpress.org/odysseygate/\">odyssey</a>, <a href=\"https://profiles.wordpress.org/precies/\">precies</a>, <a href=\"https://profiles.wordpress.org/stodorovic/\">Saša</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, and <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Nov 2017 20:33:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"John Blackbourn\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: Four Things I’d Like to See in This Year’s State of the Word\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76830\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/four-things-id-like-to-see-in-this-years-state-of-the-word\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2724:\"<p>This weekend, WordPressers from far and wide will descend upon Nashville, TN, for WordCamp US. One of the highlights of the event is Matt Mullenweg&#8217;s <a href=\"https://ma.tt/2016/12/state-of-the-word-2016/\">State of the Word</a>. Last year, Mullenweg shared a variety of statistics, made a few announcements, and plotted a new course for WordPress development.</p>
<p>As the event draws near, here are some things I&#8217;d like to see addressed in this year&#8217;s State of the Word.</p>
<h2>Will There Be A Renewed Effort to Make Calypso Plugin Aware?</h2>
<p>During the 2016 State of the Word, Mullenweg announced that Calypso became plugin aware.</p>
<img />Plugin Aware Calypso
<p>The idea was that plugins that are actively installed on more than 1 million sites could participate in an experimental program that would add meta box support and other plugin specific features to Calypso. To this day, this has not materialized and I&#8217;d like to know what happened and if there will be a renewed effort in 2018.</p>
<h2>An Update on WordPress Foundation Supported Initiatives</h2>
<p>Last year, we learned that WordCamp Central became its own Public Benefit Corporation while the WordPress Foundation maintained its non-profit status. In addition, the Foundation announced support for like-minded non-profits such as, Hack the Hood, Internet Archive, and Black Girls CODE.</p>
<p>I&#8217;d like to know how much money the Foundation has contributed to these causes and if any progress has been made on providing educational workshops in underdeveloped countries.</p>
<h2>An Update on WordPress&#8217; Development/Release Strategy</h2>
<p>A year into WordPress&#8217; new development and release strategy, I&#8217;d like to know what challenges he and the team have faced and overcome. I&#8217;d also like to know if the results he has seen thus far warrant continuing the experiment in 2018.</p>
<h2>Take an Opportunity to Explain What Gutenberg Really Is</h2>
<p>Last year, Mullenweg surprised the community by announcing that the WordPress post editor would be revamped. Since then, we&#8217;ve learned that the project&#8217;s <a href=\"https://ma.tt/2017/08/we-called-it-gutenberg-for-a-reason/\">name is Gutenberg</a> and it&#8217;s about more than just the editor. I&#8217;d like to see Mullenweg take this unique opportunity to provide a deeper explanation into what the project is and why it&#8217;s pivotal for WordPress&#8217; continued success.</p>
<hr />
<p>This year&#8217;s State of the Word will be presented on Saturday, December 2nd, at 4PM Eastern. If you can&#8217;t see it in-person, you can <a href=\"https://2017.us.wordcamp.org/live-stream/\">watch it for free</a> via the livestream.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Nov 2017 17:38:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"HeroPress: WordPress Gave Me the Perfect Identity\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2294\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:136:\"https://heropress.com/essays/wordpress-gave-perfect-identity/#utm_source=rss&utm_medium=rss&utm_campaign=wordpress-gave-perfect-identity\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:17701:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2017/11/112917-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: I have fallen head over heels in love with WordPress and I am excited.\" /><h3>How it all began…</h3>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/myself.jpg\"><img class=\"size-medium wp-image-2305\" src=\"https://heropress.com/wp-content/uploads/2017/11/myself-225x300.jpg\" alt=\"\" width=\"225\" height=\"300\" /></a>I just love this picture of myself..hehehe
<p>I remember when cybercafés started trending in Nigeria; I had just finished high school and was awaiting my results for admittance into the university. I would spend not less than 10 hours surfing the internet every day, all my pocket money went into buying bulk time at cafes. My first email was opened in 2002 on my 1st attempt to surf the internet. Spending my day at cafes continued till I left the university after which I bought a desktop computer and a modem. You can imagine my excitement as being a proud owner of a PC even though it was a desktop PC.</p>
<p>You see, my first degree was in Philosophy. I remember my dad asking me if I was sure about that course because prior to my senior school leaving exams I had always said I was going to study business administration. What business administration was, to be honest, I had no idea, I only wanted it because I had the impression it was a cool course and I would be a corporate employee in a big firm strutting around in my skirt suit looking all glamorous.</p>
<h3><a href=\"https://heropress.com/wp-content/uploads/2017/11/i-in-skirts2.jpg\"><img class=\"size-medium wp-image-2310 aligncenter\" src=\"https://heropress.com/wp-content/uploads/2017/11/i-in-skirts2-300x300.jpg\" alt=\"\" width=\"300\" height=\"300\" /></a>Funny right?</h3>
<p>Anyway i always had a thing for Philosophy so you can imagine my enthusiasm when I discovered Philosophy was a course of study, of course I opted to study Philosophy in 2004 and graduated in 2008. However my love for the internet did not reduce by the way. I not only surfed the internet but I spent a lot of time freelancing and testing my skills as a ghost writer on different freelancing sites. I also went into blogging as well in 2009. I tried using blogger, hubpages and WordPress, but oh my, I found WordPress so complicated for me because I did not understand how it worked so I stuck with blogger and hubpages.</p>
<h3>Growing up as a Timid but Curious Cat&#8230;</h3>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/i-and-my-lil-brother.jpg\"><img class=\"wp-image-2306 size-medium\" src=\"https://heropress.com/wp-content/uploads/2017/11/i-and-my-lil-brother-225x300.jpg\" alt=\"\" width=\"225\" height=\"300\" /></a>I and my little brother. Haa of course we all grown now. Haha
<p>During my younger years and even up to two years ago I was always a shy person deep down in my mind, but alas quite a number of people thought I was bold. This might be because 99.9% of my friends were males, or maybe not. Perhaps this could also be because I grew up with 3 brothers and no sister. It’s quite shocking though that they thought that way because it is only quite recent that I cultivated the courage to speak my mind. Prior to a year ago (2016), expressing my feelings by speaking the words out was a <em>herculean task</em>; this was what led me to starting a personal blog around 2009. I needed to let out my feelings and since I dared not speak them out, I blogged them.</p>
<p>Blogging gave me a voice and a medium to express my thoughts and I became a better writer with each passing script. After my one year government mandated youth service in 2010 which is required of every Nigerian citizen after a bachelor’s degree, I bought an HP Mini Laptop. Can you imagine my excitement at owning a personalized computer? This I could carry around, my happiness knew no bounds.</p>
<p>In 2010 thanks to the social network Facebook I met an Uncle of mine and we became BFF’s {Best Friends Forever} even though we had never met physically before. He was in Rome at the period we met studying Media and Communication. He came back home in 2012 but his job as a Salesian Brother took him to Ghana. Of course I made sure to keep a date with him when he came back home briefly in 2012 before heading to resume in Ghana. We had cake and ice cream at my favourite café that day.</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/i-and-bff-unc-sam.jpg\"><img class=\"size-medium wp-image-2303\" src=\"https://heropress.com/wp-content/uploads/2017/11/i-and-bff-unc-sam-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" /></a>I and my BFF Uncle..Hehe
<h3>Rediscovering WordPress…</h3>
<p>Then came 2015, I ended a horrid relationship and i lost my best friend female; I mean I thought I was in love, but alas I had loved the idea of loving a person. I was not happy and I wanted a breath of fresh air and a change of environment. At that period, I had obtained a postgraduate diploma in mass communication and I had started a Masters Degree in Information Management and my required 3 months internship was coming up that summer. I decided to volunteer in Ghana at the headquarters of the <a href=\"https://sdbafw.org\" target=\"_blank\" rel=\"noopener\">Salesians of Don Bosco in West Africa {SDBAFW}</a> where my Uncle was. My time there was beyond awesome and a new beautiful story in my life chapter.</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/at-sdbafw-in-ashaiman.jpeg\"><img class=\"size-medium wp-image-2309\" src=\"https://heropress.com/wp-content/uploads/2017/11/at-sdbafw-in-ashaiman-300x300.jpeg\" alt=\"\" width=\"300\" height=\"300\" /></a>I met a lot of amazing people and made new friends within the SDB community in Ashaiman, Ghana
<a href=\"https://heropress.com/wp-content/uploads/2017/11/i-and-volunteers-at-kakum.jpg\"><img class=\"size-medium wp-image-2308\" src=\"https://heropress.com/wp-content/uploads/2017/11/i-and-volunteers-at-kakum-300x199.jpg\" alt=\"\" width=\"300\" height=\"199\" /></a>i and other volunteers and great friends at Kakum National Park in Cape Coast, Ghana
<p>I worked in the communications department at the SDBAFW province. My Uncle knew how much I loved blogging and he had been my writing tutor for a while, so one day he asked why I was not blogging on WordPress. Of course I went on about how difficult and complicated the platform was, he sighed, told me their organization website was built on WordPress and he gave me a folder with tutorial videos made by <a href=\"https://twitter.com/mor10\">Morten Rand-Hendriksen</a> for beginners to go watch.</p>
<p>After two weeks of watching those videos, my life changed. You see prior to 2015 I treated my time online as a purely personal affair because I was just passionate about being online right, exploring, freelancing and discovering. I never thought it would become something I could make a full time career out of. I was still pursuing a career in Human Resources since managing people was another thing I was great at. In late 2015 I had joined a series of online Facebook groups and I was wowed by one in particular run by John Obidi (<a href=\"https://web.facebook.com/groups/smartbcamp\" target=\"_blank\" rel=\"noopener\">SmartBCamp</a>) because I saw a lot of people earning an income from things I did and knew for the fun of it. I found myself asking what planet I had been living on and why I had not made my passion my business.</p>
<p>Hence I made a decision in 2016 to make my passion my business, I decided to move to Lagos since I was done with my Master’s coursework and focus on this new journey of mine. Meanwhile in December of 2015, a woman had contacted me saying she loved how my blog UX on WordPress looked and if I could work on hers.</p>
<blockquote><p>As at then I didn’t even know the difference between wordpress.com and wordpress.org so I started googling which is something I’m also great at.</p></blockquote>
<p>I took on the task of redesigning her website and I started troubleshooting all the current issues she had on her site, I read up a lot, I visited the WordPress.Org/showcase and was wowed with all the good things I could do with WordPress.org, I especially loved Snoop Doggs website and told myself my goal would be to be able to make a project that would look like that one day. But of course the first few sites I designed were horrible, when I look back at them now I wonder what was going on in my head when I designed them.</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/my-typical-day-in-gh.jpg\"><img class=\"size-medium wp-image-2302\" src=\"https://heropress.com/wp-content/uploads/2017/11/my-typical-day-in-gh-300x225.jpg\" alt=\"\" width=\"300\" height=\"225\" /></a>A typical day for me in front of my PC
<p>Alas I had great online plans for the year 2016 but up until the middle of year 2016, I had a series of bad experiences that sent me back to the stone age and my parents house; I blogged about it <a href=\"https://mojispeaks.com/2017/01/09/my-2016-in-retrospect/\">here</a>. They were bad experiences alright, but a lot of good came out of them. I got saved bit by bit and found my rhythm again. Meanwhile I was already <em><strong>falling in love with WordPress</strong></em> so I decided to look for ways to give back. That&#8217;s when I stumbled upon make.wordpress.org and discovered there were so many ways to give back. I was not a programmer alright so what will I go to do in Core or CLI or any other similar place, I automatically went for the community.</p>
<h3>Building the Nigerian WordPress Community…</h3>
<p>In November 2016 I made one of the best decisions that turned my life around. I was fed up because the entire year had not turned out in any way I had planned in December 2015 of the previous year. So I made an interesting decision to turn off my data and go to sleep by 10pm. Trust me this was a big decision for me before I would usually freak out if my data wasn’t functioning or if my phone battery died. Anyway during this period I had moved back to my parents’ right and I needed to work in a quiet room because I so much needed to focus.</p>
<p>Also by now I had discovered there was a WordPress Meetup community in Lagos but when I applied I did so for Ogun which is my state, but during my conversations with WordPress Global they had requested if I would be willing to join the Lagos WordPress Group, at first I was a little hesitant because Lagos is an hour drive from my town, I don’t have a car, so that adds another one hour. Surely you can&#8217;t live in Lagos and not know Lagos and traffic are best buddies so that adds another hour to my trip. Without thinking too much about it I agreed. Looking back today I do not regret it one bit.</p>
<blockquote><p>This started my journey as a WordPress Lagos Community Co-organizer and a Community Deputy.</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/600_455477788.jpeg\"><img class=\"size-medium wp-image-2317\" src=\"https://heropress.com/wp-content/uploads/2017/11/600_455477788-300x225.jpeg\" alt=\"\" width=\"300\" height=\"225\" /></a>the first meetup i had as a Lagos co-organizer</blockquote>
<p>This is 2017 right, I must not fail to mention it to you that my income in the last one year has come solely from WordPress Web Design. Today the Nigerian WordPress has grown, still growing definitely, the Lagos WordPress Meetup group has also grown and we have had 8 Meetups this year. I have made great friends and co-organizers in the community who are dedicated to building and sharing their WordPress knowledge with the community like I am. We are hosting the very first Nigerian <a href=\"https://2018.lagos.wordcamp.org/\">WordCamp in Lagos</a> on March 10 2018 at the Civic Centre in Victoria Island, Lagos. I must not forget to mention that we also now have an Ijebu WordPress Community; that’s my town alright <span class=\"ttfmake-icon mceNonEditable fa\"></span> .</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/3rd-wp-lagos-meetup-2017.jpg\"><img class=\"wp-image-2312 size-full\" src=\"https://heropress.com/wp-content/uploads/2017/11/3rd-wp-lagos-meetup-2017.jpg\" alt=\"\" width=\"299\" height=\"224\" /></a>this was our 4th meetup event this year
<a href=\"https://heropress.com/wp-content/uploads/2017/11/first-wp-lagos-meetup-2018.jpg\"><img class=\"wp-image-2313 size-medium\" src=\"https://heropress.com/wp-content/uploads/2017/11/first-wp-lagos-meetup-2018-300x169.jpg\" alt=\"\" width=\"300\" height=\"169\" /></a>this was our first meetup event this year
<a href=\"https://heropress.com/wp-content/uploads/2017/11/600_463289287.jpeg\"><img class=\"wp-image-2316 size-medium\" src=\"https://heropress.com/wp-content/uploads/2017/11/600_463289287-300x225.jpeg\" alt=\"\" width=\"300\" height=\"225\" /></a>our third meetup early this year
<a href=\"https://heropress.com/wp-content/uploads/2017/11/WPlagos-30th-Sept-Meetup-Photo-1.jpg\"><img class=\"size-medium wp-image-2318\" src=\"https://heropress.com/wp-content/uploads/2017/11/WPlagos-30th-Sept-Meetup-Photo-1-300x199.jpg\" alt=\"\" width=\"300\" height=\"199\" /></a>WPlagos 30th Sept Meetup (5th meetup this year)
<p>We recently created a <a href=\"https://photos.app.goo.gl/VNx047kS0Bj8u7z63\" target=\"_blank\" rel=\"noopener\">google photos for our past meetups, click here to view them. </a>So tell me why I shouldn’t be grateful? Why I shouldn’t fall in love with WordPress? Because this is all that has happened to me since I met WordPress, <em><strong>I have fallen head over heels in love with WordPress and I am excited.</strong></em></p>
<h3>What have i gained from WordPress?</h3>
<ol>
<li>I overcame my stage fright fully because i have to get in front of the crowd at every meetup to do the introductions and introduce the WordPress communities.</li>
<li>I attended my first WordCamp in Cape Town, South Africa. <a href=\"https://youtu.be/PE6k8-PLKVk\" target=\"_blank\" rel=\"noopener\">Click here to see my picture story</a>. Coincidentally this was also my first time outside West Africa. I had never been in an aircraft for more than one hour before my trip.</li>
<li>I have made money from WordPress Web Design Projects, enough to sustain me during my learning period. Still learning everyday.</li>
<li>I jumped off <a href=\"https://mojispeaks.com/2017/11/19/i-did-jump-off-a-hill-my-wordcamp-cape-town-story/\" target=\"_blank\" rel=\"noopener\">Signal Hill in Cape Town, find post here</a>; next up, sky diving.</li>
</ol>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/DSC_0246-1.jpg\"><img class=\"size-medium wp-image-2314\" src=\"https://heropress.com/wp-content/uploads/2017/11/DSC_0246-1-300x200.jpg\" alt=\"\" width=\"300\" height=\"200\" /></a>At a WordCamp Cape Town session
<p><strong>My advice to you from my experience so far…</strong></p>
<p>Always seek to understand the basics of whatever knowledge you seek&#8230;never jump in too fast, wanting to spiral to the top while ignoring the learning curve. You will crash down effortlessly if you do so and would have learnt nothing.</p>
<a href=\"https://heropress.com/wp-content/uploads/2017/11/WordPress-Gave-Me-the-Perfect-Identity.png\"><img class=\"size-medium wp-image-2315\" src=\"https://heropress.com/wp-content/uploads/2017/11/WordPress-Gave-Me-the-Perfect-Identity-300x225.png\" alt=\"\" width=\"300\" height=\"225\" /></a>WordPress Gave Me the Perfect Identity Indeed&#8230;I no longer roam the internet..hehehe
<blockquote>
<p>The End&#8230;?<br />
I Don’t Think So&#8230;<br />
My Story has Just Begun. <strong>Stay Tuned&#8230;.!</strong></p>
</blockquote>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: WordPress Gave Me the Perfect Identity\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=WordPress%20Gave%20Me%20the%20Perfect%20Identity&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-gave-perfect-identity%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: WordPress Gave Me the Perfect Identity\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-gave-perfect-identity%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fwordpress-gave-perfect-identity%2F&title=WordPress+Gave+Me+the+Perfect+Identity\" rel=\"nofollow\" target=\"_blank\" title=\"Share: WordPress Gave Me the Perfect Identity\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/wordpress-gave-perfect-identity/&media=https://heropress.com/wp-content/uploads/2017/11/112917-150x150.jpg&description=WordPress Gave Me the Perfect Identity\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: WordPress Gave Me the Perfect Identity\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/wordpress-gave-perfect-identity/\" title=\"WordPress Gave Me the Perfect Identity\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/wordpress-gave-perfect-identity/\">WordPress Gave Me the Perfect Identity</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Nov 2017 12:00:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"Mary Job\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: WordCamp Albuquerque Gears Up for 5th Edition in January 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76845\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/wordcamp-albuquerque-gears-up-for-5th-edition-in-january-2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3644:\"<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-28-at-8.15.51-PM-e1511921930548.png?ssl=1\"><img /></a></p>
<p><a href=\"https://2018.albuquerque.wordcamp.org/\" rel=\"noopener\" target=\"_blank\">WordCamp Albuquerque</a> is gearing up for its 5th edition January 19-21, 2018, following events held in 2011, 2012, 2013, and 2016. An all-new organizing team is ready to invigorate the Southwestern WordPress community with an exciting array of world-class speakers and educational opportunities for both new and experienced users.</p>
<p>Lead organizer Alonso Indacochea said the team is expecting to host 300 attendees. Many of them will be coming from New Mexico, Southern Colorado, West Texas, and Arizona.</p>
<p>&#8220;The southwestern community is interesting because there are a lot of developers doing really interesting tech work, but a lot of it happens in silos due to government secrecy,&#8221; speaker wrangler Sam Hotchkiss said. &#8220;New Mexico has a rich history of technology, from the Manhattan Project and the creation of the first nuclear weapons to the formation of Microsoft, which was founded in Albuquerque in 1975.</p>
<p>&#8220;We’re trying to pull together that community to connect with each other, and also establish Albuquerque as a WordCamp with consistently high-quality speakers of global renown.&#8221;</p>
<p>In pursuit of this goal, Hotchkiss has recruited a healthy crop of top quality speakers from the WordPress community. During the Saturday afternoon session, <a href=\"http://chrislema.com/\" rel=\"noopener\" target=\"_blank\">Chris Lema</a>, Vice President of Products and Innovation at <a href=\"https://www.liquidweb.com/\" rel=\"noopener\" target=\"_blank\">Liquid Web</a>, will be interviewing a diverse group of speakers in the main hall, including the following:</p>
<ul>
<li>Ashleigh Axios, former Creative Director for the Obama White House and AIGA Board Member</li>
<li>Sakin Shrestha, Founder of Catch Themes and the main drive behind the vibrant WordPress community in Nepal</li>
<li>John Maeda, Global Head, Computational Design and Inclusion at Automattic</li>
<li>Jon Brown, WordPress Nomad</li>
<li>Alonso Indacochea, WordCamp lead organizer, who had no serious software development experience 5 years ago, went through a local boot camp, and is now CEO of the fastest growing digital agency in New Mexico</li>
</ul>
<p>This year WordCamp Albuquerque will feature multiple tracks sorted by topic, beginning with a WordPress Fundamentals track on Friday, January 19.</p>
<p>&#8220;Foundation Friday is something I’ve seen be really successful at other camps,&#8221; Hotchkiss said. &#8220;It gives people who are new to WP a base of knowledge so that they can go into Saturday feeling confident and ready to learn. Each class on Friday will build on the one before it. Starting from scratch? Show up at 9. Already have a site, but need help handling the layout?  Come at 10:30.&#8221;</p>
<p>Saturday&#8217;s program will include sessions in the Business, Design, and Development tracks throughout the day, in addition to the planned interviews. A contributor day session is planned for Sunday. The event&#8217;s organizers are still <a href=\"https://2018.albuquerque.wordcamp.org/speakers/\" rel=\"noopener\" target=\"_blank\">accepting speaker applications</a> until midnight on Monday, December 4. They plan to finalize the schedule next week. <a href=\"https://2018.albuquerque.wordcamp.org/attendees/\" rel=\"noopener\" target=\"_blank\">Tickets</a> are on sale now and attendees can elect to purchase one for whatever combination of days they wish to attend.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Nov 2017 02:30:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WPTavern: Practicing the Pac-Man Rule at WordCamp US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76857\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"https://wptavern.com/practicing-the-pac-man-rule-at-wordcamp-us\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1750:\"<p>With more than 2,000 attendees expected, WordCamp US is one of the largest conferences devoted to WordPress. It&#8217;s a great opportunity to meet a lot of new faces and catch up with familiar ones. If you&#8217;re standing in the hallway at WordCamp US speaking with a group of people and want to encourage others to say hi or be part of the conversation, try this tip <a href=\"https://www.facebook.com/GreatSmokyMountainsAssociation/videos/10155628004363673/\">shared by</a> Jason Cosper called the <a href=\"http://ericholscher.com/blog/2017/aug/2/pacman-rule-conferences/\">Pac-Man rule</a> written by Eric Holscher.</p>
<img />photo credit: rbatina <a href=\"http://www.flickr.com/photos/27988337@N00/12081061246\">Random Phone Shots</a> <a href=\"https://creativecommons.org/licenses/by-nc-nd/2.0/\">(license)</a>
<p>The rule is simple. When standing in a circle, provide an opening for someone to join the group. By standing in an open circle, it gives a passersby explicit permission to join the group and limits the appearance of cliques. I didn&#8217;t realize how standing in a closed circle can be off-putting to those wanting to introduce themselves or chime in until learning about this rule.</p>
<p>In addition to the Pac-Man rule, <a href=\"https://twitter.com/bobWP/status/935576711252533248\">Bob Dunn suggests</a> using eye contact to invite people to the group. <a href=\"https://twitter.com/mor10/status/935582280164065280\">Morten Rand-Hendriksen suggests</a> that if you&#8217;re looking to start a conversation with someone new, start with groups of two people as they likely know each other and want to talk to new people. I&#8217;ll be practicing the Pac-Man rule this weekend and I encourage other attendees to do so as well.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Nov 2017 21:06:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: Gutenberg Team Is Ramping Up Usability Testing at WordCamp US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76807\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/gutenberg-team-is-ramping-up-usability-testing-at-wordcamp-us\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4848:\"<p>The Gutenberg Team will have a usability testing station set up at WordCamp US where attendees can participate in a round of pre-set tests that focus on the writing flow. Testers will answer a short survey that includes their prior WordPress experience level, age, and device used. Volunteers will get participants set up with a testing site and will start the screen recording app.</p>
<p>Testers will be asked to create a post based on the content shown in an image. There are three different images, which require the user to perform actions such as adding images, embedding media, creating unordered lists, adding quotes, and other basic content creation tasks. In order to segment results, the usability tests have been divided into <a href=\"https://drive.google.com/file/d/0B4BHP7ZnNw32RWJRa2diODFXVGs/view\" rel=\"noopener\" target=\"_blank\">beginner</a>, <a href=\"https://drive.google.com/file/d/0B4BHP7ZnNw32bVpyd2xaaFVVMWM/view\" rel=\"noopener\" target=\"_blank\">intermediate</a>, and <a href=\"https://drive.google.com/file/d/0B4BHP7ZnNw32R3U0ZkJRVXBySWM/view\" rel=\"noopener\" target=\"_blank\">advanced</a> level images.</p>
<a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-27-at-10.23.35-PM.png?ssl=1\"><img /></a>Advanced level task image for Gutenberg usability testing
<p>After completing the test, participants will be asked to answer a few followup questions, such as &#8220;Did the task take longer or shorter than you expected?&#8221; and &#8220;Are you more or less likely to use the Gutenberg editor in the future?&#8221;</p>
<p>&#8220;This is the second round of usability testing scripts — we tried out the first batch of scripts at WordCamp Milano, and made some adjustments for clarity,&#8221; Gutenberg design lead Tammie Lister said. &#8220;As a result of testing, we moved the toolbar on blocks to not be fixed and back to the block. At Milano, we tested the tests.&#8221;</p>
<p>As the result of these tests and other prior feedback, Lister <a href=\"https://github.com/WordPress/gutenberg/issues/3570\" rel=\"noopener\" target=\"_blank\">recommended the default position of the toolbar to be fixed to the block</a>.</p>
<p>Anna Harrison, UX lead at Ephox (the makers of tinyMCE), has been instrumental in helping with the efforts around testing and writing scripts. She also offered <a href=\"https://github.com/WordPress/gutenberg/issues/3570#issuecomment-345879950\" rel=\"noopener\" target=\"_blank\">feedback on the ticket</a>, referencing comments from the previous discussion on the issue:</p>
<blockquote><p>A fixed [docked to top] toolbar solution has several complications. Firstly, we break accessibility. I won&#8217;t reiterate the discussion, as it&#8217;s well articulated above. Secondly, we break things independent of accessibility &#8211; I ran user tests on something quite similar to this last year, and we discovered that <a href=\"https://go.tinymce.com/blog/from-the-ux-desk-road-testing-inline-image-editing/\" rel=\"noopener\" target=\"_blank\">disconnecting the toolbar from the point of action resulted in 100% user test fails</a>.</p></blockquote>
<p>Gutenberg version 1.8 will change the default back to displaying block actions on the block level, although the option to change it to a fixed toolbar at the top of the screen will still be available. This change is one example of how usability testing is shaping Gutenberg&#8217;s development. WordCamp US is an opportunity for the team to collect a host of new testing data in one place.</p>
<p>Lister said all the data that is collected will be processed by volunteers on the make/test team, but the team is still small and they could use more volunteers to work on this effort.</p>
<p>&#8220;The turnaround time on processing the data we collect really depends on how many volunteers are available to work on it,&#8221; Lister said. &#8220;It also depends on if it’s a bug reported &#8211; bugs are easier to get fixed right away. If the data indicates an area where we need to investigate more, we’ll do that. The results of the testing will be published on make.wordpress.org/test.&#8221;</p>
<p>Lister said the team is hoping to reach a wider variety of WordPress users at WCUS this year, from all backgrounds and careers. The testing booth offers an opportunity for anyone to contribute to the future of WordPress, regardless of your experience level or familiarity with the software. The team is also eager to broaden its testing field by recruiting non-WordPress users as well. If you can&#8217;t make it to WordCamp US, you can still <a href=\"https://make.wordpress.org/test/2017/11/22/testing-flow-in-gutenberg/\" rel=\"noopener\" target=\"_blank\">contribute to Gutenberg by taking and administering usability tests</a> on your own with the help of the instructions posted on the make.wordpress.org/test site.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Nov 2017 16:55:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"WPTavern: Delete Me WordPress Plugin Assists Website Owners in Granting the GDPR Right to be Forgotten\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76474\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://wptavern.com/delete-me-wordpress-plugin-assists-website-owners-in-granting-the-gdpr-right-to-be-forgotten\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4080:\"<a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/eraser.jpg?ssl=1\"><img /></a>photo credit: pj_vanf <a href=\"http://www.flickr.com/photos/48066826@N02/5006945413\">to err is human</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>With the EU GDPR compliance deadline just <a href=\"http://www.gdprcountdownclock.com/\" rel=\"noopener\" target=\"_blank\">178 days away</a>, many WordPress site owners are looking for tools that will help them meet the requirements. The regulation expands existing rights of data subjects in several key ways, including (but not limited to) the right to be notified of data breaches, the right to access personal data, the right to be forgotten, and the right to data portability.</p>
<p>A plugin called <a href=\"https://wordpress.org/plugins/delete-me/\" rel=\"noopener\" target=\"_blank\">Delete Me</a>, by Clinton Caldwell, is one that may be helpful in addressing the Right to be Forgotten. The <a href=\"https://www.eugdpr.org\" rel=\"noopener\" target=\"_blank\">GDPR.org</a> website breaks it down as follows:</p>
<blockquote><p>Also known as Data Erasure, the right to be forgotten entitles the data subject to have the data controller erase his/her personal data, cease further dissemination of the data, and potentially have third parties halt processing of the data. The conditions for erasure, as outlined in article 17, include the data no longer being relevant to original purposes for processing, or a data subjects withdrawing consent. It should also be noted that this right requires controllers to compare the subjects&#8217; rights to &#8220;the public interest in the availability of the data&#8221; when considering such requests.</p></blockquote>
<p>The Delete Me plugin takes this one step further for site owners who are comfortable allowing users to delete their own data without having to create a request for it. By default, the delete button displays on the profile.php screen in the admin, but administrators can elect to use a shortcode to display it somewhere else on the frontend.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-27-at-4.54.42-PM.png?ssl=1\"><img /></a></p>
<p>The plugin will delete the users&#8217; posts, links, and even comments (optional) after the user confirms. The confirmation screen could stand to include more information about what data is being deleted so that the user knows what to expect. However, administrators do have the option to specify this within the JavaScript confirmation dialog. After deletion the user is dumped back out to the homepage by default, but the redirect URL can be configured in the plugin&#8217;s settings page.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-27-at-4.54.21-PM.png?ssl=1\"><img /></a></p>
<p>Additional configurable settings include the ability to select specific WordPress roles to allow to delete themselves, specify class and style attributes of delete link, enable or disable JavaScript confirm for Shortcode, specify button text, and send an email notification when users delete themselves.</p>
<p>Delete Me also supports network activation and single site activation for multisite installations. By default, users can only delete themselves and their content from a single site, while other networked sites where they are registered will not be affected. The plugin does include a “Delete From Network” checkbox that administrators can enable to allow users to delete themselves from all sites on the network.</p>
<p><a href=\"https://wordpress.org/plugins/delete-me/\" rel=\"noopener\" target=\"_blank\">Delete Me</a> is available for free on WordPress.org. I tested the plugin and have confirmed that it works with WordPress 5.0-alpha. It is currently active on more than 2,000 sites. By no means does it satisfy the full requirements of the GDPR, but it provides a decent starting point for site owners who want to make this option available to their users without having to manually fulfill their requests.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Nov 2017 00:08:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"WPTavern: WPWeekly Episode 295 – Turkey With A Side of Gutenberg and Giving Thanks to Open Source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=76789&preview=true&preview_id=76789\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"https://wptavern.com/wpweekly-episode-295-turkey-with-a-side-of-gutenberg-and-giving-thanks-to-open-source\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3233:\"<p>I apologize for the delay in getting this episode out to you. In this episode, <a href=\"https://jjj.blog/\">John James Jacoby</a> and I discussed a range of topics, including a caching bug introduced in WordPress 4.9 that causes Page Templates not to display for an hour. We talk about the possibilities of using Gutenberg with WooCommerce and how it could impact product management.</p>
<p>As is tradition, near the end of the show, we shared what we&#8217;re thankful for. We also shared what listeners are <a href=\"https://twitter.com/jeffr0/status/933101857039200258\">thankful for</a> regarding open source.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://core.trac.wordpress.org/ticket/42573\">This bug</a> is causing some theme developers to rip their hair out. Weston Ruter <a href=\"https://core.trac.wordpress.org/ticket/42573#comment:57\">explains</a> why the change was implemented.<br />
<a href=\"https://wptavern.com/woocommerce-explores-the-possibilities-and-challenges-for-e-commerce-in-the-gutenberg-era\">WooCommerce Explores the Possibilities and Challenges for E-Commerce in the Gutenberg Era</a><br />
<a href=\"https://wptavern.com/tailor-page-builder-plugin-discontinued-owners-cite-funding-gutenberg-and-competition\">Tailor Page Builder Plugin Discontinued, Owners Cite Funding, Gutenberg, and Competition</a><br />
<a href=\"https://wptavern.com/wordcamp-europe-2018-speaker-applications-now-open\">WordCamp Europe 2018 Speaker Applications Now Open</a><br />
<a href=\"https://wptavern.com/github-launches-security-alerts-for-javascript-and-ruby-projects-python-support-coming-in-2018\">GitHub Launches Security Alerts for JavaScript and Ruby Projects, Python Support Coming in 2018</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://wordpress.org/plugins/trigger-happy/\">Trigger Happy</a> developed by Hotsource is a visual scripting tool for WordPress, allowing you to connect plugins and events together using a simple user interface. It currently supports core WordPress functionality, WooCommerce, and Ninja Form.</p>
<p><a href=\"https://github.com/boogah/big-dummy\">Big dummy</a> is a project for folks who need to emulate an established blog with plenty of content while doing WordPress benchmarking and performance testing.</p>
<p>There are 2495 posts, 6197 comments, 231 tags, 26 categories, and 10 pages worth of WordPress dummy data, fully ready to import. That&#8217;s 3 (simulated) years worth of content. <i>Note:</i> There are ~1.6 GB of images (courtesy of<a href=\"https://unsplash.com\"> Unsplash</a>) attached to these posts. It&#8217;s a very good idea to import everything <i>but</i> the media in order to avoid timeouts or errors with the WordPress Importer.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, November 29th 3:00 P.M. Eastern</p>
<p>Subscribe to <a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\">WordPress Weekly via Itunes</a></p>
<p>Subscribe to <a href=\"https://www.wptavern.com/feed/podcast\">WordPress Weekly via RSS</a></p>
<p>Subscribe to <a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\">WordPress Weekly via Stitcher Radio</a></p>
<p><strong>Listen To Episode #295:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Nov 2017 07:54:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Workarounds for the Page Template Bug in WordPress 4.9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76785\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wptavern.com/workarounds-for-the-page-template-bug-in-wordpress-4-9\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2105:\"<p>WordPress 4.9 &#8220;Tipton&#8221; <a href=\"https://wptavern.com/wordpress-4-9-released-with-major-improvements-to-customizer-workflow-updated-code-editors-and-new-core-gallery-widget\">was released</a> last week and although it&#8217;s largely trouble-free, there is one particular issue <a href=\"https://wordpress.org/support/topic/updated-to-4-9-wont-detect-page-template/\">users</a> and <a href=\"https://core.trac.wordpress.org/ticket/42573#comment:75\">developers</a> are running into that&#8217;s causing frustration. In 4.9, custom page templates that are created fail to display in the Template drop-down menu. The issue is related to changes made to the <a href=\"https://core.trac.wordpress.org/changeset/41806\">file editor</a>.</p>
<p>Previous versions of WordPress listed files 2-levels deep in the editor. In 4.9, the entire directory tree for a theme is listed regardless of its depth. Caching was added to help limit the performance impacts of loading large WordPress themes. &#8220;An unintended side effect of the caching is that the same directory listing function <tt>get_files</tt> is used both for the theme editor and for gathering page templates,&#8221; Weston Ruter, Co-Release Lead for WordPress 4.9 <a href=\"https://core.trac.wordpress.org/ticket/42573#comment:57\">said</a>.</p>
<p>Within the <a href=\"https://core.trac.wordpress.org/ticket/42573\">trac ticket</a>, developers suggests that a button be added that flushes all caches or disabling the cache if <tt>WP_DEBUG</tt> is set to true. Neither suggestion turned into a patch committed to core. Instead, Ruter has <a href=\"https://gist.github.com/westonruter/6c2ca0e5a4da233bf4bd88a1871dd950\">released a plugin</a> as a workaround that flushes the template cache. Other workarounds include, bumping the theme&#8217;s version, running the <tt>wp cache flush</tt> command in WP CLI, or waiting 60 minutes for the cache to expire.</p>
<p>The ticket is marked as a high priority but because of the upcoming holidays in the US and WordCamp US next weekend, it could be at least a few weeks before WordPress 4.9.1 is released.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Nov 2017 00:42:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WPTavern: Tide Project Aims to Audit and Score WordPress Themes and Plugins based on Code Quality\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76652\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"https://wptavern.com/tide-project-aims-to-audit-and-score-wordpress-themes-and-plugins-based-on-code-quality\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8526:\"<p>Last week XWP dropped an intriguing <a href=\"https://xwp.co/tide-a-path-to-better-code-across-the-wordpress-ecosystem/\" rel=\"noopener\" target=\"_blank\">preview of a new project called Tide</a> that aims to improve code quality across the WordPress plugin and theme ecosystems. The company has been working with the support of Google, Automattic, and WP Engine, on creating a new service that will help users make better plugin decisions and assist developers in writing better code.</p>
<p>XWP&#8217;s marketing manager Rob Stinson summarized the project&#8217;s direction so far:</p>
<blockquote><p>Tide is a service, consisting of an API, Audit Server, and Sync Server, working in tandem to run a series of automated tests against the WordPress.org plugin and theme directories. Through the Tide plugin, the results of these tests are delivered as an aggregated score in the WordPress admin that represents the overall code quality of the plugin or theme. A comprehensive report is generated, equipping developers to better understand how they can increase the quality of their code.</p></blockquote>
<p>The XWP announcement also included a screenshot of how this data might be presented in the WordPress plugin directory:</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/jetpack-tide-plugin-score.jpg?ssl=1\"><img /></a></p>
<p>XWP plans to unveil the service at WordCamp US in Nashville at the Google booth where they will be inviting the community to get involved. Naturally, a project with the potential to have this much impact on the plugin ecosystem raises many questions about who is behind the vision and what kind of metrics will be used.</p>
<p>I contacted Rob Stinson and Luke Carbis at XWP, who are both contributors to the project, to get an inside look at how it started and where they anticipate it going.</p>
<p>&#8220;Tide was started at XWP about 12 months ago when one of our service teams pulled together the idea, followed up by a proof of concept, of a tool that ran a series of code quality tests against a package of code (WordPress plugin) and returned the results via an API,&#8221; Stinson said. &#8220;We shortly after came up with the name Tide, inspired by the proverb &#8216;A rising tide lifts all boats,&#8217; thinking that if a tool like this could lower the barrier of entry to good quality code for enough developers, it could lift the quality of code across the whole WordPress ecosystem.&#8221;</p>
<p>Stinson said XWP ramped up its efforts on Tide during the last few months after beginning to see its potential and sharing the vision with partners.</p>
<p>&#8220;Google, Automattic and WP Engine have all helped resource (funds, infrastructure, developer time, advice etc) the project recently as well,&#8221; Stinson said. &#8220;Their support has really helped us build momentum. Google have been a big part of this since about August. We had been working with them on other projects and when we shared with them the vision for Tide, they loved it and saw how in line it is with the vision they have for a better performant web.&#8221;</p>
<p>The Tide service is not currently active but a beta version will launch at WordCamp US with a WordPress plugin to follow shortly thereafter. Stinson said the team designed the first version to present the possibilities of Tide and encourage feedback and contribution from the community.</p>
<p>&#8220;We realize that Tide will be its best if its open sourced,&#8221; he said. &#8220;There are many moving parts to it and we recognize that the larger the input from the community, the better it will represent and solve the needs of the community around code quality.&#8221;</p>
<p>At this phase of the project, nothing has been set in stone. The Tide team is continuing to experiment with different ways of making the plugin audit data available, as well as refining how that data is weighed when delivering a Tide score.</p>
<p>&#8220;The star rating is just an idea we have been playing with,&#8221; Stinson said. &#8220;The purpose of it will be to aggregate the full report that is produced by Tide into a simple and easy to understand metric that WordPress users can refer to when making decisions about plugins and themes. We know we haven’t got this metric and how it is displayed quite right. We’ve had some great feedback from the community already.&#8221;</p>
<p>The service is not just designed to output scores but also to make it easy for developers to identify weaknesses in their code and learn how to fix them.</p>
<p>&#8220;Lowering the barrier of entry to writing good code was the original inspiration for the idea,&#8221; Stinson said.</p>
<h3>Tide Project Team Plans to Refine Metrics Used for Audit Score based on Community Feedback</h3>
<p>The Tide project website, <a href=\"http://wptide.org\" rel=\"noopener\" target=\"_blank\">wptide.org</a>, will launch at WordCamp US and will provide developers with scores, including specifics like line numbers and descriptions of failed sniffs. Plugin developers will be able to use the site to improve their code and WordPress users will be able to quickly check the quality of a plugin. XWP product manager Luke Carbis explained how the Tide score is currently calculated.</p>
<p>&#8220;Right now, Tide runs a series of code sniffs across a plugin / theme, takes the results, applies some weighting (potential security issues are more important than tabs vs. spaces), and then averages the results per line of code,&#8221; Carbis said. &#8220;The output of this is a score out of 100, which is a great indicator of the quality of a plugin or theme. The &#8216;algorithm&#8217; that determines the score is basically just a series of weightings.&#8221;</p>
<p>The weightings the service is currently using were selected as a starting point, but Carbis said the team hopes the WordPress community will help them to refine it.</p>
<p>&#8220;If it makes sense, maybe one day this score could be surfaced in the WordPress admin (on the add new plugin page),&#8221; Carbis said. &#8220;Or maybe it could influence the search results (higher rated plugins ranked first). Or maybe it just stays on wptide.org. That’s really up to the community to decide.&#8221;</p>
<p>In addition to running codesniffs, the Tide service will run two other scans. A <a href=\"https://developers.google.com/web/tools/lighthouse/\" rel=\"noopener\" target=\"_blank\">Lighthouse</a> scan, using Google&#8217;s open-source, automated tool for improving the quality of web pages, will be performed on themes, which Carbis says is a &#8220;huge technological accomplishment.&#8221;</p>
<p>&#8220;For every theme in the directory, we’re spinning up a temporary WordPress install, and running a Lighthouse audit in a headless chrome instance,&#8221; Carbis said. &#8220;This means we get a detailed report of the theme’s <em>front end output</em> quality, not just the code that powers it.&#8221;</p>
<p>The second scan Tide will perform measures PHP compatibility and will apply to both plugins and themes.</p>
<p>&#8220;Tide can tell which versions of PHP a plugin or theme will work with,&#8221; Carbis said. &#8220;For users, this means we could potentially hide results that we <em>know</em> won’t work with their WordPress install (or at least show a warning). For hosts, this means they can easily check the PHP compatibility before upgrading an install to PHP 7 (we think this will cause <em>many</em> more installs to be upgraded – the net effect being a noticeable speed increase, which we find really exciting and motivating).&#8221;</p>
<p>Carbis said that the team is currently working in the short term to get the PHP Compatibility piece into the WordPress.org API, which he says could start influencing search results without any changes to WordPress core.</p>
<p>&#8220;We’d also like to start engaging with the community to find out whether surfacing a Code Quality score to WordPress users is helpful, and if it is, what does that look like? (e.g. score out of 100, 5 star rating, A/B/C/D, etc.),&#8221; Carbis said. &#8220;We will release our suggestion for what this <em>could</em> look like as a plugin shortly after WordCamp US.&#8221;</p>
<p>More specific information about the metrics Tide is currently using and how it applies to plugins and themes will be available after the service launches in beta. If you are attending WordCamp US and have some suggestions or feedback to offer the team, make sure to stop by the Google sponsorship booth.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Nov 2017 21:21:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"Matt: Adam Robinson on Understanding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47663\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://ma.tt/2017/11/adam-robinson-on-understanding/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5921:\"<p>This is a long quote/excerpt from <a href=\"https://twitter.com/iamadamrobinson\">Adam Robinson</a> I&#8217;ve been holding onto for a while, from <a href=\"https://tribeofmentors.com/\">Tribe of Mentors</a>. Worth considering, especially if you strive to work in a data-informed product organization.</p>
<blockquote><p>Virtually all investors have been told when they were younger — or implicitly believe, or have been tacitly encouraged to do so by the cookie-cutter curriculums of the business schools they all attend — that the more they understand the world, the better their investment results. It makes sense, doesn’t it? The more information we acquire and evaluate, the “better informed” we become, the better our decisions. Accumulating information, becoming “better informed,” is certainly an advantage in numerous, if not most, fields.</p>
<p>But not in the eld of counterintuitive world of investing, where accumulating information can hurt your investment results.</p>
<p>In 1974, Paul Slovic — a world-class psychologist, and a peer of Nobel laureate Daniel Kahneman — decided to evaluate the effect of information on decision-making. This study should be taught at every business school in the country. Slovic gathered eight professional horse handicappers and announced, “I want to see how well you predict the winners of horse races.” Now, these handicappers were all seasoned professionals who made their livings solely on their gambling skills.</p>
<p>Slovic told them the test would consist of predicting 40 horse races in four consecutive rounds. In the first round, each gambler would be given the five pieces of information he wanted on each horse, which would vary from handicapper to handicapper. One handicapper might want the years of experience the jockey had as one of his top five variables, while another might not care about that at all but want the fastest speed any given horse had achieved in the past year, or whatever.</p>
<p>Finally, in addition to asking the handicappers to predict the winner of each race, he asked each one also to state how confident he was in his prediction. Now, as it turns out, there were an average of ten horses in each race, so we would expect by blind chance — random guessing — each handicapper would be right 10 percent of the time, and that their confidence with a blind guess to be 10 percent.</p>
<p>So in round one, with just five pieces of information, the handicappers were 17 percent accurate, which is pretty good, 70 percent better than the 10 percent chance they started with when given zero pieces of information. And interestingly, their confidence was 19 percent — almost exactly as confident as they should have been. They were 17 percent accurate and 19 percent confident in their predictions.</p>
<p>In round two, they were given ten pieces of information. In round three, 20 pieces of information. And in the fourth and final round, 40 pieces of information. That’s a whole lot more than the five pieces of information they started with. Surprisingly, their accuracy had flatlined at 17 percent; they were no more accurate with the additional 35 pieces of information. Unfortunately, their confidence nearly doubled — to 34 percent! So the additional information made them no more accurate but a whole lot more confident. Which would have led them to increase the size of their bets and lose money as a result.</p>
<p>Beyond a certain minimum amount, additional information only feeds — leaving aside the considerable cost of and delay occasioned in acquiring it — what psychologists call “confirmation bias.” The information we gain that conflicts with our original assessment or conclusion, we conveniently ignore or dismiss, while the information that confirms our original decision makes us increasingly certain that our conclusion was correct.</p>
<p>So, to return to investing, the second problem with trying to understand the world is that it is simply far too complex to grasp, and the more dogged our at- tempts to understand the world, the more we earnestly want to “explain” events and trends in it, the more we become attached to our resulting beliefs — which are always more or less mistaken — blinding us to the financial trends that are actually unfolding. Worse, we think we understand the world, giving investors a false sense of confidence, when in fact we always more or less misunderstand it.<br />
You hear it all the time from even the most seasoned investors and financial “experts” that this trend or that “doesn’t make sense.” “It doesn’t make sense that the dollar keeps going lower” or “it makes no sense that stocks keep going higher.” But what’s really going on when investors say that something makes no sense is that they have a dozen or whatever reasons why the trend should be moving in the opposite direction.. yet it keeps moving in the current direction. So they believe the trend makes no sense. But what makes no sense is their model of the world. That’s what doesn’t make sense. The world always makes sense.</p>
<p>In fact, because financial trends involve human behavior and human beliefs on a global scale, the most powerful trends won’t make sense until it becomes too late to profit from them. By the time investors formulate an understanding that gives them the confidence to invest, the investment opportunity has already passed.</p>
<p>So when I hear sophisticated investors or financial commentators say, for example, that it makes no sense how energy stocks keep going lower, I know that energy stocks have a lot lower to go. Because all those investors are on the wrong side of the trade, in denial, probably doubling down on their original decision to buy energy stocks. Eventually they will throw in the towel and have to sell those energy stocks, driving prices lower still.</p></blockquote>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Nov 2017 16:33:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"HeroPress: Finding WordPress in Cameroon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=2286\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"https://heropress.com/essays/finding-wordpress-cameroon/#utm_source=rss&utm_medium=rss&utm_campaign=finding-wordpress-cameroon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5900:\"<img width=\"960\" height=\"480\" src=\"https://heropress.com/wp-content/uploads/2018/11/112217-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull Quote: The more I share knowledge with someone the more I gain in return.\" /><p>My name is Michaël Nde Tabefor, I reside in Cameroon. I grew up in the economic capital of the country surrounded by so much diversity and culture.</p>
<p>Yet I was still very young when I developed an interest in technology, back in Primary school I had a PC at home I used to play around, most especially Spider Solitaire hahaha. Well that game sound crazy but it’s educative, it built up my reflex with the mouse and yeah it worth it. When I arrived in Secondary school I quickly picked up the subject.</p>
<p>I began educating myself on the trend of Technology and how they work. I developed a great interest for organisations such as Google, what they doing for humanity not just about technology. So I understood that no matter the position I get, I must always contribute to Humanity by volunteering.</p>
<p>When I got to the University back in 2014 as a Freshman, I enrolled into Software engineering program where I began excelling and widening my thinking and reflex, met with other enthusiasts of technology.</p>
<h3>Taking Another Path</h3>
<p>Unlike other students I decided to go in for an internship at my first year (am one of those who believe university is good but it contribute to just about 10 &#8211; 20% of what builds up skill, people must be passionate about what the do, that passion alone will get you have the skills and be able to learn more and more).</p>
<p>On my first day of internship, my internship coordinator gave me a task to go and install WordPress on my computer and create with the use of an external template (not there default themes) the website of my university.</p>
<blockquote><p>Let me make this point, I didn’t know about WordPress. Had no idea of what it’s meant for. Completely blank.</p></blockquote>
<p>I went back to my university, I met one of my professors, explained it to him, he redirected me to a senior student who once did internship and had to use WordPress.</p>
<p>I went home, got my environment set up and called my senior, She did the guiding all through the installation on phone, till installing the template, my curiosity did the rest of the job hahaha, end of story. The next day I went back to the office, my coordinator didn’t expect me that soon Lol.</p>
<h3>Diving Deeper</h3>
<p>So I worked on some tutorial on building themes and plugin from scratch from Lynda.com but I took a break from building cuz I didn’t have much skills in PHP, in first year we didn’t do web technologies, I began hacking on PHP on my own, basic’ly I learnt almost every skill on my own via research and practice.</p>
<p>I worked on several sites that used WordPress and began installing for others. My coordinator told me it would be interesting to start a WordPress Community so others could benefit from it. Actually the more I share knowledge with someone I gain 100% in return too, it builds up my mastery and ability to debug and resolve issues.</p>
<blockquote><p>I began our local community and everyday I kept understanding WordPress more and more.</p></blockquote>
<p>After a couple of months I officially joined the WordPress Volunteer Community in doing more reach outs in (November 2015 &#8211; via Rocio Valdiva) and on April 15, 2017 I organized <a href=\"https://2017.buea.wordcamp.org/\">the very first WordCamp in the whole of Central Africa</a> that brought together over 240 persons. Complete gallery on <a href=\"https://www.flickr.com/photos/144827169@N08/\">Flickr</a>, Video on <a href=\"https://youtu.be/nnUgqhveB00\">YouTube</a>.</p>
<p>After the WordCamp I later on built a Mobile Money Payment Gateway with a local Network Operator web payment API using WooCommerce.</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Finding WordPress in Cameroon\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Finding%20WordPress%20in%20Cameroon&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Ffinding-wordpress-cameroon%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Finding WordPress in Cameroon\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Ffinding-wordpress-cameroon%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Ffinding-wordpress-cameroon%2F&title=Finding+WordPress+in+Cameroon\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Finding WordPress in Cameroon\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/finding-wordpress-cameroon/&media=https://heropress.com/wp-content/uploads/2018/11/112217-150x150.jpg&description=Finding WordPress in Cameroon\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Finding WordPress in Cameroon\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/finding-wordpress-cameroon/\" title=\"Finding WordPress in Cameroon\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/finding-wordpress-cameroon/\">Finding WordPress in Cameroon</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Nov 2017 15:45:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Michaël Nde Tabefor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"WPTavern: Envato Elements Adds Unlimited WordPress Theme and Plugin Downloads to Subscription Plan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76604\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"https://wptavern.com/envato-elements-adds-unlimited-wordpress-theme-and-plugin-downloads-to-subscription-plan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4096:\"<p>Envato has added <a href=\"https://envato.com/blog/announcing-wordpress-themes-on-envato-elements/\" rel=\"noopener\" target=\"_blank\">unlimited WordPress theme and plugin downloads</a> to its Elements digital assets subscription service. The company is including a curated collection of <a href=\"https://elements.envato.com/wordpress/themes/sort-by-latest\" rel=\"noopener\" target=\"_blank\">210 WordPress themes</a> and <a href=\"https://elements.envato.com/wordpress/plugins/sort-by-latest\" rel=\"noopener\" target=\"_blank\">100 plugins</a> along with 400,000 other design assets already offered through the service.</p>
<p>Envato is the largest WordPress theme marketplace on the web with 39,102 themes and website templates for sale. Last year the company <a href=\"https://wptavern.com/envato-celebrates-10-years-in-business\" rel=\"noopener\" target=\"_blank\">celebrated 10 years in business</a> and reported that the community earned more than $40 million, with a significant portion of that revenue coming from WordPress products.</p>
<p>The new &#8220;all you can eat&#8221; style package for WordPress themes on Envato Elements was introduced to boost the value of the service&#8217;s annual subscription plan and is not available to monthly subscribers. For $228/year, annual subscribers can change themes as often as they choose, which is the chief selling point of the new addition. However, the subscription service does not provide direct item support for the themes, as they are submitted by independent designers.</p>
<p>Current Elements subscribers have the option to change their payment plans from monthly to annual to gain access to the unlimited WordPress products. Several disgruntled customers have taken to Twitter to express their dissatisfaction with the WordPress additions being withheld from existing monthly subscribers and perceive it to be heavy-handed a tactic for locking in more annual subscribers before raising the price.</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Not cheeky ask at all, your roadmap did not say anything about this price change, but got people signed up at $19 per month with the understanding this was going to be an added edition. Shocking way to treat loyal customers. <a href=\"https://twitter.com/hashtag/moneyhungry?src=hash&ref_src=twsrc%5Etfw\">#moneyhungry</a></p>
<p>&mdash; TVBanterUK <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f4ad.png\" alt=\"💭\" class=\"wp-smiley\" /> (@TVBanterUK) <a href=\"https://twitter.com/TVBanterUK/status/930943546693226501?ref_src=twsrc%5Etfw\">November 15, 2017</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Why hold monthly subscribers ransom by only allowing annual subscribers access? Feels somewhat unfair to long term subs!</p>
<p>&mdash; Paul Charlton (@ipixel_design) <a href=\"https://twitter.com/ipixel_design/status/931203052765433862?ref_src=twsrc%5Etfw\">November 16, 2017</a></p></blockquote>
<p></p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Yes we were on the understanding us early day loyal subscribers signed up would get what the roadmap said, it’s such a sneaky way to get people locked in to the annual plan which you will then increase in year 2, seen it all before.</p>
<p>&mdash; TVBanterUK <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f4ad.png\" alt=\"💭\" class=\"wp-smiley\" /> (@TVBanterUK) <a href=\"https://twitter.com/TVBanterUK/status/931097713579610112?ref_src=twsrc%5Etfw\">November 16, 2017</a></p></blockquote>
<p></p>
<p>An Envato support representative offered some background on the decision in response to monthly subscribers who do not appreciate being excluded from additions to the service.</p>
<p>&#8220;We chose this pricing model because we think it creates the fairest platform for both our subscribers and our authors,&#8221; the representative said. &#8220;A huge amount of time and dedication goes into creating and maintaining WordPress themes and plugin so this allows us to help protect the earnings of the authors who provide our community with premium assets.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Nov 2017 04:01:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: Tribe of Mentors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47661\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"https://ma.tt/2017/11/tribe-of-mentors/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1004:\"<p>Tim Ferriss&#8217;s new book <a href=\"https://tribeofmentors.com/\">Tribe of Mentors is out</a>. I have finished it already, and can say it&#8217;s really excellent and I even liked it more than Tools of Titans even though I&#8217;m not in this one. <img src=\"https://s.w.org/images/core/emoji/2.3/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /> As I said in a message to Tim:</p>
<blockquote class=\"twitter-tweet\">
<p lang=\"en\" dir=\"ltr\">Curious how Tribe of Mentors is different from Tools of Titans? Here\'s a text to me from Matt Mullenweg (<a href=\"https://twitter.com/photomatt?ref_src=twsrc%5Etfw\">@photomatt</a>, CEO Automattic)&#8230; <a href=\"https://t.co/D9kvA2rFFC\">pic.twitter.com/D9kvA2rFFC</a></p>
<p>&mdash; Tim Ferriss (@tferriss) <a href=\"https://twitter.com/tferriss/status/919729467244863488?ref_src=twsrc%5Etfw\">October 16, 2017</a></p></blockquote>
<p></p>
<p>I learned a lot from it, took a ton of notes to follow up on, and wrote down about twenty more books I have to read.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Nov 2017 23:55:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"WPTavern: Tailor Page Builder Plugin Discontinued, Owners Cite Funding, Gutenberg, and Competition\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76599\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"https://wptavern.com/tailor-page-builder-plugin-discontinued-owners-cite-funding-gutenberg-and-competition\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6385:\"<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/tailor-e1510853958841.png?ssl=1\"><img /></a></p>
<p><a href=\"https://www.enclavely.io/\" rel=\"noopener\" target=\"_blank\">Enclavely, Inc.</a>, the owners of the <a href=\"https://wordpress.org/plugins/tailor/\" rel=\"noopener\" target=\"_blank\">Tailor Page Builder plugin</a>, have announced that they will be <a href=\"https://www.tailorwp.com/discontinued/\" rel=\"noopener\" target=\"_blank\">discontinuing its development</a> effective immediately.</p>
<p><a href=\"http://andrewworsfold.com/\" rel=\"noopener\" target=\"_blank\">Andrew Worsfold</a>, the original developer, launched Tailor in April 2016 and the plugin received an enthusiastic reception from the WordPress community. After performing <a href=\"https://wptavern.com/pippin-williamson-shakes-up-page-builder-plugins-with-critical-review\" rel=\"noopener\" target=\"_blank\">a critical review of the major page builders</a> available to users in September 2016, Pippin Williamson found only three that he could happily recommend to his customers: Tailor, Pootle Page Builder, and Beaver Builder. This recommendation was based primarily on code quality, usability, and compatibility with other plugins.</p>
<p>The plugin <a href=\"https://www.tailorwp.com/tailor-page-builder-under-new-management/\" rel=\"noopener\" target=\"_blank\">came under new management in July 2017</a> after the original developer no longer had enough time to dedicate to the project. Worsfold sold it to Enclavely, whose owners were early and enthusiastic users of the plugin, for what he said was &#8220;a nominal amount.&#8221; Three months later, the new owners cite the cost of keeping up with Gutenberg and other competitors as the primary reason for <a href=\"https://www.tailorwp.com/discontinued/\" rel=\"noopener\" target=\"_blank\">discontinuing its development</a>:</p>
<blockquote><p>Gutenberg is going to be bundled with WordPress itself. That’s definitely going to give a tough time to all 3rd party page builders and even that is not the case there are some really big players around like Elementor, Divi, Beaver Builder, and others which are going to be hard for us to compete with, being a completely free project and providing almost all the great features in free version&#8230;</p>
<p>So the main reason for us to discontinue Tailor is due to finances, which Tailor needs to keep on its development and marketing to compete with all the big players and especially Gutenberg.</p></blockquote>
<p>This instance seems to be more of a case of the new management running out of funds, rather than Gutenberg preemptively killing off a page builder. Enclavely was no longer willing to invest in developing a product that could compete against some of the more widely used page builders.</p>
<p>&#8220;Tailor needs a lot of effort and money, which was much more than we estimated,&#8221; an Enclavely representative said when I contacted the company. &#8220;And even if we continue to put effort and money in this project, we all know that Gutenberg is going to smash this space soon and we won&#8217;t be able to survive, and so will be the case with some other page builders. This is why we decided to end this now.&#8221;</p>
<p>Tailor currently has more than 3,000 active installations, according to WordPress.org. Fans of the plugin commented on the <a href=\"https://medium.com/tailor-page-builder/end-of-tailor-rise-of-gutenberg-6b4c59431f99\" rel=\"noopener\" target=\"_blank\">announcement</a>, asking if the original developer might be able to pick the project back up again.</p>
<p>When I contacted the company, they said the original developer was no longer involved with the project.</p>
<p>&#8220;The original developer has parted ways since the acquisition,&#8221; an Enclavely representative said. &#8220;He was involved with some stuff in the start but not that much, thus the decision is mainly taken by us based on the issues we were facing in maintaining this project.&#8221;</p>
<p>However, Worsfold&#8217;s account of his involvement with Tailor following the acquisition differs greatly from Enclavely&#8217;s report.</p>
<p>&#8220;I handed over control of the project in July, although all releases since then were also written by me and deployed on their behalf,&#8221; Worsfold said. &#8220;Given that I haven&#8217;t been asked to help with anything recently, and there have been no further releases, it looks like development has already ended.&#8221;</p>
<p>The plugin is <a href=\"https://wordpress.org/plugins/tailor/\" rel=\"noopener\" target=\"_blank\">available free on WordPress.org</a> and licensed under the GPL, so anyone who wants to can fork it. Worsfold doesn&#8217;t anticipate having the time to maintain the project himself and said he was under the impression that Enclavely is attempting to sell it.</p>
<p>&#8220;I made the decision to hand over control of Tailor as work and other commitments meant that I couldn&#8217;t dedicate enough time to the project,&#8221; Worsfold said. &#8220;I had hoped that the new team would continue development, provide support, and ensure the needs of existing users were met. However after just three months they&#8217;ve decided to give up. That&#8217;s obviously very disappointing.&#8221;</p>
<p>Worsfold said that when he sold it to them, it was with the understanding that they would continue to develop and maintain it. He doesn&#8217;t anticipate being able to re-adopt it due to a lack of time to dedicate to the project.</p>
<p>&#8220;I&#8217;m in much the same situation I was in before and it seems they are wanting to on-sell it themselves, so I can&#8217;t imagine I will be able to readopt it,&#8221; Worsfold said. &#8220;I have mixed feelings about the whole situation. Ultimately I see Gutenberg doing most of what page builders currently do, but in a better, more standardized, way. Hopefully, whatever&#8217;s left (custom blocks, styles, functionality etc.) will build on the framework and serve to reduce the amount of fragmentation in the ecosystem.&#8221;</p>
<p>Worsfold is still limited on free time but said he would be willing to contribute to the project  if someone decided to fork it and keep it alive.</p>
<p>&#8220;It would be a shame to see something I built, and that people use, simply die,&#8221; he said. &#8220;Hopefully someone will either fork it or take over development.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Nov 2017 00:15:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: GitHub Launches Security Alerts for JavaScript and Ruby Projects, Python Support Coming in 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76663\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:115:\"https://wptavern.com/github-launches-security-alerts-for-javascript-and-ruby-projects-python-support-coming-in-2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1873:\"<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2015/04/github-octocat.jpg?ssl=1\"><img /></a></p>
<p>Last month <a href=\"https://wptavern.com/github-launches-new-dependency-graph-feature-with-security-alerts-coming-soon\" rel=\"noopener\" target=\"_blank\">GitHub launched its Dependency Graph feature</a> that tracks a repository&#8217;s dependencies and sub-dependencies under the Insights tab. This week the company rolled out an expansion of the feature and will now <a href=\"https://github.com/blog/2470-introducing-security-alerts-on-github\" rel=\"noopener\" target=\"_blank\">identify known vulnerabilities and send notifications</a> with suggested fixes from the GitHub community.</p>
<p>Dependency graphs and security alerts are automatically enabled for public repositories, provided the repository owner has defined the dependencies in <a href=\"https://help.github.com/articles/listing-the-packages-that-a-repository-depends-on\" rel=\"noopener\" target=\"_blank\">one of the supported manifest file types</a>, such as package.json or Gemfile. (Private repo owners have to opt in.) The vulnerability alerts are not public &#8211; they will only be shown to those who have been granted access to the vulnerability alerts.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2017/11/github-dependency-vulnerability.png?ssl=1\"><img /></a></p>
<p>GitHub uses data from the <a href=\"https://nvd.nist.gov/\" rel=\"noopener\" target=\"_blank\">National Vulnerability Database</a> to alert repository owners about publicly disclosed vulnerabilities that have <a href=\"https://cve.mitre.org/\" rel=\"noopener\" target=\"_blank\">CVE IDs</a>. Vulnerability detection is currently limited to JavaScript and Ruby projects but Python support is next on the roadmap for 2018. PHP, which is a bet less widely used in projects on GitHub, is likely further down the list.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 18 Nov 2017 00:25:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: WordCamp Europe 2018 Speaker Applications Now Open\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76608\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wptavern.com/wordcamp-europe-2018-speaker-applications-now-open\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3019:\"<p>WordCamp Europe 2018 has opened the <a href=\"https://2018.europe.wordcamp.org/2017/11/15/are-you-ready-to-speak-at-the-largest-wordpress-event-in-europe/\" rel=\"noopener\" target=\"_blank\">call for speakers</a> and will be accepting applications through January 15. The organizing team recommends that speakers already have some experience ahead of applying to speak at the largest WordPress event in Europe, but a dedicated Content Team will also be available with resources for helping speakers create a successful presentation.</p>
<p>The 2017 event received a total of 235 speaker applications and 43 were selected for the main event. Organizers plan to stick to the same format and are calling for 40-minute talks (30 min + 10 min Q&amp;A) as well as 10-minute lightning talks. This year the event will experiment with hosting community workshops and organizers plan to open a separate call for workshop leaders next week.</p>
<p>The Content Team put out a specific call for more technical talks at the 2018 event after a <a href=\"https://2018.europe.wordcamp.org/2017/11/10/how-your-feedback-will-help-us-shape-the-next-wordcamp-europe/\" rel=\"noopener\" target=\"_blank\">community survey</a> showed that more developer-oriented talks are what the audience is looking for. More than half of those surveyed identified themselves as developers (54%), with business owners (12%) the next largest demographic.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-17-at-11.44.21-AM.png?ssl=1\"><img /></a></p>
<p>The survey also showed that 37% of respondents have been working with WordPress for more than 9 years and roughly 90% of attendees have been using WordPress for 4-9+ years. Advanced development was the most highly requested topic for presentations, selected by 53% of respondents, followed by design (45%).</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-17-at-11.54.06-AM.png?ssl=1\"><img /></a></p>
<p>The survey results offer some insight about which topics might fare well at WCEU in 2018. Organizers have also compiled an extensive <a href=\"https://apply.wp-europe.org/ideas\" rel=\"noopener\" target=\"_blank\">list of ideas and topics</a> to inspire speaker applicants.</p>
<p>A batch of 1,000 Early Bird tickets recently <a href=\"https://wptavern.com/wordcamp-europe-2018-early-bird-tickets-now-on-sale\" rel=\"noopener\" target=\"_blank\">went on sale</a> and there are still 680 available. Attendees who purchase a ticket before December 31, 2017, will receive a limited-edition swag item. The organizing team plans to release tickets in batches, as in previous years, but will not be setting specific expectations on sales this year, according to PR representative Letizia Barbi. The Sava Center venue, an international congress and cultural center, is the largest audience hall in Serbia and will accommodate all who want to attend WCEU 2018. Barbi said it should also scale down nicely in case of a smaller turn out.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Nov 2017 19:19:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"WPTavern: WooCommerce Explores the Possibilities and Challenges for E-Commerce in the Gutenberg Era\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76597\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"https://wptavern.com/woocommerce-explores-the-possibilities-and-challenges-for-e-commerce-in-the-gutenberg-era\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4350:\"<p>The next release of WordPress (5.0) will introduce the new Gutenberg editor and contributors plan to keep it rolling towards the eventual goal of providing a full site building experience. Nearly every WordPress theme and plugin developer will be impacted by the change and many are starting to look ahead to how their products may interact with Gutenberg in the future.</p>
<p>What will e-commerce look like in the Gutenberg era? The WooCommerce design team has published <a href=\"https://woocommerce.com/2017/11/woocommerce-gutenberg/\" rel=\"noopener\" target=\"_blank\">a preview of some of their &#8220;Wootenberg&#8221; experiments</a>, along with a gif demonstrating what a block-based editing experience may look like in the context of working with products. The team sees a lot of potential for putting the power of visual product editing into the hands of users.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/wootenberg.gif?ssl=1\"><img /></a></p>
<p>The example shows a quick exploration of page layout with product blocks and the team also posted an idea of what basic product authoring may look like with a predefined product template that includes the featured image, product title, description, and price as new Gutenberg blocks. But will it be possible to have complex product creation fit into a block-based editor? The WooCommerce team admits in the post that they don&#8217;t yet know how this will work.</p>
<p>&#8220;One thing that isn’t yet 100% clear is how complex plugins like WooCommerce will work with Gutenberg,&#8221; Automattic designer/developer James Koster said. &#8220;A simple product with a description, a price, and a category is one thing. But a product with variations, for each of which you want to upload a different image, and need to manage/track stock is quite another. Imagining a WYSIWYG editing experience for that kind of data is a little fuzzier.&#8221;</p>
<p>Koster referenced Gutenberg&#8217;s newly merged support for meta boxes, the first step in making product authoring possible. However, the Gutenberg team is still experimenting and isn&#8217;t yet set on a solution for implementing meta boxes.</p>
<p>&#8220;How this works with WooCommerce in the long term is unclear,&#8221; Koster said. &#8220;But you can rest assured it’s something we’ll be dedicating more time to investigating as WordPress approaches the 5.0 release.&#8221; Koster concludes the post by asking readers if visual product editing, with the flexibility to rearrange product/shop layouts, is something that interests them.</p>
<p>&#8220;If there’s one thing that WooCommerce should perhaps learn from Shopify’s rapid growth, it’s that many &#8216;would-be&#8217; shop owners don’t care to spend hours upon hours tweaking the layout of their shop, and that pre-built easy-to-use software that looks good and feels good, but can still be extended in complex ways, is what attracts many users,&#8221; Jesse Nickles commented on the post. &#8220;While this may be the underlying goal of Gutenberg, it perhaps doesn’t crossover clearly to the e-commerce world.&#8221;</p>
<p>Koster said he agrees that users don&#8217;t always need visual editing experiences and that simple things like price changes should be quick and painless.</p>
<p>&#8220;How we present data-driven editing alongside the Gutenberg experience will ultimately determine the success of the project from a WooCommerce perspective,&#8221; Koster said.</p>
<p>Support for meta boxes is one the most challenging aspects of the Gutenberg project that the team has yet to solve. Exploring the possibilities of flexible page layouts for products is exciting, but even the WooCommerce team is left wondering how this is all going to work with more complex CMS data. Smaller product teams without the collective knowledge and resources of WooCommerce may have a more difficult time finding the bandwidth to experiment and rebuild their products in time for WordPress 5.0.</p>
<p>The WooCommerce team invites any users interested in Gutenberg-related UX changes to join the plugin&#8217;s <a href=\"https://woocommerce.com/design-feedback/\" rel=\"noopener\" target=\"_blank\">design feedback group</a>, as they continue to explore how the new editor will work in the context of complex e-commerce product creation and display.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Nov 2017 04:30:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"WPTavern: GDPR for WordPress Project Gains Momentum, Proposal Receives Positive Response from Developer Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76484\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:123:\"https://wptavern.com/gdpr-for-wordpress-project-gains-momentum-proposal-receives-positive-response-from-developer-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5743:\"<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/10/WP-GDPR-Compliance.png?ssl=1\"><img /></a></p>
<p>Community feedback on the new <a href=\"https://www.gdprwp.com\" rel=\"noopener\" target=\"_blank\">GDPR for WordPress project</a>, created by WordCamp Denmark organizer Kåre Mulvad Steffensen and WP Pusher creator Peter Suhm, has started rolling in after the two launched a survey for developers. The project aims to provide an industry standard for getting plugins compliant with EU General Data Protection Regulation (GDPR) legislation ahead of the May 2018 deadline.</p>
<p>Steffensen <a href=\"https://www.gdprwp.com/status-the-gdpr-interface/\" rel=\"noopener\" target=\"_blank\">published</a> some initial results of the survey after having it open for two weeks. So far, 90% of respondents have answered that they would consider implementing a GDPR &#8220;file&#8221; types solution for their plugins if a standard was available. Only 4.9% of the 40 developers who responded said they have a plan for making their plugins GDPR compliant and 43.9% said they do not currently have a plan. The remaining 24.4% were developers of plugins that do not handle personal data.</p>
<p>&#8220;Our talks with Paul Sieminski from <a href=\"https://automattic.com/\" rel=\"noopener\" target=\"_blank\">Automattic</a> and Dovy Paukstys from the <a href=\"https://reduxframework.com/\" rel=\"noopener\" target=\"_blank\">Redux options framework</a> have reassured us that we still do have a need for a GDPR structure which can help the community establish a basis for handling GDPR compliance,&#8221; Steffensen said.</p>
<p>Steffensen and Suhm created a <a href=\"https://github.com/GDPRWP/standard\" rel=\"noopener\" target=\"_blank\">GitHub repository</a> where they have outlined their proposal for a PHP object interface that plugin developers could add to their codebases as a standard way of indicating how their plugins work with personal data.</p>
<p>&#8220;The nature of such an interface puts some responsibility in the hands of the developer to identify any place personal data is stored,&#8221; Steffensen said. &#8220;What kind of data it is, and for what purpose as well as how it should be handled upon deletion. The Interface approach will allow a community-wide adoption, without setting limitations on how plugin developers choose to work with their data – something we obviously can’t control.&#8221;</p>
<p>The idea is that plugin developers could then build other tools on top of this framework using specific functions that correspond to GDPR requirements, such as functions that allow users to access their data, implement the right to be forgotten, report data breaches, and delete and anonymize data. Developers could also build plugins that offer a plain language description of what personal data a plugin collects and how it is handled.</p>
<p>In speaking with Dovy Paukstys on how this could work with Redux, Steffensen said the options framework may be able to facilitate compliance for the 500,000+ sites where it is active and the developers who use it to build plugins.</p>
<p>&#8220;Dovy from Redux has a coder&#8217;s view on this,&#8221; Steffensen said. &#8220;Our object interface (PHP) would be something his framework could provide an easy way to utilize for the many developers using Redux.  The redux users (developers) could essentially do this themselves also, but since Redux is a framework it makes sense to see if they can build something that will make it near instant for developers to provide compliance for the GDPR.&#8221;</p>
<p>Steffensen said the team is aware that the first version of the interface will not render plugins, and by extension their sites, instantly compliant. The interface they are proposing is not one that could be held legally accountable, but the goal is to make it possible for developers to build accountable systems on top of it.</p>
<h3>GDPR for WordPress Project Founders Consider Accepting Sponsorships</h3>
<p>With 189 <a href=\"http://www.gdprcountdownclock.com/\" rel=\"noopener\" target=\"_blank\">days remaining before the GDPR goes into effect</a>, the team will need to work quickly to make a solution available with enough time for interested developers to incorporate it into their plugins. They have not yet set up a way to accept donations but are considering it.</p>
<p>&#8220;We aren&#8217;t actively seeking funding, but would love any funds that would help us allocate the time needed to keep the momentum going,&#8221; Steffensen said. &#8220;We&#8217;re lucky that the <a href=\"https://wptavern.com/gdpr-for-wordpress-project-seeks-to-provide-a-standard-for-plugin-compliance\" rel=\"noopener\" target=\"_blank\">WP Tavern article</a> brought attention to our GDPR approach and have caught the eyes of some of the key players in the ecosystem. One such company is Mailpoet that was the first to raise the idea of sponsoring our work.&#8221;</p>
<p>Steffensen works at <a href=\"http://Peytz.dk\" rel=\"noopener\" target=\"_blank\">Peytz.dk</a>, a Danish WordPress agency that wants to support the community and has allocated some of his time to work on the project. He said any funding/donations they receive would be spent on pushing the roadmap forward, investing time in coding, and possibly seeking further advice from people who they cannot expect to be in it for free.</p>
<p>In addition to looking at ways to receive donations, the team plans to keep the survey open for developers for awhile longer to try to make more connections in the community. Steffensen said they hope respondents will help them gain insight on the developer community&#8217;s readiness and also enable them to reach out to any plugin owners who could play a key role in a wider adoption.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Nov 2017 20:58:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: Consultants Are WordPress’ Boots on the Ground\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76619\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"https://wptavern.com/consultants-are-wordpress-boots-on-the-ground\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1173:\"<blockquote><p>A business can’t survive without strong sales &amp; customer service, two competencies that are arguably the lifeblood of a company.</p>
<p>Many of you reading this fill that exact gap for the open source WordPress project. I don’t mean this as a slight to the thousands of wonderful people who build the software, document it, and support it in the forums, but that consultants (doing it right or wrong) are also fueling this locomotive too.</p>
<p>There are no official sales or customer service channels at WordPress.org and us consultants bear the brunt of it — for better or worse — and that’s where our job comes in. Just as you trust a core contributor to spot-check her code and ensure that we’ve <em>sanitized all the things! </em></p>
<p><em>Consultants are the boots on the ground, and as you’ll see below in my feedback section, represent a disproportionate ratio of launching many more websites than an individual website owner. &#8211; Matt Medeiros<br />
</em></p></blockquote>
<p>From <a href=\"https://mattreport.com/growth-of-wordpress/\">The blue-collar WordPress worker and the 2,500+ websites built to grow the CMS</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Nov 2017 20:07:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: WPWeekly Episode 294 – HeroPress, Community, and WinningWP With Topher DeRosia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com?p=76578&preview=true&preview_id=76578\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"https://wptavern.com/wpweekly-episode-294-heropress-community-and-winningwp-with-topher-derosia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2958:\"<p>In this episode, <a href=\"https://jjj.blog/\">John James Jacoby</a> and I are joined by <a href=\"https://topher1kenobe.com/\">Topher DeRosia</a>, founder of <a href=\"https://heropress.com/\">HeroPress</a>. DeRosia provides an update on HeroPress and explains his new role creating <a href=\"https://www.youtube.com/channel/UCt8Sa48zWN_WcordE7TaUBg\">WordPress training videos</a> for <a href=\"https://winningwp.com/\">WinningWP</a>. Jacoby and I discussed the news of the week including, Press This removed in WordPress 4.9, Meta box support in Gutenberg, and WP-SpamShield removed from the directory.</p>
<p>Near the end of the show, we discuss whether or not consultants, agencies, and site builders have been left out of the discussion and not factored into WordPress&#8217; growth over the years.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wptavern.com/press-this-removed-from-wordpress-4-9-in-favor-of-a-plugin\">Press This Removed from WordPress 4.9 in Favor of a Plugin</a><br />
<a href=\"https://wptavern.com/bianca-welds-awarded-kim-parsell-travel-scholarship\">Bianca Welds Awarded Kim Parsell Travel Scholarship</a><br />
<a href=\"https://wptavern.com/wordcamp-europe-2018-early-bird-tickets-now-on-sale\">WordCamp Europe 2018 Early Bird Tickets Now on Sale</a><br />
<a href=\"https://wptavern.com/gutenberg-contributors-explore-alternative-to-using-iframes-for-meta-boxes\">Gutenberg Contributors Explore Alternative to Using iframes for Meta Boxes</a><br />
<a href=\"https://wptavern.com/wp-spamshield-plugin-removed-from-wordpress-org-author-plans-to-pull-all-plugins-from-the-directory\">WP-SpamShield Plugin Removed from WordPress.org, Author Plans to Pull All Plugins from the Directory</a><br />
<a href=\"https://mattreport.com/growth-of-wordpress/?utm_content=bufferee910&utm_medium=social&utm_source=twitter.com&utm_campaign=buffer\">The blue-collar WordPress worker and the 2,500+ websites built to grow the CMS</a></p>
<h2>Picks of the Week:</h2>
<p><a href=\"https://wptavern.com/how-to-whitelist-comments-in-wordpress\">How to Whitelist Comments in WordPress</a></p>
<p><a href=\"https://wordpress.org/plugins/dark-mode/\">Dark Mode</a> is an experimental feature plugin that darkens the colors of the WordPress backend.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, November 22nd 3:00 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\" rel=\"noopener\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"https://wptavern.com/feed/podcast\" target=\"_blank\" rel=\"noopener\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\" rel=\"noopener\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #294:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Nov 2017 03:13:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:130:\"WPTavern: WordPress 4.9 Released with Major Improvements to Customizer Workflow, Updated Code Editors, and New Core Gallery Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76391\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:139:\"https://wptavern.com/wordpress-4-9-released-with-major-improvements-to-customizer-workflow-updated-code-editors-and-new-core-gallery-widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5359:\"<p><a href=\"https://wordpress.org/news/2017/11/tipton/\" rel=\"noopener\" target=\"_blank\">WordPress 4.9</a> &#8220;Tipton&#8221; was released today, named for Oklahoma-born jazz musician <a href=\"https://en.wikipedia.org/wiki/Billy_Tipton\" rel=\"noopener\" target=\"_blank\">William Lee Tipton</a>, a gifted pianist and saxophonist. This update introduces major improvements to the design and collaboration workflow in the Customizer, improves WordPress&#8217; built-in code editor, and enhances core text and media widgets.</p>
<h4>Draft, Schedule, and Preview Changes in the Customizer</h4>
<p>Prior to 4.9, users could get a live preview of their sites in the Customizer but any changes they made would need to be saved immediately or discarded. This update makes it possible to draft and schedule changes in the Customizer, and even share a preview link to collaborate on changes before making them live. Users can now stage content, such as new pages, a new set of widgets, a different combination of menu items, and schedule it all to publish at a future date.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/customizer-publish-settings-schedule-e1510636315310.png?ssl=1\"><img /></a></p>
<p>This release also brings the ability to search, browse, and preview themes directly in the Customizer. The search interface includes filters for subject, features, and layout, just like the ones on the &#8220;Add Themes&#8221; screen in wp-admin. It does not yet include the featured, popular, latest, or favorites tabs, so users will need to navigate back to the admin if they want to browse those categories.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2017/11/theme-browser-customizer.png?ssl=1\"><img /></a></p>
<p>The menu creation process has also been updated in the Customizer to be less confusing with a rethink of the UI and revised copy.</p>
<h4>Syntax Highlighting and Error Checking Added to the Code Editors</h4>
<p>WordPress 4.9 brings syntax highlighting, linting, and auto-completion to the built-in code editors by incorporating the <a href=\"https://codemirror.net/\">CodeMirror</a> library. These long-awaited improvements are now available in the theme and plugin editors as well as the custom HTML widget and additional CSS box in the Customizer. The feature comes with <a href=\"https://wptavern.com/wordpress-4-9-protects-users-from-fatal-errors-created-in-the-theme-and-plugin-editors\" rel=\"noopener\" target=\"_blank\">prominent warnings</a> about directly editing themes and plugins and protection against saving code that would cause a fatal error.</p>
<p><a href=\"https://i1.wp.com/wptavern.com/wp-content/uploads/2017/11/editor-css-error-e1510640427941.png?ssl=1\"><img /></a></p>
<h4>New Core Gallery Widget and Support for Shortcodes and Embedded Media in the Text Widget</h4>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/09/core-gallery-widget.png?ssl=1\"><img /></a><a href=\"https://wptavern.com/new-core-gallery-widget-targeted-for-wordpress-4-9\" rel=\"noopener\" target=\"_blank\">WordPress 4.9 adds a new gallery widget</a> to the collection of core media widgets (audio, image, and video) that were introduced in 4.8. It brings the same gallery-creation features to widgets that have long been available in the post and page editors.</p>
<p>These incremental changes will help users get ready for Gutenberg&#8217;s block-based interface. The plan is to eventually transition widgets over to blocks after Gutenberg is in core and the plugin already has support for a gallery block, as well as a Custom HTML block.</p>
<p>As of 4.9, users can now embed media in the Text widget, including images, video, and audio by clicking the &#8220;Add Media&#8221; button. In order to make this possible, WordPress contributors also needed to <a href=\"https://wptavern.com/wordpress-4-9-will-support-shortcodes-and-embedded-media-in-the-text-widget\" rel=\"noopener\" target=\"_blank\">add shortcode support to widgets</a>, a feature that users have requested for nearly a decade. With this now built into core, hundreds of thousands of WordPress sites will no longer need additional code from plugins and themes to use shortcodes in widgets.</p>
<p>Widgets have also been improved to offer a better migration experience with updated logic for mapping widgets between two themes’ widget areas.</p>
<h4>On Towards Gutenberg</h4>
<p>WordPress 4.9 also includes a notice in the about.php page of the admin, inviting users to help test or contribute to Gutenberg. It is the first time a feature plugin has been highlighted so prominently on the page users see after they update to the latest version.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-15-at-4.33.01-PM-e1510785254925.png?ssl=1\"><img /></a></p>
<p>The Gutenberg project has been getting a lot of attention over the past few months as the WordPress community looks ahead to the 5.0 release that will introduce the new editor to the world. Meanwhile, contributors to 4.9 have been working in tandem to make significant improvements to existing features, enabling users to do more with widgets and overall site design than ever before. This release was led by Weston Ruter and Mel Choyce with help from 443 contributors, 42% (185) of them contributing to WordPress for the first time.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Nov 2017 01:24:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"Dev Blog: WordPress 4.9 “Tipton”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=4968\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wordpress.org/news/2017/11/tipton/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:41416:\"<h2>Major Customizer Improvements, Code Error Checking, and More!&nbsp;🎉</h2>

<img src=\"https://i1.wp.com/wordpress.org/news/files/2017/11/banner.png?fit=2400%2C1200&ssl=1\" alt=\"\" />



<p>Version 4.9 of WordPress, named “Tipton” in honor of jazz musician and band leader Billy Tipton, is available for download or update in your WordPress dashboard. New features in 4.9 will smooth your design workflow and keep you safe from coding errors.</p>



<p>Featuring design drafts, scheduling, and locking, along with preview links, the Customizer workflow improves collaboration for content creators. What’s more, code syntax highlighting and error checking will make for a clean and smooth site building experience. Finally, if all that wasn’t pretty great, we’ve got an awesome new Gallery widget and improvements to theme browsing and switching.</p>



<hr class=\"wp-block-separator\" />



<h2>Customizer Workflow Improved </h2>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2017/11/customizer-workflow-improved-small.png?w=632&ssl=1\" alt=\"\" />



<h3>Draft and Schedule Site Design Customizations</h3>



<p>Yes, you read that right. Just like you can draft and revise posts and schedule them to go live on the date and time you choose, you can now tinker with your site’s design and schedule those design changes to go live as you please.</p>



<h3>Collaborate with Design Preview Links</h3>



<p>Need to get some feedback on proposed site design changes? WordPress 4.9 gives you a preview link you can send to colleagues and customers so that you can collect and integrate feedback before you schedule the changes to go live. Can we say collaboration++?</p>



<h3>Design Locking Guards Your Changes</h3>



<p>Ever encounter a scenario where two designers walk into a project and designer A overrides designer B’s beautiful changes? WordPress 4.9’s design lock feature (similar to post locking) secures your draft design so that no one can make changes to it or erase all your hard work.</p>



<h3>A Prompt to Protect Your Work</h3>



<p>Were you lured away from your desk before you saved your new draft design? Fear not, when you return, WordPress 4.9 will politely ask whether or not you’d like to save your unsaved changes.</p>



<hr class=\"wp-block-separator\" />



<h2>Coding Enhancements</h2>



<img src=\"https://i2.wp.com/wordpress.org/news/files/2017/11/coding-enhancements-small.png?w=632&ssl=1\" alt=\"\" />



<h3>Syntax Highlighting and Error Checking? Yes, Please!</h3>



<p>You’ve got a display problem but can’t quite figure out exactly what went wrong in the CSS you lovingly wrote. With syntax highlighting and error checking for CSS editing and the Custom HTML widget introduced in WordPress 4.8.1, you’ll pinpoint coding errors quickly. Practically guaranteed to help you scan code more easily, and suss out &amp; fix code errors quickly.</p>



<h3>Sandbox for Safety</h3>



<p>The dreaded white screen. You’ll avoid it when working on themes and plugin code because WordPress 4.9 will warn you about saving an error. You’ll sleep better at night.</p>



<h3>Warning: Potential Danger Ahead!</h3>



<p>When you edit themes and plugins directly, WordPress 4.9 will politely warn you that this is a dangerous practice and will recommend that you draft and test changes before updating your file. Take the safe route: You’ll thank you. Your team and customers will thank you.</p>



<hr class=\"wp-block-separator\" />



<h2>Even More Widget Updates </h2>



<img src=\"https://i1.wp.com/wordpress.org/news/files/2017/11/even-more-widget-updates-small.png?w=632&ssl=1\" alt=\"\" />



<h3>The New Gallery Widget</h3>



<p>An incremental improvement to the media changes hatched in WordPress 4.8, you can now add a gallery via this new widget. Yes!</p>



<h3>Press a Button, Add Media</h3>



<p>Want to add media to your text widget? Embed images, video, and audio directly into the widget along with your text, with our simple but useful Add Media button. Woo!</p>



<hr class=\"wp-block-separator\" />



<h2>Site Building Improvements </h2>



<img src=\"https://i1.wp.com/wordpress.org/news/files/2017/11/site-building-improvements-small.png?w=632&ssl=1\" alt=\"\" />



<h3>More Reliable Theme Switching</h3>



<p>When you switch themes, widgets sometimes think they can just move location. Improvements in WordPress 4.9 offer more persistent menu and widget placement when you decide it’s time for a new theme. </p>



<h3>Find and Preview the Perfect Theme</h3>



<p>Looking for a new theme for your site? Now, from within the Customizer, you can search, browse, and preview over 2600 themes before deploying changes to your site. What’s more, you can speed your search with filters for subject, features, and layout.</p>



<h3>Better Menu Instructions = Less Confusion</h3>



<p>Were you confused by the steps to create a new menu? Perhaps no longer! We’ve ironed out the UX for a smoother menu creation process. Newly updated copy will guide you.</p>



<hr class=\"wp-block-separator\" />



<h2>Lend a Hand with Gutenberg 🤝</h2>



<img src=\"https://i2.wp.com/wordpress.org/news/files/2017/11/gutenberg-1.png?w=632&ssl=1\" alt=\"\" />



<p>WordPress is working on a new way to create and control your content and we’d love to have your help. Interested in being an <a href=\"https://wordpress.org/plugins/gutenberg/\">early tester</a> or getting involved with the Gutenberg project? <a href=\"https://github.com/WordPress/gutenberg\">Contribute on GitHub</a>.</p>



<p>(PS: this post was written in Gutenberg!)</p>



<hr class=\"wp-block-separator\" />



<h2>Developer Happiness 😊</h2>



<h3><a href=\"https://make.wordpress.org/core/2017/11/01/improvements-to-the-customize-js-api-in-4-9/\">Customizer JS API Improvements</a></h3>



<p>We’ve made numerous improvements to the Customizer JS API in WordPress 4.9, eliminating many pain points. (Hello, default parameters for constructs! Goodbye repeated ID for constructs!) There are also new base control templates, a date/time control, and section/panel/global notifications to name a few. <a href=\"https://make.wordpress.org/core/2017/11/01/improvements-to-the-customize-js-api-in-4-9/\">Check out the full list.</a></p>



<h3><a href=\"https://make.wordpress.org/core/2017/10/22/code-editing-improvements-in-wordpress-4-9/\">CodeMirror available for use in your themes and plugins</a></h3>



<p>We’ve introduced a new code editing library, CodeMirror, for use within core. CodeMirror allows for syntax highlighting, error checking, and validation when creating code writing or editing experiences within your plugins, like CSS or JavaScript include fields.</p>



<h3><a href=\"https://make.wordpress.org/core/2017/10/30/mediaelement-upgrades-in-wordpress-4-9/\">MediaElement.js upgraded to 4.2.6</a></h3>



<p>WordPress 4.9 includes an upgraded version of MediaElement.js, which removes dependencies on jQuery, improves accessibility, modernizes the UI, and fixes many bugs.</p>



<h3><a href=\"https://make.wordpress.org/core/2017/10/15/improvements-for-roles-and-capabilities-in-4-9/\">Roles and Capabilities Improvements</a></h3>



<p>New capabilities have been introduced that allow granular management of plugins and translation files. In addition, the site switching process in multisite has been fine-tuned to update the available roles and capabilities in a more reliable and coherent way.</p>



<hr class=\"wp-block-separator\" />



<h2>The Squad</h2>



<p>This release was led by <a href=\"https://choycedesign.com/\">Mel Choyce</a> and <a href=\"https://weston.ruter.net/\">Weston Ruter</a>, with the help of the following fabulous folks. There are 443 contributors with props in this release, with 185 of them contributing for the first time. Pull up some Billy Tipton on your music service of choice, and check out some of their profiles:</p>



<a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abrightclearweb\">abrightclearweb</a>, <a href=\"https://profiles.wordpress.org/ibachal\">Achal Jain</a>, <a href=\"https://profiles.wordpress.org/achbed\">achbed</a>, <a href=\"https://profiles.wordpress.org/acmethemes\">Acme Themes</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/adammacias\">adammacias</a>, <a href=\"https://profiles.wordpress.org/mrahmadawais\">Ahmad Awais</a>, <a href=\"https://profiles.wordpress.org/ahmadawais\">ahmadawais</a>, <a href=\"https://profiles.wordpress.org/airesvsg\">airesvsg</a>, <a href=\"https://profiles.wordpress.org/ajoah\">ajoah</a>, <a href=\"https://profiles.wordpress.org/akibjorklund\">Aki Bj&#246;rklund</a>, <a href=\"https://profiles.wordpress.org/akshayvinchurkar\">akshayvinchurkar</a>, <a href=\"https://profiles.wordpress.org/schlessera\">Alain Schlesser</a>, <a href=\"https://profiles.wordpress.org/xknown\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/xavortm\">Alex Dimitrov</a>, <a href=\"https://profiles.wordpress.org/ironpaperweight\">Alex Hon</a>, <a href=\"https://profiles.wordpress.org/alex27\">alex27</a>, <a href=\"https://profiles.wordpress.org/allancole\">allancole</a>, <a href=\"https://profiles.wordpress.org/arush\">Amanda Rush</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andrewp-2\">Andreas Panag</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst\">Andrey \"Rarst\" Savchenko</a>, <a href=\"https://profiles.wordpress.org/andizer\">Andy Meerwaldt</a>, <a href=\"https://profiles.wordpress.org/kelderic\">Andy Mercer</a>, <a href=\"https://profiles.wordpress.org/andy\">Andy Skelton</a>, <a href=\"https://profiles.wordpress.org/aniketpant\">Aniket Pant</a>, <a href=\"https://profiles.wordpress.org/anilbasnet\">Anil Basnet</a>, <a href=\"https://profiles.wordpress.org/ankit-k-gupta\">Ankit K Gupta</a>, <a href=\"https://profiles.wordpress.org/ahortin\">Anthony Hortin</a>, <a href=\"https://profiles.wordpress.org/antisilent\">antisilent</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/apokalyptik\">apokalyptik</a>, <a href=\"https://profiles.wordpress.org/artoliukkonen\">artoliukkonen</a>, <a href=\"https://profiles.wordpress.org/ideag\">Arunas Liuiza</a>, <a href=\"https://profiles.wordpress.org/attitude\">attitude</a>, <a href=\"https://profiles.wordpress.org/backermann\">backermann</a>, <a href=\"https://profiles.wordpress.org/b-07\">Bappi</a>, <a href=\"https://profiles.wordpress.org/bcole808\">Ben Cole</a>, <a href=\"https://profiles.wordpress.org/quasel\">Bernhard Gronau</a>, <a href=\"https://profiles.wordpress.org/kau-boy\">Bernhard Kau</a>, <a href=\"https://profiles.wordpress.org/binarymoon\">binarymoon</a>, <a href=\"https://profiles.wordpress.org/birgire\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/bjornw\">BjornW</a>, <a href=\"https://profiles.wordpress.org/bobbingwide\">bobbingwide</a>, <a href=\"https://profiles.wordpress.org/boblinthorst\">boblinthorst</a>, <a href=\"https://profiles.wordpress.org/boboudreau\">boboudreau</a>, <a href=\"https://profiles.wordpress.org/gitlost\">bonger</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone B. Gorges</a>, <a href=\"https://profiles.wordpress.org/bradyvercher\">Brady Vercher</a>, <a href=\"https://profiles.wordpress.org/brainstormforce\">Brainstorm Force</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/brianhogg\">Brian Hogg</a>, <a href=\"https://profiles.wordpress.org/krogsgard\">Brian Krogsgard</a>, <a href=\"https://profiles.wordpress.org/bronsonquick\">Bronson Quick</a>, <a href=\"https://profiles.wordpress.org/sixhours\">Caroline Moore</a>, <a href=\"https://profiles.wordpress.org/caseypatrickdriscoll\">Casey Driscoll</a>, <a href=\"https://profiles.wordpress.org/caspie\">Caspie</a>, <a href=\"https://profiles.wordpress.org/chandrapatel\">Chandra Patel</a>, <a href=\"https://profiles.wordpress.org/chaos-engine\">Chaos Engine</a>, <a href=\"https://profiles.wordpress.org/cheeserolls\">cheeserolls</a>, <a href=\"https://profiles.wordpress.org/chesio\">chesio</a>, <a href=\"https://profiles.wordpress.org/ketuchetan\">chetansatasiya</a>, <a href=\"https://profiles.wordpress.org/choongsavvii\">choong</a>, <a href=\"https://profiles.wordpress.org/chouby\">Chouby</a>, <a href=\"https://profiles.wordpress.org/chredd\">chredd</a>, <a href=\"https://profiles.wordpress.org/chrisjean\">Chris Jean</a>, <a href=\"https://profiles.wordpress.org/cmmarslender\">Chris Marslender</a>, <a href=\"https://profiles.wordpress.org/chris_d2d\">Chris Smith</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/chriswiegman\">Chris Wiegman</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">chriscct7</a>, <a href=\"https://profiles.wordpress.org/chriseverson\">chriseverson</a>, <a href=\"https://profiles.wordpress.org/christian1012\">Christian Chung</a>, <a href=\"https://profiles.wordpress.org/cwpnolen\">Christian Nolen</a>, <a href=\"https://profiles.wordpress.org/needle\">Christian Wach</a>, <a href=\"https://profiles.wordpress.org/christophherr\">Christoph Herr</a>, <a href=\"https://profiles.wordpress.org/clarionwpdeveloper\">Clarion Technologies</a>, <a href=\"https://profiles.wordpress.org/claudiosmweb\">Claudio Sanches</a>, <a href=\"https://profiles.wordpress.org/claudiosanches\">Claudio Sanches</a>, <a href=\"https://profiles.wordpress.org/claudiolabarbera\">ClaudioLaBarbera</a>, <a href=\"https://profiles.wordpress.org/codemovementpk\">codemovement.pk</a>, <a href=\"https://profiles.wordpress.org/coderkevin\">coderkevin</a>, <a href=\"https://profiles.wordpress.org/codfish\">codfish</a>, <a href=\"https://profiles.wordpress.org/coreymcollins\">coreymcollins</a>, <a href=\"https://profiles.wordpress.org/curdin\">Curdin Krummenacher</a>, <a href=\"https://profiles.wordpress.org/cgrymala\">Curtiss Grymala</a>, <a href=\"https://profiles.wordpress.org/cdog\">Cătălin Dogaru</a>, <a href=\"https://profiles.wordpress.org/danhgilmore\">danhgilmore</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber\">Daniel Bachhuber </a>, <a href=\"https://profiles.wordpress.org/danielkanchev\">Daniel Kanchev</a>, <a href=\"https://profiles.wordpress.org/danielpietrasik\">Daniel Pietrasik</a>, <a href=\"https://profiles.wordpress.org/mte90\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/dllh\">Daryl L. L. Houston (dllh)</a>, <a href=\"https://profiles.wordpress.org/davepullig\">Dave Pullig</a>, <a href=\"https://profiles.wordpress.org/goto10\">Dave Romsey (goto10)</a>, <a href=\"https://profiles.wordpress.org/davidakennedy\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/turtlepod\">David Chandra Purnama</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dglingren\">David Lingren</a>, <a href=\"https://profiles.wordpress.org/davidmosterd\">David Mosterd</a>, <a href=\"https://profiles.wordpress.org/dshanske\">David Shanske</a>, <a href=\"https://profiles.wordpress.org/davidbhayes\">davidbhayes</a>, <a href=\"https://profiles.wordpress.org/folletto\">Davide \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/deeptiboddapati\">deeptiboddapati</a>, <a href=\"https://profiles.wordpress.org/delphinus\">delphinus</a>, <a href=\"https://profiles.wordpress.org/deltafactory\">deltafactory</a>, <a href=\"https://profiles.wordpress.org/denis-de-bernardy\">Denis de Bernardy</a>, <a href=\"https://profiles.wordpress.org/valendesigns\">Derek Herman</a>, <a href=\"https://profiles.wordpress.org/pcfreak30\">Derrick Hammer</a>, <a href=\"https://profiles.wordpress.org/derrickkoo\">Derrick Koo</a>, <a href=\"https://profiles.wordpress.org/dimchik\">dimchik</a>, <a href=\"https://profiles.wordpress.org/dineshc\">Dinesh Chouhan</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dipeshkakadiya\">dipeshkakadiya</a>, <a href=\"https://profiles.wordpress.org/dmsnell\">dmsnell</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/dotancohen\">Dotan Cohen</a>, <a href=\"https://profiles.wordpress.org/dougwollison\">Doug Wollison</a>, <a href=\"https://profiles.wordpress.org/doughamlin\">doughamlin</a>, <a href=\"https://profiles.wordpress.org/dreamon11\">DreamOn11</a>, <a href=\"https://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/duncanjbrown\">duncanjbrown</a>, <a href=\"https://profiles.wordpress.org/dungengronovius\">dungengronovius</a>, <a href=\"https://profiles.wordpress.org/dylanauty\">DylanAuty</a>, <a href=\"https://profiles.wordpress.org/hurtige\">Eddie Hurtig</a>, <a href=\"https://profiles.wordpress.org/oso96_2000\">Eduardo Reveles</a>, <a href=\"https://profiles.wordpress.org/chopinbach\">Edwin Cromley</a>, <a href=\"https://profiles.wordpress.org/electricfeet\">ElectricFeet</a>, <a href=\"https://profiles.wordpress.org/eliorivero\">Elio Rivero</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/elyobo\">elyobo</a>, <a href=\"https://profiles.wordpress.org/enodekciw\">enodekciw</a>, <a href=\"https://profiles.wordpress.org/enshrined\">enshrined</a>, <a href=\"https://profiles.wordpress.org/ericlewis\">Eric Andrew Lewis</a>, <a href=\"https://profiles.wordpress.org/pushred\">Eric Lanehart</a>, <a href=\"https://profiles.wordpress.org/eherman24\">Evan Herman</a>, <a href=\"https://profiles.wordpress.org/flixos90\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/fencer04\">Fencer04</a>, <a href=\"https://profiles.wordpress.org/florianbrinkmann\">Florian Brinkmann</a>, <a href=\"https://profiles.wordpress.org/mista-flo\">Florian TIAR</a>, <a href=\"https://profiles.wordpress.org/foliovision\">FolioVision</a>, <a href=\"https://profiles.wordpress.org/fomenkoandrey\">fomenkoandrey</a>, <a href=\"https://profiles.wordpress.org/frank-klein\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/frankiet\">Frankie</a>, <a href=\"https://profiles.wordpress.org/fjarrett\">Frankie Jarrett</a>, <a href=\"https://profiles.wordpress.org/akeif\">Fred</a>, <a href=\"https://profiles.wordpress.org/frozzare\">Fredrik Forsmo</a>, <a href=\"https://profiles.wordpress.org/fuscata\">fuscata</a>, <a href=\"https://profiles.wordpress.org/gma992\">Gabriel Maldonado</a>, <a href=\"https://profiles.wordpress.org/voldemortensen\">Garth Mortensen</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/geekysoft\">Geeky Software</a>, <a href=\"https://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/goranseric\">Goran &#352;erić</a>, <a href=\"https://profiles.wordpress.org/grahamarmfield\">Graham Armfield</a>, <a href=\"https://profiles.wordpress.org/grantderepas\">Grant Derepas</a>, <a href=\"https://profiles.wordpress.org/tivnet\">Gregory Karpinsky (@tivnet)</a>, <a href=\"https://profiles.wordpress.org/hardeepasrani\">Hardeep Asrani</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/henrywright\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/hiddenpearls\">hiddenpearls</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/hristo-sg\">Hristo Pandjarov</a>, <a href=\"https://profiles.wordpress.org/hugobaeta\">Hugo Baeta</a>, <a href=\"https://profiles.wordpress.org/polevaultweb\">Iain Poulson</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianedington\">Ian Edington</a>, <a href=\"https://profiles.wordpress.org/idealien\">idealien</a>, <a href=\"https://profiles.wordpress.org/igmoweb\">Ignacio Cruz Moreno</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/implenton\">implenton</a>, <a href=\"https://profiles.wordpress.org/ionutst\">Ionut Stanciu</a>, <a href=\"https://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/ivdimova\">ivdimova</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jakept\">Jacob Peattie</a>, <a href=\"https://profiles.wordpress.org/whyisjake\">Jake Spurlock</a>, <a href=\"https://profiles.wordpress.org/jnylen0\">James Nylen</a>, <a href=\"https://profiles.wordpress.org/jamesacero\">jamesacero</a>, <a href=\"https://profiles.wordpress.org/japh\">Japh</a>, <a href=\"https://profiles.wordpress.org/jaredcobb\">Jared Cobb</a>, <a href=\"https://profiles.wordpress.org/jayarjo\">jayarjo</a>, <a href=\"https://profiles.wordpress.org/jdolan\">jdolan</a>, <a href=\"https://profiles.wordpress.org/jdoubleu\">jdoubleu</a>, <a href=\"https://profiles.wordpress.org/jblz\">Jeff Bowen</a>, <a href=\"https://profiles.wordpress.org/jbpaul17\">Jeff Paul</a>, <a href=\"https://profiles.wordpress.org/cheffheid\">Jeffrey de Wit</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jpry\">Jeremy Pry</a>, <a href=\"https://profiles.wordpress.org/jimt\">jimt</a>, <a href=\"https://profiles.wordpress.org/jipmoors\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/jmusal\">jmusal</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joehoyle\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joelcj91\">Joel James</a>, <a href=\"https://profiles.wordpress.org/johanmynhardt\">johanmynhardt</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/zyphonic\">John Dittmar</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/johnpbloch\">John P. Bloch</a>, <a href=\"https://profiles.wordpress.org/johnregan3\">John Regan</a>, <a href=\"https://profiles.wordpress.org/johnpgreen\">johnpgreen</a>, <a href=\"https://profiles.wordpress.org/kenshino\">Jon (Kenshino)</a>, <a href=\"https://profiles.wordpress.org/jonathanbardo\">Jonathan Bardo</a>, <a href=\"https://profiles.wordpress.org/jbrinley\">Jonathan Brinley</a>, <a href=\"https://profiles.wordpress.org/daggerhart\">Jonathan Daggerhart</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jonnyauk\">jonnyauk</a>, <a href=\"https://profiles.wordpress.org/jordesign\">jordesign</a>, <a href=\"https://profiles.wordpress.org/jorritschippers\">JorritSchippers</a>, <a href=\"https://profiles.wordpress.org/joefusco\">Joseph Fusco</a>, <a href=\"https://profiles.wordpress.org/jjeaton\">Josh Eaton</a>, <a href=\"https://profiles.wordpress.org/shelob9\">Josh Pollock</a>, <a href=\"https://profiles.wordpress.org/joshcummingsdesign\">joshcummingsdesign</a>, <a href=\"https://profiles.wordpress.org/joshkadis\">joshkadis</a>, <a href=\"https://profiles.wordpress.org/joyously\">Joy</a>, <a href=\"https://profiles.wordpress.org/jrf\">jrf</a>, <a href=\"https://profiles.wordpress.org/jrgould\">JRGould</a>, <a href=\"https://profiles.wordpress.org/juanfra\">Juanfra Aldasoro</a>, <a href=\"https://profiles.wordpress.org/juhise\">Juhi Saxena</a>, <a href=\"https://profiles.wordpress.org/nukaga\">Junko Nukaga</a>, <a href=\"https://profiles.wordpress.org/justinbusa\">Justin Busa</a>, <a href=\"https://profiles.wordpress.org/justinsainton\">Justin Sainton</a>, <a href=\"https://profiles.wordpress.org/jshreve\">Justin Shreve</a>, <a href=\"https://profiles.wordpress.org/jtsternberg\">Justin Sternberg</a>, <a href=\"https://profiles.wordpress.org/kadamwhite\">K.Adam White</a>, <a href=\"https://profiles.wordpress.org/kacperszurek\">kacperszurek</a>, <a href=\"https://profiles.wordpress.org/trepmal\">Kailey (trepmal)</a>, <a href=\"https://profiles.wordpress.org/kalenjohnson\">KalenJohnson</a>, <a href=\"https://profiles.wordpress.org/codebykat\">Kat Hagan</a>, <a href=\"https://profiles.wordpress.org/kkoppenhaver\">Keanan Koppenhaver</a>, <a href=\"https://profiles.wordpress.org/keesiemeijer\">keesiemeijer</a>, <a href=\"https://profiles.wordpress.org/kellbot\">kellbot</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/khag7\">Kevin Hagerty</a>, <a href=\"https://profiles.wordpress.org/kwight\">Kirk Wight</a>, <a href=\"https://profiles.wordpress.org/kitchin\">kitchin</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjbenk\">kjbenk</a>, <a href=\"https://profiles.wordpress.org/knutsp\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/koenschipper\">koenschipper</a>, <a href=\"https://profiles.wordpress.org/kokarn\">kokarn</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/kouratoras\">Konstantinos Kouratoras</a>, <a href=\"https://profiles.wordpress.org/kuchenundkakao\">kuchenundkakao</a>, <a href=\"https://profiles.wordpress.org/kuldipem\">kuldipem</a>, <a href=\"https://profiles.wordpress.org/laurelfulford\">Laurel Fulford</a>, <a href=\"https://profiles.wordpress.org/leewillis77\">Lee Willis</a>, <a href=\"https://profiles.wordpress.org/leobaiano\">Leo Baiano</a>, <a href=\"https://profiles.wordpress.org/littlebigthing\">LittleBigThings (Csaba)</a>, <a href=\"https://profiles.wordpress.org/lucasstark\">Lucas Stark</a>, <a href=\"https://profiles.wordpress.org/lukecavanagh\">Luke Cavanagh</a>, <a href=\"https://profiles.wordpress.org/lgedeon\">Luke Gedeon</a>, <a href=\"https://profiles.wordpress.org/lukepettway\">Luke Pettway</a>, <a href=\"https://profiles.wordpress.org/lyubomir_popov\">lyubomir_popov</a>, <a href=\"https://profiles.wordpress.org/mariovalney\">M&#225;rio Valney</a>, <a href=\"https://profiles.wordpress.org/mageshp\">mageshp</a>, <a href=\"https://profiles.wordpress.org/mahesh901122\">Mahesh Waghmare</a>, <a href=\"https://profiles.wordpress.org/mangeshp\">Mangesh Parte</a>, <a href=\"https://profiles.wordpress.org/manishsongirkar36\">Manish Songirkar</a>, <a href=\"https://profiles.wordpress.org/mantismamita\">mantismamita</a>, <a href=\"https://profiles.wordpress.org/mbootsman\">Marcel Bootsman</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mbelchev\">Mariyan Belchev</a>, <a href=\"https://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/mrwweb\">Mark Root-Wiley</a>, <a href=\"https://profiles.wordpress.org/mapk\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/markoheijnen\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/markshep\">markshep</a>, <a href=\"https://profiles.wordpress.org/matrixik\">matrixik</a>, <a href=\"https://profiles.wordpress.org/mjbanks\">Matt Banks</a>, <a href=\"https://profiles.wordpress.org/mattking5000\">Matt King</a>, <a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/jaworskimatt\">Matt PeepSo</a>, <a href=\"https://profiles.wordpress.org/veraxus\">Matt van Andel</a>, <a href=\"https://profiles.wordpress.org/mattwiebe\">Matt Wiebe</a>, <a href=\"https://profiles.wordpress.org/mattheu\">Matthew Haines-Young</a>, <a href=\"https://profiles.wordpress.org/mattyrob\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/maxcutler\">Max Cutler</a>, <a href=\"https://profiles.wordpress.org/maximeculea\">Maxime Culea</a>, <a href=\"https://profiles.wordpress.org/mayukojpn\">Mayo Moriyama</a>, <a href=\"https://profiles.wordpress.org/mckernanin\">mckernanin</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/mhowell\">mhowell</a>, <a href=\"https://profiles.wordpress.org/michaelarestad\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/michael-arestad\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/michalzuber\">michalzuber</a>, <a href=\"https://profiles.wordpress.org/stubgo\">Miina Sikk</a>, <a href=\"https://profiles.wordpress.org/mauteri\">Mike Auteri</a>, <a href=\"https://profiles.wordpress.org/mihai2u\">Mike Crantea</a>, <a href=\"https://profiles.wordpress.org/mdgl\">Mike Glendinning</a>, <a href=\"https://profiles.wordpress.org/mikehansenme\">Mike Hansen</a>, <a href=\"https://profiles.wordpress.org/mikelittle\">Mike Little</a>, <a href=\"https://profiles.wordpress.org/mikeschroder\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikeviele\">Mike Viele</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/modemlooper\">modemlooper</a>, <a href=\"https://profiles.wordpress.org/batmoo\">Mohammad Jangda</a>, <a href=\"https://profiles.wordpress.org/deremohan\">Mohan Dere</a>, <a href=\"https://profiles.wordpress.org/monikarao\">Monika Rao</a>, <a href=\"https://profiles.wordpress.org/morettigeorgiev\">morettigeorgiev</a>, <a href=\"https://profiles.wordpress.org/morganestes\">Morgan Estes</a>, <a href=\"https://profiles.wordpress.org/mor10\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/mt8biz\">moto hachi ( mt8.biz )</a>, <a href=\"https://profiles.wordpress.org/mrbobbybryant\">mrbobbybryant</a>, <a href=\"https://profiles.wordpress.org/nnaimov\">Naim Naimov</a>, <a href=\"https://profiles.wordpress.org/natereist\">Nate Reist</a>, <a href=\"https://profiles.wordpress.org/natewr\">NateWr</a>, <a href=\"https://profiles.wordpress.org/nathanrice\">nathanrice</a>, <a href=\"https://profiles.wordpress.org/nazgul\">Nazgul</a>, <a href=\"https://profiles.wordpress.org/greatislander\">Ned Zimmerman</a>, <a href=\"https://profiles.wordpress.org/krstarica\">net</a>, <a href=\"https://profiles.wordpress.org/celloexpressions\">Nick Halsey </a>, <a href=\"https://profiles.wordpress.org/nikeo\">Nicolas GUILLAUME</a>, <a href=\"https://profiles.wordpress.org/nikschavan\">Nikhil Chavan</a>, <a href=\"https://profiles.wordpress.org/nikv\">Nikhil Vimal</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/rabmalin\">Nilambar Sharma</a>, <a href=\"https://profiles.wordpress.org/noplanman\">noplanman</a>, <a href=\"https://profiles.wordpress.org/nullvariable\">nullvariable</a>, <a href=\"https://profiles.wordpress.org/odie2\">odie2</a>, <a href=\"https://profiles.wordpress.org/odysseygate\">odyssey</a>, <a href=\"https://profiles.wordpress.org/hideokamoto\">Okamoto Hidetaka</a>, <a href=\"https://profiles.wordpress.org/orvils\">orvils</a>, <a href=\"https://profiles.wordpress.org/oskosk\">oskosk</a>, <a href=\"https://profiles.wordpress.org/ottok\">Otto Kek&#228;l&#228;inen</a>, <a href=\"https://profiles.wordpress.org/ovann86\">ovann86</a>, <a href=\"https://profiles.wordpress.org/imnok\">Pantip Treerattanapitak (Nok)</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/patilvikasj\">patilvikasj</a>, <a href=\"https://profiles.wordpress.org/pbearne\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/paulwilde\">Paul Wilde</a>, <a href=\"https://profiles.wordpress.org/sirbrillig\">Payton Swick</a>, <a href=\"https://profiles.wordpress.org/pdufour\">pdufour</a>, <a href=\"https://profiles.wordpress.org/piewp\">Perdaan</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/phh\">phh</a>, <a href=\"https://profiles.wordpress.org/php\">php</a>, <a href=\"https://profiles.wordpress.org/delawski\">Piotr Delawski</a>, <a href=\"https://profiles.wordpress.org/pippinsplugins\">pippinsplugins</a>, <a href=\"https://profiles.wordpress.org/pjgalbraith\">pjgalbraith</a>, <a href=\"https://profiles.wordpress.org/pkevan\">pkevan</a>, <a href=\"https://profiles.wordpress.org/pratikchaskar\">Pratik</a>, <a href=\"https://profiles.wordpress.org/pressionate\">Pressionate</a>, <a href=\"https://profiles.wordpress.org/presskopp\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/procodewp\">procodewp</a>, <a href=\"https://profiles.wordpress.org/rachelbaker\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rahulsprajapati\">Rahul Prajapati</a>, <a href=\"https://profiles.wordpress.org/superpoincare\">Ramanan</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/ramiabraham\">ramiabraham</a>, <a href=\"https://profiles.wordpress.org/ranh\">ranh</a>, <a href=\"https://profiles.wordpress.org/redsand\">Red Sand Media Group</a>, <a href=\"https://profiles.wordpress.org/youknowriad\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/rianrietveld\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/iamfriendly\">Richard Tape</a>, <a href=\"https://profiles.wordpress.org/rpayne7264\">Robert D Payne</a>, <a href=\"https://profiles.wordpress.org/iamjolly\">Robert Jolly</a>, <a href=\"https://profiles.wordpress.org/rnoakes3rd\">Robert Noakes</a>, <a href=\"https://profiles.wordpress.org/d4z_c0nf\">Rocco Aliberti</a>, <a href=\"https://profiles.wordpress.org/rodrigosprimo\">Rodrigo Primo</a>, <a href=\"https://profiles.wordpress.org/rommelxcastro\">Rommel Castro</a>, <a href=\"https://profiles.wordpress.org/fronaldaraujo\">Ronald Ara&#250;jo</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, <a href=\"https://profiles.wordpress.org/guavaworks\">Roy Sivan</a>, <a href=\"https://profiles.wordpress.org/ryankienstra\">Ryan Kienstra</a>, <a href=\"https://profiles.wordpress.org/rmccue\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/ryanplas\">Ryan Plas</a>, <a href=\"https://profiles.wordpress.org/welcher\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/salcode\">Sal Ferrarello</a>, <a href=\"https://profiles.wordpress.org/samikeijonen\">Sami Keijonen</a>, <a href=\"https://profiles.wordpress.org/solarissmoke\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/samuelsidler\">Samuel Sidler</a>, <a href=\"https://profiles.wordpress.org/sandesh055\">Sandesh</a>, <a href=\"https://profiles.wordpress.org/smyoon315\">Sang-Min Yoon</a>, <a href=\"https://profiles.wordpress.org/sanketparmar\">Sanket Parmar</a>, <a href=\"https://profiles.wordpress.org/pollyplummer\">Sarah Gooding</a>, <a href=\"https://profiles.wordpress.org/sayedwp\">Sayed Taqui</a>, <a href=\"https://profiles.wordpress.org/schrapel\">schrapel</a>, <a href=\"https://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scrappyhuborg\">scrappy@hub.org</a>, <a href=\"https://profiles.wordpress.org/scribu\">scribu</a>, <a href=\"https://profiles.wordpress.org/seancjones\">seancjones</a>, <a href=\"https://profiles.wordpress.org/sebastianpisula\">Sebastian Pisula</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sgr33n\">Sergio De Falco</a>, <a href=\"https://profiles.wordpress.org/sfpt\">sfpt</a>, <a href=\"https://profiles.wordpress.org/shayanys\">shayanys</a>, <a href=\"https://profiles.wordpress.org/shazahm1hotmailcom\">shazahm1</a>, <a href=\"https://profiles.wordpress.org/shprink\">shprink</a>, <a href=\"https://profiles.wordpress.org/simonlampen\">simonlampen</a>, <a href=\"https://profiles.wordpress.org/skippy\">skippy</a>, <a href=\"https://profiles.wordpress.org/smerriman\">smerriman</a>, <a href=\"https://profiles.wordpress.org/snacking\">snacking</a>, <a href=\"https://profiles.wordpress.org/solal\">solal</a>, <a href=\"https://profiles.wordpress.org/soean\">Soren Wrede</a>, <a href=\"https://profiles.wordpress.org/sstoqnov\">Stanimir Stoyanov</a>, <a href=\"https://profiles.wordpress.org/metodiew\">Stanko Metodiev</a>, <a href=\"https://profiles.wordpress.org/sharkomatic\">Steph</a>, <a href=\"https://profiles.wordpress.org/sswells\">Steph Wells</a>, <a href=\"https://profiles.wordpress.org/sillybean\">Stephanie Leary</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stephenharris\">Stephen Harris</a>, <a href=\"https://profiles.wordpress.org/stevenkword\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/stevenlinx\">stevenlinx</a>, <a href=\"https://profiles.wordpress.org/sudar\">Sudar Muthu</a>, <a href=\"https://profiles.wordpress.org/patilswapnilv\">Swapnil V. Patil</a>, <a href=\"https://profiles.wordpress.org/swapnild\">swapnild</a>, <a href=\"https://profiles.wordpress.org/szaqal21\">szaqal21</a>, <a href=\"https://profiles.wordpress.org/takahashi_fumiki\">Takahashi Fumiki</a>, <a href=\"https://profiles.wordpress.org/miyauchi\">Takayuki Miyauchi</a>, <a href=\"https://profiles.wordpress.org/karmatosed\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/tapsboy\">tapsboy</a>, <a href=\"https://profiles.wordpress.org/tlovett1\">Taylor Lovett</a>, <a href=\"https://profiles.wordpress.org/team\">team</a>, <a href=\"https://profiles.wordpress.org/tg29359\">tg29359</a>, <a href=\"https://profiles.wordpress.org/tharsheblows\">tharsheblows</a>, <a href=\"https://profiles.wordpress.org/the\">the</a>, <a href=\"https://profiles.wordpress.org/themeshaper\">themeshaper</a>, <a href=\"https://profiles.wordpress.org/thenbrent\">thenbrent</a>, <a href=\"https://profiles.wordpress.org/thomaswm\">thomaswm</a>, <a href=\"https://profiles.wordpress.org/tfrommen\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/tierra\">tierra</a>, <a href=\"https://profiles.wordpress.org/tnash\">Tim Nash</a>, <a href=\"https://profiles.wordpress.org/timmydcrawford\">Timmy Crawford</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timph\">timph</a>, <a href=\"https://profiles.wordpress.org/tkama\">Tkama</a>, <a href=\"https://profiles.wordpress.org/tnegri\">tnegri</a>, <a href=\"https://profiles.wordpress.org/tomauger\">Tom Auger</a>, <a href=\"https://profiles.wordpress.org/tjnowell\">Tom J Nowell</a>, <a href=\"https://profiles.wordpress.org/tomdxw\">tomdxw</a>, <a href=\"https://profiles.wordpress.org/toro_unit\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/zodiac1978\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/transl8or\">transl8or</a>, <a href=\"https://profiles.wordpress.org/traversal\">traversal</a>, <a href=\"https://profiles.wordpress.org/wpsmith\">Travis Smith</a>, <a href=\"https://profiles.wordpress.org/nmt90\">Triet Minh</a>, <a href=\"https://profiles.wordpress.org/trishasalas\">Trisha Salas</a>, <a href=\"https://profiles.wordpress.org/tristangemus\">tristangemus</a>, <a href=\"https://profiles.wordpress.org/truongwp\">truongwp</a>, <a href=\"https://profiles.wordpress.org/tsl143\">tsl143</a>, <a href=\"https://profiles.wordpress.org/tywayne\">Ty Carlson</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/utkarshpatel\">Utkarsh</a>, <a href=\"https://profiles.wordpress.org/valeriutihai\">Valeriu Tihai</a>, <a href=\"https://profiles.wordpress.org/zuige\">Viljami Kuosmanen</a>, <a href=\"https://profiles.wordpress.org/vishalkakadiya\">Vishal Kakadiya</a>, <a href=\"https://profiles.wordpress.org/vortfu\">vortfu</a>, <a href=\"https://profiles.wordpress.org/vrundakansara-1\">Vrunda Kansara</a>, <a href=\"https://profiles.wordpress.org/webbgaraget\">webbgaraget</a>, <a href=\"https://profiles.wordpress.org/webmandesign\">WebMan Design &#124; Oliver Juhas</a>, <a href=\"https://profiles.wordpress.org/websupporter\">websupporter</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/williampatton\">williampatton</a>, <a href=\"https://profiles.wordpress.org/wolly\">Wolly aka Paolo Valenti</a>, <a href=\"https://profiles.wordpress.org/wraithkenny\">WraithKenny</a>, <a href=\"https://profiles.wordpress.org/yale01\">yale01</a>, <a href=\"https://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/yogasukma\">Yoga Sukma</a>, <a href=\"https://profiles.wordpress.org/oxymoron\">Zach Wills</a>, <a href=\"https://profiles.wordpress.org/tollmanz\">Zack Tollman</a>, <a href=\"https://profiles.wordpress.org/vanillalounge\">Ze Fontainhas</a>, <a href=\"https://profiles.wordpress.org/zhildzik\">zhildzik</a>, and <a href=\"https://profiles.wordpress.org/zsusag\">zsusag</a>.



<p>Finally, thanks to all the community translators who worked on WordPress 4.9. Their efforts bring WordPress 4.9 fully translated to 43 languages at release time, with more on the way.</p>



<p>Do you want to report on WordPress 4.9? <a href=\"https://s.w.org/images/core/4.9/wp-4-9_press-kit.zip\">We&#x27;ve compiled a press kit featuring information about the release features, and some media assets to help you along</a>.</p>



<p>If you want to follow along or help out, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/core/\">core development blog</a>.</p>



<p>Thanks for choosing WordPress!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Nov 2017 01:16:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Mel Choyce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:108:\"WPTavern: Gutenberg 1.7 Adds Multi-Block Transform Functionality, Drops iframes Implementation of Meta Boxes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=76552\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"https://wptavern.com/gutenberg-1-7-adds-multi-block-transform-functionality-drops-iframes-implementation-of-meta-boxes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4469:\"<p><a href=\"https://make.wordpress.org/core/2017/11/15/whats-new-in-gutenberg-15th-november/\" rel=\"noopener\" target=\"_blank\">Gutenberg 1.7</a> was released today, two weeks after version 1.6, with a fresh round of new features, design updates, and the groundwork for nested blocks and block extensibility.</p>
<p>Last week contributors began exploring <a href=\"https://wptavern.com/gutenberg-contributors-explore-alternative-to-using-iframes-for-meta-boxes\" rel=\"noopener\" target=\"_blank\">an alternative to using iframes for meta boxes</a>. This experiment has landed in 1.7 so that the plugin now <a href=\"https://github.com/WordPress/gutenberg/pull/3345\" rel=\"noopener\" target=\"_blank\">renders meta boxes inline</a>. Gutenberg engineer Riad Benguella, who wrote and merged the code, said that it doesn&#8217;t fix all the meta box issues and might create some new ones, but it &#8220;gets us closer to where we want to go.&#8221; Pre-rendering meta boxes and creating a migration path for existing ones is next on the agenda.</p>
<p>One of the most exciting new features in 1.7 is the <a href=\"https://github.com/WordPress/gutenberg/pull/3357\" rel=\"noopener\" target=\"_blank\">multi-block transform functionality</a> that allows users to select multiple blocks and instantly transform them into other block types. It works like a little bit of Gutenberg magic. By default, users can select multiple paragraphs and transform them into a list or select multiple images and transform them into a gallery.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-15-at-2.50.25-PM-e1510779367673.png?ssl=1\"><img /></a></p>
<p>After selecting two or more blocks, the user can click on the block&#8217;s settings in the toolbar to transform them. They can also be easily changed back to single blocks. The multi-block transform functionality has been added to the Blocks API so that developers can set isMultiBlock to true to specify blocks that can be transformed.</p>
<p><a href=\"https://i0.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-15-at-3.31.49-PM-e1510781927286.png?ssl=1\"><img /></a></p>
<p>Version 1.7 introduces a new toggle that the team is testing for <a href=\"https://github.com/WordPress/gutenberg/pull/3311\" rel=\"noopener\" target=\"_blank\">switching between the top fixed toolbar and the contextual toolbars attached to each block</a>. It provides an easy way for users to test both types of toolbar styles, but may be temporary as the pull request was submitted as a suggestion for an A/B test.</p>
<p><a href=\"https://i2.wp.com/wptavern.com/wp-content/uploads/2017/11/Screen-Shot-2017-11-15-at-4.03.38-PM.png?ssl=1\"><img /></a></p>
<p>Gutenberg 1.7 <a href=\"https://github.com/WordPress/gutenberg/pull/2743\" rel=\"noopener\" target=\"_blank\">paves the way for nested blocks</a> in the data structure. It also adds <a href=\"https://github.com/WordPress/gutenberg/pull/3318\" rel=\"noopener\" target=\"_blank\">hooks for block extensibility</a> and contributors are currently testing how these work internally.</p>
<p>A few other notable features in this release include the following:</p>
<ul>
<li>Added <a href=\"https://github.com/WordPress/gutenberg/pull/2896\" rel=\"noopener\" target=\"_blank\">@-mention autocomplete for users</a> in a site</li>
<li>Allow <a href=\"https://github.com/WordPress/gutenberg/pull/2792\" rel=\"noopener\" target=\"_blank\">pasting standalone images</a> and uploading them (also supports pasting base64 encoded images)</li>
<li>Full <a href=\"https://github.com/WordPress/gutenberg/pull/3401\" rel=\"noopener\" target=\"_blank\">design update to focus styles</a> around the UI</li>
<li>Placed <a href=\"https://github.com/WordPress/gutenberg/pull/3459\" rel=\"noopener\" target=\"_blank\">&#8220;table of contents&#8221; button in the header area</a>, disabled when there are no blocks in the content, added paragraph count</li>
</ul>
<p>Gutenberg&#8217;s documentation has also been <a href=\"https://github.com/WordPress/gutenberg/pull/3381\" rel=\"noopener\" target=\"_blank\">moved</a> to <a href=\"https://wordpress.org/gutenberg/handbook/\" rel=\"noopener\" target=\"_blank\">https://wordpress.org/gutenberg/handbook/</a>, signaling the project is getting closer to becoming part of WordPress. The new editor will be included in WordPress 5.0, which will ship when Gutenberg is ready. A notice in the 4.9 about.php page invites users to start testing the feature plugin ahead of its inclusion in core.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Nov 2017 23:57:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Post Status Interview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=47650\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"https://ma.tt/2017/11/post-status-interview/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:676:\"<p>In the lead-up <a href=\"https://2017.us.wordcamp.org/\">to WordCamp US</a> we&#x27;re in right now <a href=\"https://poststatus.com/interview-matt-mullenweg-wordpress-ecosystem-draft-podcast/\">I chatted with Brian Krogsgard at Post Status in an hour podcast</a> and we spoke about the core releases this year, Gutenberg, React, WooCommerce, and WordPress.org. On the 29th I&#x27;ll be <a href=\"https://wptavern.com/\">talking to WP Tavern</a>, so tune in then as well. For something completely different, I was on the <a href=\"https://offrcrd.com/episodes/matt-mullenweg/\">new OFF RCRD podcast with Cory Levy about the earliest days at Automattic and entrepreneurship</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Nov 2017 17:06:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Fri, 29 Dec 2017 17:44:32 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Fri, 29 Dec 2017 17:30:29 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20171220203310\";}", "no");
INSERT INTO `wp_options` VALUES("658", "_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9", "1514612672", "no");
INSERT INTO `wp_options` VALUES("659", "_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9", "1514569472", "no");
INSERT INTO `wp_options` VALUES("660", "_transient_timeout_dash_v2_1f6be06cc73fd52d187c194a61b83c35", "1514612672", "no");
INSERT INTO `wp_options` VALUES("661", "_transient_dash_v2_1f6be06cc73fd52d187c194a61b83c35", "<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://en-ca.wordpress.org/2017/04/18/wordcamp-coming-to-halifax-nova-scotia/\'>WordCamp Coming to Halifax, Nova Scotia!</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wptavern.com/wpweekly-episode-299-2017-year-in-review\'>WPTavern: WPWeekly Episode 299 – 2017 Year in Review</a></li><li><a class=\'rsswidget\' href=\'https://heropress.com/essays/journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai/#utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=journey-dyslexic-kid-becoming-co-organiser-wordcamp-mumbai\'>HeroPress: My Journey from being a Dyslexic kid to becoming A Co-organiser For WordCamp Mumbai</a></li><li><a class=\'rsswidget\' href=\'https://ma.tt/2017/12/norads-santa-tracker/\'>Matt: NORAD’s Santa Tracker</a></li></ul></div>", "no");
INSERT INTO `wp_options` VALUES("662", "_site_transient_timeout_available_translations", "1514580274", "no");
INSERT INTO `wp_options` VALUES("663", "_site_transient_available_translations", "a:111:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-01 13:40:41\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-27 09:27:02\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 06:19:36\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.1/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 09:53:15\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:5:\"4.8.4\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:7:\"Bengali\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.4/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-05 09:44:12\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-04 20:20:28\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-29 05:52:09\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 08:46:26\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-22 16:19:20\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-07 17:05:51\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-22 15:43:53\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/4.9.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-22 15:38:30\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 20:27:48\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 20:27:03\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-10 15:04:39\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 14:51:39\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-24 22:15:20\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 09:54:30\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-23 18:53:44\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 02:06:55\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 01:23:37\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 23:17:08\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-18 11:09:35\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.8.4\";s:7:\"updated\";s:19:\"2017-07-31 15:12:02\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.4/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"4.8.4\";s:7:\"updated\";s:19:\"2017-07-30 16:09:17\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.4/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-01 17:54:52\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-28 20:09:49\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 03:15:17\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 15:03:42\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-19 14:11:29\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:3:\"4.8\";s:7:\"updated\";s:19:\"2017-06-09 15:50:45\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 09:48:14\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-29 14:45:02\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 21:50:23\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-19 23:55:33\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 10:40:05\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 11:06:53\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-06 13:23:01\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-02 23:26:33\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 13:03:07\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-14 10:14:07\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-21 02:45:34\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-04-13 13:55:54\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-13 12:06:14\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-17 09:56:44\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 11:47:57\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-07 12:32:16\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 13:32:29\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.1/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-07 02:07:59\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-04 01:44:20\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:48:25\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 19:40:23\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-03-17 20:40:40\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.7/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:5:\"4.8.4\";s:7:\"updated\";s:19:\"2017-09-30 06:25:41\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.4/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-09 00:51:20\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-17 19:14:57\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-05 06:45:20\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-06 06:13:30\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-22 08:05:07\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-22 08:13:09\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/4.9.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-09-25 10:02:16\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.8.3/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-28 19:24:26\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-14 20:53:34\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-19 23:04:20\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-18 12:10:14\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/4.9.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-19 20:26:00\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-15 20:59:00\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-19 10:53:46\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-16 18:38:56\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-30 17:20:03\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 23:19:48\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-06 10:38:27\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-10-07 02:08:56\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.3/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-20 16:20:13\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:0:\"\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-05 09:23:39\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-11-02 17:05:02\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.8.3/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-07 09:26:23\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-28 12:41:50\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-15 10:43:28\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-02 09:46:12\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-11-17 22:20:52\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"4.9.1\";s:7:\"updated\";s:19:\"2017-12-09 02:29:44\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.1/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}", "no");
INSERT INTO `wp_options` VALUES("665", "_transient_timeout_settings_errors", "1514569619", "no");
INSERT INTO `wp_options` VALUES("666", "_transient_settings_errors", "a:1:{i:0;a:4:{s:7:\"setting\";s:7:\"general\";s:4:\"code\";s:16:\"settings_updated\";s:7:\"message\";s:15:\"Settings saved.\";s:4:\"type\";s:7:\"updated\";}}", "no");
INSERT INTO `wp_options` VALUES("667", "_site_transient_timeout_browser_f4b342427dc93e6e5fd5c14ef1fb74ec", "1515175877", "no");
INSERT INTO `wp_options` VALUES("668", "_site_transient_browser_f4b342427dc93e6e5fd5c14ef1fb74ec", "a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"57.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}", "no");
INSERT INTO `wp_options` VALUES("670", "_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a", "1514581952", "no");
INSERT INTO `wp_options` VALUES("671", "_site_transient_poptags_40cd750bba9870f18aada2478b24840a", "O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4416;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2524;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:2491;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2385;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1854;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1622;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1617;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1440;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1372;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1370;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1359;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1284;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1282;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1165;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1075;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1056;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1006;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:974;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:848;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:840;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:818;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:789;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:781;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:681;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:678;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:675;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:669;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:666;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:652;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:641;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:639;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:622;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:619;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:600;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:595;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:593;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:591;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:584;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:572;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:571;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:551;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:541;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:530;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:526;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:514;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:506;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:506;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:499;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:485;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:482;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:482;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:474;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:464;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:461;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:458;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:451;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:451;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:447;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:430;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:417;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:417;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:416;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:411;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:410;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:407;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:404;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:402;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:393;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:387;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:379;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:359;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:355;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:353;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:348;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:339;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:337;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:336;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:335;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:331;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:331;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:328;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:326;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:325;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:325;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:321;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:310;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:310;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:301;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:300;}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";i:300;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:298;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:295;}s:7:\"adsense\";a:3:{s:4:\"name\";s:7:\"adsense\";s:4:\"slug\";s:7:\"adsense\";s:5:\"count\";i:289;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:287;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:286;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:285;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:284;}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";i:282;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:281;}s:7:\"tinymce\";a:3:{s:4:\"name\";s:7:\"tinyMCE\";s:4:\"slug\";s:7:\"tinymce\";s:5:\"count\";i:280;}}", "no");
INSERT INTO `wp_options` VALUES("672", "_site_transient_timeout_theme_roots", "1514572954", "no");
INSERT INTO `wp_options` VALUES("673", "_site_transient_theme_roots", "a:9:{s:7:\"auberge\";s:7:\"/themes\";s:18:\"classtheme20140625\";s:7:\"/themes\";s:14:\"dark-shop-lite\";s:7:\"/themes\";s:15:\"dark_shop_child\";s:7:\"/themes\";s:4:\"dyad\";s:7:\"/themes\";s:7:\"masonic\";s:7:\"/themes\";s:13:\"masonic_child\";s:7:\"/themes\";s:10:\"storefront\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";}", "no");
INSERT INTO `wp_options` VALUES("674", "_transient_is_multi_author", "1", "yes");
INSERT INTO `wp_options` VALUES("677", "duplicator_settings", "a:10:{s:7:\"version\";s:6:\"1.2.30\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:20:\"storage_htaccess_off\";b:0;}", "yes");
INSERT INTO `wp_options` VALUES("678", "duplicator_version_plugin", "1.2.30", "yes");
INSERT INTO `wp_options` VALUES("679", "_site_transient_update_core", "O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/en_CA/wordpress-4.9.1.zip\";s:6:\"locale\";s:5:\"en_CA\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/en_CA/wordpress-4.9.1.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.9.1\";s:7:\"version\";s:5:\"4.9.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1514571318;s:15:\"version_checked\";s:5:\"4.9.1\";s:12:\"translations\";a:0:{}}", "no");
INSERT INTO `wp_options` VALUES("680", "_site_transient_update_plugins", "O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1514571309;s:7:\"checked\";a:16:{s:19:\"akismet/akismet.php\";s:5:\"4.0.2\";s:33:\"BootstrapMenus/BootStrapMenus.php\";s:3:\"1.0\";s:76:\"cloudinary-image-management-and-manipulation-in-the-cloud-cdn/cloudinary.php\";s:5:\"1.1.6\";s:23:\"CoffeeOrderer/index.php\";s:0:\"\";s:25:\"duplicator/duplicator.php\";s:6:\"1.2.30\";s:41:\"GitWordPressLayout/GitWordPressLayout.php\";s:3:\"1.0\";s:9:\"hello.php\";s:3:\"1.6\";s:19:\"jetpack/jetpack.php\";s:5:\"5.6.1\";s:29:\"MigratePages/MigratePages.php\";s:3:\"1.0\";s:47:\"one-click-child-theme/one-click-child-theme.php\";s:3:\"1.6\";s:25:\"profile-builder/index.php\";s:5:\"2.7.2\";s:41:\"sqlite-integration/sqlite-integration.php\";s:5:\"1.8.1\";s:25:\"testplugin/TestPlugin.php\";s:3:\"1.0\";s:33:\"unplug-jetpack/unplug-jetpack.php\";s:5:\"0.1.1\";s:19:\"weforms/weforms.php\";s:5:\"1.2.4\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.2.6\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:11:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.0.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.0.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:7:\"default\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";s:7:\"default\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:76:\"cloudinary-image-management-and-manipulation-in-the-cloud-cdn/cloudinary.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:75:\"w.org/plugins/cloudinary-image-management-and-manipulation-in-the-cloud-cdn\";s:4:\"slug\";s:61:\"cloudinary-image-management-and-manipulation-in-the-cloud-cdn\";s:6:\"plugin\";s:76:\"cloudinary-image-management-and-manipulation-in-the-cloud-cdn/cloudinary.php\";s:11:\"new_version\";s:5:\"1.1.6\";s:3:\"url\";s:92:\"https://wordpress.org/plugins/cloudinary-image-management-and-manipulation-in-the-cloud-cdn/\";s:7:\"package\";s:104:\"https://downloads.wordpress.org/plugin/cloudinary-image-management-and-manipulation-in-the-cloud-cdn.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:114:\"https://ps.w.org/cloudinary-image-management-and-manipulation-in-the-cloud-cdn/assets/icon-128x128.png?rev=1555615\";s:2:\"2x\";s:114:\"https://ps.w.org/cloudinary-image-management-and-manipulation-in-the-cloud-cdn/assets/icon-256x256.png?rev=1555615\";s:7:\"default\";s:114:\"https://ps.w.org/cloudinary-image-management-and-manipulation-in-the-cloud-cdn/assets/icon-256x256.png?rev=1555615\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:115:\"https://ps.w.org/cloudinary-image-management-and-manipulation-in-the-cloud-cdn/assets/banner-772x250.jpg?rev=677371\";s:7:\"default\";s:115:\"https://ps.w.org/cloudinary-image-management-and-manipulation-in-the-cloud-cdn/assets/banner-772x250.jpg?rev=677371\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:6:\"1.2.30\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/duplicator.1.2.30.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=1298463\";s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";s:7:\"default\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=1298463\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";s:7:\"default\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=1645055\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=969907\";s:2:\"2x\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";s:7:\"default\";s:63:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=969907\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";s:7:\"default\";s:65:\"https://ps.w.org/hello-dolly/assets/banner-772x250.png?rev=478342\";}s:11:\"banners_rtl\";a:0:{}}s:19:\"jetpack/jetpack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/jetpack\";s:4:\"slug\";s:7:\"jetpack\";s:6:\"plugin\";s:19:\"jetpack/jetpack.php\";s:11:\"new_version\";s:5:\"5.6.1\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/jetpack/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/jetpack.5.6.1.zip\";s:5:\"icons\";a:4:{s:2:\"1x\";s:60:\"https://ps.w.org/jetpack/assets/icon-128x128.png?rev=1791404\";s:2:\"2x\";s:60:\"https://ps.w.org/jetpack/assets/icon-256x256.png?rev=1791404\";s:3:\"svg\";s:52:\"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404\";s:7:\"default\";s:52:\"https://ps.w.org/jetpack/assets/icon.svg?rev=1791404\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:63:\"https://ps.w.org/jetpack/assets/banner-1544x500.png?rev=1791404\";s:2:\"1x\";s:62:\"https://ps.w.org/jetpack/assets/banner-772x250.png?rev=1791404\";s:7:\"default\";s:63:\"https://ps.w.org/jetpack/assets/banner-1544x500.png?rev=1791404\";}s:11:\"banners_rtl\";a:0:{}}s:47:\"one-click-child-theme/one-click-child-theme.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:35:\"w.org/plugins/one-click-child-theme\";s:4:\"slug\";s:21:\"one-click-child-theme\";s:6:\"plugin\";s:47:\"one-click-child-theme/one-click-child-theme.php\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/one-click-child-theme/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/one-click-child-theme.zip\";s:5:\"icons\";a:2:{s:3:\"svg\";s:66:\"https://ps.w.org/one-click-child-theme/assets/icon.svg?rev=1121861\";s:7:\"default\";s:66:\"https://ps.w.org/one-click-child-theme/assets/icon.svg?rev=1121861\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:77:\"https://ps.w.org/one-click-child-theme/assets/banner-1544x500.jpg?rev=1121868\";s:2:\"1x\";s:76:\"https://ps.w.org/one-click-child-theme/assets/banner-772x250.jpg?rev=1121868\";s:7:\"default\";s:77:\"https://ps.w.org/one-click-child-theme/assets/banner-1544x500.jpg?rev=1121868\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"profile-builder/index.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:29:\"w.org/plugins/profile-builder\";s:4:\"slug\";s:15:\"profile-builder\";s:6:\"plugin\";s:25:\"profile-builder/index.php\";s:11:\"new_version\";s:5:\"2.7.2\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/profile-builder/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/profile-builder.2.7.2.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:68:\"https://ps.w.org/profile-builder/assets/icon-128x128.png?rev=1470754\";s:2:\"2x\";s:68:\"https://ps.w.org/profile-builder/assets/icon-256x256.png?rev=1470754\";s:7:\"default\";s:68:\"https://ps.w.org/profile-builder/assets/icon-256x256.png?rev=1470754\";}s:7:\"banners\";a:2:{s:2:\"1x\";s:70:\"https://ps.w.org/profile-builder/assets/banner-772x250.png?rev=1471307\";s:7:\"default\";s:70:\"https://ps.w.org/profile-builder/assets/banner-772x250.png?rev=1471307\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"sqlite-integration/sqlite-integration.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/sqlite-integration\";s:4:\"slug\";s:18:\"sqlite-integration\";s:6:\"plugin\";s:41:\"sqlite-integration/sqlite-integration.php\";s:11:\"new_version\";s:5:\"1.8.1\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/sqlite-integration/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/sqlite-integration.1.8.1.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:70:\"https://ps.w.org/sqlite-integration/assets/icon-128x128.jpg?rev=972861\";s:2:\"2x\";s:70:\"https://ps.w.org/sqlite-integration/assets/icon-256x256.jpg?rev=972861\";s:7:\"default\";s:70:\"https://ps.w.org/sqlite-integration/assets/icon-256x256.jpg?rev=972861\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:33:\"unplug-jetpack/unplug-jetpack.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/unplug-jetpack\";s:4:\"slug\";s:14:\"unplug-jetpack\";s:6:\"plugin\";s:33:\"unplug-jetpack/unplug-jetpack.php\";s:11:\"new_version\";s:5:\"0.1.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/unplug-jetpack/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/unplug-jetpack.zip\";s:5:\"icons\";a:0:{}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:19:\"weforms/weforms.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/weforms\";s:4:\"slug\";s:7:\"weforms\";s:6:\"plugin\";s:19:\"weforms/weforms.php\";s:11:\"new_version\";s:5:\"1.2.4\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/weforms/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/weforms.1.2.4.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:60:\"https://ps.w.org/weforms/assets/icon-128x128.png?rev=1709491\";s:2:\"2x\";s:60:\"https://ps.w.org/weforms/assets/icon-256x256.png?rev=1709491\";s:7:\"default\";s:60:\"https://ps.w.org/weforms/assets/icon-256x256.png?rev=1709491\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:63:\"https://ps.w.org/weforms/assets/banner-1544x500.png?rev=1709491\";s:2:\"1x\";s:62:\"https://ps.w.org/weforms/assets/banner-772x250.png?rev=1709491\";s:7:\"default\";s:63:\"https://ps.w.org/weforms/assets/banner-1544x500.png?rev=1709491\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.2.6\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.2.6.zip\";s:5:\"icons\";a:3:{s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=1440831\";s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";s:7:\"default\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=1440831\";}s:7:\"banners\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=1629184\";s:7:\"default\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=1629184\";}s:11:\"banners_rtl\";a:0:{}}}}", "no");
INSERT INTO `wp_options` VALUES("681", "_site_transient_update_themes", "O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1514571308;s:7:\"checked\";a:9:{s:7:\"auberge\";s:5:\"2.3.0\";s:18:\"classtheme20140625\";s:0:\"\";s:14:\"dark-shop-lite\";s:5:\"1.2.5\";s:15:\"dark_shop_child\";s:0:\"\";s:4:\"dyad\";s:6:\"1.0.10\";s:7:\"masonic\";s:5:\"1.2.8\";s:13:\"masonic_child\";s:0:\"\";s:10:\"storefront\";s:5:\"2.2.5\";s:13:\"twentyfifteen\";s:3:\"1.9\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}", "no");
INSERT INTO `wp_options` VALUES("682", "_site_transient_timeout_browser_c34fbe0893b504a8f7ca5b8e754e60a9", "1515176313", "no");
INSERT INTO `wp_options` VALUES("683", "_site_transient_browser_c34fbe0893b504a8f7ca5b8e754e60a9", "a:10:{s:4:\"name\";s:14:\"Microsoft Edge\";s:7:\"version\";s:8:\"16.16299\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:0:\"\";s:7:\"img_src\";s:0:\"\";s:11:\"img_src_ssl\";s:0:\"\";s:15:\"current_version\";s:8:\"15.15063\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}", "no");
INSERT INTO `wp_options` VALUES("684", "duplicator_package_active", "O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-12-29 18:18:48\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:5:\"4.9.1\";s:9:\"VersionDB\";s:3:\"5.5\";s:10:\"VersionPHP\";s:5:\"7.1.9\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:19:\"20171229_coffeehall\";s:4:\"Hash\";s:32:\"0cc1287ae29833717748171229181848\";s:8:\"NameHash\";s:52:\"20171229_coffeehall_0cc1287ae29833717748171229181848\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:61:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-snapshots/tmp\";s:8:\"StoreURL\";s:35:\"http://localhost:8000/wp-snapshots/\";s:8:\"ScanFile\";s:62:\"20171229_coffeehall_0cc1287ae29833717748171229181848_scan.json\";s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";O:11:\"DUP_Archive\":18:{s:10:\"FilterDirs\";s:0:\"\";s:11:\"FilterFiles\";s:0:\"\";s:10:\"FilterExts\";s:0:\"\";s:13:\"FilterDirsAll\";a:0:{}s:14:\"FilterFilesAll\";a:0:{}s:13:\"FilterExtsAll\";a:0:{}s:8:\"FilterOn\";i:0;s:12:\"ExportOnlyDB\";i:0;s:4:\"File\";N;s:6:\"Format\";s:3:\"ZIP\";s:7:\"PackDir\";s:44:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www\";s:4:\"Size\";i:0;s:4:\"Dirs\";a:0:{}s:5:\"Files\";a:0:{}s:10:\"FilterInfo\";O:23:\"DUP_Archive_Filter_Info\":8:{s:4:\"Dirs\";O:34:\"DUP_Archive_Filter_Scope_Directory\":4:{s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:5:\"Files\";O:29:\"DUP_Archive_Filter_Scope_File\":5:{s:4:\"Size\";a:0:{}s:7:\"Warning\";a:0:{}s:10:\"Unreadable\";a:0:{}s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:4:\"Exts\";O:29:\"DUP_Archive_Filter_Scope_Base\":2:{s:4:\"Core\";a:0:{}s:8:\"Instance\";a:0:{}}s:9:\"UDirCount\";i:0;s:10:\"UFileCount\";i:0;s:9:\"UExtCount\";i:0;s:8:\"TreeSize\";a:0:{}s:11:\"TreeWarning\";a:0:{}}s:10:\"\0*\0Package\";O:11:\"DUP_Package\":23:{s:7:\"Created\";s:19:\"2017-12-29 18:18:48\";s:7:\"Version\";s:6:\"1.2.30\";s:9:\"VersionWP\";s:5:\"4.9.1\";s:9:\"VersionDB\";s:3:\"5.5\";s:10:\"VersionPHP\";s:5:\"7.1.9\";s:9:\"VersionOS\";s:5:\"WINNT\";s:2:\"ID\";N;s:4:\"Name\";s:19:\"20171229_coffeehall\";s:4:\"Hash\";s:32:\"0cc1287ae29833717748171229181848\";s:8:\"NameHash\";s:52:\"20171229_coffeehall_0cc1287ae29833717748171229181848\";s:4:\"Type\";i:0;s:5:\"Notes\";s:0:\"\";s:9:\"StorePath\";s:61:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-snapshots/tmp\";s:8:\"StoreURL\";s:35:\"http://localhost:8000/wp-snapshots/\";s:8:\"ScanFile\";N;s:7:\"Runtime\";N;s:7:\"ExeSize\";N;s:7:\"ZipSize\";N;s:6:\"Status\";N;s:6:\"WPUser\";N;s:7:\"Archive\";r:22;s:9:\"Installer\";O:13:\"DUP_Installer\":7:{s:4:\"File\";N;s:4:\"Size\";i:0;s:10:\"OptsDBHost\";s:0:\"\";s:10:\"OptsDBPort\";s:0:\"\";s:10:\"OptsDBName\";s:0:\"\";s:10:\"OptsDBUser\";s:0:\"\";s:10:\"\0*\0Package\";r:57;}s:8:\"Database\";O:12:\"DUP_Database\":13:{s:4:\"Type\";s:5:\"MySQL\";s:4:\"Size\";N;s:4:\"File\";N;s:4:\"Path\";N;s:12:\"FilterTables\";s:0:\"\";s:8:\"FilterOn\";i:0;s:4:\"Name\";N;s:10:\"Compatible\";s:0:\"\";s:8:\"Comments\";s:0:\"\";s:10:\"\0*\0Package\";r:57;s:25:\"\0DUP_Database\0dbStorePath\";N;s:23:\"\0DUP_Database\0EOFMarker\";s:0:\"\";s:26:\"\0DUP_Database\0networkFlush\";b:0;}}s:29:\"\0DUP_Archive\0tmpFilterDirsAll\";a:0:{}s:24:\"\0DUP_Archive\0wpCorePaths\";a:6:{i:0;s:53:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-admin\";i:1;s:63:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-content/uploads\";i:2;s:65:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-content/languages\";i:3;s:63:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-content/plugins\";i:4;s:62:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-content/themes\";i:5;s:56:\"C:/Users/Ebarber5969/Desktop/Coffee Hall/www/wp-includes\";}}s:9:\"Installer\";r:79;s:8:\"Database\";r:87;}", "yes");

/* INSERT TABLE DATA: wp_custom_getcoffeecatalogdefaults */
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("1", "100 grams", "Robusta Coffee");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("2", "100 grams", "Arabica Coffee");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("3", "100 grams", "Liberica Coffee");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("4", "100 grams", "Dewevrei Coffee");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("5", "100 grams", "Ekstselsa Coffee");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("6", "100 grams", "Кolambia Coffee");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("7", "100 grams", "Nicaragua Maraggit");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("8", "100 grams", "Arabika Harar");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("9", "100 grams", "Southern Peaberry");
INSERT INTO `wp_custom_getcoffeecatalogdefaults` VALUES("10", "100 grams", "Boring Old Regular");

/* INSERT TABLE DATA: wp_custom_getcoffeecatalog */
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("1", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "These beans are of a lower grade than Arabica, and are typically grown at lower elevations. They are easier to grow and maintain, and they are also more disease resistant and produce a higher yield.  Robusta beans have more of an astringent flavor and contain a higher amount of caffeine.", "Robusta Coffee ");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("2", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "These are the higher quality beans and are referred to as gourmet coffee. They have half the amount of caffeine as Robusta and have more pleasing flavours and aromatic properties. Most Arabica bean varieties are name after their country or region in which they are found, or originated from. ", "Arabica Coffee ");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("3", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "
The official name of the plant is Coffea Dewevrei. Another kind of coffee. Excelsa coffee - or Coffee High - is even less known than Libereca. Trees of this species reach a height of 20 m. This kind of coffee has no economic significance.", "Liberica Coffee ");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("4", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "The official name of the plant is the Coffee Tree of Liberia (Coffea Liberica). Liberian coffee comes from West Africa. Currently, this species is grown almost all countries of the African continent, as well as Shri- Lanka, Indonesia, the Philippines and others.", "Dewevrei Coffee ");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("5", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "Excelsa coffee - or Coffee High - is even less known than Libereca. Trees of this species reach a height of 20 m. This kind of coffee has no economic significance.", "Ekstselsa Coffee ");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("6", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "
The highest grade is supremo, with its processing the most advanced technologies are used, the grains themselves are very large and even.", "Кolambia Coffee ");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("7", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "
Rich and expressive, the grains are large, even.", "Nicaragua Maraggit");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("8", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "
Ethiopian Arabica Harar reveals itself gradually, always has a witney taste and some tartness. And additionally, depending on the weather conditions, the place of cultivation and storage, can enjoy the aromas of oriental fruits and spices.", "Arabika Harar");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("9", "http://s019.radikal.ru/i615/1712/3e/869ef5caf34d.jpg", "
Alpine coffee, smelling of apricot, almonds and brandy, turning into jasmine while cooling down. The aroma is very bright, memorable. In addition, worthy grades of Kilimanjaro, Moshi.", "Southern Peaberry");
INSERT INTO `wp_custom_getcoffeecatalog` VALUES("10", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzCmLnSed2T0f5Y5KzUJ-cs2TR0_mESgXz3rzg1AtuE7EirjEA", "Customize your coffee from scratch.", "Custom");

/* INSERT TABLE DATA: sqlite_sequence */
INSERT INTO `sqlite_sequence` VALUES("wp_options", "684");
INSERT INTO `sqlite_sequence` VALUES("wp_users", "8");
INSERT INTO `sqlite_sequence` VALUES("wp_usermeta", "171");
INSERT INTO `sqlite_sequence` VALUES("wp_terms", "2");
INSERT INTO `sqlite_sequence` VALUES("wp_term_taxonomy", "2");
INSERT INTO `sqlite_sequence` VALUES("wp_posts", "203");
INSERT INTO `sqlite_sequence` VALUES("wp_comments", "1");
INSERT INTO `sqlite_sequence` VALUES("wp_postmeta", "507");
INSERT INTO `sqlite_sequence` VALUES("wp_weforms_entries", "5");
INSERT INTO `sqlite_sequence` VALUES("wp_weforms_entrymeta", "15");
INSERT INTO `sqlite_sequence` VALUES("wp_custom_getcoffeecatalog", "10");

SET FOREIGN_KEY_CHECKS = 1; 

/* Duplicator WordPress Timestamp: 2017-12-29 18:19:03*/
/* DUPLICATOR_MYSQLDUMP_EOF */
